//
//  AppUrlDefine.h
//  ESTicket
//
//  Created by wuguanghui on 2018/7/11.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#ifndef AppUrlDefine_h
#define AppUrlDefine_h

#endif /* AppUrlDefine_h */

#define kWxKey @"wxcb27bf26686988f0"
#define kWxAppSecret @"9cd6ad840155d9a145933a801d94e9a3"
#define kScheme @"gallop"
#define kAppName @"飞驰体育"
#define kAppPinYin @"FeiChiTiYu"
#define kUmengPushKey @"5db006734ca357b8d2000398"


#define AppFrom @"ios_bifen"
#define SandBox 0
#define wsHostUrl @"wss://live.feichitiyu.com"
#define wsChatHostUrl @"wss://chat.feichitiyu.com"
#define HostUrl @"https://gallop.feichitiyu.com"

#define H5Domin @"http://hybird.feichitiyu.com/"
#define MatchLiveUrl @"https://hybird.feichitiyu.com/cartoon.html?matchId=%@&_t=%@&from=app"
#define AgainstPlanUrl @"https://hybird.feichitiyu.com/battle.html?leagueId=%@&season=%@&_t=%@&from=app"
#define CommunityPostUrl @"https://hybird.feichitiyu.com/community.html#/editor"


//#ifdef DEBUG
///************测试环境*********/
//#define AppFrom @"ios_apple"
//#define SandBox 1
//#define wsHostUrl @"ws://live.feichihao.com"
//#define wsChatHostUrl @"ws://chat.feichihao.com"
//#define HostUrl @"http://gallop.5000yuant.com"
//
//#define H5Domin @"http://hybird.5000yuant.com/"
//#define MatchLiveUrl @"http://hybird.5000yuant.com/cartoon.html?matchId=%@&_t=%@&from=app"
//#define AgainstPlanUrl @"http://hybird.5000yuant.com/battle.html?leagueId=%@&season=%@&_t=%@&from=app"
//#define CommunityPostUrl @"http://hybird.5000yuant.com/community.html#/editor"
//
//#else
///************正式环境*********/
//#define AppFrom @"ios_bifen"
//#define SandBox 0
//#define wsHostUrl @"wss://live.feichitiyu.com"
//#define wsChatHostUrl @"wss://chat.feichitiyu.com"
//#define HostUrl @"https://gallop.feichitiyu.com"
//
//#define H5Domin @"http://hybird.feichitiyu.com/"
//#define MatchLiveUrl @"https://hybird.feichitiyu.com/cartoon.html?matchId=%@&_t=%@&from=app"
//#define AgainstPlanUrl @"https://hybird.feichitiyu.com/battle.html?leagueId=%@&season=%@&_t=%@&from=app"
//#define CommunityPostUrl @"https://hybird.feichitiyu.com/community.html#/editor"
//
//#endif
