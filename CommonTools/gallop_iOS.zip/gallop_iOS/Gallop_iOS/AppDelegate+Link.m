//
//  AppDelegate+Link.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/19.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "AppDelegate+Link.h"
#import "WTCContentViewController.h"
#import "PaperContentViewController.h"
#import "CommunityPaperContentViewController.h"
#import "ExpertDetailViewController.h"
#import "CYPlanDetailViewController.h"

@implementation AppDelegate (Link)
-(void)applicationBusinessProcessWithURL:(NSURL *)url{
	NSMutableDictionary *dic =[self turnDictionaryparametersWithURL:url];
	
	[self jumpTagetWithParamer:dic];
	
}

-(NSMutableDictionary *)turnDictionaryparametersWithURL:(NSURL *)url{
	
	NSString *urlstring = [url.absoluteString substringFromIndex:9];;
	
	NSArray *array = [urlstring componentsSeparatedByString:@"?"];
	
	NSString *paramerStr = [array lastObject];
	
	NSArray *paramerArr = [paramerStr componentsSeparatedByString:@"&"];
	
	NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
	
	for (NSString * string in paramerArr) {
		NSArray *paramersArr = [string componentsSeparatedByString:@"="];
		[dic setObject:[paramersArr lastObject] forKey:[paramersArr firstObject]];
	}
	
	return dic;
}

-(void)jumpTagetWithParamer:(NSMutableDictionary *)paramer{
	NSString * type = [paramer objectForKey:@"type"];
	if ([type isEqualToString:@"webView"]) {
		NSString * url = [paramer objectForKey:@"url"];
		WTCContentViewController*vc = [WTCContentViewController new];
		vc.url = [url urlDecodedString];
		vc.contentType = WTCContentTypeOther;
		[vc setHidesBottomBarWhenPushed:YES];
		UITabBarController *tab = ((UITabBarController *)self.window.rootViewController);
		[tab.selectedViewController pushViewController:vc animated:YES];
	}
	
	if ([type isEqualToString:@"paper"]) {
		PaperContentViewController*vc = [PaperContentViewController new];
		ESBanner *banner = [[ESBanner alloc] init];
		banner.textFormat = @"1";
		banner.textId = [paramer objectForKey:@"textId"];
		vc.banerModel = banner;
		vc.hidesBottomBarWhenPushed = YES;
		UITabBarController *tab = ((UITabBarController *)self.window.rootViewController);
		[tab.selectedViewController pushViewController:vc animated:YES];
	}
	
	if ([type isEqualToString:@"post"]) {
		//帖子
		CommunityPaperContentViewController*vc = [[CommunityPaperContentViewController alloc] init];
		vc.postId = [[paramer objectForKey:@"postId"] integerValue];
		vc.hidesBottomBarWhenPushed = YES;
		UITabBarController *tab = ((UITabBarController *)self.window.rootViewController);
		[tab.selectedViewController pushViewController:vc animated:YES];
	}
	
	if ([type isEqualToString:@"expert"]) {
		//专家主页
		ExpertDetailViewController*vc = [ExpertDetailViewController new];
		vc.expertId = [paramer objectForKey:@"expertId"];
		vc.hidesBottomBarWhenPushed = YES;
		UITabBarController *tab = ((UITabBarController *)self.window.rootViewController);
		[tab.selectedViewController pushViewController:vc animated:YES];
	}
	
	if ([type isEqualToString:@"plan"]) {
		//专家主页
        CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
		vc.planId = [[paramer objectForKey:@"planId"] integerValue];
		vc.hidesBottomBarWhenPushed = YES;
		UITabBarController *tab = ((UITabBarController *)self.window.rootViewController);
		[tab.selectedViewController pushViewController:vc animated:YES];
	}
}

@end
