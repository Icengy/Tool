//
//  AppDelegate.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/9.
//  Copyright © 2019 homosum. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "WTCTabBarViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic,strong) WTCTabBarViewController *matchTabBarVC;
@end

