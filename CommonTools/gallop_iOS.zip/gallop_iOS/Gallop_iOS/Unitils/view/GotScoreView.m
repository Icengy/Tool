//
//  GotScoreView.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/26.
//  Copyright © 2019 homosum. All rights reserved.
//
#define ColorGotScore [UIColor colorWithHexString:@"#FFDF25"];

#import "GotScoreView.h"
#import "MatchTCPMessageModel.h"

static int _gcdIdx = 0;

@interface GotScoreSegment : UISegmentedControl

@end

@implementation GotScoreSegment

- (instancetype)initWithCoder:(NSCoder *)coder {
    if (self = [super initWithCoder:coder]) {
        [self configProperty];
    }return self;
}

- (void)configProperty {
    
    [self setTitleTextAttributes:@{NSForegroundColorAttributeName: Color99, NSFontAttributeName: GetFont(10.0)} forState:UIControlStateNormal];
    [self setTitleTextAttributes:@{NSForegroundColorAttributeName: UIColor.whiteColor, NSFontAttributeName: GetFont(10.0)} forState:UIControlStateSelected];
    
    [self setBackgroundImage:[UIImage imageWithColor:UIColor.whiteColor] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [self setBackgroundImage:[UIImage imageWithColor:ColorMatchHost] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    self.layer.cornerRadius = 2.0;
    self.layer.borderColor = ColorMatchHost.CGColor;
    self.layer.borderWidth = 1.0;
    self.layer.masksToBounds = YES;
}

@end

@interface GotScoreView() <UIGestureRecognizerDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *mark;

@property (nonatomic,weak) IBOutlet UILabel*hostNameL;
@property (nonatomic,weak) IBOutlet UILabel*guestNameL;

@property (nonatomic,weak) IBOutlet UILabel*hostL;
@property (nonatomic,weak) IBOutlet UILabel*guestL;
@property (nonatomic,weak) IBOutlet UILabel*jinqiuL;
@property (nonatomic,weak) IBOutlet UILabel*timeL;

@property (nonatomic,weak) IBOutlet CYButton *toSettingBtn;

@property (weak, nonatomic) IBOutlet UILabel *tipsLabel;
@property (weak, nonatomic) IBOutlet GotScoreSegment *segment;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottom_contraint;


@property (strong, nonatomic) dispatch_source_t  timer;

@end

@implementation GotScoreView

//- (id)initWithFrame:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//        self.backgroundColor = [UIColor clearColor];
//        [self setupView];
//
//    }
//    return self;
//}

- (void)awakeFromNib {
    [super awakeFromNib];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(remove)];
    tap.delegate = self;
    [self addGestureRecognizer:tap];
    
    self.frame = [UIApplication sharedApplication].keyWindow.bounds;
    self.bottom_contraint.constant = (75.0 + TabBarHeight);
    
    [self bringSubviewToFront:self.segment];
}

-(void)setModel:(MatchGoalMessageModel *)model {
    
    _model = model;
    
    self.timeL.text = [NSString stringWithFormat:@"%@’" ,@(model.goalTime).stringValue];
    
    self.hostNameL.text = [CommonUtils isEqualToNonNull:model.hostName replace:@"-"];
    self.hostL.text = @(model.hostScore).stringValue;
    
    self.guestNameL.text = [CommonUtils isEqualToNonNull:model.guestName replace:@"-"];
    self.guestL.text = @(model.guestScore).stringValue;
    
    if (model.hostGuest == 1) {
        self.hostL.textColor = ColorGotScore;
    } else {
        self.guestL.textColor = ColorGotScore;
    }
    
    self.segment.selectedSegmentIndex = model.followedOnly;
    
    dispatch_resume(self.timer);
}

- (IBAction)clickToSegment:(UISegmentedControl *)sender {
    
//    sender.selectedSegmentIndex = ;
    self.model.followedOnly = sender.selectedSegmentIndex;
    if (self.delegate && [self.delegate respondsToSelector:@selector(scoreView:clickToChooseWithModel:)]) {
        [self.delegate scoreView:self clickToChooseWithModel:self.model];
    }
}


- (IBAction)clickToSetting:(id)sender {
    [self remove];
    if (self.delegate && [self.delegate respondsToSelector:@selector(scoreView:clickToSetting:)]) {
        [self.delegate scoreView:self clickToSetting:sender];
    }
}

- (void)remove {
    _gcdIdx = 0;
    @weakify(self)
    dispatch_main_async_safe(^{
        @strongify(self)
        dispatch_source_cancel(self.timer);
        self.timer = nil;
        [self removeFromSuperview];
    });
}


#pragma mark - UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    CGPoint point = [touch locationInView:[touch view]];
    if (point.y > self.mark.y) return NO;
    return YES;
}

#pragma mark -
- (dispatch_source_t)timer {
    if (!_timer) {
        _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(0, 0));
        dispatch_source_set_timer(_timer, DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC, 0);
        dispatch_source_set_event_handler(_timer, ^{
            if (_gcdIdx == 5) {
                [self remove];
                return;
            }
            _gcdIdx ++;
        });
    }return _timer;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
