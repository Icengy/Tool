//
//  GotScoreView.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "CYView.h"

NS_ASSUME_NONNULL_BEGIN

@class GotScoreView;
@class MatchGoalMessageModel;
@protocol GotScoreDelegate <NSObject>

@optional

/// 选择提示范围
/// @param scoreView scoreView
/// @param model model
- (void)scoreView:(GotScoreView *)scoreView clickToChooseWithModel:(MatchGoalMessageModel *)model;

/// 前往设置
/// @param scoreView scoreView
/// @param sender sender
- (void)scoreView:(GotScoreView *)scoreView clickToSetting:(id)sender;

@end

@interface GotScoreView : CYCodeView

@property (nonatomic,weak) id <GotScoreDelegate> delegate;
@property (nonatomic, strong) MatchGoalMessageModel *model;

- (void)remove;

@end

NS_ASSUME_NONNULL_END
