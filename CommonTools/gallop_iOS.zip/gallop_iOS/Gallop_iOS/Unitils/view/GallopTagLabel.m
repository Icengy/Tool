//
//  GallopTagLabel.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/21.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "GallopTagLabel.h"

#define defaultInsets UIEdgeInsetsMake(2, 4, 2, 4)

@implementation CYLabel

- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines {
    
    CGRect rect = [super textRectForBounds:UIEdgeInsetsInsetRect(bounds, self.edgeInsets) limitedToNumberOfLines:numberOfLines];
    rect.origin.x -= self.edgeInsets.left;
    rect.origin.y -= self.edgeInsets.top;
    rect.size.width += (self.edgeInsets.left + self.edgeInsets.right);
    rect.size.height += (self.edgeInsets.top + self.edgeInsets.bottom);

    return rect;
}

- (void)drawTextInRect:(CGRect)rect {
    [super drawTextInRect:UIEdgeInsetsInsetRect(rect, self.edgeInsets)];
}

@end

@implementation GallopTagLabel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.edgeInsets = defaultInsets;
    self.textAlignment = NSTextAlignmentCenter;
    self.font = [UIFont addPingFangSCBold:10];
    
//    [self transform:5.0];
}

- (CGRect)textRectForBounds:(CGRect)bounds limitedToNumberOfLines:(NSInteger)numberOfLines {
    CGRect rect = [super textRectForBounds:bounds limitedToNumberOfLines:numberOfLines];
    
    if (rect.size.height < 18.0) { rect.size.height = 18.0;
    }
    CGFloat limitWidth = 18.0 *44.0/16.0;
    if (rect.size.width < limitWidth) {
        rect.size.width = limitWidth;
    }
    return rect;
}

- (void)transform:(CGFloat)c {
//    if (c != 0.0) {
//
//    }else {
//        [self transform:0];
//    }
    self.transform = CGAffineTransformIdentity;
    CGAffineTransform matrix = CGAffineTransformMake(1, 0, tanf((0.0-c) * (CGFloat)M_PI / 180), 1, 0, 0);
    self.transform = matrix;
}

- (void)setTransformDegrees:(CGFloat)transformDegrees {
    _transformDegrees = transformDegrees;
    
    [self transform:_transformDegrees];
}

@end

@implementation GallopTagNonBgLabel

- (void)awakeFromNib {
    [super awakeFromNib];
//    self.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:9];
    [self sizeToFit];
    self.layer.borderWidth = 1;
    self.layer.borderColor = self.textColor.CGColor;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self addRoundedCorners:(UIRectCornerAllCorners) withRadii:self.height/2];
}

@end


@implementation GallopTagBgLabel

- (void)awakeFromNib {
    [super awakeFromNib];
    
//    self.font = [UIFont fontWithName:@"PingFangSC-Semibold" size:9];
    [self sizeToFit];
//    self.backgroundColor = RGBCOLORV(0xF4F4F4);
    self.corners = UIRectCornerAllCorners;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self addRoundedCorners:self.corners withRadii:self.height/2];
}

- (void)setCorners:(UIRectCorner)corners {
    _corners = corners;
    
    [self layoutIfNeeded];
}

@end

@implementation GallopTagLeagueLabel

- (void)awakeFromNib {
    [super awakeFromNib];
    
//    self.font = [UIFont fontWithName:@"PingFangSC-Regular" size:9];
    [self sizeToFit];
//    self.backgroundColor = [RGBCOLORV(0xDE3C31) colorWithAlphaComponent:0.1];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self addRoundedCorners:(UIRectCornerAllCorners) withRadii:self.height/2];
}

- (void)setTagTintColor:(UIColor *)tagTintColor {
    _tagTintColor = tagTintColor;
    
    self.backgroundColor = [_tagTintColor colorWithAlphaComponent:0.1];
    self.textColor = _tagTintColor;
    
    [self setNeedsLayout];
}

@end
