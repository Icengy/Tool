//
//  TimeUnitily.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/7.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TimeUnitily : NSObject

#pragma mark - 比较时间差值，不用考虑时区 返回值为“xx前/MM-dd hh-mm/""”
/// 时间戳与当前时间差值
/// @param stamp 时间戳
+ (NSString *)stampDateFormatForTimeStamp:(NSString *)stamp;

/// 格式时间与当前时间差值，格式为yyyy-MM-dd HH:mm:ss
/// @param timeStr 格式时间
+ (NSString *)formatDateForTimeStr:(NSString *)timeStr;

/// 格式时间与当前时间差值，指定格式
/// @param timeStr 格式时间
/// @param timeFormat 指定的时间格式
+ (NSString *)formatDateForTimeStr:(NSString *)timeStr wihtFormat:(NSString *)timeFormat;

#pragma mark - 格式转换
/// 将指定的时间转换格式
/// @param timeStr 指定时间
/// @param from 原有格式
/// @param to 预期格式
+ (NSString *)dateChangeWith:(NSString *)timeStr fromFormat:(NSString *)from toFormat:(NSString *)to;

@end

NS_ASSUME_NONNULL_END
