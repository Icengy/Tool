//
//  GallopNavigationBar.h
//  Gallop_iOS
//
//  Created by lcy on 2021/8/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol GallopNavigationBarDelegate <NSObject>

@optional
- (BOOL)navigationBar:(UINavigationBar *)navigationBar shouldReceiveTouch:(UITouch *)touch;
- (void)navigationBar:(UINavigationBar *)navigationBar didTouch:(UITouch *)touch;

@end

@interface GallopNavigationBar : UINavigationBar

@property(weak, nonatomic) id <GallopNavigationBarDelegate> gallopDelegate;

@end

NS_ASSUME_NONNULL_END
