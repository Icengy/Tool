//
//  GallopTabbar.h
//  Gallop_iOS
//
//  Created by lcy on 2021/4/29.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GallopTabbar : UITabBar

@end

NS_ASSUME_NONNULL_END
