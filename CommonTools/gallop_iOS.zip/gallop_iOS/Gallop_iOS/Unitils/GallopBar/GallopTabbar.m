//
//  GallopTabbar.m
//  Gallop_iOS
//
//  Created by lcy on 2021/4/29.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "GallopTabbar.h"

@implementation GallopTabbar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)layoutSubviews {
    [super layoutSubviews];
    
//    WTCLog(@"%@ - %@",self.class,self.subviews);
//    [self.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        if ([obj isKindOfClass:NSClassFromString(@"_UIBarBackground")]) {
//            WTCLog(@"enumerateObjectsUsingBlock :%@ -- %@",obj.subviews ,obj);
//            [obj.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj1, NSUInteger idx1, BOOL * _Nonnull stop1) {
//                if ([obj1 isKindOfClass:[UIImageView class]]) {
//                    obj1.contentMode = UIViewContentModeScaleToFill;
//                }
//            }];
//        }
//    }];
    
    [self.items enumerateObjectsUsingBlock:^(UITabBarItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.imageInsets = UIEdgeInsetsMake(-12, 0, 0, 0);
    }];
}



@end
