//
//  GallopNavigationBar.m
//  Gallop_iOS
//
//  Created by lcy on 2021/8/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "GallopNavigationBar.h"

@implementation GallopNavigationBar

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)init {
    if (self = [super init]) {
        [self setup];
    }return self;
}

- (void)setup {
    self.tintColor = ColorMainNormalBlack;
    UIImage *backButtonImage = [[[UIImage imageNamed:@"nav_return_black"] scaleToSize:CGSizeMake(22.0, 22.0)] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *barApp = [UINavigationBarAppearance new];
        [barApp setBackIndicatorImage:backButtonImage transitionMaskImage:backButtonImage];
        
        self.standardAppearance = barApp;
        self.scrollEdgeAppearance = barApp;
    }else {
        self.backIndicatorTransitionMaskImage = backButtonImage;
        self.backIndicatorImage = backButtonImage;
    }
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    if (self.gallopDelegate && [self.gallopDelegate respondsToSelector:@selector(navigationBar:shouldReceiveTouch:)]) {
        UITouch * touch = [touches anyObject];
        BOOL receive = [self.gallopDelegate navigationBar:self shouldReceiveTouch:touch];
        if (receive) {
            if ([self.gallopDelegate respondsToSelector:@selector(navigationBar:didTouch:)]) {
                [self.gallopDelegate navigationBar:self didTouch:touch];
            }
        }
    }
    
}

@end
