//
//  CYTabTitleBar.m
//  ArtMedia2
//
//  Created by icnengy on 2020/6/9.
//  Copyright © 2020 翁磊. All rights reserved.
//

#import "CYTabTitleBar.h"

@interface CYTabTitleBar () <AMSegmentDelegate>

@property (weak, nonatomic) IBOutlet AMSegment *segment;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *right;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *left;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *top;

@end

@implementation CYTabTitleBar

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    _segment.delegate = self;
    _segment.segStyle = AMSegmentStyleProgressView;
}

//- (void)layoutSubviews {
//    [super layoutSubviews];
////    [_segment mas_remakeConstraints:^(MASConstraintMaker *make) {
////        make.edges.offset(0);
////    }];
//}

- (void)setDataArray:(NSArray *)dataArray {
    _dataArray = dataArray;
    _segment.items = _dataArray;
}

- (void)setBadges:(NSArray *)badges {
    _badges = badges;
    _segment.badges = _badges;
}

- (void)setCurrentIndex:(NSInteger)currentIndex {
    _currentIndex = currentIndex;
    _segment.selectedSegmentIndex = _currentIndex;
}

- (void)setStyle:(AMSegmentStyle)style {
    _style = style;
    _segment.segStyle = _style;
    
}

//- (void)setFrame:(CGRect)frame {
//    if (!UIEdgeInsetsEqualToEdgeInsets(_insets, UIEdgeInsetsZero)) {
//        [self addRoundedCorners:(UIRectCornerTopLeft | UIRectCornerTopRight) withRadii:8.0f];
//    }else {
//        [self addRoundedCorners:UIRectCornerAllCorners withRadii:0.0];
//    }
//    frame.origin.x += _insets.left;
//    frame.size.width -= (_insets.left+_insets.right);
//    [super setFrame:frame];
//}

- (void)setInsets:(UIEdgeInsets)insets {
    _insets = insets;
    if (!UIEdgeInsetsEqualToEdgeInsets(_insets, UIEdgeInsetsZero)) {
        self.top.constant = _insets.top;
        self.bottom.constant = _insets.bottom;
        self.left.constant = _insets.left;
        self.right.constant = _insets.right;
        [self setNeedsLayout];
    }
}

- (void)setItemBackgroundColor:(UIColor *)itemBackgroundColor {
    _itemBackgroundColor = itemBackgroundColor;
    self.segment.itemBackgroundColor = _itemBackgroundColor;
}

- (void)setSliderColor:(UIColor *)sliderColor {
    _sliderColor = sliderColor;
    self.segment.sliderColor = sliderColor;
}

- (void)setSliderWidth:(CGFloat)sliderWidth {
    _sliderWidth = sliderWidth;
    self.segment.sliderWidth = _sliderWidth;
}

- (void)setSliderHeight:(CGFloat)sliderHeight {
    _sliderHeight = sliderHeight;
    self.segment.sliderHeight = _sliderHeight;
}

- (void)setNormalItemTextAttributes:(NSDictionary<NSAttributedStringKey,id> *)normalItemTextAttributes {
    _normalItemTextAttributes = normalItemTextAttributes;
    self.segment.normalItemTextAttributes = _normalItemTextAttributes;
}

- (void)setSelectedItemTextAttributes:(NSDictionary<NSAttributedStringKey,id> *)selectedItemTextAttributes {
    _selectedItemTextAttributes = selectedItemTextAttributes;
    self.segment.selectedItemTextAttributes = _selectedItemTextAttributes;
}

#pragma mark -
- (void)segment:(AMSegment *)seg switchSegmentIndex:(NSInteger)index {
    _currentIndex = index;
    if (_clickIndexBlock) _clickIndexBlock(_currentIndex);
}

@end
