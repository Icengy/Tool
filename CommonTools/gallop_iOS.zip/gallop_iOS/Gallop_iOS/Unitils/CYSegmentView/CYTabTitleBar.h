//
//  CYTabTitleBar.h
//  ArtMedia2
//
//  Created by icnengy on 2020/6/9.
//  Copyright © 2020 翁磊. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AMSegment.h"

NS_ASSUME_NONNULL_BEGIN

@interface CYTabTitleBar : UIView

@property (assign, nonatomic) AMSegmentStyle style;
@property (assign, nonatomic) NSInteger currentIndex;
@property (strong, nonatomic) NSArray *dataArray;
@property (strong, nonatomic) NSArray *badges;
@property(nonatomic,copy) void(^clickIndexBlock)(NSInteger index);

@property (nonatomic ,assign) UIEdgeInsets insets;
@property (nonatomic, strong) UIColor *itemBackgroundColor;
@property (nonatomic, strong) UIColor *sliderColor;
@property (nonatomic, assign) CGFloat sliderWidth;
@property (nonatomic, assign) CGFloat sliderHeight;

@property (nonatomic, strong, nonnull) NSDictionary <NSAttributedStringKey,id> * normalItemTextAttributes;
@property (nonatomic, strong, nonnull) NSDictionary <NSAttributedStringKey,id>*selectedItemTextAttributes;


@end

NS_ASSUME_NONNULL_END
