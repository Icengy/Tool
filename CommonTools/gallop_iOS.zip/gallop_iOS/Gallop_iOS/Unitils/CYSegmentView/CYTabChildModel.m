//
//  CYTabChildModel.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/1.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYTabChildModel.h"

@implementation CYTabChildModel

@end
