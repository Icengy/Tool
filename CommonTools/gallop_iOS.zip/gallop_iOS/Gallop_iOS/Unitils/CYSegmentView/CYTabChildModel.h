//
//  CYTabChildModel.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/1.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CYBaseItemViewController;

NS_ASSUME_NONNULL_BEGIN

@interface CYTabChildModel : NSObject

@property (nonatomic ,assign) NSInteger field;
@property (nonatomic ,copy) NSString *childTitle;
@property (nonatomic ,strong) CYBaseItemViewController *childViewController;

@end

NS_ASSUME_NONNULL_END
