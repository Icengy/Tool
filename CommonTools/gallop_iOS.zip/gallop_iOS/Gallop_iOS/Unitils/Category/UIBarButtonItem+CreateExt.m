//
//  UIBarButtonItem+CreateExt.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/31.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "UIBarButtonItem+CreateExt.h"

#import "CYButton.h"

@implementation UIBarButtonItem (CreateExt)

+ (UIBarButtonItem *)createPostionBarItemWithTitle:(NSString *)title
                                        titleColor:(UIColor *)titleColor
                               horizontalAlignment:(CYBarButtonItemPosition)postion
                                            target:(id)target
                                            action:(SEL)action {
    UIControlContentHorizontalAlignment alignment = UIControlContentHorizontalAlignmentCenter;
    switch (postion) {
        case CYBarButtonItemPositionLeft:
            alignment = UIControlContentHorizontalAlignmentLeft;
            break;
        case CYBarButtonItemPositionRight:
            alignment = UIControlContentHorizontalAlignmentRight;
            break;
            
        default:
            break;
    }
    return [self createBarItemWithTitle:title
                             titleColor:titleColor
                            normalImage:nil
                           withHightImg:nil
                    horizontalAlignment:alignment
                                 target:target
                                 action:action];
}

+ (UIBarButtonItem *)createBarItemWithTitle:(NSString *)title
                                 titleColor:(UIColor *)titleColor
                                     target:(id)target
                                     action:(SEL)action {
    
    return [self createPostionBarItemWithTitle:title
                                    titleColor:titleColor
                           horizontalAlignment:CYBarButtonItemPositionDefatult
                                        target:target
                                        action:action];
}

+ (UIBarButtonItem *)createBarItemWithImage:(NSString *)normalImageName
                               withHightImg:(NSString *)heightedImageName
                                     target:(id)target
                                     action:(SEL)action {
    
    return [self createPostionBarItemWithImage:normalImageName
                                  withHightImg:heightedImageName
                           horizontalAlignment:CYBarButtonItemPositionDefatult
                                        target:target
                                        action:action];
}

+ (UIBarButtonItem *)createBackBarItemWithImage:(NSString *)normalImageName
                               withHightImg:(NSString *)heightedImageName
                                     target:(id)target
                                     action:(SEL)action {
    
    return [self createPostionBarItemWithImage:normalImageName
                                  withHightImg:heightedImageName
                           horizontalAlignment:CYBarButtonItemPositionLeft
                                        target:target
                                        action:action];
}


+ (UIBarButtonItem *)createPostionBarItemWithImage:(NSString *)normalImageName
                                      withHightImg:(NSString *)heightedImageName
                               horizontalAlignment:(CYBarButtonItemPosition)postion
                                            target:(id)target
                                            action:(SEL)action {
    
    UIControlContentHorizontalAlignment alignment = UIControlContentHorizontalAlignmentCenter;
    switch (postion) {
        case CYBarButtonItemPositionLeft:
            alignment = UIControlContentHorizontalAlignmentLeft;
            break;
        case CYBarButtonItemPositionRight:
            alignment = UIControlContentHorizontalAlignmentRight;
            break;
            
        default:
            break;
    }
    return [self createBarItemWithTitle:nil
                             titleColor:nil
                            normalImage:normalImageName
                           withHightImg:heightedImageName
                    horizontalAlignment:alignment
                                 target:target
                                 action:action];
}

#pragma mark - base
+ (UIBarButtonItem *)createBarItemWithTitle:(NSString *)title
                                 titleColor:(UIColor *)titleColor
                                normalImage:(NSString *)normalImageName
                               withHightImg:(NSString *)heightedImageName
                        horizontalAlignment:(UIControlContentHorizontalAlignment)horizontalAlignment
                                     target:(id)target
                                     action:(SEL)action {
    
    CYButton *button = [self createButtonWithTitle:title
                                        titleColor:titleColor
                                       normalImage:normalImageName
                                      withHightImg:heightedImageName
                               horizontalAlignment:horizontalAlignment
                                            target:target
                                            action:action];
    UIView *wrapView = [[UIView alloc] init];
    [wrapView addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(wrapView);
    }];
    UIBarButtonItem *barbutton = [[UIBarButtonItem alloc] initWithCustomView:wrapView];
    return barbutton;
}

+ (CYButton *)createButtonWithTitle:(NSString *)title
                         titleColor:(UIColor *)titleColor
                        normalImage:(NSString *)normalImageName
                       withHightImg:(NSString *)heightedImageName
                horizontalAlignment:(UIControlContentHorizontalAlignment)horizontalAlignment
                             target:(id)target
                             action:(SEL)action {
    
    CYButton *button = [CYButton buttonWithType:UIButtonTypeCustom];
    if ([CommonUtils isEqualToNonNull:title]) {
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitle:title forState:UIControlStateHighlighted];
    }
    
    [button setTitleColor:titleColor?:RGBCOLORV(0x282828) forState:UIControlStateNormal];
    [button setTitleColor:titleColor?:RGBCOLORV(0x282828) forState:UIControlStateHighlighted];
    
    if ([CommonUtils isEqualToNonNull:normalImageName]) {
        [button setImage:GetNavigationImage(normalImageName) forState:UIControlStateNormal];
        
        if ([CommonUtils isEqualToNonNull:heightedImageName]) {
            [button setImage:GetNavigationImage(heightedImageName) forState:UIControlStateHighlighted];
        }else
            [button setImage:GetNavigationImage(normalImageName) forState:UIControlStateHighlighted];
    }
    
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    
    if ([CommonUtils isEqualToNonNull:title]) {
        button.titleLabel.font = GetFont(14);
        CGSize size = [title sizeWithFont:button.titleLabel.font andMaxSize:CGSizeMake(CGFLOAT_MAX, 44.0) numberOfLines:1];
        button.titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        button.frame = CGRectMake(0, 0, (size.width > 44.0)?size.width:44.0, 44.0);
        horizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    }else
        button.frame = CGRectMake(0, 0, 44.0, 44.0);
    
    button.contentHorizontalAlignment = horizontalAlignment;
    
    return button;
}


@end
