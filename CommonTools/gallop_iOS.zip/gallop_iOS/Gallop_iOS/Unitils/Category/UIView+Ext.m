//
//  UIView+Ext.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/18.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "UIView+Ext.h"

//@implementation UIView (Ext)
//
//@end


@implementation UIView (Frame)
- (void)setSize:(CGSize)size
{
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

- (CGSize)size
{
    return self.frame.size;
}

- (void)setX:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)x
{
    return self.frame.origin.x;
}

- (void)setY:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)y
{
    return self.frame.origin.y;
}

- (void)setWidth:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)width
{
    return self.frame.size.width;
}

- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGFloat)height
{
    return self.frame.size.height;
}

- (void)setCenterX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)centerX
{
    return self.center.x;
}

- (void)setCenterY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)centerY
{
    return self.center.y;
}
@end


@implementation UIView (Corner)

///设置部分圆角(绝对布局)
- (void)addRoundedCorners:(UIRectCorner)corners
                withRadii:(CGFloat)radii {
    
    if (@available(iOS 11.0, *)) {
        self.layer.cornerRadius = radii;
        self.layer.maskedCorners = (CACornerMask)corners;
//        self.layer.masksToBounds = YES;
        self.layer.masksToBounds = radii != 0?YES:NO;
    } else {
        UIBezierPath* rounded = [UIBezierPath bezierPathWithRoundedRect:self.bounds byRoundingCorners:corners cornerRadii:CGSizeMake(radii, radii)];
        CAShapeLayer* shape = [[CAShapeLayer alloc] init];
        shape.frame = self.bounds;
        [shape setPath:rounded.CGPath];
        
        self.layer.mask = shape;
    }
}


///设置部分圆角、边框
- (void)addRoundedCorners:(UIRectCorner)corners
                withRadii:(CGFloat)radii
          withBorderColor:(UIColor *)borderColor
          withBorderWidth:(CGFloat)borderWitdh {
    
    CGRect borderRect = [self borderRectWithCorners:corners borderWidth:borderWitdh];
    if (@available(iOS 11.0, *)) {
        CALayer *layer = [CALayer layer];
        layer.frame = borderRect;
        layer.cornerRadius = radii;
        layer.maskedCorners = (CACornerMask)corners;
        layer.borderColor = borderColor.CGColor;
        layer.borderWidth = borderWitdh;
        layer.masksToBounds = radii != 0?YES:NO;
        
        [self.layer addSublayer:layer];
        
    } else {
        UIBezierPath* rounded = [UIBezierPath bezierPathWithRoundedRect:borderRect byRoundingCorners:corners cornerRadii:CGSizeMake(radii, radii)];
        CAShapeLayer* shape = [[CAShapeLayer alloc] init];
        shape.frame = borderRect;
        [shape setPath:rounded.CGPath];
        [shape setBorderColor:borderColor.CGColor];
        [shape setBorderWidth:borderWitdh];
        
        self.layer.mask = shape;
    }
}

/// 设置边框
/// @param corners 圆角位置
/// @param borderColor 边框颜色
/// @param borderWidth 边框宽度
- (void)addBorderWithCorners:(UIRectCorner)corners
             withBorderColor:(UIColor *)borderColor
             withBorderWidth:(CGFloat)borderWidth {
    
    CALayer *borderLayer = [CALayer layer];
    borderLayer.backgroundColor = borderColor.CGColor;
    borderLayer.frame = [self borderRectWithCorners:corners borderWidth:borderWidth];
    [self.layer addSublayer:borderLayer];
}

- (CGRect)borderRectWithCorners:(UIRectCorner)corners borderWidth:(CGFloat)borderWidth {
    
    CGRect rect = self.bounds, frame = self.frame;
    if (corners == UIRectCornerTopLeft + UIRectCornerTopRight) {
        WTCLog(@"borderRectWithCorners 上");
        rect = CGRectMake(0, 0, frame.size.width, borderWidth);
    }else if (corners == UIRectCornerTopRight + UIRectCornerBottomRight) {
        WTCLog(@"borderRectWithCorners 右");
        rect = CGRectMake(frame.size.width, 0, borderWidth, frame.size.height);
    }else if (corners == UIRectCornerBottomLeft + UIRectCornerBottomRight) {
        WTCLog(@"borderRectWithCorners 下");
        rect = CGRectMake(0, frame.size.height, frame.size.width, borderWidth);
    }else if (corners == UIRectCornerTopLeft + UIRectCornerBottomLeft) {
        WTCLog(@"borderRectWithCorners 左");
        rect = CGRectMake(0, 0, borderWidth, frame.size.height);
    }else {
        WTCLog(@"borderRectWithCorners 全");
    }
    return rect;
}

- (UIView *)subViewOfClassName:(NSString *)className {
    for (UIView* subView in self.subviews) {
        if ([NSStringFromClass(subView.class) isEqualToString:className]) {
            return subView;
        }
        
        UIView * resultFound = [subView subViewOfClassName:className];
        if (resultFound) {
            return resultFound;
        }
    }
    return nil;
}

@end


@implementation UIView (UIViewController)

- (UIViewController *)viewController {
    UIResponder *next = self.nextResponder;
    do {
        if ([next isKindOfClass:[UIViewController class]]) {
            return (UIViewController *)next;
        }
        next = next.nextResponder;
    } while (next);
    return nil;
}

@end


@implementation UIView (Designable)

- (void)setBorderWidth:(CGFloat)borderWidth
{
    if (borderWidth < 0) {
        return;
    }
    self.layer.borderWidth = borderWidth;
}

- (void)setBorderColor:(UIColor *)borderColor
{
    self.layer.borderColor = borderColor.CGColor;
}

- (void)setCornerRadius:(CGFloat)cornerRadius
{
    self.layer.cornerRadius = cornerRadius;
    self.layer.masksToBounds = YES;
}

- (CGFloat)borderWidth
{
    return self.borderWidth;
}

- (UIColor *)borderColor
{
    return self.borderColor;
}

- (CGFloat)cornerRadius
{
    return self.cornerRadius;
}

@end
