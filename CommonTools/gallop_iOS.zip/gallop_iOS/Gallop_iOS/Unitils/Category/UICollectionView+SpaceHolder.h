//
//  UICollectionView+SpaceHolder.h
//  Gallop_iOS
//
//  Created by lcy on 2021/8/24.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UICollectionView (SpaceHolder)

@property (nonatomic, strong) UIImageView *placeHolderView;
@property (nonatomic, strong) UILabel *placeHolderLabel;
@property (nonatomic, copy) NSString *placeHolderText;

@end

NS_ASSUME_NONNULL_END
