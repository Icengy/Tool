//
//  UIView+Ext.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/18.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//@interface UIView (Ext)
//
//@end

@interface UIView (Frame)

@property (nonatomic, assign) CGFloat x;
@property (nonatomic, assign) CGFloat y;
@property (nonatomic, assign) CGFloat centerX;
@property (nonatomic, assign) CGFloat centerY;
@property (nonatomic, assign) CGFloat width;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGSize size;

@end

@interface UIView (Corner)

/**
 *  设置部分圆角(绝对布局)
 *
 *  @param corners 需要设置为圆角的角 UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight | UIRectCornerAllCorners
 *  @param radii   需要设置的圆角大小 例如 CGSizeMake(20.0f, 20.0f)
 */
- (void)addRoundedCorners:(UIRectCorner)corners
                withRadii:(CGFloat)radii;



/// 设置部分圆角、边框(绝对布局)
/// @param corners 圆角位置
/// @param radii 圆角半径
/// @param borderColor 边框颜色
/// @param borderWitdh 边框宽度
- (void)addRoundedCorners:(UIRectCorner)corners
                withRadii:(CGFloat)radii
          withBorderColor:(UIColor *)borderColor
          withBorderWidth:(CGFloat)borderWitdh;

/// 设置边框(绝对布局)
/// @param corners 圆角位置
/// @param borderColor 边框颜色
/// @param borderWidth 边框宽度
//- (void)addBorderWithCorners:(UIRectCorner)corners
//             withBorderColor:(UIColor *)borderColor
//             withBorderWidth:(CGFloat)borderWidth;

- (UIView*)subViewOfClassName:(NSString*)className;

@end

@interface UIView (UIViewController)

- (UIViewController *)viewController;

@end

IB_DESIGNABLE

@interface UIView (Designable)

@property(nonatomic, assign) IBInspectable CGFloat borderWidth;
@property(nonatomic, assign) IBInspectable UIColor *borderColor;
@property(nonatomic, assign) IBInspectable CGFloat cornerRadius;

@end


NS_ASSUME_NONNULL_END
