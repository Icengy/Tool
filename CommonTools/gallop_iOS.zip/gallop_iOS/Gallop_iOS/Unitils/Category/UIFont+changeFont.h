//
//  UIFont+changeFont.h
//  JUXIU_iOS
//
//  Created by Homosum on 17/5/9.
//  Copyright © 2017年 JuXiuSheQu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, CYPingFangSCType) {
    CYPingFangSCTypeRegular,      // 常规体
    CYPingFangSCTypeUltralight,// 极细体
    CYPingFangSCTypeLight,//细体
    CYPingFangSCTypeThin,// 纤细体
    CYPingFangSCTypeMedium,    // 中黑体
    CYPingFangSCTypeBold     // 中粗体
};

@interface UIFont (changeFont)

@end


@interface UIFont (PingFangSC)

+ (UIFont *)addPingFangSC:(CGFloat)fontSize fontType:(CYPingFangSCType)type;

+ (UIFont *)addPingFangSCRegular:(CGFloat)fontSize;
+ (UIFont *)addPingFangSCBold:(CGFloat)fontSize;
+ (UIFont *)addPingFangSCMedium:(CGFloat)fontSize;

@end
