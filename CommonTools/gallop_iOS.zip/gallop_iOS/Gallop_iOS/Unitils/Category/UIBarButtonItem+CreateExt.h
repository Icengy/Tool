//
//  UIBarButtonItem+CreateExt.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/31.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, CYBarButtonItemPosition) {
    /// 默认 内容居中
    CYBarButtonItemPositionDefatult                   = 0,
    /// 居左 leftBarButtonItem
    CYBarButtonItemPositionLeft,
    /// 居右 rightBarButtonItem
    CYBarButtonItemPositionRight,
};

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (CreateExt)

///使用纯文本创建导航栏按钮 区分左右Item
+ (UIBarButtonItem *)createPostionBarItemWithTitle:(nullable NSString *)title
                                        titleColor:(nullable UIColor *)titleColor
                               horizontalAlignment:(CYBarButtonItemPosition)postion
                                            target:(nullable id)target
                                            action:(nullable SEL)action;
///使用纯文本创建导航栏按钮 不区分左右Item
+ (UIBarButtonItem *)createBarItemWithTitle:(nullable NSString *)title
                                 titleColor:(nullable UIColor *)titleColor
                                     target:(nullable id)target
                                     action:(nullable SEL)action;

///使用图片创建导航栏按钮 区分左右Item
+ (UIBarButtonItem *)createPostionBarItemWithImage:(nullable NSString *)normalImageName
                                      withHightImg:(nullable NSString *)heightedImageName
                               horizontalAlignment:(CYBarButtonItemPosition)postion
                                            target:(nullable id)target
                                            action:(nullable SEL)action;

///使用图片创建导航栏按钮 不区分左右Item
+ (UIBarButtonItem *)createBarItemWithImage:(nullable NSString *)normalImageName
                               withHightImg:(nullable NSString *)heightedImageName
                                     target:(nullable id)target
                                     action:(nullable SEL)action;

///使用图片创建返回按钮
+ (UIBarButtonItem *)createBackBarItemWithImage:(nullable NSString *)normalImageName
                                   withHightImg:(nullable NSString *)heightedImageName
                                         target:(nullable id)target
                                         action:(nullable SEL)action;
@end

NS_ASSUME_NONNULL_END
