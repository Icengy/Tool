//
//  UIScrollView+Setting.h
//  Gallop_iOS
//
//  Created by icengy on 2021/4/21.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableView (Setting)

/// 注册通过xib创建的cell
/// @param cellClass cell Class
- (void)registerNibCell:(Class)cellClass;
- (void)registerNibCell:(Class)cellClass withIdentifier:(NSString *)identifier;

/// 注册纯代码创建的cell
/// @param cellClass cell Class
- (void)registerCell:(Class)cellClass;
- (void)registerCell:(Class)cellClass withIdentifier:(NSString *)identifier;

/// 通过cell类获取cell, 默认style
/// @param cellClass cellClass
- (id)dequeueReusableCell:(Class)cellClass;

/// 通过cell类获取cell
/// @param cellClass cellClass
/// @param style style
- (id)dequeueReusableCell:(Class)cellClass withStyle:(UITableViewCellStyle)style;
- (id)dequeueReusableCell:(Class)cellClass withIdentifier:(NSString *)identifier;
- (id)dequeueReusableCell:(Class)cellClass withStyle:(UITableViewCellStyle)style withIdentifier:(NSString *)identifier;

/// 创建一个默认空cell ESTableViewCell类型
- (id)dequeueDefaultESCell;
- (id)dequeueDefaultESCell:(NSString *)identifier;

@end


@interface UICollectionView (Setting)

/// 注册通过xib创建的cell
/// @param cellClass cell Class
- (void)registerNibCell:(Class)cellClass;

/// 注册纯代码创建的cell
/// @param cellClass cell Class
- (void)registerCell:(Class)cellClass;

/// 通过cell类获取cell
/// @param cellClass cellClass
/// @param indexPath indexPath
- (id)dequeueReusableCell:(Class)cellClass
             forIndexPath:(NSIndexPath *)indexPath;

@end



@interface UIScrollView (Setting)



/// 添加头部下拉
- (void)addRefreshHeaderWithTarget:(id)target action:(SEL)action;
- (void)addRefreshHeaderWithTarget:(id)target textColor:(nullable UIColor *)textColor action:(SEL)action;
/// 添加尾部上拉
- (void)addRefreshFooterWithTarget:(id)target action:(SEL)action;

#pragma mark -
///结束所有Refresh动画
- (void)endAllFreshing;
///更新Footer的状态
- (void)updataFreshFooter:(BOOL)show;

@end

NS_ASSUME_NONNULL_END
