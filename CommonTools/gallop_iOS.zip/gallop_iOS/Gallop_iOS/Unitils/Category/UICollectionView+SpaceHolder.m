//
//  UICollectionView+SpaceHolder.m
//  Gallop_iOS
//
//  Created by lcy on 2021/8/24.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "UICollectionView+SpaceHolder.h"

@implementation UICollectionView (SpaceHolder)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self swizzleInstanceSelector:@selector(reloadData) WithSwizzledSelector:@selector(tc_reloadData)];
    });
}

+ (void)swizzleInstanceSelector:(SEL)originalSel
           WithSwizzledSelector:(SEL)swizzledSel {
    
    Method originMethod = class_getInstanceMethod(self, originalSel);
    Method swizzedMehtod = class_getInstanceMethod(self, swizzledSel);
    BOOL methodAdded = class_addMethod(self, originalSel, method_getImplementation(swizzedMehtod), method_getTypeEncoding(swizzedMehtod));
    
    if (methodAdded) {
        class_replaceMethod(self, swizzledSel, method_getImplementation(originMethod), method_getTypeEncoding(originMethod));
    }else{
        method_exchangeImplementations(originMethod, swizzedMehtod);
    }
}

- (void)tc_reloadData {
    [self tc_checkEmpty];
    dispatch_main_async_safe(^{
        [self tc_reloadData];
    });
}

- (void)tc_checkEmpty {
    dispatch_main_async_safe(^{
        
        BOOL isEmpty = YES;
        id <UICollectionViewDataSource> src = self.dataSource;
        NSInteger sections = 1;
        if ([src respondsToSelector:@selector(numberOfSectionsInCollectionView:)]) {
            sections = [src numberOfSectionsInCollectionView:self];
        }
        for (int i = 0; i < sections; i++) {
            NSInteger rows = [src collectionView:self numberOfItemsInSection:i];
            if (rows) {
                isEmpty = NO;
                break;
            }
        }
        
        if ([[Reachability reachabilityForInternetConnection] currentReachabilityStatus] == 0) {
            //无网络时
            self.placeHolderView.image = [UIImage imageNamed:@"no_wifi"];
        }else{
            if (!QM_IS_STR_NIL(self.placeHolderText)) {
                //有网络时
                self.placeHolderView.image = [UIImage imageNamed:@"no_data_withoutword"];
            }else {
                self.placeHolderView.image = [UIImage imageNamed:@"no_data"];
            }
        }
        CGFloat min = MIN(self.width, self.height);
        __block CGSize imageSize = CGSizeZero;
        if (min < kScreen_Width/2) {
            CGFloat min2 = min *2/3 > 120.0 ? 120.0:min *2/3;
            if (min == self.width) {
                imageSize = [UIImage sizeForNoDataImageWithWidth:min2];
            }
            if (min == self.height) {
                imageSize = [UIImage sizeForNoDataImageWithHeight:min2];
            }
        }else {
            CGFloat min2 = min /2 > 120.0 ? 120.0:min /2;
            if (min == self.width) {
                imageSize = [UIImage sizeForNoDataImageWithWidth:min2];
            }
            if (min == self.height) {
                imageSize = [UIImage sizeForNoDataImageWithHeight:min2];
            }
        }
        
        if (isEmpty) {//数据为空，在这里添加视图
            if (![self.subviews containsObject:self.placeHolderView]) {
                [self addSubview:self.placeHolderView];
            }
            WTCLog(@"self class = %@- imageSize =%@",NSStringFromClass([self class]), NSStringFromCGSize(imageSize));
            self.placeHolderView.hidden = NO;
            self.placeHolderView.size = imageSize;
            [self.placeHolderView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerX.equalTo(self);
                make.centerY.equalTo(self).offset(-10);
            }];
            [self addSubview:self.placeHolderLabel];
            self.placeHolderLabel.hidden = NO;
            
            if (!QM_IS_STR_NIL(self.placeHolderText)) {
                if (![self.subviews containsObject:self.placeHolderLabel]) {
                    [self addSubview:self.placeHolderLabel];
                }
                self.placeHolderLabel.text = self.placeHolderText;
                [self.placeHolderLabel sizeToFit];
                self.placeHolderLabel.hidden = NO;
                //调整布局
                [self.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(self);
                    make.top.equalTo(self.placeHolderView.mas_bottom).offset(5);
                }];
            }else {
                self.placeHolderLabel.hidden = YES;
            }
            
        }else {//数据不为空，在这里一处视图
            self.placeHolderLabel.hidden = YES;
            self.placeHolderView.hidden = YES;
        }
    });
}

#pragma mark -
- (void)setPlaceHolderView:(UIImageView *)placeHolderView {
    objc_setAssociatedObject(self, @selector(placeHolderView), placeHolderView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIImageView *)placeHolderView {
    return objc_getAssociatedObject(self, @selector(placeHolderView));
}

- (void)setPlaceHolderLabel:(UILabel *)placeHolderLabel {
    objc_setAssociatedObject(self, @selector(placeHolderLabel), placeHolderLabel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UILabel *)placeHolderLabel {
    return objc_getAssociatedObject(self, @selector(placeHolderLabel));
}

- (void)setPlaceHolderText:(NSString *)placeHolderText {
    objc_setAssociatedObject(self, @selector(placeHolderText), placeHolderText, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSString *)placeHolderText {
    return objc_getAssociatedObject(self, @selector(placeHolderText));
}

@end
