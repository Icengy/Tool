//
//  UIScrollView+Setting.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/21.
//  Copyright © 2021 homosum. All rights reserved.
//
// 注册单元格 Identifier为当前cell的名称
//

#import "UIScrollView+Setting.h"

@implementation UITableView (Setting)


/// 注册通过xib创建的cell
/// @param cellClass cell Class
- (void)registerNibCell:(Class)cellClass {
    [self registerNibCell:cellClass withIdentifier:NSStringFromClass(cellClass)];
}
- (void)registerNibCell:(Class)cellClass withIdentifier:(NSString *)identifier {
    [self registerNib:[UINib nibWithNibName:NSStringFromClass(cellClass) bundle:nil] forCellReuseIdentifier:identifier];
}


/// 注册纯代码创建的cell
/// @param cellClass cell Class
- (void)registerCell:(Class)cellClass {
    [self registerCell:cellClass withIdentifier:NSStringFromClass(cellClass)];
}
- (void)registerCell:(Class)cellClass withIdentifier:(NSString *)identifier {
    [self registerClass:cellClass forCellReuseIdentifier:identifier];
}

/// 通过nib的cell类获取cell
/// @param cellClass cellClass
- (id)dequeueReusableCell:(Class)cellClass {
    return [self dequeueReusableCell:cellClass withStyle:UITableViewCellStyleDefault];
}

/// 通过纯代码cell类获取cell
/// @param cellClass cellClass
/// @param style style
- (id)dequeueReusableCell:(Class)cellClass withStyle:(UITableViewCellStyle)style {
    return [self dequeueReusableCell:cellClass withStyle:style withIdentifier:NSStringFromClass([cellClass class])];
}

- (id)dequeueReusableCell:(Class)cellClass withIdentifier:(NSString *)identifier {
    return [self dequeueReusableCell:cellClass withStyle:UITableViewCellStyleDefault withIdentifier:identifier];
}

- (id)dequeueReusableCell:(Class)cellClass withStyle:(UITableViewCellStyle)style withIdentifier:(NSString *)identifier {
    id cell = [self dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        if ([[NSBundle mainBundle] pathForResource:identifier ofType:@"xib"]) {
            cell = [[NSBundle mainBundle] loadNibNamed:identifier owner:nil options:nil].lastObject;
        }else {
            cell = [[UITableViewCell alloc] initWithStyle:style reuseIdentifier:identifier];
        }
    }
    return cell;
}

/// 创建一个默认空cell ESTableViewCell类型
- (id)dequeueDefaultESCell {
    return [self dequeueDefaultESCell:NSStringFromClass([ESTableViewCell class])];
}
- (id)dequeueDefaultESCell:(NSString *)identifier {
    ESTableViewCell *cell = [self dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[ESTableViewCell alloc] initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:identifier];
    }else {
        [[(ESTableViewCell *)cell contentView].subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    }
    return cell;
}

@end



@implementation UICollectionView (Setting)

/// 注册通过xib创建的cell
/// @param cellClass cell Class
- (void)registerNibCell:(Class)cellClass {
    [self registerNib:[UINib nibWithNibName:NSStringFromClass(cellClass) bundle:nil] forCellWithReuseIdentifier:NSStringFromClass(cellClass)];
    
}

/// 注册纯代码创建的cell
/// @param cellClass cell Class
- (void)registerCell:(Class)cellClass {
    [self registerClass:cellClass forCellWithReuseIdentifier:NSStringFromClass(cellClass)];
}

/// 通过cell类获取cell
/// @param cellClass cellClass
- (id)dequeueReusableCell:(Class)cellClass forIndexPath:(NSIndexPath *)indexPath {
    return [self dequeueReusableCellWithReuseIdentifier:NSStringFromClass(cellClass) forIndexPath:indexPath];
//    id cell = [self dequeueReusableCellWithReuseIdentifier:NSStringFromClass(cellClass) forIndexPath:indexPath];
//    if (!cell) {
//        if ([[NSBundle mainBundle] pathForResource:NSStringFromClass(cellClass) ofType:@"xib"]) {
//            cell = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(cellClass) owner:nil options:nil].lastObject;
//        }else {
//            cell = [UICollectionViewCell alloc] ini
//            [[UITableViewCell alloc] initWithStyle:style reuseIdentifier:NSStringFromClass(cellClass)];
//        }
//    }
//    return cell;
}

@end


@implementation UIScrollView (Setting)

- (void)addRefreshHeaderWithTarget:(id)target action:(SEL)action {
    [self addRefreshHeaderWithTarget:target textColor:nil action:action];
}

- (void)addRefreshHeaderWithTarget:(id)target textColor:(nullable UIColor *)textColor action:(SEL)action {
    MJCostomAnimHeader *header = [MJCostomAnimHeader headerWithRefreshingTarget:target refreshingAction:action];
    header.lastUpdatedTimeLabel.hidden = YES;
//    header.stateLabel.hidden = YES;
//    [header setTitle:@"" forState:MJRefreshStateIdle];
    
    header.stateLabel.font = [UIFont addPingFangSCRegular:12.0];
    header.stateLabel.textColor = textColor? textColor:ColorMainNormalBlack;
    
    self.mj_header = header;
}

- (void)addRefreshFooterWithTarget:(id)target action:(SEL)action {
    [self addRefreshFooterWithTarget:target withTitle:@"- 没有更多了 -" action:action];
}

- (void)addRefreshFooterWithTarget:(id)target withTitle:(NSString *)title action:(SEL)action {
    MJRefreshAutoNormalFooter *footer = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:target refreshingAction:action];
    footer.refreshingTitleHidden = YES;
    
    footer.stateLabel.font = [UIFont addPingFangSCRegular:12.0];
    footer.stateLabel.textColor = ColorMainNormalBlack;
    [footer setTitle:@"" forState:MJRefreshStateIdle];
    [footer setTitle:title forState:MJRefreshStateNoMoreData];
    
    footer.hidden = YES;
    
    self.mj_footer = footer;
}

#pragma mark -
- (void)endAllFreshing {
//    if (self.mj_footer)
//        [self.mj_footer endRefreshing];
    if (self.mj_header)
        [self.mj_header endRefreshing];
    
    if ([self isKindOfClass:[UITableView class]]) {
        [(UITableView *)self setAllowsSelection:YES];
    }
    if ([self isKindOfClass:[UICollectionView class]]) {
        [(UICollectionView *)self setAllowsSelection:YES];
    }
}

- (void)updataFreshFooter:(BOOL)show {
    if (show) {
        [self.mj_footer endRefreshingWithNoMoreData];
    }else {
        [self.mj_footer setState:MJRefreshStateIdle];
    }
}

@end
