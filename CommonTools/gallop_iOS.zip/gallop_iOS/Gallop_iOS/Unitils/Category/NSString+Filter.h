//
//  NSString+Filter.h
//  ESTicket
//
//  Created by What on 15/07/2017.
//  Copyright © 2017 鹏 刘. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Filter)
- (NSArray*)rangesOfNumbers;
@end
