//
//  UIColor+Ext.h
//  ESTicket
//
//  Created by phoenix on 15/10/23.
//  Copyright © 2015年 SEU. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger,ZQGradientChangeDirection) {
    ZQGradientChangeDirectionLevel, //水平方向渐变
    ZQGradientChangeDirectionVertical,  //垂直方向渐变
    ZQGradientChangeDirectionUpwardDiagonalLine,    //主对角线方向渐变
    ZQGradientChangeDirectionDownDiagonalLine,  //副对角线方向渐变
};

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (IdentifierAddition)

+ (instancetype)colorFromSelectorString:(NSString*)str;

+ (UIColor*)colorWithCSS:(NSString*)css;
+ (UIColor*)colorWithHex:(NSUInteger)hex;

- (uint)hex;
- (NSString*)hexString;
- (NSString*)cssString;

@end

@interface UIColor (Gradient)
/*
 size:渐变区域的尺寸
 direction:渐变方向
 colors:颜色数组
 */
+ (instancetype)bm_colorGradientChangeWithSize:(CGSize)size
                                     direction:(ZQGradientChangeDirection)direction
                                        colors:(NSArray <UIColor *>*)colors;
@end

#define RGBA_COLOR(R, G, B, A) [UIColor colorWithRed:((R) / 255.0f) green:((G) / 255.0f) blue:((B) / 255.0f) alpha:A]
#define RGB_COLOR(R, G, B) [UIColor colorWithRed:((R) / 255.0f) green:((G) / 255.0f) blue:((B) / 255.0f) alpha:1.0f]

@interface UIColor (Hex)

+ (UIColor *)colorWithHexString:(NSString *)color;

//从十六进制字符串获取颜色，
//color:支持@“#123456”、 @“0X123456”、 @“123456”三种格式
+ (UIColor *)colorWithHexString:(NSString *)color alpha:(CGFloat)alpha;

/// 随机颜色
+ (UIColor *)arcrandomColor;

@end

NS_ASSUME_NONNULL_END
