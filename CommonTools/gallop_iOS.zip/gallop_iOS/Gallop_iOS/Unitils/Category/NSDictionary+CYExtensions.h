//
//  NSDictionary+CYSwizzing.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/3.
//  Copyright © 2021 homosum. All rights reserved.
//
// 字典扩展
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark - key存在判定
@interface NSDictionary (CYExtensions)

/// 判断key是否存在
- (BOOL)existWithKey:(nonnull id)key;

@end

@interface NSMutableDictionary (CYExtensions)

/// 判断key是否存在
- (BOOL)existWithKey:(nonnull id)key;

@end

NS_ASSUME_NONNULL_END
