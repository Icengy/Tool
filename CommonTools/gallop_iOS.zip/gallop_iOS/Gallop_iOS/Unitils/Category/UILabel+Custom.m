//
//  UILabel+Custom.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "UILabel+Custom.h"

#import "objc/runtime.h"

@implementation UILabel (Custom)

-(void)setLabelSpace:(CGFloat)space withFont:(UIFont*)font  {
    if (![CommonUtils isEqualToNonNull:self.text]) return;
    
    NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
    paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
    paraStyle.alignment = NSTextAlignmentLeft;
    paraStyle.lineSpacing = space; //设置行间距
    paraStyle.hyphenationFactor = 1.0;
    paraStyle.firstLineHeadIndent = 0.0;
    paraStyle.paragraphSpacingBefore = 0.0;
    paraStyle.headIndent = 0;
    paraStyle.tailIndent = 0;
    //设置字间距 NSKernAttributeName:@1.5f
    NSDictionary *dic = @{NSFontAttributeName:font, NSParagraphStyleAttributeName:paraStyle, NSKernAttributeName:@0.0f
                          };
    NSAttributedString *attributeStr = [[NSAttributedString alloc] initWithString:self.text attributes:dic];
    self.attributedText = attributeStr;
}

-(void)setColorArr:(NSArray *)colorArr forTextArr:(NSArray *)textArr {
    if (![CommonUtils isEqualToNonNull:self.text]) {
        return;
    }
    NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:self.text];
    for (NSUInteger i = 0; i < textArr.count; i++) {
        NSArray *rangeArr = [self getRangeStr:self.text findText:textArr[i]];
        for (NSNumber *location in rangeArr) {
            [attributeStr addAttribute:NSForegroundColorAttributeName value:colorArr[i] range:NSMakeRange(location.integerValue, ((NSString *)textArr[i]).length)];
        }
    }
    self.attributedText = attributeStr;
}

#pragma mark - 获取这个字符串ASting中的所有abc的所在的index
- (NSMutableArray *)getRangeStr:(NSString *)text findText:(NSString *)findText
{
    
    NSMutableArray *arrayRanges = [NSMutableArray arrayWithCapacity:3];
    
    if (findText == nil && [findText isEqualToString:@""])
    {
        
        return nil;
        
    }
    
    NSRange rang = [text rangeOfString:findText]; //获取第一次出现的range
    
    if (rang.location != NSNotFound && rang.length != 0)
    {
        
        [arrayRanges addObject:[NSNumber numberWithInteger:rang.location]];//将第一次的加入到数组中
        
        NSRange rang1 = {0,0};
        
        NSInteger location = 0;
        
        NSInteger length = 0;
        
        for (int i = 0;; i++)
        {
            
            if (0 == i)
            {
                
                //去掉这个abc字符串
                location = rang.location + rang.length;
                
                length = text.length - rang.location - rang.length;
                
                rang1 = NSMakeRange(location, length);
                
            }
            else
            {
                
                location = rang1.location + rang1.length;
                
                length = text.length - rang1.location - rang1.length;
                
                rang1 = NSMakeRange(location, length);
                
            }
            
            //在一个range范围内查找另一个字符串的range
            
            rang1 = [text rangeOfString:findText options:NSCaseInsensitiveSearch range:rang1];
            
            if (rang1.location == NSNotFound && rang1.length == 0)
            {
                
                break;
                
            }
            else//添加符合条件的location进数组
                
                [arrayRanges addObject:[NSNumber numberWithInteger:rang1.location]];
            
        }
        
        return arrayRanges;
        
    }
    
    return nil;
    
}

- (void)addAttributedText:(NSString *)attrText withAttributeds:(NSDictionary<NSAttributedStringKey,id> *)attributeds {
    if (![CommonUtils isEqualToNonNull:attrText]) {
        NSAssert(YES, @"attrText为空");
        return;
    }
    [self addAttributedTexts:@[attrText] withAttributeds:attributeds];
}

- (void)addAttributedTexts:(NSArray <NSString *>*)attrTexts withAttributeds:(NSDictionary<NSAttributedStringKey,id> *)attributeds {
    
    if (![CommonUtils isEqualToNonNull:self.text]) {
        NSAssert(YES, @"UILabel的text为空");
        return;
    }
    if (!attrTexts.count) return;
    
    __block NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:self.text];
    
    [attrTexts enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([self islawfulText:obj]) {
            [attrStr addAttributes:attributeds range:[self.text rangeOfString:obj]];
        }
    }];
    self.attributedText = attrStr;
}


- (BOOL)islawfulText:(id)obj {
    BOOL islawful = NO;
    if ([CommonUtils isEqualToNonNull:obj]) {
        islawful = YES;
    }
    
    if ([self.text rangeOfString:obj].location != NSNotFound) {
        islawful = YES;
    }
    return islawful;
}


#pragma mark -
+ (void)load {
    [super load];
    
    static dispatch_once_t ondeToken;
    dispatch_once(&ondeToken, ^{
        Method fromMethod = class_getInstanceMethod(self, @selector(setText:));
        Method toMethod = class_getInstanceMethod(self, @selector(cy_setText:));
        method_exchangeImplementations(fromMethod, toMethod);
    });
}

/// 替换空/Null字符串
- (void)cy_setText:(NSString *)text {
    NSString *nonNullStr = [CommonUtils isEqualToNonNull:text replace:@""];
    [self cy_setText:nonNullStr];
}

@end
