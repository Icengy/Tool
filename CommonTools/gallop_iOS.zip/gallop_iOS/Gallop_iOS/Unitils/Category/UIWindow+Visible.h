//
//  UIWindow+Visible.h
//  ESTicket
//
//  Created by 王帅 on 16/8/16.
//  Copyright © 2016年 鹏 刘. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (Visible)

- (UIViewController *)visibleViewController;

@end
