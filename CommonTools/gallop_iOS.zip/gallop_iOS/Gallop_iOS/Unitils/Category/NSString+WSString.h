//
//  NSString+WSString.h
//  ESTicket
//
//  Created by 王帅 on 16/3/10.
//  Copyright © 2016年 鹏 刘. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (WSString)

@end


@interface NSString(Size)

- (CGSize)sizeWithFont:(UIFont*)font andMaxSize:(CGSize)size;
/// 多行无边距
- (CGSize)sizeWithFont:(UIFont*)font andMaxSize:(CGSize)size numberOfLines:(NSInteger)numberOfLines;
/// 多行+默认边距
- (CGSize)sizeWithDefaultLabelEdgeWithFont:(UIFont*)font andMaxSize:(CGSize)size numberOfLines:(NSInteger)numberOfLines;
/// 多行有边距
- (CGSize)sizeWithFont:(UIFont*)font andMaxSize:(CGSize)size numberOfLines:(NSInteger)numberOfLines withEdge:(UIEdgeInsets)edge;

@end
