//
//  NSDictionary+CYSwizzing.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/3.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "NSDictionary+CYExtensions.h"

@implementation NSDictionary (CYExtensions)

- (BOOL)existWithKey:(nonnull id)key {
    if ([[self allKeys] containsObject:key]) {
        return YES;
    }
    return NO;
}

@end


@implementation NSMutableDictionary (CYExtensions)

- (BOOL)existWithKey:(nonnull id)key {
    if ([[self allKeys] containsObject:key]) {
        return YES;
    }
    return NO;
}

@end


