//
//  UITableView+SpaceHolder.h
//  ESTicket
//
//  Created by Homosum on 2018/5/17.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableView (SpaceHolder)

@property (nonatomic, strong) UIImageView *placeHolderView;
@property (nonatomic, strong) UILabel *placeHolderLabel;
@property (nonatomic, copy) NSString *placeHolderText;

@end
