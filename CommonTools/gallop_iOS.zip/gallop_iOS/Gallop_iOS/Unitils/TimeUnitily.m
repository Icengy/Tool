//
//  TimeUnitily.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/7.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "TimeUnitily.h"

@implementation TimeUnitily


#pragma mark - 比较时间差值，不用考虑时区 返回值为“xx前/MM-dd hh-mm/""”
+ (NSString *)stampDateFormatForTimeStamp:(NSString *)stamp {
    if (![CommonUtils isEqualToNonNull:stamp] && stamp.doubleValue == 0) {
        return @"";
    }
    //毫秒转换为秒
    NSTimeInterval timerInterval = [stamp doubleValue] / 1000;
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timerInterval];
    
    return [self compareCurrentTimeWithDate:date];
}

+ (NSString *)formatDateForTimeStr:(NSString *)timeStr {
    return [self formatDateForTimeStr:timeStr wihtFormat:@"yyyy-MM-dd HH:mm:ss"];
}

+ (NSString *)formatDateForTimeStr:(NSString *)timeStr wihtFormat:(NSString *)timeFormat {
    if (![CommonUtils isEqualToNonNull:timeStr]) return @"";
    
    //把字符串转为NSdate
    NSDate *timeDate = [[self formatter:timeFormat] dateFromString:timeStr];
    
    return [self compareCurrentTimeWithDate:timeDate];
}

+ (NSString *)compareCurrentTimeWithDate:(NSDate *)targetDate {
    return [self compareDate:[NSDate date] withDate:targetDate];
}

+ (NSString *)compareDate:(NSDate *)date withDate:(NSDate *)targetDate {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSCalendarUnit unit =NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    
    NSDateComponents *cmps = [calendar components:unit fromDate:targetDate toDate:date options:0];
    
    if (cmps.day >= 1) {
        //大于24小时
        return [[self formatter] stringFromDate:targetDate];;
    } else if (cmps.hour >= 1) {
        //1 < h < 24
        return [NSString stringWithFormat:@"%@小时前",@(cmps.hour)];
    } else if (cmps.minute > 1) {
        //1 < minute <60
        return [NSString stringWithFormat:@"%@分钟前",@(cmps.minute)];
    } else {
        return @"刚刚";
    }
}


#pragma mark - 格式转换
+ (NSString *)dateChangeWith:(NSString *)timeStr fromFormat:(NSString *)from toFormat:(NSString *)to {
    if (![CommonUtils isEqualToNonNull:timeStr])
        return timeStr;
    
    //把字符串转为NSdate
    NSDate *timeDate = [[self formatter:from] dateFromString:timeStr];
    
    return [[self formatter:to] stringFromDate:timeDate];
}


#pragma mark -
/// 基本时间格式 MM-dd HH:mm
+ (NSDateFormatter *)formatter {
    return [self formatter:@"MM-dd HH:mm"];
}

/// 自定义时间格式
+ (NSDateFormatter *)formatter:(NSString *)dateFormat {
    NSDateFormatter *_formatter = [[NSDateFormatter alloc] init];
    [_formatter setDateStyle:NSDateFormatterMediumStyle];
    [_formatter setTimeStyle:NSDateFormatterShortStyle];
    [_formatter setDateFormat:dateFormat];
    
    _formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US"];
    if (@available(iOS 10.0, *)) {
//        _formatter.locale = [NSLocale localeWithLocaleIdentifier:[NSLocale currentLocale].collatorIdentifier];
    }
    
    _formatter.timeZone = [NSTimeZone systemTimeZone];
    
    return _formatter;
}

/// 校正时区差别
/// @param targetDate 目标时间
+ (NSDate *)correctingTimeZone:(NSDate *)targetDate {
    
    NSTimeZone *timeZone = [NSTimeZone systemTimeZone]; // 获取的是系统的时区
    double interval = [timeZone secondsFromGMTForDate:targetDate];// local时间距离GMT的秒数
    //
    NSDate *localeDate = [targetDate dateByAddingTimeInterval:interval];
    /// 东八区的实际时间
    return localeDate;
}




@end
