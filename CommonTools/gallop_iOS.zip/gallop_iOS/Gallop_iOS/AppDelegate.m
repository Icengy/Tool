//
//  AppDelegate.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/9.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Link.h"
#import "XHLaunchAd.h"
#import <UMessage.h>
#import <UMCommon/UMCommon.h>
#import "WXApi.h"
#import "ApplyingViewController.h"
#import "ApplyExpertViewController.h"


#import "ExpertViewController.h"
#import "AccountDetailViewController.h"
#import "MatchHomeViewController.h"


#import <StoreKit/StoreKit.h>
#import "GTMBase64.h"
#import <CommonCrypto/CommonDigest.h>

#import "GuideViewController.h"
#import "CaiJinQuanViewController.h"


#import "GoodsDetailViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityTopicDetailViewController.h"

/// 广告跳转
#import "PayViewController.h"
#import "MatchDetailViewController.h"
#import "ExpertDetailViewController.h"
#import "CYPlanDetailViewController.h"
#import "CommunityPaperContentViewController.h"
#import "PaperContentViewController.h"
#import "WTCContentViewController.h"

@interface GallopAdvertisementModel : NSObject

@property (nonatomic , copy) NSString              * mallLink;
@property (nonatomic , copy) NSString              * eventTopicName;
///  4, // 跳转页面, 跳转页面，OUT_PAGE:APP外页面、PLAN:方案、EXPERT:专家、POST:帖子、MATCH:比赛、RECHARGE_PAGE:充值页.
@property (nonatomic , copy) NSString              * businessType;
@property (nonatomic , copy) NSString *              startImageId;
@property (nonatomic , copy) NSString              * hybridH5Domain;
/*
// 跳转参数 json格式或外链url;
// linkType = NOT_LINKED, 或businessType = RECHARGE_PAGE 时, linkTo字段可以忽略;
// linkType = URL 时, linkTo字段为需要跳转的url;
// linkType = ARTICLE 时, linkTo字段为json格式, json内部包含1个参数 textI:文章id;
// linkType = APP_PAGE, businessType = PLAN时, linkTo字段为json格式, json内部包含1个参数 planId:方案id;
// linkType = APP_PAGE, businessType = EXPERT, linkTo字段为json格式, json内部包含1个参数 expertId:专家id;
// linkType = APP_PAGE, businessType = POST, linkTo字段为json格式, json内部包含1个参数 postId:帖子id;
// linkType = APP_PAGE, businessType = MATCH, linkTo字段为json格式, json内部包含2个参数 field:比赛类型, 1.足球, 2.篮球; matchId:比赛id
 */
@property (nonatomic , copy) NSString              * linkTo;
/// 4, // 跳转类型，NOT_LINKED:纯图（不跳转）、URL:链接、ARTICLE:文章、APP_PAGE:APP页面
@property (nonatomic , copy) NSString              * type;
@property (nonatomic , copy) NSString              * customerServiceQQ;
@property (nonatomic , copy) NSString              * startImageLink;
@property (nonatomic , assign) NSInteger              startImageContentType;
@property (nonatomic , copy) NSString              * likeText;
@property (nonatomic , assign) NSInteger              iosState;
@property (nonatomic , copy) NSString              * startAdvertisementContent;
@property (nonatomic , copy) NSString              * customerServiceTime;
@property (nonatomic , copy) NSString              *eventTopicId;
@property (nonatomic , copy) NSString              * startImageContent;
@property (nonatomic , assign) NSInteger              startImageSkipType;
@property (nonatomic , copy) NSString              * customerServiceTel;
@property (nonatomic , copy) NSString              * startImage;

@end

@implementation GallopAdvertisementModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{
             @"type" : @"startAdvertisementLinkType",
             @"linkTo" : @"startAdvertisementLinkTo",
             @"businessType" : @"startAdvertisementBusinessType",
    };
}

@end


@interface AppDelegate ()<UITabBarControllerDelegate,UNUserNotificationCenterDelegate,WXApiDelegate, XHLaunchAdDelegate>
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //引导页
//    if(![[NSUserDefaults standardUserDefaults] boolForKey:@"didShowGuidPage"])
//    {
//		//获取初始化配置
//		[ESNetworkService getAppInitInfo:^(id dict, ESError *error) {
//			if (dict&&[dict[@"code"] integerValue] == 0) {
//				NSDictionary *dic = dict[@"data"];
//				dispatch_async(dispatch_get_main_queue(), ^{
//					[[NSUserDefaults standardUserDefaults] setBool:[dic[@"iosState"] boolValue] forKey:kIOSState];
//					App_Utility.currentUser.customerServiceTel = dic[@"customerServiceTel"];
//					[App_Utility saveCurrentUser];
//					[SystemManager setEventTopicId:dic[@"eventTopicId"]];
//					[SystemManager setEventTopicName:dic[@"eventTopicName"]];
//				});
//			}
//		}];
//        //自己创建的引导页控制器
//        GuideViewController *vc = [GuideViewController new];
//        self.window.rootViewController = vc;
//        //滑到最后一页的回调
//        vc.callBack = ^{
//            self.window.rootViewController = self.matchTabBarVC;
//        };
//        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"didShowGuidPage"];
//    } else {
		[self getAppInit:!QM_IS_DICT_NIL(launchOptions)];
//    }
    
    //反馈全局悬浮窗
	[self addFeedBackWindow];
    
    [WXApi registerApp:kWxKey universalLink:@"https://www.feichitiyu.com/"];

    WTCLog(@"WXApi version = %@",[WXApi getApiVersion]);
    @try {
        [self setupUMengPushWithOptions:launchOptions];
    } @catch (NSException *exception) {
    }
    @try {
        [UMConfigure initWithAppkey:kUmengPushKey channel:@""];
        [UMConfigure setLogEnabled:NO];
    } @catch (NSException *exception) {
    }
    
    [self checkUnfinishedTrade];
    
    UILocalNotification *localNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if (localNotification) {
        NSLog(@"Recieved Notification === %@",localNotification);
    }
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    
    return YES;
}

-(void)checkUnfinishedTrade{
    NSArray*cArr = [[NSUserDefaults standardUserDefaults] objectForKey:kUnfinishedTradeArr];
    
    if (!QM_IS_ARRAY_NIL(cArr)) {
        NSMutableArray*mArr = [NSMutableArray arrayWithArray:cArr];
        [mArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            
            NSDictionary*cDic = obj;
            
            NSString*cReceipt = cDic[@"receipt"];
            NSString*receiptToken = cDic[@"receiptToken"];
            [ESNetworkService appleVerityWithReceipt:cReceipt Type:!SandBox ReceiptToken:receiptToken Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    [mArr removeObject:cDic];
                 [[NSUserDefaults standardUserDefaults] setObject:[mArr copy] forKey:kUnfinishedTradeArr];
                 [[NSUserDefaults standardUserDefaults] synchronize];
                      NSArray *tansactions = [SKPaymentQueue defaultQueue].transactions;
                     NSString*str = [DES3Util getDESDecrypt:receiptToken withKey:payKey];
                     NSArray*pramArr = [str componentsSeparatedByString:@"&&"];
                     NSString*tranStr = pramArr[1];
                     NSString*ctranId = [tranStr componentsSeparatedByString:@"="][1];
                     [tansactions enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                         SKPaymentTransaction *transaction = obj;
                         if ([transaction.transactionIdentifier isEqualToString:ctranId]) {
                             [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
                         }
                     }];
                 }
             }];
             
             
         }];
     }
}

- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    if (![deviceToken isKindOfClass:[NSData class]]) return;
    const unsigned *tokenBytes = [deviceToken bytes];
    NSString *hexToken = [NSString stringWithFormat:@"%08x%08x%08x%08x%08x%08x%08x%08x",
                          ntohl(tokenBytes[0]), ntohl(tokenBytes[1]), ntohl(tokenBytes[2]),
                          ntohl(tokenBytes[3]), ntohl(tokenBytes[4]), ntohl(tokenBytes[5]),
                          ntohl(tokenBytes[6]), ntohl(tokenBytes[7])];
    NSLog(@"deviceToken:%@",hexToken);
    
    [UMessage registerDeviceToken:deviceToken];
    [[NSUserDefaults standardUserDefaults] setObject:hexToken forKey:kDeviceTokenUmeng];
    [[NSUserDefaults standardUserDefaults]synchronize];
    if ([App_Utility checkCurrentUser]){
        [ESNetworkService setDeviceToken:hexToken Response:^(id dict, ESError *error) {
        }];
    }
}

//iOS10新增：处理后台点击通知的代理方法
-(void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler API_AVAILABLE(ios(10.0)) API_AVAILABLE(ios(10.0)){
    NSDictionary * userInfo = response.notification.request.content.userInfo;
    WTCLog(@"push%@",userInfo);
    if([response.notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        //应用处于后台时的远程推送接受
        //必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
        NSDictionary*payloadDict=response.notification.request.content.userInfo;
        NSString*payloadMsg=[payloadDict objectForKey:@"payload"];
        if (!QM_IS_STR_NIL(payloadMsg)) {
            NSData*payLoadDat=[payloadMsg dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary*payload=[NSJSONSerialization JSONObjectWithData:payLoadDat options:NSJSONReadingMutableLeaves error:nil];
            [self gh_dealPushData:payload];
        }else{
            NSDictionary*payload=response.notification.request.content.userInfo;
            [self gh_dealPushData:payload];
        }
    }else{
        //应用处于后台时的本地推送接受
    }
}
- (void)gh_dealPushData:(NSDictionary *)payload {
    if (!QM_IS_DICT_NIL(payload)) {
        NSString*link = [payload objectForKey:@"link"];
        NSString*pushType = [payload objectForKey:@"pushType"];
        switch (pushType.integerValue) {
            case 10020001:
            case 10020003:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //提交专家申请
                [ESNetworkService getExpertInfoResponse:^(id dict, ESError *error) {
                    if (dict&&[dict[@"code"] integerValue] == 0) {
                        NSDictionary*data = dict[@"data"];
                        NSInteger applyStatus = [data[@"applyStatus"] integerValue];
                        NSInteger userRole = [data[@"userRole"] integerValue];
                        App_Utility.currentUser.role = data[@"userRole"];
                        if (userRole!=3&&userRole!=7) {
                            switch (applyStatus) {
                                case 2://申请失败
                                {
                                    ApplyingViewController*vc = [ApplyingViewController new];
                                    vc.text = data[@"applyResultDesc"];
                                    vc.isRefused = 1;
                                    [vc setHidesBottomBarWhenPushed:YES];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                                        UINavigationController*nav = rootVC.selectedViewController;
                                        [nav pushViewController:vc animated:YES];
                                    });
                                }
                                    break;
                                case -1://未申请
                                {
                                    ApplyExpertViewController*vc = [ApplyExpertViewController new];
                                    [vc setHidesBottomBarWhenPushed:YES];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                                        UINavigationController*nav = rootVC.selectedViewController;
                                        [nav pushViewController:vc animated:YES];
                                    });
                                }
                                    break;
                                case 0:{
                                    //申请中
                                    ApplyingViewController*vc = [ApplyingViewController new];
                                    vc.text = data[@"applyResultDesc"];
                                    vc.isRefused = 0;
                                    [vc setHidesBottomBarWhenPushed:YES];
                                    dispatch_async(dispatch_get_main_queue(), ^{
                                        UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                                        UINavigationController*nav = rootVC.selectedViewController;
                                        [nav pushViewController:vc animated:YES];
                                    });
                                }
                                default:
                                    break;
                            }
                        }else{
                            ExpertViewController*vc = [ExpertViewController new];
                            vc.expertName = data[@"expertName"];
                            vc.avatarUrl = data[@"expertAvatar"];
                            vc.introduction = data[@"introduction"];
                            vc.detailT = data[@"applyResultDesc"];
                            [vc setHidesBottomBarWhenPushed:YES];
                            dispatch_async(dispatch_get_main_queue(), ^{
                                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                                UINavigationController*nav = rootVC.selectedViewController;
                                [nav pushViewController:vc animated:YES];
                            });
                            
                        }
                        
                    }
                }];
                
            }
                break;
            case 10020002:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //专家申请成功
                WTCContentViewController*vc = [WTCContentViewController new];
                vc.url = link;
                vc.contentType = WTCContentTypeNav;
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
                
            }
                break;
                
            case 10000001:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //订阅专家发单
                ExpertDetailViewController*vc = [ExpertDetailViewController new];
                
                vc.expertId = payload[@"expertId"];
                vc.sourcePage = @"推送消息-订阅专家发单";
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10000002:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //订阅专家红单
                ExpertDetailViewController*vc = [ExpertDetailViewController new];
                vc.expertId = payload[@"expertId"];
                vc.sourcePage = @"推送消息-订阅专家红单";
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10000003:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //订阅专家连红
                ExpertDetailViewController*vc = [ExpertDetailViewController new];
               
                vc.expertId = payload[@"expertId"];
                vc.sourcePage = @"推送消息-订阅专家连红";
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
			case 10000004:
			{
				if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
					[App_Utility showLoginViewController];
					return ;
				}
                CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
				vc.planId = [payload[@"planId"] intValue];
				vc.sourcePage = @"推送消息-订阅专家发单";
				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
				UINavigationController*nav = rootVC.selectedViewController;
				[vc setHidesBottomBarWhenPushed:YES];
				[nav pushViewController:vc animated:YES];
			}
				break;
			case 10000005:
			{
				if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
					[App_Utility showLoginViewController];
					return ;
				}
                CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
				
				vc.planId = [payload[@"planId"] intValue];
				vc.sourcePage = @"推送消息-订阅专家红单";
				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
				UINavigationController*nav = rootVC.selectedViewController;
				[vc setHidesBottomBarWhenPushed:YES];
				[nav pushViewController:vc animated:YES];
			}
				break;
            case 10010002:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //异常退款
                AccountDetailViewController*vc = [AccountDetailViewController new];
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10010003:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //方案没红
                CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
                
                vc.planId = [payload[@"planId"] intValue];
                vc.sourcePage = @"推送消息-方案没红";
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10010004:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //不中退款
                AccountDetailViewController*vc = [AccountDetailViewController new];
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10010005:
            {
                if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
                    [App_Utility showLoginViewController];
                    return ;
                }
                //方案红了
                CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
                
                vc.planId = [payload[@"planId"] intValue];
                vc.sourcePage = @"推送消息-方案红了";
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10070001://篮球开始
            case 10070002://篮球中场
            case 10070003://篮球结束
            {
                if ([CommonUtils isEqualToNonNull:[payload objectForKey:@"matchId"]]) {
                    MatchDetailViewController *matchVC = [[MatchDetailViewController alloc] init];
                    matchVC.field = 2;
                    matchVC.matchId = [payload[@"matchId"] integerValue];
                    matchVC.sourcePage = @"比赛通知推送";
                    UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                    UINavigationController*nav = rootVC.selectedViewController;
                    [nav pushViewController:matchVC animated:YES];
                }
                
            }
                break;
            case 10030001:
            case 10030002:
            case 10030003:
            case 10030004:
            case 10030005:
            case 10030006:
            case 10030007:
            {
                //比赛开始
                if ([CommonUtils isEqualToNonNull:[payload objectForKey:@"matchId"]]) {
                    MatchDetailViewController *matchVC = [[MatchDetailViewController alloc] init];
                    matchVC.field = 1;
                    matchVC.matchId = [payload[@"matchId"] integerValue];
                    matchVC.sourcePage = @"比赛通知推送";
                    
                    UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                    UINavigationController*nav = rootVC.selectedViewController;
                    [nav pushViewController:matchVC animated:YES];
                }
            }
                break;
//			case 10040001:
//			{
//				//优惠券
//				if (![App_Utility checkCurrentUser]) {  // || !APP_DELEGATE.getRCDataSuccess
//					[App_Utility showLoginViewController];
//					return ;
//				}
//				CaiJinQuanViewController*vc = [CaiJinQuanViewController new];
//				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
//				UINavigationController*nav = rootVC.selectedViewController;
//				[vc setHidesBottomBarWhenPushed:YES];
//				[nav pushViewController:vc animated:YES];
//			}
//				break;
			case 10050001:
			{
				//banner推送
				WTCContentViewController*vc = [WTCContentViewController new];
				vc.url = link;
				vc.contentType = WTCContentTypeNav;
				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
				UINavigationController*nav = rootVC.selectedViewController;
				[vc setHidesBottomBarWhenPushed:YES];
				[nav pushViewController:vc animated:YES];
			}
				break;
			case 10050002:
			{
				//banner文章推送
				ESBanner *banner = [[ESBanner alloc] init];
                banner.textId = [NSString stringWithFormat:@"%@",payload[@"textId"]];
				banner.textFormat = @"1";
				PaperContentViewController*vc = [PaperContentViewController new];
				vc.banerModel = banner;
				vc.hidesBottomBarWhenPushed = YES;
				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
				UINavigationController*nav = rootVC.selectedViewController;
				[vc setHidesBottomBarWhenPushed:YES];
				[nav pushViewController:vc animated:YES];
			}
				break;
            case 10050003:
            {
                //商品推送
                GoodsDetailViewController*vc = [[GoodsDetailViewController alloc] init];
                vc.productId = [NSString stringWithFormat:@"%@",payload[@"productId"]];
                vc.hidesBottomBarWhenPushed = YES;
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
            case 10050004:
            {
                //帖子推送
                CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
                vc.postId =  [payload[@"postId"] integerValue];
                vc.hidesBottomBarWhenPushed = YES;
                UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
                UINavigationController*nav = rootVC.selectedViewController;
                [vc setHidesBottomBarWhenPushed:YES];
                [nav pushViewController:vc animated:YES];
            }
                break;
			case 10050005:
			{
				//话题推送
				CommunityTopicDetailViewController*vc = [[CommunityTopicDetailViewController alloc] init];
				vc.topicId = [payload[@"topicId"] integerValue];
				vc.hidesBottomBarWhenPushed = YES;
				UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
				UINavigationController*nav = rootVC.selectedViewController;
				[vc setHidesBottomBarWhenPushed:YES];
				[nav pushViewController:vc animated:YES];
			}
				break;
			case 10061001:
			{
				//客服回馈通知
				[self openFeedBackPage];
			}
				break;
                
            default:
                break;
        }
    }
}
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    // register to receive notifications
    application.applicationIconBadgeNumber = 0;//角标
    [application registerForRemoteNotifications];
}

- (void)getAppInit:(BOOL)isFromPush {
    self.window.rootViewController = self.matchTabBarVC;

#ifdef DEBUG
#else
    if (!isFromPush) {
        [XHLaunchAd setLaunchSourceType:SourceTypeLaunchScreen];
        [XHLaunchAd setWaitDataDuration:5];
    }
    //获取初始化配置
    @weakify(self)
    [ESNetworkService getAppInitInfo:^(id dict, ESError *error) {
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSDictionary *dic = dict[@"data"];
            dispatch_async(dispatch_get_main_queue(), ^{
                GallopAdvertisementModel *model = [GallopAdvertisementModel mj_objectWithKeyValues:dic];
                if (!QM_IS_STR_NIL(dic[@"startImage"])) {
                    if (!isFromPush) {
                        [self setupXHLaunchAdWithDict:model andImageUrl:model.startAdvertisementContent];
                    }
                }
                
                [[NSUserDefaults standardUserDefaults] setBool:model.iosState forKey:kIOSState];
                App_Utility.currentUser.customerServiceTel = model.customerServiceTel;
                [App_Utility saveCurrentUser];
                
                [SystemManager setEventTopicId:model.eventTopicId];
                [SystemManager setEventTopicName:model.eventTopicName];
            });
        }
    }];
#endif
}

#pragma mark -
/**
广告显示完成代理方法
*/
- (void)xhLaunchAdShowFinish:(XHLaunchAd *)launchAd {
    NSLog(@"广告显示完成");
    [[NSNotificationCenter defaultCenter] postNotificationName:kADLunchFinish object:nil userInfo:nil];
}

/**
广告点击事件代理方法
*/
- (void)xhLaunchAd:(XHLaunchAd *)launchAd clickAndOpenModel:(id)openModel clickPoint:(CGPoint)clickPoint {
    NSLog(@"广告点击事件");
    if(!openModel) return;
    GallopAdvertisementModel *model = (GallopAdvertisementModel *)openModel;
	if (QM_IS_STR_NIL(model.startImageContent) || QM_IS_STR_NIL(model.startImageId)) {
		return;
	}
    [ESNetworkService hitsStartImageWithImageId:model.startImageId Response:^(id dict, ESError *error) {
    }];
	//跳转处理
    [self clickToBannerOrHeadlinesWithModel:model withSource:@"开屏广告"];
}

- (void)clickToBannerOrHeadlinesWithModel:(GallopAdvertisementModel *)model withSource:(NSString *)source {
    if (QM_IS_STR_NIL(model.type)) {
        return;
    }
    /// NOT_LINKED：纯图
    if ([model.type isEqualToString:@"NOT_LINKED"]) {
        return;
    }else if ([model.type isEqualToString:@"URL"]) {
        /// 跳转网页
        if (![CommonUtils isEqualToNonNull:model.linkTo]) {
            return;
        }
        WTCContentViewController *vc = [WTCContentViewController new];
        vc.url = model.linkTo;
        vc.contentType = WTCContentTypeNav;
        [self pushViewController:vc];
        
    }else if ([model.type isEqualToString:@"ARTICLE"]) {
        if (![CommonUtils isEqualToNonNull:model.linkTo]) {
            return;
        }
        ESBanner *banner = [ESBanner mj_objectWithKeyValues:[model.linkTo mj_JSONObject]];
        /// 跳转文章
        PaperContentViewController *vc = [PaperContentViewController new];
        banner.textFormat = @"1";
        vc.banerModel = banner;
        [self pushViewController:vc];
        
    }else if ([model.type isEqualToString:@"APP_PAGE"]) {
        if ([model.businessType isEqualToString:@"POST"]) {
            /// 跳转帖子
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
            vc.postId = [[linkTo objectForKey:@"postId"] integerValue];
            [self pushViewController:vc];
        }else if ([model.businessType isEqualToString:@"PLAN"]) {
            /// 跳转方案详情
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
            vc.planId = [[linkTo objectForKey:@"planId"] integerValue];
            vc.sourcePage = source;
            [self pushViewController:vc];
        }else if ([model.businessType isEqualToString:@"EXPERT"]) {
            /// 专家主页
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            ExpertDetailViewController*vc = [ExpertDetailViewController new];
            vc.expertId = [linkTo objectForKey:@"expertId"];
            vc.sourcePage = source;
            vc.hidesBottomBarWhenPushed = YES;
            [self pushViewController:vc];
        }else if ([model.businessType isEqualToString:@"RECHARGE_PAGE"]) {
            //充值
            if (![App_Utility checkCurrentUser]) {
                [App_Utility showLoginViewController];
            }else{
                [self pushViewController:[[PayViewController alloc] init]];
            }
        }else if ([model.businessType isEqualToString:@"MATCH"]) {
            /// 比赛页面
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            NSString *field = [linkTo objectForKey:@"field"];
            if (![CommonUtils isEqualToNonNull:field]) {
                return;
            }
            if (![CommonUtils isEqualToNonNull:[linkTo objectForKey:@"matchId"]]) {
                return;
            }
            MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
            liveVC.field = field.integerValue;
            liveVC.matchId = [[linkTo objectForKey:@"matchId"] integerValue];
            liveVC.sourcePage = source;
            [self pushViewController:liveVC];
        }
    }
}


#pragma mark -
- (void)pushViewController:(UIViewController *)vc {
    UITabBarController *rootVC = ((UITabBarController *)self.window.rootViewController);
    UINavigationController*nav = rootVC.selectedViewController;
    [vc setHidesBottomBarWhenPushed:YES];
    [nav pushViewController:vc animated:YES];
}

#pragma mark 友盟推送
-(void)setupUMengPushWithOptions:(NSDictionary *)launchOptions
{
    //    [UMessage startWithAppkey:kUmengPushKey launchOptions:launchOptions];
    [UMessage setLogEnabled:YES];
    
    [UMessage startWithAppkey:kUmengPushKey launchOptions:launchOptions httpsEnable:YES];
    
    [UMessage registerForRemoteNotifications];
    
    [UMessage openDebugMode:SandBox];
    
	if (@available(iOS 10.0, *)) {
		UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
		center.delegate=self;
		UNAuthorizationOptions types10=UNAuthorizationOptionBadge|  UNAuthorizationOptionAlert|UNAuthorizationOptionSound;
		[center requestAuthorizationWithOptions:types10     completionHandler:^(BOOL granted, NSError * _Nullable error) {
			if (granted) {
				//点击允许
				//这里可以添加一些自己的逻辑
			} else {
				//点击不允许
				//这里可以添加一些自己的逻辑
			}
		}];
	}
}

-(void)userNotificationCenter:(UNUserNotificationCenter *)center willPresentNotification:(UNNotification *)notification withCompletionHandler:(void (^)(UNNotificationPresentationOptions))completionHandler API_AVAILABLE(ios(10.0)){
    NSDictionary * userInfo = notification.request.content.userInfo;
    WTCLog(@"push1%@",userInfo);
    if([notification.request.trigger isKindOfClass:[UNPushNotificationTrigger class]]) {
        //应用处于前台时的远程推送接受
        //关闭U-Push自带的弹出框
        [UMessage setAutoAlert:NO];
        //必须加这句代码
        [UMessage didReceiveRemoteNotification:userInfo];
        
    }else{
        //应用处于前台时的本地推送接受
    }
    //当应用处于前台时提示设置，需要哪个可以设置哪一个
    if (!QM_IS_DICT_NIL(userInfo)) {
        NSString*payloadMsg=[userInfo objectForKey:@"payload"];
        if (!QM_IS_STR_NIL(payloadMsg)) {
            NSData*payLoadDat=[payloadMsg dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary*payload=[NSJSONSerialization JSONObjectWithData:payLoadDat options:NSJSONReadingMutableLeaves error:nil];
            if (!QM_IS_DICT_NIL(payload)) {
                NSString*pushType = [payload objectForKey:@"pushType"];
                if (pushType.integerValue>10030000&&pushType.integerValue<10031000) {
                    return;
                }
            }
        }else{
            NSDictionary*payload=userInfo;
            if (!QM_IS_DICT_NIL(payload)) {
                NSString*pushType = [payload objectForKey:@"pushType"];
                if (pushType.integerValue>10030000&&pushType.integerValue<10031000) {
                    return;
                }
            }
        }
    } completionHandler(UNNotificationPresentationOptionSound|UNNotificationPresentationOptionBadge|UNNotificationPresentationOptionAlert);
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    WTCLog(@"push3%@",userInfo);
    [UMessage didReceiveRemoteNotification:userInfo];
    
    if (!QM_IS_DICT_NIL(userInfo)) {
        NSString*payloadMsg=[userInfo objectForKey:@"payload"];
        if (!QM_IS_STR_NIL(payloadMsg)) {
            NSData*payLoadDat=[payloadMsg dataUsingEncoding:NSUTF8StringEncoding];
            NSDictionary*payload=[NSJSONSerialization JSONObjectWithData:payLoadDat options:NSJSONReadingMutableLeaves error:nil];
            [self gh_dealPushData:payload];
        }else{
            NSDictionary*payload=userInfo;
            [self gh_dealPushData:payload];
        }
    }
    if ([UIApplication sharedApplication].applicationState == UIApplicationStateActive || [UIApplication sharedApplication].applicationState == UIApplicationStateBackground) {
        //App在前台收到推送
        [[NSNotificationCenter defaultCenter] postNotificationName:@"openAPPReceiveRemoteNotification" object:nil userInfo:userInfo];
        
        
    }else{
        //App在后台收到推送
        [[NSNotificationCenter defaultCenter] postNotificationName:@"closeAPPReceiveRemoteNotification" object:nil userInfo:userInfo];
        
        
    }
    //    }
    completionHandler(UIBackgroundFetchResultNewData);
    
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo {
    WTCLog(@"push2%@",userInfo);
    [UMessage didReceiveRemoteNotification:userInfo];
}

#pragma mark - 反馈悬浮窗
- (void)addFeedBackWindow {
	UIImageView *imageView = [[UIImageView alloc] init];
	imageView.image = GetImage(@"feedBack");
	imageView.userInteractionEnabled = YES;
	[self.window addSubview:imageView];
	[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.window).offset(-15);
		make.bottom.equalTo(self.window).offset(-70);
		make.size.mas_equalTo(CGSizeMake(40,40));
	}];
	UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(openFeedBackPage)];
	[imageView addGestureRecognizer:tap];
	imageView.tag = 12345;
	imageView.hidden = YES;
}

- (void)openFeedBackPage {
	/** 设置App自定义扩展反馈数据 */
	NSString *userId = App_Utility.currentUser.userId.stringValue;
	ES_LPUnitily.feedbackKit.extInfo = @{@"loginTime":[[NSDate date] description],
							 @"visitPath":@"悬浮窗",
							 @"userid":QM_STR_NOT_NIL(userId)};
	
	__weak typeof(self) weakSelf = self;
	[ES_LPUnitily.feedbackKit makeFeedbackViewControllerWithCompletionBlock:^(YWFeedbackViewController *viewController, NSError *error) {
		if (viewController != nil) {
			UINavigationController *nav = [[ESNavigationViewController alloc] initWithRootViewController:viewController];
			[weakSelf.window viewWithTag:12345].hidden = YES;
			[weakSelf.window.rootViewController presentViewController:nav animated:YES completion:nil];
			
			[viewController setCloseBlock:^(UIViewController *aParentController){
				[weakSelf.window viewWithTag:12345].hidden = NO;
				[aParentController dismissViewControllerAnimated:YES completion:nil];
			}];
		}
	}];
}

#pragma mark 开屏广告
/****************开屏广告设置*************/
-(void)setupXHLaunchAdWithDict:(GallopAdvertisementModel *)model andImageUrl:(NSString*)imageUrl
{
    //配置广告数据
    XHLaunchImageAdConfiguration *imageAdconfiguration = [XHLaunchImageAdConfiguration new];
    //广告停留时间
    imageAdconfiguration.duration = 5;
    
    imageAdconfiguration.frame =  CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width * 16.0/9.0);
    //广告图片URLString/或本地图片名(.jpg/.gif请带上后缀)
    imageAdconfiguration.imageNameOrURLString = imageUrl;
    //缓存机制(仅对网络图片有效)
    imageAdconfiguration.imageOption = XHLaunchAdImageDefault;
    //图片填充模式
    imageAdconfiguration.contentMode = UIViewContentModeScaleAspectFill;
    //广告点击打开页面参数(openModel可为NSString,模型,字典等任意类型)
    imageAdconfiguration.openModel = model;
    //广告显示完成动画
    imageAdconfiguration.showFinishAnimate = ShowFinishAnimateFlipFromLeft;
    //广告显示完成动画时间
    imageAdconfiguration.showFinishAnimateTime = 0.8;
    //跳过按钮类型
    imageAdconfiguration.skipButtonType = SkipTypeTimeText;
    //后台返回时,是否显示广告
    imageAdconfiguration.showEnterForeground = NO;
    //显示开屏广告
    [XHLaunchAd imageAdWithImageAdConfiguration:imageAdconfiguration delegate:self];
}

#pragma mark tabbarDelegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
	if (viewController == [tabBarController.viewControllers objectAtIndex:4]) {
		if (![App_Utility checkCurrentUser]) {
			[App_Utility showLoginViewController];
			[tabBarController setSelectedIndex:0];
			return NO;
		}
		[ES_LPUnitily removeHUDToCurrentView];
	}
	
	return YES;
}

-(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options
{
	if ([url.scheme isEqualToString:@"gallop"]){
		//分类中处理业务跳转
		[self applicationBusinessProcessWithURL:url];
	}
	if ([url.absoluteString containsString:kWxKey]){
		//微信
		return [WXApi handleOpenURL:url delegate:self];
	}
	return YES;
}

-(void) onReq:(BaseReq*)req
{
    NSLog(@"hakdhskdhaslkdjsalkdjalskjdklasjdsadj\nahkdjhsajkhdkjas\n");
}

-(void) onResp:(BaseResp*)resp
{
	if ([resp isMemberOfClass:[SendAuthResp class]])  {
		SendAuthResp *aresp = (SendAuthResp *)resp;
		if (aresp.errCode != 0 ) {
			dispatch_async(dispatch_get_main_queue(), ^{
				[CMMUtility showToastWithText:@"微信授权失败"];
			});
			return;
		}
		NSString *code = aresp.code;
		[self getWeiXinOpenId:code];
	}
}

- (void)getWeiXinOpenId:(NSString *)code{
	//微信返回信息后,会跳到登录页面,添加通知进行其他逻辑操作
	[[NSNotificationCenter defaultCenter] postNotificationName:kWechatLoginSuccess object:code];
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void(^)(NSArray<id<UIUserActivityRestoring>> * __nullable restorableObjects))restorationHandler {
	return [WXApi handleOpenUniversalLink:userActivity delegate:self];
}

- (void)scene:(UIScene *)scene continueUserActivity:(NSUserActivity *)userActivity  API_AVAILABLE(ios(13.0)){
	
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    //重置角标
     application.applicationIconBadgeNumber = 0;
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    [ES_LPUnitily removeHUDToSystemWindow];
    [ES_LPUnitily removeHUDToCurrentView];
    //重置角标
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
    //检查更新
    [ESNetworkService checkVersonResponse:^(id dict, ESError *error) {
        
    }];
}


- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


#pragma mark - lazy init
- (WTCTabBarViewController *)matchTabBarVC {
	if (!_matchTabBarVC) {
		_matchTabBarVC = [[WTCTabBarViewController alloc]init];
		_matchTabBarVC.delegate = self;
	}
	return _matchTabBarVC;
}


@end
