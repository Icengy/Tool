//
//  AppColorDefine.h
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/26.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#ifndef AppColorDefine_h
#define AppColorDefine_h

/** 背景颜色*/
//#define ColorDefaultBackground RGBCOLORV(0xf4f4f4)
#define ColorDefaultBackground [UIColor whiteColor]
#define ColorDefaultGrayBackground RGBCOLORV(0xF1F1F1)
#define ColorDefaultLightGrayBackground RGBCOLORV(0xFAFAFA)

/** 导航栏颜色*/
#define NavgationBarColor RGBCOLORV(0xffffff)
//#define NavgationBarColor      RGBCOLORV(0xf42a24)
//#define NavgationBarColor       RGBCOLOR(227, 23, 13)

/** 大标题颜色*/
#define ColorLargeTitle [UIColor blackColor]
/** 标题颜色*/
#define ColorTitle RGBCOLORV(0x15151A)
/** 副标题颜色*/
#define ColorSubTitle RGBCOLORV(0x666666)
/** 灰色*/
#define ColorGray RGBCOLORV(0x757575)
/** 亮灰色*/
#define ColorTextLightGray RGBCOLORV(0x111111)
/** 内容颜色*/
#define ColorBaseText RGBCOLORV(0x888888)
/** 占位字体颜色*/
#define ColorPlaceText RGBCOLOR(192, 192, 192)

/** 线颜色*/
#define ColorLineGray RGBCOLORV(0xeaeaea)
/** 红球颜色*/
#define ColorBallRed RGBCOLOR(255, 75, 75)
/** 篮球颜色*/
#define ColorBallBlue RGBCOLOR(15, 145, 235)
/** 黄球颜色*/
#define ColorBallYellow RGBCOLOR(255, 185, 0)
/** 背景绿*/
#define ColorBackgroundGreen RGBCOLOR(95, 197, 168);
/** 订单页HeaderSection深灰*/
#define ColorHeaderSectionDarkGray RGBCOLOR(218, 218, 218)
/** 结果页HeaderSection灰*/
#define ColorHeaderSectionGray RGBCOLOR(241, 241, 241)
/** 竞彩HeaderSection白色*/
#define ColorJCHeaderSectionWhite RGBCOLORV(0xffffff)
/** 竞彩HeaderSection深灰*/
#define ColorJCHeaderSectionDarkGray RGBCOLORV(0xe3e3e3)
/** 红色按钮颜色*/
#define ColorButtonRed  RGBCOLORV(0xf42a24)
/**粉色界面颜色*/
#define ColorPink RGBCOLORV(0xff6161)
/**主题绿**/
#define ColorAppGreen RGBCOLORV(0x3BB197)
/**主题红**/
#define ColorAppRed RGBCOLORV(0xFD0230)
/**主题黑**/
#define ColorAppBlack RGBCOLORV(0x15151A)
/**x灰色底线**/
#define ColorGrayBack RGBCOLORV(0xE7E7E7)
/**灰色字体颜色**/
#define ColorTextGray RGBCOLORV(0xA8A8A8)

/**主题红色**/
#define ColorMainAppRed RGBCOLORV(0xDE3C31)
/**主题蓝色**/
#define ColorMainAppBlue RGBCOLORV(0x1489FB)
/**选中主题红色**/
#define ColorMainAppDarkRed RGBCOLORV(0xBA3224)
/**默认黑色**/
#define ColorMainNormalBlack RGBCOLORV(0x282828)
/**选中底色蓝色**/
#define ColorMainBlue RGBCOLORV(0x5EB1FF)


/**比赛-主队颜色(红)**/
#define ColorMatchHost    RGBCOLORV(0xFF4D4D)
/**比赛-客队颜色(绿)**/
#define ColorMatchGuest   RGBCOLORV(0x4493F7)


#endif /* AppColorDefine_h */

#define ColorWin RGBCOLORV(0xDE3C31)

#define ColorLoss RGBCOLORV(0x00AE09)

#define ColorGuest RGBCOLORV(0x4493F7)

#define ColorHost RGBCOLORV(0xFF4D4D)

#define ColorDaw RGBCOLORV(0xFFC138)

#define Color88 RGBCOLORV(0x888888)

#define ColorF4 RGBCOLORV(0xF4F4F4)

#define Color66 RGBCOLORV(0x666666)

#define ColorFootBall RGBCOLORV(0xDE3C31)

#define ColorBasketBall RGBCOLORV(0x1489FB)

#define Color99 RGBCOLORV(0x999999)

