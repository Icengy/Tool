//
//  ShopProductShareVC.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/16.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ShopProductShareVC.h"

@interface ShopProductShareVC ()
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UIView *shareContentView;
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *productNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *orginPriceTitleLabel;
@property (weak, nonatomic) IBOutlet UIView *originLineView;

@property (weak, nonatomic) IBOutlet UILabel *orginPriceLabel;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UIImageView *shareCodeIamgeView;

@end

@implementation ShopProductShareVC

- (void)viewDidLoad {
    [super viewDidLoad];
	self.view.backgroundColor = [UIColor clearColor];
	self.contentView.backgroundColor = RGBA_COLOR(0, 0, 0, 0.45);
	[self setupView];
}

- (void)setupView {
	NSData *data = [NSData dataFromBase64String:self.model.wechatMiniProgramCode];
	[self.headImage sd_setImageWithURL:[NSURL URLWithString:self.model.headImg]];
	self.productNameLabel.text = self.model.name;
	self.priceLabel.text = [@"￥" stringByAppendingString:self.model.discountPrice];
	self.orginPriceLabel.text = self.model.price;
	self.shareCodeIamgeView.image = [UIImage imageWithData:data];
	
	if ([self.model.discountPrice isEqualToString:self.model.price]) {
		self.orginPriceLabel.hidden = YES;
		self.orginPriceTitleLabel.hidden = YES;
		self.originLineView.hidden = YES;
		self.priceTitleLabel.text = @"售价";
	} else {
		self.orginPriceLabel.hidden = NO;
		self.orginPriceTitleLabel.hidden = NO;
		self.originLineView.hidden = NO;
		self.priceTitleLabel.text = @"特价";
	}
	
	//虚线
	[self drawDottedLine];
}

-(void)drawDottedLine{
	CAShapeLayer *dotteShapeLayer = [CAShapeLayer layer];
	CGMutablePathRef dotteShapePath =  CGPathCreateMutable();
	//设置虚线颜色为blackColor
	[dotteShapeLayer setStrokeColor:RGBCOLOR(231, 231, 231).CGColor];
	//设置虚线宽度
	dotteShapeLayer.lineWidth = 1.0f;
	//10=线的宽度 5=每条线的间距
	NSArray *dotteShapeArr = [[NSArray alloc] initWithObjects:[NSNumber numberWithInt:4],[NSNumber numberWithInt:2], nil];
	[dotteShapeLayer setLineDashPattern:dotteShapeArr];
	CGPathMoveToPoint(dotteShapePath, NULL, 0 ,0);
	CGPathAddLineToPoint(dotteShapePath, NULL, self.lineView.width, 0);
	[dotteShapeLayer setPath:dotteShapePath];
	CGPathRelease(dotteShapePath);
	//把绘制好的虚线添加上来
	[self.lineView.layer addSublayer:dotteShapeLayer];
}

//截屏
- (UIImage *)getShareImage {
	UIImage* image = nil;
	
	//把View绘制成UIImage
	UIGraphicsBeginImageContextWithOptions(self.shareContentView.size, NO, [UIScreen mainScreen].scale);
	CGContextRef ctx = UIGraphicsGetCurrentContext();
	[self.shareContentView.layer renderInContext:ctx];
	image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return image;
}

//type : 0 - 聊天 1 - 朋友圈
- (void)weChatShareWithImage:(UIImage *)image type:(int)type{
	[ESNetworkService completeShareTaskWithResponse:^(id dict, ESError *error) {
	}];
	
	if([WXApi isWXAppInstalled]){//判断当前设备是否安装微信客户端
		NSData *imageData = UIImageJPEGRepresentation(image, 0.7);
		
		WXImageObject *imageObject = [WXImageObject object];
		imageObject.imageData = imageData;
		
		WXMediaMessage *message = [WXMediaMessage message];
		message.thumbData = nil;
		message.mediaObject = imageObject;
		
		SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
		req.bText = NO;
		req.message = message;
		req.scene = type;
		[WXApi sendReq:req completion:nil];
	}else{
		//未安装微信应用或版本过低
		NSArray *activityItemsArray = @[image];
		NSArray *activityArray = @[];
		
		// 2、初始化控制器，添加分享内容至控制器
		UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItemsArray applicationActivities:activityArray];
		activityVC.modalInPopover = YES;
		// 3、设置回调
		UIActivityViewControllerCompletionWithItemsHandler itemsBlock = ^(UIActivityType __nullable activityType, BOOL completed, NSArray * __nullable returnedItems, NSError * __nullable activityError){
			NSLog(@"activityType == %@",activityType);
			if (completed == YES) {
				NSLog(@"completed");
			}else{
				NSLog(@"cancel");
			}
		};
		activityVC.completionWithItemsHandler = itemsBlock;
		[self presentViewController:activityVC animated:YES completion:nil];
	}
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
	NSString *msg = nil ;
	if(error != NULL){
		msg = @"图片保存失败" ;
	}else{
		msg = @"图片保存成功，可到相册查看" ;
	}
	[CMMUtility showToastWithText:msg];
}

//微信好友
- (IBAction)wechatClick:(id)sender {
	//获取分享截图
	UIImage *shareImage = [self getShareImage];
	if (!shareImage) {
		[CMMUtility showToastWithText:@"获取分享截图失败,请重试"];
		return;
	}
	//微信
	[self weChatShareWithImage:shareImage type:0];
}

//朋友圈
- (IBAction)circleClick:(id)sender {
	//获取分享截图
	UIImage *shareImage = [self getShareImage];
	if (!shareImage) {
		[CMMUtility showToastWithText:@"获取分享截图失败,请重试"];
		return;
	}
	//朋友圈
	[self weChatShareWithImage:shareImage type:1];
}

//本地相册
- (IBAction)photoClick:(id)sender {
	//获取分享截图
	UIImage *shareImage = [self getShareImage];
	if (!shareImage) {
		[CMMUtility showToastWithText:@"获取分享截图失败,请重试"];
		return;
	}
	//本地保存
	UIImageWriteToSavedPhotosAlbum(shareImage, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
}

- (IBAction)cancelClick:(id)sender {
	[self dismissViewControllerAnimated:YES completion:nil];
}
@end
