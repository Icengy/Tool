//
//  ShopViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/16.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ShopViewController.h"
#import "ShopProductListVC.h"
#import "ShopCategoryListModel.h"

@interface ShopViewController ()
//view
@property (nonatomic,strong) UIScrollView *segmentSrollView;
@property (nonatomic,strong) UIScrollView *bgScrollView;
@property (nonatomic,strong) UIView		  *refreshView;
//data
@property (nonatomic,strong) ShopCategoryListModel *model;
@property (nonatomic,strong) NSMutableArray *vcArr;
@property (nonatomic,strong) NSMutableArray<UIButton *> *segmentArr;
@property (nonatomic,assign) NSUInteger currentType;
@end

@implementation ShopViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	self.navigationItem.title = @"飞驰商城";
	self.vcArr = [NSMutableArray array];
	[self loadData];
}

- (void)loadData {
	[ESNetworkService getShopProductCategoryList:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.refreshView.hidden = YES;
			self.model = [ShopCategoryListModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				[self setupView];
			});
		} else {
			//接口调用失败显示重试页面
			self.refreshView.hidden = NO;
		}
	}];
}

- (void)setupView {
	if (QM_IS_ARRAY_NIL(self.model.categories)) {
		//防止崩溃
		return;
	}
	self.bgScrollView.contentSize = CGSizeMake(self.model.categories.count * SCREEN_WIDTH, SCREEN_HEIGHT - 50 - NavBarHeight - kBottomSafeArea);
	[self.model.categories enumerateObjectsUsingBlock:^(CategoriesItem *item, NSUInteger idx, BOOL * _Nonnull stop) {
		UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
		[btn setTitle:item.name forState:UIControlStateNormal];
		[btn setTitleColor:RGBCOLOR(168, 168, 168) forState:UIControlStateNormal];
		[btn setTitleColor:ColorAppRed forState:UIControlStateSelected];
		btn.titleLabel.font = fcBoldFont(15);
		btn.tag = idx;
		[btn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		[self.segmentArr addObject:btn];
		[self.segmentSrollView addSubview:btn];
		//vc
		ShopProductListVC *vc = [[ShopProductListVC alloc] init];
		vc.categoryId = item.categoryId;
		[self.vcArr addObject:vc];
		[self addChildViewController:vc];
		[self.bgScrollView addSubview:vc.view];
		//layout
		if (idx == 0) {
			[btn mas_makeConstraints:^(MASConstraintMaker *make) {
				make.centerY.equalTo(self.segmentSrollView);
				make.left.equalTo(self.segmentSrollView).offset(15);
			}];
			btn.selected = YES;
		} else if (idx == self.model.categories.count - 1) {
			[btn mas_makeConstraints:^(MASConstraintMaker *make) {
				make.centerY.equalTo(self.segmentSrollView);
				make.left.equalTo(self.segmentArr[idx - 1].mas_right).offset(20);
				make.right.equalTo(self.segmentSrollView).offset(-15);
			}];
		} else {
			[btn mas_makeConstraints:^(MASConstraintMaker *make) {
				make.centerY.equalTo(self.segmentSrollView);
				make.left.equalTo(self.segmentArr[idx - 1].mas_right).offset(20);
			}];
		}
		vc.view.frame= CGRectMake(SCREEN_WIDTH * idx, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 50 - NavBarHeight - kBottomSafeArea);
	}];
	[self.vcArr[0] firstLoad];
}

#pragma mark - action
- (void)swithBtnClick:(UIButton *)btn {
	[self.segmentArr enumerateObjectsUsingBlock:^(UIButton *button, NSUInteger idx, BOOL * _Nonnull stop) {
		button.selected = NO;
		button.titleLabel.font = fcBoldFont(15);
	}];
	
	if (btn.selected) {
		return;
	} else {
		btn.selected = YES;
		[self.vcArr[btn.tag] firstLoad];
	}
	
	self.currentType = btn.tag;
	btn.titleLabel.font = fcBoldFont(16);
	CGRect frame = [btn convertRect:btn.bounds toView:APP_DELEGATE.window];
	CGFloat offset = CGRectGetMidX(frame) - SCREEN_WIDTH / 2;
	CGFloat contentOffset = offset + self.segmentSrollView.contentOffset.x;
	if (contentOffset < self.segmentSrollView.contentSize.width - SCREEN_WIDTH) {
		if (contentOffset <= 0) {
			[self.segmentSrollView setContentOffset:CGPointZero animated:YES];
		} else {
			[self.segmentSrollView setContentOffset:CGPointMake(contentOffset, 0) animated:YES];
		}
	}
	[self.bgScrollView setContentOffset:CGPointMake(SCREEN_WIDTH * btn.tag, 0) animated:NO];
}

#pragma mark - lazy init
- (NSMutableArray<UIButton *> *)segmentArr {
	if (!_segmentArr) {
		_segmentArr = [NSMutableArray array];
	}
	return _segmentArr;
}

- (UIScrollView *)segmentSrollView {
	if (!_segmentSrollView) {
		_segmentSrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, NavBarHeight, SCREEN_WIDTH, 50)];
		_segmentSrollView.showsHorizontalScrollIndicator = NO;
		[self.view addSubview:_segmentSrollView];
	}
	return _segmentSrollView;
}

- (UIScrollView *)bgScrollView {
	if (!_bgScrollView) {
		_bgScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 50 + NavBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight - 50 - kBottomSafeArea)];
		_bgScrollView.scrollEnabled = NO;
		_bgScrollView.showsHorizontalScrollIndicator = NO;
		[self.view addSubview:_bgScrollView];
	}
	return _bgScrollView;
}

- (UIView *)refreshView {
	if (!_refreshView) {
		_refreshView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
		_refreshView.backgroundColor = [UIColor whiteColor];
		_refreshView.userInteractionEnabled = YES;
		[self.view addSubview:_refreshView];
		[self.view bringSubviewToFront:_refreshView];
		
		UIImageView *imageView = [UIImageView new];
		imageView.image = GetImage(@"no_data_withoutword");
		[_refreshView addSubview:imageView];
		
		UILabel *label = [UILabel new];
		label.textColor = RGBCOLOR(231, 231, 231);
		label.font = fcFont(16);
		label.text = @"加载失败,请重试";
		[_refreshView addSubview:label];
		
		//调整布局
		[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(_refreshView);
			make.centerY.equalTo(_refreshView).offset(-10);
			make.size.mas_equalTo(CGSizeMake(300, 300));
		}];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(imageView);
			make.top.equalTo(imageView.mas_bottom).offset(5);
		}];
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(loadData)];
		[_refreshView addGestureRecognizer:tap];
		_refreshView.hidden = YES;
	}
	return _refreshView;
}
@end
