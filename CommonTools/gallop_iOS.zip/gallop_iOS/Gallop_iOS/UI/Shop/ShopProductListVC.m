//
//  ShopProductListVC.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/16.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ShopProductListVC.h"
#import "ShopProductListModel.h"
#import "ShopProductTagsModel.h"
#import "ShopProductCell.h"
#import "ShopTagCell.h"
#import "ShopTagProductListViewController.h"
#import "WTCContentViewController.h"
#import "GoodsDetailViewController.h"
#import "ShopCartViewController.h"
#import "NavButton.h"
#import "dsbridge.h"

#define kShopProductCellIdentifier @"ShopProductCellIdentifier"
#define kShopTagCellIdentifier @"ShopTagCellIdentifier"
#define kPageSize 20

@interface ShopProductListVC ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,WKNavigationDelegate>
@property (nonatomic, strong) ShopProductListModel *productModel;
@property (nonatomic, strong) ShopProductTagsModel *tagsModel;
@property (nonatomic, assign) BOOL isFirstLoad;
@property (nonatomic, assign) NSUInteger currentPage;
@property (nonatomic, strong) NSMutableArray *tagArr;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic,strong) NavButton *cartBtn;
@property (nonatomic,strong) UILabel *cartCountL;
@property (nonatomic,strong) UIView		  *noDataView;
@property (nonatomic,strong) DWKWebView	  *activityWebView;

//timeCount
@property (nonatomic,strong) NSTimer *timer;
@end

@implementation ShopProductListVC
- (void)dealloc {
	[self.timer invalidate];
	self.timer = nil;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	self.isFirstLoad = YES;
	self.tagArr = [NSMutableArray array];
	[self setupView];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[ESNetworkService getShopCartCountWithResponse:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary*data = dict[@"data"];
			NSString*count = [data[@"skuCount"] stringValue];
			dispatch_main_async_safe(^{
				if (count.integerValue > 0) {
					self.cartCountL.text = count.intValue > 99 ? @"99+" : count;
					self.cartCountL.hidden = NO;
				} else {
					self.cartCountL.hidden = YES;
				}
			});
		}
	}];
}

- (void)setupView {
	self.view.backgroundColor = [UIColor whiteColor];
	[self.view addSubview:self.collectionView];
    [self.collectionView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.collectionView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];

	[self.cartBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.view).offset(-17);
		make.bottom.equalTo(self.view).offset(-22.55);
		make.size.mas_equalTo(CGSizeMake(40, 40));
	}];
}

- (void)firstLoad {
	if (self.isFirstLoad) {
		self.isFirstLoad = NO;
		[self.collectionView.mj_header beginRefreshing];
	}
}

- (void)loadData {
	dispatch_group_t group = dispatch_group_create();
	@weakify(self)
	
	dispatch_group_enter(group);
	dispatch_group_enter(group);
	self.currentPage = 1;
	[ESNetworkService getShopProductListWithCategoryId:self.categoryId Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.collectionView.mj_header endRefreshing];
		});
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.productModel = [ShopProductListModel mj_objectWithKeyValues:dict[@"data"]];
		}
		dispatch_group_leave(group);
	}];
	
	[ESNetworkService getShopTagLIstWithCategoryId:self.categoryId Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.tagsModel = [ShopProductTagsModel mj_objectWithKeyValues:dict[@"data"]];
		}
		dispatch_group_leave(group);
	}];
	dispatch_group_notify(group, dispatch_get_main_queue(), ^{
		[self.activityWebView.scrollView.mj_header endRefreshing];
		[self.collectionView.mj_header endRefreshing];
		//海报显隐

		if (self.productModel.activitySwitch) {
			self.activityWebView.hidden = NO;
			[self.view bringSubviewToFront:self.activityWebView];
			[self.view bringSubviewToFront:self.cartBtn];
			[self.activityWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.productModel.activityPosterVO.h5Url]]];
			
			//reset timer
			[self.timer invalidate];
			self.timer = nil;
			self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeHandle) userInfo:nil repeats:YES];
			[[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
		} else {
			self.activityWebView.hidden = YES;
			[self.view bringSubviewToFront:self.cartBtn];
		}
		//标签
		[self.tagArr removeAllObjects];
		[self.tagArr addObjectsFromArray:self.tagsModel.tags];
		//商品
		if (self.productModel.page >= self.productModel.pageCount) {
			[self.collectionView.mj_footer endRefreshingWithNoMoreData];
			self.collectionView.mj_footer.hidden = YES;
		} else {
			self.collectionView.mj_footer.hidden = NO;
			[self.collectionView.mj_footer resetNoMoreData];
		}
		[self.dataSource removeAllObjects];
		[self.dataSource addObjectsFromArray:self.productModel.products];
		
		[self.collectionView reloadData];
	});
}

- (void)loadMoreData {
	self.currentPage ++;
	@weakify(self)
	[ESNetworkService getShopProductListWithCategoryId:self.categoryId Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.collectionView.mj_footer endRefreshing];
		});
		@strongify(self)
		ShopProductListModel *model = [ShopProductListModel mj_objectWithKeyValues:dict[@"data"]];
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.collectionView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.dataSource addObjectsFromArray:model.products];
				[self.collectionView reloadData];
			});
		}
	}];
}

#pragma mark - timer
- (void)timeHandle {
	self.productModel.activityPosterVO.differenceTime -= 1000;
	if (self.productModel.activityPosterVO.differenceTime <= 0) {
		//关闭计时器
		[self.timer invalidate];
		self.timer = nil;
		[self loadData];
	}
}

#pragma mark - action
- (void)goShopCart {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//跳转购物车
	ShopCartViewController *vc = [[ShopCartViewController alloc] init];
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark UICollectionView代理
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
	if (section == 0) {
		if (QM_IS_ARRAY_NIL(self.tagArr)) {
			return 0;
		} else {
			return self.tagArr.count;
		}
	} else {
		if (QM_IS_ARRAY_NIL(self.dataSource)) {
			self.noDataView.hidden = NO;
			return 0;
		} else {
			self.noDataView.hidden = YES;
			return self.dataSource.count;
		}
	}
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
	return 2;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		return CGSizeMake(SCREEN_WIDTH / 4, 88);
	} else {
		return CGSizeMake(SCREEN_WIDTH / 2, SCREEN_WIDTH / 2  + 78);
	}
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section == 0) {
		ShopTagCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kShopTagCellIdentifier forIndexPath:indexPath];
		[cell configCellWithModel:self.tagArr[indexPath.row] indexPath:indexPath];
		return cell;
	} else {
		ShopProductCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kShopProductCellIdentifier forIndexPath:indexPath];
		[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath];
		return cell;
	}
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		//点击标签
		TagsItem *item = self.tagArr[indexPath.row];
		ShopTagProductListViewController *vc = [[ShopTagProductListViewController alloc] init];
		vc.tagId = item.tagId;
		vc.categoryId = self.categoryId;
		vc.title = item.name;
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	} else {
		//点击商品
		ProductsItem *item = self.dataSource[indexPath.row];

        GoodsDetailViewController*vc = [[GoodsDetailViewController alloc] init];
        vc.productId = @(item.productId).stringValue;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
	}
}

#pragma mark - wkWebView delegate
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
}

// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
	[webView loadHTMLString:@"" baseURL:nil];
}

// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
}

// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential * _Nullable))completionHandler {
	if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
		NSURLCredential *card = [[NSURLCredential alloc]initWithTrust:challenge.protectionSpace.serverTrust];
		completionHandler(NSURLSessionAuthChallengeUseCredential,card);
	} else {
		completionHandler(NSURLSessionAuthChallengeUseCredential, nil);
	}
}

//提交发生错误时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
	
}

// 接收到服务器跳转请求即服务重定向时之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
}

// 根据WebView对于即将跳转的HTTP请求头信息和相关信息来决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
	decisionHandler(WKNavigationActionPolicyAllow);
}

// 根据客户端受到的服务器响应头以及response相关信息来决定是否可以跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
	decisionHandler(WKNavigationResponsePolicyAllow);
}

//进程被终止时调用
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView{
}


#pragma mark - lazy init
- (UICollectionView *)collectionView {
	if (!_collectionView) {
		UICollectionViewFlowLayout  *layout = [[UICollectionViewFlowLayout alloc] init];
		layout.minimumLineSpacing = 0;
		layout.minimumInteritemSpacing = 0;
		layout.scrollDirection =  UICollectionViewScrollDirectionVertical;
		layout.sectionInset = UIEdgeInsetsZero;
		
		_collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 50 - NavBarHeight - kBottomSafeArea) collectionViewLayout:layout];
		_collectionView.backgroundColor = [UIColor clearColor];
		_collectionView.showsHorizontalScrollIndicator = NO;
		_collectionView.showsVerticalScrollIndicator = NO;
		_collectionView.delegate = self;
		_collectionView.dataSource = self;
		[_collectionView registerClass:[ShopProductCell class] forCellWithReuseIdentifier:kShopProductCellIdentifier];
		_collectionView.backgroundColor = [UIColor whiteColor];
		[_collectionView registerClass:[ShopTagCell class] forCellWithReuseIdentifier:kShopTagCellIdentifier];
	}
	return _collectionView;
}

- (UIView *)noDataView {
	if (!_noDataView) {
		_noDataView = [[UIView alloc] initWithFrame:self.collectionView.bounds];
		_noDataView.backgroundColor = [UIColor whiteColor];
		_noDataView.userInteractionEnabled = YES;
		[self.collectionView addSubview:_noDataView];
		[self.collectionView bringSubviewToFront:_noDataView];
		
		UIImageView *imageView = [UIImageView new];
		imageView.image = GetImage(@"no_data_withoutword");
		[_noDataView addSubview:imageView];
		
		UILabel *label = [UILabel new];
		label.textColor = RGBCOLOR(231, 231, 231);
		label.font = fcFont(16);
		label.text = @"品类下暂无商品";
		[_noDataView addSubview:label];
		
		//调整布局
		[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(_noDataView);
			make.centerY.equalTo(_noDataView).offset(-10);
			make.size.mas_equalTo(CGSizeMake(300, 300));
		}];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(imageView);
			make.top.equalTo(imageView.mas_bottom).offset(5);
		}];
		_noDataView.hidden = YES;
	}
	return _noDataView;
}

- (WKWebView *)activityWebView {
	if (!_activityWebView) {
		//初始化
		_activityWebView = [[DWKWebView alloc] initWithFrame:self.collectionView.bounds];;
		_activityWebView.scrollView.showsVerticalScrollIndicator = NO;
		_activityWebView.scrollView.showsHorizontalScrollIndicator = NO;
		_activityWebView.hidden = YES;
		[self.view addSubview:_activityWebView];
        [_activityWebView.scrollView addRefreshHeaderWithTarget:self action:@selector(loadData)];
	}
	return _activityWebView;
}

- (NavButton*)cartBtn
{
	if(!_cartBtn){
		_cartBtn = [NavButton buttonWithType:UIButtonTypeCustom];
		[_cartBtn setImage:[UIImage imageNamed:@"shop_cart_icon"] forState:UIControlStateNormal];
		[_cartBtn addTarget:self action:@selector(goShopCart) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_cartBtn];
		
		self.cartCountL = [UILabel new];
		self.cartCountL.textColor = [UIColor whiteColor];
		self.cartCountL.backgroundColor = RGBCOLOR(240, 72, 68);
		self.cartCountL.font = fcFont(10);
		self.cartCountL.adjustsFontSizeToFitWidth = YES;
		self.cartCountL.clipsToBounds = YES;
		self.cartCountL.textAlignment = NSTextAlignmentCenter;
		self.cartCountL.layer.cornerRadius = 8;
		[_cartBtn addSubview:self.cartCountL];
		[self.cartCountL mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.top.equalTo(_cartBtn);
			make.size.mas_equalTo(CGSizeMake(16, 16));
		}];
		self.cartCountL.hidden = YES;
	}
	return _cartBtn;
}
@end
