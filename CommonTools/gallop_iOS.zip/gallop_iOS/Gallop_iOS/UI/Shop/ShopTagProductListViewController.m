//
//  ShopTagProductListViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/22.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ShopTagProductListViewController.h"
#import "ShopProductListModel.h"
#import "ShopProductTagsModel.h"
#import "ShopProductCell.h"
#import "ShopTagCell.h"
#import "NavButton.h"
#import "WTCContentViewController.h"
#import "ShopCartViewController.h"
#import "GoodsDetailViewController.h"
#import "dsbridge.h"

#define kShopProductCellIdentifier @"ShopProductCellIdentifier"
#define kShopTagCellIdentifier @"ShopTagCellIdentifier"
#define kPageSize 20

@interface ShopTagProductListViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,WKNavigationDelegate>
@property (nonatomic, strong) ShopProductListModel *productModel;
@property (nonatomic, assign) NSUInteger currentPage;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic,strong) NavButton *cartBtn;
@property (nonatomic,strong) UILabel *cartCountL;
@property (nonatomic,strong) UIView		  *noDataView;
@property (nonatomic,strong) DWKWebView	  *activityWebView;

//timeCount
@property (nonatomic,strong) NSTimer *timer;
@end

@implementation ShopTagProductListViewController
- (void)dealloc {
	[self.timer invalidate];
	self.timer = nil;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[ESNetworkService getShopCartCountWithResponse:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary*data = dict[@"data"];
			NSString*count = [data[@"skuCount"] stringValue];
			dispatch_main_async_safe(^{
				if (count.integerValue > 0) {
					self.cartCountL.text = count.intValue > 99 ? @"99+" : count;
					self.cartCountL.hidden = NO;
				} else {
					self.cartCountL.hidden = YES;
				}
			});
		}
	}];
}

- (void)setupView {
	self.view.backgroundColor = [UIColor whiteColor];
	[self.view addSubview:self.collectionView];
    [self.collectionView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.collectionView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self.collectionView.mj_header beginRefreshing];
	
	[self.cartBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.view).offset(-17);
		make.bottom.equalTo(self.view).offset(-22.55 - TabBarHeight);
		make.size.mas_equalTo(CGSizeMake(40, 40));
	}];
}

- (void)loadData {
	@weakify(self)
	
	self.currentPage = 1;
	[ESNetworkService getShopProductListWithCategoryId:self.categoryId tagId:self.tagId Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.collectionView.mj_header endRefreshing];
			[self.activityWebView.scrollView.mj_header endRefreshing];
		});
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
           
			self.productModel = [ShopProductListModel mj_objectWithKeyValues:dict[@"data"]];
            if (self.productModel.page >= self.productModel.pageCount) {

				[self.collectionView.mj_footer endRefreshingWithNoMoreData];
			} else {
				self.collectionView.mj_footer.hidden = NO;
				[self.collectionView.mj_footer resetNoMoreData];
			}

			dispatch_main_async_safe((^{
				//海报显隐
				if (self.productModel.activitySwitch) {
					self.activityWebView.hidden = NO;
					[self.activityWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.productModel.activityPosterVO.h5Url]]];
					[self.view bringSubviewToFront:self.activityWebView];
					[self.view bringSubviewToFront:self.cartBtn];
					//reset timer
					[self.timer invalidate];
					self.timer = nil;
					self.timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeHandle) userInfo:nil repeats:YES];
					[[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
				} else {
					self.activityWebView.hidden = YES;
					[self.view bringSubviewToFront:self.cartBtn];
					[self.timer invalidate];
					self.timer = nil;
				}
				[self.dataSource removeAllObjects];
				[self.dataSource addObjectsFromArray:self.productModel.products];
				[self.collectionView reloadData];
			}));
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	@weakify(self)
	[ESNetworkService getShopProductListWithCategoryId:self.categoryId tagId:self.tagId Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.collectionView.mj_footer endRefreshing];
		});
		@strongify(self)
		ShopProductListModel *model = [ShopProductListModel mj_objectWithKeyValues:dict[@"data"]];
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.collectionView.mj_footer endRefreshingWithNoMoreData];
                }else{
                    self.collectionView.mj_footer.hidden = NO;
                }
				[self.dataSource addObjectsFromArray:model.products];
				[self.collectionView reloadData];
			});
		}
	}];
}

#pragma mark - timer
- (void)timeHandle {
	self.productModel.activityPosterVO.differenceTime -= 1000;
	if (self.productModel.activityPosterVO.differenceTime <= 0) {
		//关闭计时器
		[self.timer invalidate];
		self.timer = nil;
		[self loadData];
	}
}

#pragma mark - action
- (void)goShopCart {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//跳转购物车
	ShopCartViewController *vc = [[ShopCartViewController alloc] init];
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}


#pragma mark UICollectionView代理
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
	if (QM_IS_ARRAY_NIL(self.dataSource)) {
		self.noDataView.hidden = NO;
		return 0;
	} else {
		self.noDataView.hidden = YES;
		return self.dataSource.count;
	}
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
	return 1;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
	return CGSizeMake(SCREEN_WIDTH / 2, SCREEN_WIDTH / 2  + 78);
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
	ShopProductCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kShopProductCellIdentifier forIndexPath:indexPath];
	[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath];
	return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	//点击商品
	ProductsItem *item = self.dataSource[indexPath.row];
	
	GoodsDetailViewController*vc = [[GoodsDetailViewController alloc] init];
	vc.productId = @(item.productId).stringValue;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - wkWebView delegate
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
}

// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
	[webView loadHTMLString:@"" baseURL:nil];
}

// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
}

// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential * _Nullable))completionHandler {
	if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
		NSURLCredential *card = [[NSURLCredential alloc]initWithTrust:challenge.protectionSpace.serverTrust];
		completionHandler(NSURLSessionAuthChallengeUseCredential,card);
	} else {
		completionHandler(NSURLSessionAuthChallengeUseCredential, nil);
	}
}

//提交发生错误时调用
- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
	
}

// 接收到服务器跳转请求即服务重定向时之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation {
}

// 根据WebView对于即将跳转的HTTP请求头信息和相关信息来决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
	decisionHandler(WKNavigationActionPolicyAllow);
}

// 根据客户端受到的服务器响应头以及response相关信息来决定是否可以跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
	decisionHandler(WKNavigationResponsePolicyAllow);
}

//进程被终止时调用
- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView{
}

#pragma mark - lazy init
- (UICollectionView *)collectionView {
	if (!_collectionView) {
		UICollectionViewFlowLayout  *layout = [[UICollectionViewFlowLayout alloc] init];
		layout.minimumLineSpacing = 0;
		layout.minimumInteritemSpacing = 0;
		layout.scrollDirection =  UICollectionViewScrollDirectionVertical;
		layout.sectionInset = UIEdgeInsetsZero;
		
		_collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, NavBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight - kBottomSafeArea) collectionViewLayout:layout];
		_collectionView.backgroundColor = [UIColor clearColor];
		_collectionView.showsHorizontalScrollIndicator = NO;
		_collectionView.showsVerticalScrollIndicator = NO;
		_collectionView.delegate = self;
		_collectionView.dataSource = self;
		[_collectionView registerClass:[ShopProductCell class] forCellWithReuseIdentifier:kShopProductCellIdentifier];
		_collectionView.backgroundColor = [UIColor whiteColor];
		[_collectionView registerClass:[ShopTagCell class] forCellWithReuseIdentifier:kShopTagCellIdentifier];
	}
	return _collectionView;
}

- (NavButton*)cartBtn
{
	if(!_cartBtn){
		_cartBtn = [NavButton buttonWithType:UIButtonTypeCustom];
		[_cartBtn setImage:[UIImage imageNamed:@"shop_cart_icon"] forState:UIControlStateNormal];
		[_cartBtn addTarget:self action:@selector(goShopCart) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_cartBtn];
		
		self.cartCountL = [UILabel new];
		self.cartCountL.textColor = [UIColor whiteColor];
		self.cartCountL.backgroundColor = RGBCOLOR(240, 72, 68);
		self.cartCountL.font = fcFont(10);
		self.cartCountL.adjustsFontSizeToFitWidth = YES;
		self.cartCountL.clipsToBounds = YES;
		self.cartCountL.textAlignment = NSTextAlignmentCenter;
		self.cartCountL.layer.cornerRadius = 8;
		[_cartBtn addSubview:self.cartCountL];
		[self.cartCountL mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.top.equalTo(_cartBtn);
			make.size.mas_equalTo(CGSizeMake(16, 16));
		}];
	}
	return _cartBtn;
}

- (UIView *)noDataView {
	if (!_noDataView) {
		_noDataView = [[UIView alloc] initWithFrame:self.collectionView.bounds];
		_noDataView.backgroundColor = [UIColor whiteColor];
		_noDataView.userInteractionEnabled = YES;
		[self.collectionView addSubview:_noDataView];
		[self.collectionView bringSubviewToFront:_noDataView];
		
		UIImageView *imageView = [UIImageView new];
		imageView.image = GetImage(@"no_data_withoutword");
		[_noDataView addSubview:imageView];
		
		UILabel *label = [UILabel new];
		label.textColor = RGBCOLOR(231, 231, 231);
		label.font = fcFont(16);
		label.text = @"标签下暂无商品";
		[_noDataView addSubview:label];
		
		//调整布局
		[imageView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(_noDataView);
			make.centerY.equalTo(_noDataView).offset(-10);
			make.size.mas_equalTo(CGSizeMake(300, 300));
		}];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(imageView);
			make.top.equalTo(imageView.mas_bottom).offset(5);
		}];
		_noDataView.hidden = YES;
	}
	return _noDataView;
}

- (WKWebView *)activityWebView {
	if (!_activityWebView) {
		//初始化
		_activityWebView = [[DWKWebView alloc] initWithFrame:self.collectionView.frame];;
		_activityWebView.scrollView.showsVerticalScrollIndicator = NO;
		_activityWebView.scrollView.showsHorizontalScrollIndicator = NO;
		_activityWebView.hidden = YES;
		[self.view addSubview:_activityWebView];
        [_activityWebView.scrollView addRefreshHeaderWithTarget:self action:@selector(loadData)];
	}
	return _activityWebView;
}


@end
