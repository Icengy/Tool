//
//  ShopProductListVC.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/16.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface ShopProductListVC : ESViewController
@property (nonatomic,strong)NSString *categoryId;
- (void)firstLoad;
@end
