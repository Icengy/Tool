//
//  ShopTagProductListViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/22.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface ShopTagProductListViewController : ESViewController
@property (nonatomic,strong)NSString *categoryId;
@property (nonatomic,strong)NSString *tagId;
@end

