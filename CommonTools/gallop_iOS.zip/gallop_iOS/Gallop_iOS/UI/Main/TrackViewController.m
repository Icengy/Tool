//
//  TrackViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/4.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "TrackViewController.h"
#import "TrackListManager.h"
#import "HomeTableViewCell.h"
#import "CYPlanDetailViewController.h"
#import "ExpertDetailViewController.h"
@interface TrackViewController ()<TrackListManagerDelegate,HomeTableViewCellDelegate>
@property (nonatomic, strong) NSString*type;
@property (nonatomic, strong) TrackListManager *manager;
@end

@implementation TrackViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initWithSubViews];
    // Do any additional setup after loading the view.
}
-(void)didSelectHeadV:(id)cell
{
    NSIndexPath*indexPath = [self.tableView indexPathForCell:cell];
    PlanModel*model  = self.manager.dataSource[indexPath.row];
    ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",model.userId];
    vc.sourcePage = self.title;
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
}
- (void)initWithSubViews{
	self.navigationItem.title = self.field.intValue == 1 ? @"足球浏览记录" : @"篮球浏览记录";
    self.type = @"";
    
    self.tableView.frame = CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight);
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
    //    [self.tableView.mj_header beginRefreshing];
    [self loadData];
    
}
-(void)trackListManager:(TrackListManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
    
    dispatch_main_async_safe(^{
        [self.tableView.mj_header endRefreshing];
        [self.tableView.mj_footer endRefreshing];
        
        if (self.manager.dataSource.count == 0) {
        }
        
        if (!isRefresh && self.manager.dataSource.count >= 20) {
            self.tableView.mj_footer.hidden = NO;
        }else{
            self.tableView.mj_footer.hidden = YES;
        }
        
        [self.tableView reloadData];
        
    });
}
-(void)loadData{
    [self.manager refreshDataWithType:self.type andField:self.field];
}
-(void)loadMoreData
{
    [self.manager loadDataWithType:self.type andField:self.field];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  self.manager.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    PlanModel*model  = self.manager.dataSource[indexPath.row];
    static NSString *identifier=@"homeTableViewCell";
    HomeTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (cell==nil) {
        cell=[[HomeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        
        
    }
    //cell贴边
    UIEdgeInsets inset;
    inset.bottom=0;
    inset.top=0;
    inset.left=0;
    inset.right=0;
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:inset];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
        [cell setSeparatorInset:inset];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.isBasket = (self.field.integerValue == 2);
    cell.model = model;
    cell.delegate = self;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    PlanModel*model  = self.manager.dataSource[indexPath.row];
    CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
    vc.planId = [model.planId integerValue];
    vc.sourcePage = @"浏览记录页面";
//    vc.isBasket = (model.field.integerValue == 2);
//    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	tableView.rowHeight = UITableViewAutomaticDimension;
	tableView.estimatedRowHeight = 150;
	return tableView.rowHeight;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}
-(TrackListManager*)manager
{
    if (!_manager) {
        _manager = [TrackListManager new];
        _manager.delegate = self;
    }
    return _manager;
}

@end
