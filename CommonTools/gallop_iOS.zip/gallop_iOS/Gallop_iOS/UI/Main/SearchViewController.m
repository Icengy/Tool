//
//  SearchViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/4.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SearchViewController.h"
#import "ExpertDetailViewController.h"

#import "GallopExpertModel.h"
#import "SizingSearchCollectionViewCell.h"
#import "QMPageFooterView.h"
#import "NavButton.h"
#import "ExpertSearchTableViewCell.h"

#define kpageNum 20
#define fontCOLOR [UIColor colorWithRed:163/255.0f green:163/255.0f blue:163/255.0f alpha:1]

@interface SearchViewController ()<UISearchBarDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UINavigationControllerDelegate, ExpertSearchTableViewCellDelegate>
{
    NSMutableArray <GallopExpertModel *>*newsListArray;
    NSMutableArray*historyArray;
    QMPageFooterView*footView;
    QMPageFootViewState footerLoadingState;
    BOOL mIsLoading;
    UIView*historyView;
    UIView*headView;
    int showfooter;
    UIView*headSView;
    NSInteger _page;
}
@property(nonatomic,strong)UISearchBar*searchBar;
@property(nonatomic,strong)UIScrollView*scrollView;
@property(nonatomic,assign)BOOL isAllDataLoaded;
@property(nonatomic,strong)UIButton*deleteButton;
@end

@implementation SearchViewController
-(instancetype)init
{
    if (self=[super init]) {
        newsListArray=[NSMutableArray arrayWithCapacity:0];
        NSArray*hisArray=[[NSUserDefaults standardUserDefaults]objectForKey:ksearchHistroy];
        historyArray=[NSMutableArray arrayWithArray:hisArray];
    }
    return self;
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.fd_prefersNavigationBarHidden = YES;
    
    _page = 1;
    
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    self.tableView.contentInset = kTableViewDetailtContentInset;
    
    [self.tableView setFrame:CGRectMake(0, 0, kScreen_Width, kScreen_Height-NavBarHeight)];
  
    self.tableView.translatesAutoresizingMaskIntoConstraints =YES;
    
    self.tableView.showsVerticalScrollIndicator = NO;
    
    self.tableView.placeHolderText = @"未找到匹配结果";
    
    self.tableView.tag = 9999;
    [self.tableView registerNibCell:[ExpertSearchTableViewCell class]];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    
    headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreen_Width, NavBarHeight)];
    headView.backgroundColor = ColorMainAppRed;
    [headView addSubview:self.searchBar];
    if ([self.searchBar.text isEqualToString:@""]) {
        [self.searchBar becomeFirstResponder];
        
    }
    UIButton*quitButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [quitButton setFrame:CGRectMake(kScreen_Width-50, NavBarHeight-40, 40, 30)];
    [quitButton setTitle:@"取消" forState:UIControlStateNormal];
    [quitButton setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [quitButton addTarget:self action:@selector(returnback:) forControlEvents:UIControlEventTouchUpInside];
    quitButton.titleLabel.font = [UIFont addPingFangSCMedium:16];
    
    UILabel*lineLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, NavBarHeight-1, kScreen_Width, 1)];
    lineLabel.backgroundColor=[UIColor colorWithHexString:@"#EBEBEB"];
    [headView addSubview:lineLabel];
    [headView addSubview:quitButton];
    [self.view addSubview:headView];
    self.isAllDataLoaded=NO;
    self.searchBar.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.delegate=self;
    [self.view addSubview:self.scrollView];
    [self.scrollView addSubview:self.tableView];
    
    [self setHistoryView];
    
    self.tableView.mj_footer = [MJRefreshAutoStateFooter footerWithRefreshingTarget:self refreshingAction:@selector(didTriggerLoadNextPageData:)];
    self.tableView.mj_footer.hidden = YES;
}

- (UILabel *)labelWithTitle:(NSString *)title{
    
    UILabel *label = [[UILabel alloc] init];
    label.text = title;
    [label sizeToFit];
    label.backgroundColor = ColorGrayBack;
    label.layer.cornerRadius = 5;
    label.layer.masksToBounds = YES;
//    label.layer.borderWidth = 0.5;
    label.userInteractionEnabled = YES;
    label.font = [UIFont addPingFangSCRegular:12];
    label.textAlignment = NSTextAlignmentCenter;
    return label;
}
-(void)setupLayoutViews {
    
    UILabel*hisL = [[UILabel alloc] initWithFrame:CGRectMake(15, 15,80, 15)];
    hisL.text = @"最近搜索";
    hisL.font = [UIFont addPingFangSCRegular:13];
    [historyView addSubview:hisL];
    UIButton*deletButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [deletButton setFrame:CGRectMake(kScreen_Width-45, 15, 20, 20)];
	deletButton.contentMode = UIViewContentModeScaleAspectFill;
    [deletButton setImage:[UIImage imageNamed:@"垃圾箱"] forState:UIControlStateNormal];
    [deletButton addTarget:self action:@selector(deleteHistory) forControlEvents:UIControlEventTouchUpInside];
    [historyView addSubview:deletButton];
    
    CGFloat x = 15;
    CGFloat y = 10 + 30;
    
    for (int i = 0; i < historyArray.count; i++) {
        
        UILabel *label = [self labelWithTitle:historyArray[i]];
        label.tag = i;
        UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchL:)];
        [label addGestureRecognizer:tap];
        CGFloat width = label.frame.size.width + 20;
        
        if (x + width + 15 > self.view.bounds.size.width) {
            y += 30;//换行
            x = 15; //15位置开始
        }
        
        label.frame = CGRectMake(x, y, width, 20);
        [historyView addSubview:label];
    
        x += width + 10;//宽度+间隙
    }
}
-(void)deleteHistory{
    [historyArray removeAllObjects];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:ksearchHistroy];
    [self reloadLabels];
}
-(void)touchL:(UITapGestureRecognizer*)tap{
    NSInteger tag = tap.view.tag;
    NSString*str = historyArray[tag];
    self.searchBar.text=str;
    [self.searchBar resignFirstResponder];
    [self searchWithString:str];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    // 判断要显示的控制器是否是自己
    //    BOOL isShowHomePage = [viewController isKindOfClass:[self class]];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
}
#pragma mark navigation
-(void)returnback:(UIBarButtonItem*)button
{
    //收回键盘
    [self.searchBar resignFirstResponder];
    //    该会bar 以下可以在其他contoller里独立修改
    //退回首页
    //    [self dismissViewControllerAnimated:YES completion:nil];
    [self.navigationController popViewControllerAnimated:NO];
    [UIView setAnimationsEnabled:YES];
    
    
}
#pragma mark searchDisplay
#pragma mark searchBar
-(UISearchBar*)searchBar
{
    if (!_searchBar) {
        _searchBar = [[UISearchBar alloc] initWithFrame:CGRectMake(10, NavBarHeight-40,kScreen_Width-70, 30)];
        
        /// 切圆角
        UIView* backgroundView = [_searchBar subViewOfClassName:@"_UISearchBarSearchFieldBackgroundView"];
        backgroundView.layer.cornerRadius = 15.0f;
        backgroundView.clipsToBounds = YES;
        
        _searchBar.placeholder = @"搜索";
        [_searchBar setImage:[UIImage imageNamed:@"salecard_search"]forSearchBarIcon:UISearchBarIconSearch state:UIControlStateNormal];
        
        /// 设置内部背景
        if(@available(iOS 13.0, *)) {
            _searchBar.searchTextField.backgroundColor = UIColor.whiteColor;
        }else{
            UITextField *txfSearchField = [_searchBar valueForKey:@"_searchField"];
            txfSearchField.backgroundColor = UIColor.whiteColor;
        }
        
        _searchBar.backgroundColor=[UIColor clearColor];
        _searchBar.backgroundImage=[[UIImage alloc]init];
    }
    return _searchBar;
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //添加searchbar
    [self.navigationController.navigationBar setHidden:YES];
    [UIView setAnimationsEnabled:YES];
    
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    //    [_searchBar removeFromSuperview];
    self.navigationController.navigationBar.hidden=NO;
    [UIView setAnimationsEnabled:YES];
    
    
}

#pragma mark nonView
//协议上说明:暂时不用
//-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
//{
//
//}
-(void)reloadLabels{
    dispatch_main_async_safe(^{
        for (UIView*view in self->historyView.subviews) {
            [view removeFromSuperview];
        }
        [self setupLayoutViews];
    });
}
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    
    NSLog(@"搜索框文本改变了");
    if ([searchText isEqualToString:@""]) {
        historyView.hidden=NO;
        [self reloadLabels];
    }
   
    
}
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    
    NSLog(@"搜索按钮被地点击了text:%@",searchBar.text);
    if (searchBar.text.length>10) {
        [CMMUtility showToastWithText:@"输入不能超过10位"];
        return;
    }
    [self searchWithString:searchBar.text];
    [self.searchBar resignFirstResponder];
}

-(void)searchWithString:(NSString*)string
{
    NSLog(@"开始搜索了");
    historyView.hidden=YES;
    self.isAllDataLoaded=NO;
    [newsListArray removeAllObjects];
    [self.tableView reloadData];
//    if ([string isEqualToString:@""]||[[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] isEqualToString:@""]) {
    if ([string isEqualToString:@""]) {
        historyView.hidden=NO;
        [self reloadLabels];
    }else{
        [self fetchSearchResultWithString:string andPageNo:1];//这里改变pageOn
        NSArray*copyArray=[NSArray arrayWithArray:historyArray];//遍历时防止多线程冲突
        for (NSString*str in copyArray) {
            if ([str isEqualToString:string]) {
                [historyArray removeObject:str];
            }
        }
        [historyArray insertObject:string atIndex:0];
        if (historyArray.count>8) {
            [historyArray removeLastObject];
        }
        [[NSUserDefaults standardUserDefaults] setObject:historyArray forKey:ksearchHistroy];
    }
    
}

#pragma mark -
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return newsListArray.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ExpertSearchTableViewCell *cell = [tableView dequeueReusableCell:[ExpertSearchTableViewCell class]];
    cell.delegate = self;
    cell.model = [newsListArray objectAtIndex:indexPath.row];
    return cell;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    ExpertSearchTableViewCell *cell = (ExpertSearchTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    ExpertDetailViewController *detailVC = [[ExpertDetailViewController alloc] init];
    detailVC.expertId = [NSString stringWithFormat:@"%@",@(cell.model.expertId)];
    [self.navigationController pushViewController:detailVC animated:YES];
    
}

#pragma mark - ExpertSearchTableViewCellDelegate
- (void)listCell:(ExpertSearchTableViewCell *)cell didClickToFollow:(GallopExpertModel *)model withState:(NSInteger)state withBtns:(NSArray<UIButton *> *)btns {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    if (model.expertId) {
        if (state) {
            /// 取关
            [ESNetworkService unfollowExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = NO;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }else{
            /// 关注
            [ESNetworkService followExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = YES;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }
    }
}


//搜索的数据
-(void)fetchSearchResultWithString:(NSString*)string andPageNo:(NSInteger)pageNo {
    
    [ESNetworkService searchExpertWithPage:(int)pageNo PageSize:kpageNum SearchKey:string Response:^(id dict, ESError *error) {
        [self.tableView endAllFreshing];
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray *postsArray = [data objectForKey:@"expertList"];
            
            if (!QM_IS_ARRAY_NIL(postsArray) && postsArray.count) {
                [newsListArray addObjectsFromArray:[GallopExpertModel mj_objectArrayWithKeyValuesArray:postsArray]];
            }
            dispatch_main_async_safe(^{

                [self.tableView updataFreshFooter:(newsListArray.count && postsArray.count < kpageNum)];
                self.tableView.mj_footer.hidden = !newsListArray.count;
                
                [self.tableView reloadData];
            });
        }
    }];
}

#pragma mark 搜索的下拉刷新功能补全
-(UIScrollView*)scrollView
{
    if (!_scrollView) {
        _scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight)];
        _scrollView.delegate=self;
    }
    return _scrollView;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.searchBar resignFirstResponder];
}
-(void)setUppageFooterView{
    if (!footView) {
        footView=[[QMPageFooterView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(self.scrollView.frame)-40, CGRectGetWidth(self.scrollView.frame), 40)];
        footView.backgroundColor=[UIColor whiteColor];
        footView.autoresizingMask=UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleWidth;
        footerLoadingState=QMPageFootViewNormalState;
        [footView setQMPageFootViewState:footerLoadingState];
    }
}
- (void)reloadTableViewDataSource{
    //  should be calling your tableviews data source model to reload
    //  put here just for demo
    mIsLoading = YES;
}

//搜索开始
- (void)didTriggerLoadNextPageData:(id)sender {
    if (historyView.hidden) {
        if ([sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
            _page ++;
        }else {
            _page = 1;
        }
        [self fetchSearchResultWithString:self.searchBar.text andPageNo:_page];
    }
}
////搜索开始
//- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
//    if ((scrollView.contentSize.height - scrollView.contentOffset.y < CGRectGetHeight(scrollView.frame)) && !mIsLoading && !self.isAllDataLoaded && scrollView.contentOffset.y > 0) {
//        footerLoadingState = QMPageFootViewLoadingState;
//        [footView setQMPageFootViewState:footerLoadingState];
//        mIsLoading = YES;
//        [self didTriggerLoadNextPageData:nil];
//    }
//
//}
-(void)setHistoryView
{
    if (!historyView) {
        historyView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreen_Width, kScreen_Height-65)];
        historyView.tag=6666;
        
        historyView.backgroundColor=[UIColor whiteColor];
//        historyView.delegate=self;
//        historyView.dataSource=self;
        [self.scrollView addSubview:historyView];
        [self reloadLabels];
    }
}
#pragma mark 添加搜索热门
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
   
        return nil;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
   
        return 0.01;
    
}
-(CGFloat) tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
@end
