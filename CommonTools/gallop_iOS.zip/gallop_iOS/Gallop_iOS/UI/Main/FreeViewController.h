//
//  FreeViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface FreeViewController : ESViewController
@property (nonatomic,strong) NSString *field;
@end
