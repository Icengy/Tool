//
//  ESShareViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/9/23.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESShareViewController.h"
#import "WXApi.h"

@interface ESShareViewController () <UIGestureRecognizerDelegate>

@property (nonatomic,strong) NSDictionary *model;

//分享按钮区域
@property (nonatomic,weak) IBOutlet UIView *shareContentView;
@property (nonatomic,weak) IBOutlet UIStackView *stackView;
@property (nonatomic,weak) IBOutlet CYButton *cancelBtn;

@end

@implementation ESShareViewController

- (instancetype)initWithModel:(id)model {
    if (self = [super init]) {
        self.model = model;
        
        self.modalPresentationStyle = UIModalPresentationOverFullScreen;
        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        
    }return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor.blackColor colorWithAlphaComponent:0.3];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cancelBtnClick:)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
    
    [self.cancelBtn addRoundedCorners:UIRectCornerTopLeft | UIRectCornerTopRight withRadii:2.0 withBorderColor:ColorDefaultGrayBackground withBorderWidth:1.0];
    
    NSArray *imageArr = @[@"微信",@"朋友圈"];
    [imageArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CYButton *btn = [CYButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[GetImage(obj) scaleToSize:CGSizeMake(44.0, 44.0)] forState:UIControlStateNormal];
        btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        btn.tag = idx + 33220;
        [btn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.stackView addArrangedSubview:btn];
    }];
}


#pragma mark - action
- (IBAction)cancelBtnClick:(id)sender {
    [self dismissBack:sender];
}

- (void)shareBtnClick:(UIButton *)btn {
    //获取分享截图
    switch (btn.tag - 33220) {
        case 0: {
            //微信
            [self shareWithModel:self.model type:0];
        }
            break;
        case 1: {
            //朋友圈
            [self shareWithModel:self.model type:1];
        }
            break;
        default:
            break;
    }
}

- (void)shareWithModel:(NSDictionary *)model
                  type:(int)type {
    if([WXApi isWXAppInstalled]){//判断当前设备是否安装微信客户端
        UIImage *imageToShare = QM_IS_STR_NIL([model objectForKey:@"icon"]) ? GetImage(@"app_icon") : [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[model objectForKey:@"icon"]]]];
        //创建多媒体消息结构体
        WXMediaMessage *message = [WXMediaMessage message];
        message.title = [model objectForKey:@"title"];//标题
        message.description = [model objectForKey:@"content"];//描述
        [message setThumbImage:imageToShare];//设置预览图
        
        //创建网页数据对象
        WXWebpageObject *webObj = [WXWebpageObject object];
        webObj.webpageUrl = [model objectForKey:@"link"];//链接
        message.mediaObject = webObj;
        
        SendMessageToWXReq *sendReq = [[SendMessageToWXReq alloc] init];
        sendReq.bText = NO;//不使用文本信息
        sendReq.message = message;
        sendReq.scene = type;
        
        [WXApi sendReq:sendReq completion:nil];//发送对象实例
    }else{
        //未安装微信应用或版本过低
        NSURL *url = [NSURL URLWithString:[model objectForKey:@"link"]];
        UIImage *imageV = QM_IS_STR_NIL([model objectForKey:@"icon"]) ? GetImage(@"app_icon") : [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[model objectForKey:@"icon"]]]];
        NSString *str = [[model objectForKey:@"title"] stringByAppendingFormat:@"\n%@",[model objectForKey:@"content"]];
        NSArray *items = [NSArray arrayWithObjects:url,imageV,str, nil];
        UIActivityViewController *activityViewController = [[UIActivityViewController alloc] initWithActivityItems:items applicationActivities:nil];
        [APP_DELEGATE.window.rootViewController presentViewController:activityViewController animated:YES completion:nil];
    }
}

#pragma mark -
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isDescendantOfView:self.shareContentView]) {
        return NO;
    }
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
