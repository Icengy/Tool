//
//  GuideViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface GuideViewController : ESViewController
//定义回调
@property (nonatomic,strong) void (^callBack)(void);
@end
