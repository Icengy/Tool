//
//  GuideViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "GuideViewController.h"
#import "PointExtenButton.h"

@interface GuideViewController ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) UIPageControl *pageControl;

@end

@implementation GuideViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.scrollView = [[UIScrollView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.scrollView.delegate = self;
    [self.view addSubview:self.scrollView];
    
    self.pageControl = [UIPageControl new];
    self.pageControl.numberOfPages = 4;
    self.pageControl.currentPage = 0;
    self.pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
    self.pageControl.pageIndicatorTintColor = RGBCOLOR(168, 168, 168);
    [self.view addSubview:self.pageControl];
    [self.pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.view);
        make.bottom.equalTo(self.view).offset(-5);
    }];
    
    [self loadPhoto];
}

- (void)loadPhoto
{
        //加载图片, 可以在这网络请求
        for (int i = 0; i < 5; i ++) {
            UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(SCREEN_WIDTH * i, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"guidPage%d",i % 4 + 1]];
            imageView.contentMode = UIViewContentModeScaleAspectFill;
            imageView.clipsToBounds = YES;
            
            [self.scrollView addSubview:imageView];
            
            if (i == 3) {
                imageView.userInteractionEnabled = YES;
                //点击进入
                PointExtenButton *enterBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
                [enterBtn setTitle:@"点击进入" forState:UIControlStateNormal];
                [enterBtn addTarget:self action:@selector(enterBtnClick) forControlEvents:UIControlEventTouchUpInside];
                enterBtn.titleLabel.font = GetFont(14);
                [enterBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                enterBtn.backgroundColor = [UIColor colorWithHexString:@"#a8a8a8"];
                enterBtn.layer.cornerRadius = 4;
                enterBtn.layer.borderColor = [UIColor whiteColor].CGColor;
                enterBtn.layer.borderWidth = 0.5f;
                enterBtn.clipsToBounds = YES;
                [imageView addSubview:enterBtn];
                [enterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.bottom.equalTo(self.view).offset(-48);
                    make.centerX.equalTo(imageView);
                    make.size.mas_equalTo(CGSizeMake(100, 32));
                }];
            }
        }
        self.scrollView.contentOffset = CGPointMake(0, 0);
        self.scrollView.contentSize = CGSizeMake(SCREEN_WIDTH * 5, SCREEN_HEIGHT);
        
        self.scrollView.bounces = NO;
        self.scrollView.pagingEnabled = YES;
        self.scrollView.showsHorizontalScrollIndicator = NO;
        self.scrollView.showsVerticalScrollIndicator = NO;
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (self.scrollView.contentOffset.x > SCREEN_WIDTH * 3.2 && self.callBack)
    {
        //回调
        self.callBack();
    }
}

- (void)enterBtnClick {
    if (self.callBack)
    {
        //回调
        self.callBack();
    }
}

//pageControl状态
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if (self.scrollView.contentOffset.x < SCREEN_WIDTH * 0.5) {
        self.pageControl.currentPage = 0;
    }else if(self.scrollView.contentOffset.x > SCREEN_WIDTH * 0.5 && self.scrollView.contentOffset.x < SCREEN_WIDTH * 1.5)
    {
        self.pageControl.currentPage = 1;
    } else if(self.scrollView.contentOffset.x > SCREEN_WIDTH * 1.5 && self.scrollView.contentOffset.x < SCREEN_WIDTH * 2.5){
        self.pageControl.currentPage = 2;
    } else {
        self.pageControl.currentPage = 3;
    }
}

@end
