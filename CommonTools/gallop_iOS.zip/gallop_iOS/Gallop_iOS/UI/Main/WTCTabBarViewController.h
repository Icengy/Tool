//
//  WTCTabBarViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WTCTabBarViewController : UITabBarController

@end
