//
//  ESShareViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/9/23.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ESShareViewController : ESViewController

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithModel:(id)model;

@end

NS_ASSUME_NONNULL_END
