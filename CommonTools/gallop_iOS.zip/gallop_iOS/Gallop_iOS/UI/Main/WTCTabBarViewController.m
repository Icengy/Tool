//
//  WTCTabBarViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "WTCTabBarViewController.h"
#import "DiscoverViewController.h"
#import "HomeViewController.h"
#import "MatchHomeViewController.h"
#import "CommunityViewController.h"
#import "MineViewController.h"
#import "GallopExpertViewController.h"
#import "GallopTabbar.h"

@interface WTCTabBarViewController ()

@end

@implementation WTCTabBarViewController

+ (void)initialize {
    /// 设置未选中/选中时的主题颜色（体现在文字颜色上）
    [[UITabBar appearance] setUnselectedItemTintColor:RGBCOLORV(0xA8A8A8)];
    [[UITabBar appearance] setTintColor:ColorMainAppRed];
    
    if (@available(iOS 13, *)) {
        /// 设置tabbar背景/设置tabbar顶部的分割线
        UITabBarAppearance *appearance = [UITabBarAppearance new];
        appearance.backgroundColor = UIColor.whiteColor;
        appearance.backgroundImage = [UIImage imageWithColor:[UIColor whiteColor]];
        appearance.shadowColor = UIColor.clearColor;
        appearance.shadowImage = [UIImage new];
        
        [UITabBar appearance].standardAppearance = appearance;
        if (@available(iOS 15.0, *)) {
            [UITabBar appearance].scrollEdgeAppearance = appearance;
        }
    }else {
        [[UITabBar appearance] setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]]];
        //    UIImage *backGroundImage = [(kTabBarHeight > 49.0)?GetImage(@"tabbar_bg"):GetImage(@"tabbar_bg_49") resizableImageWithCapInsets:UIEdgeInsetsZero resizingMode:UIImageResizingModeStretch];
        //    [[UITabBar appearance] setBackgroundImage:backGroundImage];
        
        [[UITabBar appearance] setShadowImage:[UIImage new]];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setUpChildViewController];
    
    //创建自己的tabbar，然后用kvc将自己的tabbar和系统的tabBar替换下
    GallopTabbar *tabbar = [[GallopTabbar alloc] init];
//    tabbar.myDelegate = self;
    //kvc实质是修改了系统的_tabBar
    [self setValue:tabbar forKeyPath:@"tabBar"];
    
    [self setUpTabBarItemTextAttributes];
    
    [self dropShadowWithOffset:CGSizeMake(0, -1.0) radius:25.0 color:[UIColor.grayColor colorWithAlphaComponent:1.0] opacity:0.3];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
//    [ESNetworkService checkVersonResponse:^(id dict, ESError *error) {
//        
//    }];
}

/**
 *  tabBarItem 的选中和不选中文字属性
 */
- (void)setUpTabBarItemTextAttributes {
    
    // 普通状态下的文字属性
    NSMutableDictionary *normalAttrs = [NSMutableDictionary dictionary];
    normalAttrs[NSForegroundColorAttributeName] = RGBCOLORV(0xA8A8A8);
    normalAttrs[NSFontAttributeName] = [UIFont addPingFangSCMedium:11];
    
    // 选中状态下的文字属性
    NSMutableDictionary *selectedAttrs = [NSMutableDictionary dictionary];
    selectedAttrs[NSForegroundColorAttributeName] = ColorMainAppRed;
    selectedAttrs[NSFontAttributeName] = [UIFont addPingFangSCMedium:11];
    
    // 设置文字属性
    if (@available(iOS 13, *)) {
        UITabBarAppearance *appearance = self.tabBar.standardAppearance;
        UITabBarItemAppearance *itemAppearance = appearance.stackedLayoutAppearance;
        if (!itemAppearance) {
            itemAppearance = [[UITabBarItemAppearance alloc] init];
        }
        UITabBarItemStateAppearance *normal = itemAppearance.normal;
        if (normal) {
            normal.titleTextAttributes = normalAttrs;
        }
        UITabBarItemStateAppearance *selected = itemAppearance.selected;
        if (selected) {
            selected.titleTextAttributes = selectedAttrs;
        }
        
        appearance.stackedLayoutAppearance = itemAppearance;
        self.tabBar.standardAppearance = appearance;
        
        if (@available(iOS 15.0, *)) {
            self.tabBar.scrollEdgeAppearance = appearance;
        }
    }else {
        UITabBarItem *tabBar = [UITabBarItem appearance];
        [tabBar setTitleTextAttributes:normalAttrs forState:UIControlStateNormal];
        [tabBar setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    }
}

- (void)addOneChildViewController:(UIViewController *)viewController WithTitle:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName{
    viewController.view.backgroundColor     = [UIColor whiteColor];
    viewController.tabBarItem.title         = title;
    UIImage *image = [[UIImage imageNamed:imageName] scaleToSize:CGSizeMake(44, 44)];
    viewController.tabBarItem.image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIImage *selectImage = [[UIImage imageNamed:selectedImageName] scaleToSize:CGSizeMake(44, 44)];
    selectImage = [selectImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    viewController.tabBarItem.selectedImage = selectImage;
    [self addChildViewController:viewController];
}
/**
 *  添加子控制器
 */
- (void)setUpChildViewController{
    
    
    [self addOneChildViewController:[[ESNavigationViewController alloc]initWithRootViewController:[[HomeViewController alloc]init]]
                          WithTitle:@"首页"
                          imageName:@"home_n"
                  selectedImageName:@"home_s"];
    
    [self addOneChildViewController:[[ESNavigationViewController alloc]initWithRootViewController:[[GallopExpertViewController alloc]init]]
                          WithTitle:@"专家"
                          imageName:@"expert_n"
                  selectedImageName:@"expert_s"];
    
    MatchHomeViewController *mVC = [[MatchHomeViewController alloc] init];
    [self addOneChildViewController:[[ESNavigationViewController alloc] initWithRootViewController:mVC]
                          WithTitle:@"比赛"
                          imageName:@"martch_n"
                  selectedImageName:@"martch_s"];
    
//   DiscoverViewController *dVC = [[DiscoverViewController alloc] init];
//   [self addOneChildViewController:[[ESNavigationViewController alloc] initWithRootViewController:dVC]
//                            WithTitle:@"发现"
//                            imageName:@"发现"
//                    selectedImageName:@"发现a"];
    
	[self addOneChildViewController:[[ESNavigationViewController alloc]initWithRootViewController:[[CommunityViewController alloc]init]]
						  WithTitle:@"社区"
						  imageName:@"community_n"
				  selectedImageName:@"community_s"];
	
	MineViewController *mineViewController = [[MineViewController alloc] init];
    mineViewController.hideSperator=YES;
	[self addOneChildViewController:[[ESNavigationViewController alloc]initWithRootViewController:mineViewController]
						  WithTitle:@"我的"
						  imageName:@"mine_n"
				  selectedImageName:@"mine_s"];
}

- (void)dropShadowWithOffset:(CGSize)offset
                      radius:(CGFloat)radius
                       color:(UIColor *)color
                     opacity:(CGFloat)opacity {
    
    // Creating shadow path for better performance
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, self.tabBar.bounds);
    self.tabBar.layer.shadowPath = path;
    CGPathCloseSubpath(path);
    CGPathRelease(path);
    
    self.tabBar.layer.shadowColor = color.CGColor;
    self.tabBar.layer.shadowOffset = offset;
    self.tabBar.layer.shadowRadius = radius;
    self.tabBar.layer.shadowOpacity = opacity;
    
    // Default clipsToBounds is YES, will clip off the shadow, so we disable it.
    self.tabBar.clipsToBounds = NO;
}

@end
