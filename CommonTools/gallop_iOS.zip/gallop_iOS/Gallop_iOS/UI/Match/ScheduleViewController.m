//
//  ScheduleViewController.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ScheduleViewController.h"
#import "InstantTableViewCell.h"
#import "MatchInstantListModel.h"
#import "TimeSliderView.h"
#import "UICustomDatePicker.h"
#import "MatchDetailViewController.h"
#import "BasketballListModel.h"
#import "BasketballTableViewCell.h"

#import <BRPickerView/BRDatePickerView.h>

@interface ScheduleViewController ()<MatchInstantTableCellDelegate,TimeSliderViewDelegate>

@property(nonatomic, strong)NSMutableArray *dataList;
@property(nonatomic, strong)BasketballListModel *basketballModel;

@property(nonatomic, strong) TimeSliderView *slider;

@end

@implementation ScheduleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSMutableArray array];
    
    // 获取当前时间
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    // 得到当前时间（世界标准时间 UTC/GMT）
    NSDate *nowDate = [NSDate date];
    
    self.selectedDate = [dateFormatter stringFromDate:nowDate];
    [self setupView];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchScreenChange:) name:kMatchScreenChange object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadData:nil];
}

- (void)matchScreenChange:(NSNotification *)notify {
    if (!self.isViewLoaded || !self.view.window) {
        return;
    }
    if ([notify.object integerValue] == 1) {
        //刷新列表
        [self loadData:nil];
    }
}

- (void)setupView {
    [self.view addSubview:self.slider];
    [self.slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.offset(45.0);
    }];
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.slider.mas_bottom);
        make.bottom.left.right.equalTo(self.view);
    }];
    self.tableView.contentOffset = CGPointMake(0, 100);
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.estimatedRowHeight = 172;
    [self.tableView registerCell:[InstantTableViewCell class]];
    [self.tableView registerCell:[BasketballTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)loadData:(id)sedner {
    
    [ES_HttpService showLoading:!sedner];
    
    //请求列表数据
    @weakify(self)
	if (self.field == 2) {
		//篮球
		[ESNetworkService getUnstartBaskectballList:self.selectedDate response:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
                NSDictionary *data = dict[@"data"];
                BasketballListModel *model = [BasketballListModel  mj_objectWithKeyValues:data];
                
                self.basketballModel = model;
                [self.dataList removeAllObjects];
                [self.dataList addObjectsFromArray:model.matches.ongoings];
                [self.dataList addObjectsFromArray:model.matches.unStarts];
                [self.dataList addObjectsFromArray:model.matches.ends];
                self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
			} else {
                [self.dataList removeAllObjects];
                self.tableView.placeHolderText = @"";
            }
            dispatch_main_async_safe(^{
                [self.tableView updataFreshFooter:YES];
                self.tableView.mj_footer.hidden = !self.dataList.count;
                [self.tableView reloadData];
                if (!QM_IS_ARRAY_NIL(self.dataList)) {
                    self.tableView.contentOffset = CGPointZero;
                }
            });
		}];
	} else {
		[ESNetworkService getSchedulesList:1 date:self.selectedDate sclassId:0 response:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
                NSDictionary *data = dict[@"data"];
                MatchInstantListModel *model = [MatchInstantListModel  mj_objectWithKeyValues:data];
                
                [self.dataList removeAllObjects];
                [self.dataList addObjectsFromArray:model.matchList];
                self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
            } else {
                [self.dataList removeAllObjects];
                self.tableView.placeHolderText = @"";
			}
            dispatch_main_async_safe(^{
                [self.tableView updataFreshFooter:YES];
                self.tableView.mj_footer.hidden = !self.dataList.count;
                [self.tableView reloadData];
                if (!QM_IS_ARRAY_NIL(self.dataList)) {
                    self.tableView.contentOffset = CGPointZero;
                }
            });
		}];
	}
}

#pragma mark - instantCellDelegate
- (void)focusStateChange:(UIButton *)focusBtn matchId:(NSInteger)matchId {
	if (![App_Utility checkCurrentUser]) {
		[CMMUtility showToastWithText:@"请先登录再关注比赛"];
		[App_Utility showLoginViewController];
	}
    if (self.field == 1) {
        [MobClick event:@"match8" attributes:@{@"tab":@"赛程",@"isFllow":@(!focusBtn.selected)}];
        
        [ESNetworkService focusMatch:!focusBtn.selected matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    focusBtn.selected = !focusBtn.selected;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kMatchFoucesStateChange object:@(!focusBtn.selected)];
                });
            }
        }];
    }
    
    if (self.field == 2) {
        [MobClick event:@"basketball8" attributes:@{@"tab":@"赛程",@"isFllow":@(!focusBtn.selected)}];

        NSUInteger type = (!focusBtn.selected ? 1 : 0);
        [ESNetworkService focusBasketMatch:type matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    focusBtn.selected = !focusBtn.selected;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kMatchFoucesStateChange object:@(type)];
                });
            }
        }];
    }
}

#pragma mark - tableView delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (self.field == 2) {
		//篮球
		BasketballTableViewCell *cell = [tableView dequeueReusableCell:[BasketballTableViewCell class]];
		cell.cellDelegate = self;
        
        if (indexPath.row < self.dataList.count) {
            [cell configCellWithModel:self.dataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeSchedule];
        }
		return cell;
	} else {
		//足球
        InstantTableViewCell *cell = [tableView dequeueReusableCell:[InstantTableViewCell class]];
		cell.cellDelegate = self;
        if (indexPath.row < self.dataList.count) {
            [cell configCellWithModel:self.dataList[indexPath.row] cellType:MatchCellTypeSchedule];
        }
		return cell;
	}
}

//选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
    liveVC.field = self.field;
    
    if (self.field == 2) {
        //篮球
        BasketballItem *matchModel = self.dataList[indexPath.row];
        
        liveVC.matchId = matchModel.matchId;
        liveVC.sourcePage = @"篮球比赛赛程页";
    }else {
        InstantMatcth *matchModel = self.dataList[indexPath.row];
        
        liveVC.matchId = matchModel.matchId;
        liveVC.needHidePlan = (matchModel.hasExpert == 1) ? NO : YES;
        liveVC.sourcePage = @"比赛赛程页";
    }
    [self.navigationController pushViewController:liveVC animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  self.dataList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return nil;
}

#pragma mark - TimeSliderDelegat
- (void)didSelectItemsWithDate:(NSString *)dateStr {
    [self handleSelectValue:dateStr];
}

- (void)showDateView {
    
    //赛程：未来30天；赛果为过去30天
    // 1.创建日期选择器
    BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
    // 2.设置属性
    datePickerView.pickerMode = BRDatePickerModeYMD;
    datePickerView.title = @"请选择日期";
    datePickerView.selectValue = self.selectedDate;
//    datePickerView.selectDate = [NSDate br_setYear:2019 month:10 day:30];
    NSDate *currentData = [NSDate date];
    datePickerView.minDate = currentData;
    datePickerView.maxDate = [currentData br_getNewDate:currentData addDays:29];
    @weakify(self)
    datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
        @strongify(self)
        WTCLog(@"选择的值：%@", selectValue);
        [self handleSelectValue:selectValue];
    };

    // 3.显示
    [datePickerView show];
}

#pragma mark -
- (void)handleSelectValue:(NSString *)selectValue {
    if ([selectValue isEqualToString:self.selectedDate]) {
        return;
    }
    if (![self.slider.selectedDate isEqualToString:selectValue]) {
        self.slider.selectedDate = selectValue;
    }
    //埋点
    NSUInteger day = [CMMUtility getDayDifferenceWithStr:selectValue];
    if (self.field == 1) {
        [MobClick event:@"match9" attributes:@{@"isCalendar":@(YES),@"day":@(day)}];
    }else{
        [MobClick event:@"basketball9" attributes:@{@"isCalendar":@(YES),@"day":@(day)}];
    }
    //清空筛选缓存
    if (self.field == 1) {
        ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
        model.screenIsAll = @"1";
        model.screenMatchType = @"-1";
        model.screenLeague = @"-1";
        NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:[SystemManager footBallScreenCache]];
        tmpArr[1] = model;
        [SystemManager setFootBallScreenCache:tmpArr];
    } else {
        ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
        model.screenIsAll = @"1";
        model.screenMatchType = @"-1";
        model.screenLeague = @"-1";
        NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:[SystemManager basketScreenCache]];
        tmpArr[1] = model;
        [SystemManager setBasketScreenCache:tmpArr];
    }
    self.selectedDate = selectValue;
    
    if (self.resetDelegate && [self.resetDelegate respondsToSelector:@selector(resetItemViewController:)]) {
        [self.resetDelegate resetItemViewController:self];
    }
    
    [self loadData:nil];
}

#pragma mark -
- (TimeSliderView *)slider {
    if (!_slider) {
        _slider = [[TimeSliderView alloc] init];
        _slider.delegate = self;
        _slider.type = TimeSliderTypeFuture;
    }return _slider;
}

@end
