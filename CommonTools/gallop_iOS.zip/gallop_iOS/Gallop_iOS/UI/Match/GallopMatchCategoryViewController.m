//
//  GallopMatchCategoryViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/27.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "GallopMatchCategoryViewController.h"

#import "TYTabButtonPagerController.h"
#import "CYTabTitleBar.h"

#import "InstantViewController.h"
#import "ScheduleViewController.h"
#import "ResultViewController.h"
#import "FocusViewController.h"

@interface GallopMatchCategoryViewController () <TYTabPagerControllerDelegate, TYPagerControllerDataSource, MatchScheduleResultResetDelegate>

@property (nonatomic ,strong) TYTabButtonPagerController *titleBarController;
@property (nonatomic ,strong) CYTabTitleBar *titleBarView;

@property (nonatomic ,copy) NSArray *barTitleArray;
@property (nonatomic ,copy) NSArray <ESChildViewController *>*barControllerArray;
@property (nonatomic ,assign) NSInteger currentBarIndex;

@property (nonatomic, strong) NSMutableArray *badgesArray;

@end

@implementation GallopMatchCategoryViewController

- (ESChildViewController *)currentChildVC {
    return [self.barControllerArray objectAtIndex:self.currentBarIndex];
}

- (NSUInteger)currentIndex {
    return self.currentBarIndex;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.badgesArray = @[@0, @0, @0, @0].mutableCopy;
    
    self.barTitleArray = @[@"即时", @"赛程", @"赛果",  @"关注"];
    self.barControllerArray = [self getTitleControllerArray];
    
    [self initSubViews];
    
    if ([self.delegate respondsToSelector:@selector(viewController:didScrollToTabPageIndex:)]) {
        [self.delegate viewController:self didScrollToTabPageIndex:0];
    }
    
    [[NSNotificationCenter defaultCenter] addObserverForName:kFllowMatchCountChange object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        if (self.field != 1) {
            return;
        }
        //关注足球比赛数变化
        dispatch_main_async_safe(^{
            [self updateBadgesValues:note.object];
        });
    }];
    [[NSNotificationCenter defaultCenter] addObserverForName:kFllowBasketMatchCountChange object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        if (self.field != 2) {
            return;
        }
        //关注篮球比赛数变化
        dispatch_main_async_safe(^{
            [self updateBadgesValues:note.object];
        });
    }];
    /// 关注数量增减
    [[NSNotificationCenter defaultCenter] addObserverForName:kMatchFoucesStateChange object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        NSInteger count = [[self.badgesArray objectAtIndex:3] integerValue];
        NSInteger state = [note.object integerValue];
        if (state) {
            count ++;
        }else {
            count --;
        }
        [self.badgesArray replaceObjectAtIndex:3 withObject:@(count)];
        dispatch_main_async_safe(^{
            self.titleBarView.badges = self.badgesArray.copy;
        });
    }];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self loadRedBadges:nil];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.titleBarView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.offset(44);
    }];
    [self.titleBarController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(self.titleBarView.mas_bottom);
    }];
}

#pragma mark -
- (void)initSubViews {
    [self.view addSubview:self.titleBarView];
    self.titleBarView.sliderColor = ColorMainAppRed;
    self.titleBarView.normalItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCRegular:16],
                                                         NSForegroundColorAttributeName:ColorMainNormalBlack};
    self.titleBarView.selectedItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCBold:16],
                                                         NSForegroundColorAttributeName:ColorMainAppRed};
    self.titleBarView.dataArray = self.barTitleArray.copy;
    self.titleBarView.sliderWidth = (kScreen_Width/4) *0.8;
    
    [self addChildViewController:self.titleBarController];
    [self.view addSubview:self.titleBarController.view];
}

#pragma mark -
- (NSInteger)numberOfControllersInPagerController {
    return self.barTitleArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return self.barTitleArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return self.barControllerArray[index];
}

- (void)pagerController:(TYTabPagerController *)pagerController didScrollToTabPageIndex:(NSInteger)index {
    if (self.currentBarIndex != index) {
        self.currentBarIndex = index;
        _titleBarView.currentIndex = index;
        
        [self segementSeletedChange:index];
    }
    if ([self.delegate respondsToSelector:@selector(viewController:didScrollToTabPageIndex:)]) {
        [self.delegate viewController:self didScrollToTabPageIndex:index];
    }
}

#pragma mark -
- (NSArray <ESChildViewController *>*)getTitleControllerArray {
    
    InstantViewController *instant = [[InstantViewController alloc] init];
    instant.field = self.field;
    
    ScheduleViewController *schedule = [[ScheduleViewController alloc] init];
    schedule.field = self.field;
    schedule.resetDelegate = self;
    
    ResultViewController *result = [[ResultViewController alloc] init];
    result.field = self.field;
    result.resetDelegate = self;
    
    FocusViewController *focus = [[FocusViewController alloc] init];
    focus.field = self.field;
    
    return @[instant, schedule, result, focus];
}

#pragma mark -
- (void)segementSeletedChange:(NSInteger)index {
    if (self.currentBarIndex != index) {
        self.currentBarIndex = index;
        _titleBarView.currentIndex = self.currentBarIndex;
    }
    
    if (index != 3) {
        [self loadRedBadges:nil];
    }
}

- (void)loadRedBadges:(id _Nullable)sender {
    if (self.field == 2) {
        //篮球
        //关注红点数
        [ESNetworkService getBasketFollowCount:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                NSString *count = [[dict objectForKey:@"data"]  objectForKey:@"followCount"];
                dispatch_main_async_safe(^{
                    //篮球关注红点展示
                    [self updateBadgesValues:[CommonUtils isEqualToNonNull:count replace:@"0"]];
                });
            }
        }];
    } else {
        //足球
        //关注红点数
        [ESNetworkService getScreenList:2 pageType:0 date:@"" response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                NSString *count = [[dict objectForKey:@"data"]  objectForKey:@"followMatchCount"];
                dispatch_main_async_safe(^{
                    //关注红点展示
                    [self updateBadgesValues:[CommonUtils isEqualToNonNull:count replace:@"0"]];
                });
            }
        }];
    }
}

- (void)updateBadgesValues:(id)lastBadge {
    if (![CommonUtils isEqualToNonNull:lastBadge]) return;
    
    if (self.badgesArray.count != 4) {
        self.badgesArray = @[@0, @0, @0, @0].mutableCopy;
    }
    if ([lastBadge integerValue] != [[self.badgesArray objectAtIndex:3] integerValue]) {
        [self.badgesArray replaceObjectAtIndex:3 withObject:lastBadge];
        self.titleBarView.badges = self.badgesArray.copy;
    }
}

#pragma mark - MatchScheduleResultResetDelegate
- (void)resetItemViewController:(UIViewController *)itemViewController {
    if ([self.delegate respondsToSelector:@selector(viewController:didScrollToTabPageIndex:)]) {
        [self.delegate viewController:self didScrollToTabPageIndex:self.currentBarIndex];
    }
}

#pragma mark - init
- (TYTabButtonPagerController *)titleBarController {
    if (!_titleBarController) {
        _titleBarController = [[TYTabButtonPagerController alloc] init];
        _titleBarController.contentTopEdging = 0.0f;
        _titleBarController.delegate = self;
        _titleBarController.dataSource = self;
        _titleBarController.contentScrollEnabled = NO;
    }return _titleBarController;
}

- (CYTabTitleBar *)titleBarView {
    if (!_titleBarView) {
        _titleBarView = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([CYTabTitleBar class]) owner:self options:nil].lastObject;
        _titleBarView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 44);
        @weakify(self);
        _titleBarView.clickIndexBlock = ^(NSInteger index) {
            @strongify(self);
            if (self.currentBarIndex != index) {
                self.currentBarIndex = index;
                [self.titleBarController moveToControllerAtIndex:index animated:YES];
                [self segementSeletedChange:index];
            }
        };
    } return _titleBarView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
