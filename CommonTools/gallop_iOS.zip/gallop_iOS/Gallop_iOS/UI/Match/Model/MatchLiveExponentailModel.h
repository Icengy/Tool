//
//  MatchLiveExponentailModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface ExponentailDataItem :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , copy) NSString              * matchMin;
@property (nonatomic , copy) NSString              * score;
@property (nonatomic , assign) NSInteger              runningOddsType;
@property (nonatomic , strong) NSString 			   * odds1;
@property (nonatomic , strong) NSString 			   * odds2;
@property (nonatomic , strong) NSString 			   * odds3;
@property (nonatomic , assign) NSInteger              changeOdds1;
@property (nonatomic , assign) NSInteger              changeOdds2;
@property (nonatomic , assign) NSInteger              changeOdds3;
@property (nonatomic , copy) NSString              * changeTime;
@end

@interface MatchLiveExponentailModel : NSObject
@property (nonatomic , assign) NSInteger              code;
@property (nonatomic , copy) NSString              * message;
@property (nonatomic , strong) NSArray <ExponentailDataItem *>              * data;
@end
