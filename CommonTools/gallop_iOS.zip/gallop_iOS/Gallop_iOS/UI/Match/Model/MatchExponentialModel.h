//
//  MatchExponentialModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
//篮球指数变化
@interface BasketChangesItem :NSObject
@property (nonatomic , assign) CGFloat              host;
@property (nonatomic , assign) CGFloat              away;
@property (nonatomic , assign) CGFloat              handicap;
@property (nonatomic , assign) CGFloat				returnRate;
@property (nonatomic , assign) NSInteger              companyId;
@property (nonatomic , assign) NSInteger              state;
@property (nonatomic , assign) NSInteger              closed;
@property (nonatomic , assign) NSInteger              changeTime;
@property (nonatomic , strong) NSArray<NSNumber *> 	*change;

@end


@interface BasketExponentialChart :NSObject
@property (nonatomic , strong) NSArray <BasketChangesItem *>              * changes;
//手动生成字段
@property (nonatomic , strong) NSString *companyName;

@end

//篮球指数
@interface BasketExponentialInit :NSObject
@property (nonatomic , assign) CGFloat              host;
@property (nonatomic , assign) CGFloat              away;
@property (nonatomic , assign) CGFloat              handicap;
@property (nonatomic , assign) NSInteger              companyId;
@property (nonatomic , assign) NSInteger              state;
@property (nonatomic , assign) NSInteger              closed;
@property (nonatomic , assign) NSInteger              changeTime;
@property (nonatomic , strong) NSArray<NSNumber *>	*change;

@end

@interface BasketExponentialItem :NSObject
@property (nonatomic , strong) BasketExponentialInit             *start;
@property (nonatomic , strong) BasketExponentialInit             *current;

@end

@interface BasketExponentialList :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , strong) NSArray <BasketExponentialItem *>              * asia;
@property (nonatomic , strong) NSArray <BasketExponentialItem *>              * eu;
@property (nonatomic , strong) NSArray <BasketExponentialItem *>              * bs;
@property (nonatomic , strong) NSDictionary              * companies;

@end

//足球
@interface ChartOddsListItem :NSObject
@property (nonatomic , assign) CGFloat              odds1;
@property (nonatomic , assign) CGFloat              odds2;
@property (nonatomic , assign) CGFloat              odds3;
@property (nonatomic , copy) NSString              *changeTime;

@end


@interface MatchExponentialChart :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              companyId;
@property (nonatomic , copy) NSString              * companyName;
@property (nonatomic , assign) NSInteger              oddsType;
@property (nonatomic , strong) NSArray <ChartOddsListItem *>              * oddsList;

@end

@interface MatchExponentialItem :NSObject
@property (nonatomic , assign) NSInteger              cid;
@property (nonatomic , copy) NSString              * cname;
@property (nonatomic , strong) NSArray <NSString *>              * start;
@property (nonatomic , strong) NSArray <NSString *>              * instant;
@property (nonatomic , strong) NSArray <NSNumber *>              * change;

@end


@interface MatchExponentialEuro :NSObject
@property (nonatomic , strong) NSArray <MatchExponentialItem *>              * statistics;
@property (nonatomic , strong) NSArray <MatchExponentialItem *>              * odds;
@end

@interface MatchExponentialModel : NSObject
@property (nonatomic , assign) NSInteger matchId;
@property (nonatomic , strong) NSArray <MatchExponentialItem *> *asia;
@property (nonatomic , strong) MatchExponentialEuro *euro;
@property (nonatomic , strong) NSArray <MatchExponentialItem *> *goal;
@end

