//
//  MatchExponentialModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchExponentialModel.h"
//篮球指数变化
@implementation BasketChangesItem

@end


@implementation BasketExponentialChart
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"changes":@"BasketChangesItem"};
}
@end

//篮球指数
@implementation BasketExponentialInit

@end

@implementation BasketExponentialItem
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"start":@"init",@"current":@"now"};
}
@end

@implementation BasketExponentialList
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"matchId":@"id"};
}

+ (NSDictionary *)mj_objectClassInArray {
	return @{@"asia":@"BasketExponentialItem",
			 @"eu":@"BasketExponentialItem",
			 @"bs":@"BasketExponentialItem"
	};
}

@end

//足球
@implementation ChartOddsListItem
@end


@implementation MatchExponentialChart
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"oddsList" : @"ChartOddsListItem"
             };
}

@end

@implementation MatchExponentialItem

@end


@implementation MatchExponentialEuro
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"statistics" : @"MatchExponentialItem",
             @"odds" : @"MatchExponentialItem"
             };
}
@end

@implementation MatchExponentialModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"goal" : @"MatchExponentialItem",
             @"asia" : @"MatchExponentialItem"
             };
}
@end
