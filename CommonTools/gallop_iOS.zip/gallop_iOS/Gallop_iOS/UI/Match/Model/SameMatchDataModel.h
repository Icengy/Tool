//
//  SameMatchDataModel.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/9/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface SameNums : NSObject
@property (nonatomic,strong) NSString *total;
@property (nonatomic,strong) NSString *lose;
@property (nonatomic,strong) NSString *win;
@property (nonatomic,strong) NSString *flow;
@property (nonatomic,strong) NSString *rate;
@end
@interface SameMatchSub : NSObject
@property (nonatomic , copy) NSString              * startTime;
@property (nonatomic , copy) NSString              * league;
@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * hostScore;
@property (nonatomic , copy) NSString              * guestScore;
@property (nonatomic , copy) NSString              * halfHostScore;
@property (nonatomic , copy) NSString              * halfGuestScore;
@property (nonatomic , copy) NSString              * odds;
@property (nonatomic , copy) NSString              * result;

@end
@interface SameMatchDataModel : NSObject

@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * hostFlag;
@property (nonatomic , copy) NSString              * guestFlag;
@property (nonatomic , strong) NSArray <SameMatchSub *>              * hostList;
@property (nonatomic , strong) NSArray <SameMatchSub *>              * guestList;
@property (nonatomic,strong) SameNums*hostDataTotal;
@property (nonatomic,strong) SameNums*guestDataTotal;

@property (nonatomic , assign) BOOL              isHost;
@property (nonatomic , assign) CGFloat              hostHeight;
@property (nonatomic , assign) CGFloat              guestHeight;

@end

NS_ASSUME_NONNULL_END
