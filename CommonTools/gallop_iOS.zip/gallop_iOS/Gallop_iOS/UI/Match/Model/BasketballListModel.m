//
//  BasketballListModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "BasketballListModel.h"
@implementation infoMapModel

@end

@implementation Host

@end

@implementation Away

@end

@implementation AsiaDish

@end

@implementation BsDish

@end

@implementation BasketballItem
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"matchId":@"id"};
}
@end

@implementation BasketballMatches
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"ends" : @"BasketballItem",
			 @"unStarts" : @"BasketballItem",
			 @"ongoings" : @"BasketballItem"
	};
}
@end

@implementation BasketballListModel

@end

