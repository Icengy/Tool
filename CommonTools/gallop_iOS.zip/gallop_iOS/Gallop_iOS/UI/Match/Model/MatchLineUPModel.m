//
//  MatchLineUPModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchLineUPModel.h"
@implementation LineupModel

@end
@implementation PlaceArrModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"m_0": @"0",@"m_1": @"1",@"m_2": @"2",@"m_3": @"3",@"m_4": @"4",@"m_5": @"5"};
}
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"m_1" : @"LineupModel",
             @"m_0" : @"LineupModel",
             @"m_2" : @"LineupModel",
             @"m_3" : @"LineupModel",
             @"m_4" : @"LineupModel",
             @"m_5" : @"LineupModel"
             };
}
@end
@implementation MatchLineUPModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"guestFirstLineup" : @"LineupModel",
             @"guestSecondLineup" : @"LineupModel",
             @"hostFirstLineup" : @"LineupModel",
             @"hostSecondLineup" : @"LineupModel"
             };
}

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    
    self.isHost = YES;
    /// 主队首发+替补
    self.hostLineupHeight += [self configureLineupHeight:self.hostFirstLineup];
    self.hostLineupHeight += [self configureLineupHeight:self.hostSecondLineup];
    if (self.hostLineupHeight != 0.0)
        self.hostLineupHeight += (40.0 + 10.0);
    
    /// 客队首发+替补
    self.guestLineupHeight += [self configureLineupHeight:self.guestFirstLineup];
    self.guestLineupHeight += [self configureLineupHeight:self.guestSecondLineup];
    if (self.guestLineupHeight != 0.0)
        self.guestLineupHeight += (40.0 + 10.0);
    
    
    /// map
    [self configureHostMark:self.hostFirstLineupMap.m_0];
    [self configureHostMark:self.hostFirstLineupMap.m_1];
    [self configureHostMark:self.hostFirstLineupMap.m_2];
    [self configureHostMark:self.hostFirstLineupMap.m_3];
    [self configureHostMark:self.hostFirstLineupMap.m_4];
    [self configureHostMark:self.hostFirstLineupMap.m_5];
    
    if (self.hostPrice > 0 && self.guestPrice > 0) {
        self.showStartingPriceSquad = YES;
    }else {
        self.showStartingPriceSquad = NO;
    }
    self.startingPriceHeight = self.showStartingPriceSquad?97.0:0.0;
    
    if (self.hostFirstLineupMap.m_0.count != 1 ||
        self.guestFirstLineupMap.m_0.count != 1) {
        self.showPlayerMapSquad = NO;
    }else {
        self.showPlayerMapSquad = YES;
    }
    self.playerMapHeight = self.showPlayerMapSquad?700.0:0.0;
}

- (void)configureHostMark:(NSArray <LineupModel *>*)datas {
    if (QM_IS_ARRAY_NIL(datas)) return;
    [datas enumerateObjectsUsingBlock:^(LineupModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.isHost = YES;
    }];
}

- (CGFloat)configureLineupHeight:(NSArray <LineupModel *>*)datas {
    if (QM_IS_ARRAY_NIL(datas)) return 0.0;
    CGFloat height = 40.0;// 头部
    height += (44.0 * datas.count);
    return height;
}

@end
