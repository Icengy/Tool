//
//  MatchTCPMessageModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
//比赛开始
@interface MatchStartMessageModel : NSObject
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger status;
@end
//红牌
@interface MatchRedCardMessageModel : NSObject
@property (nonatomic, assign) NSInteger hostGuest;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger currentCount;
@end
//黄牌
@interface MatchYellowCardMessageModel : NSObject;
@property (nonatomic, assign) NSInteger hostGuest;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger currentCount;
@end
//角球
@interface MatchCornerMessageModel : NSObject
@property (nonatomic, assign) NSInteger hostGuest;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger currentCount;
@end
//进球
@interface MatchGoalMessageModel : NSObject
@property (nonatomic, assign) NSInteger goalTime;
@property (nonatomic, strong) NSString *guestName;
@property (nonatomic, assign) NSInteger guestScore;
@property (nonatomic, assign) NSInteger hostGuest;
@property (nonatomic, strong) NSString *hostName;
@property (nonatomic, assign) NSInteger hostScore;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger sound;
@property (nonatomic, assign) NSInteger shake;
@property (nonatomic, assign) NSInteger isShow;
/// 0 全部 1 仅我关注的
@property (nonatomic, assign) NSInteger followedOnly;
@end
//半场结束
@interface MatchHalfEndMessageModel : NSObject
@property (nonatomic, assign) NSInteger guestScore;
@property (nonatomic, assign) NSInteger hostScore;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@end
//比赛结束
@interface MatchEndMessageModel : NSObject
@property (nonatomic, assign) NSInteger guestScore;
@property (nonatomic, assign) NSInteger hostScore;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@end

@interface MatchTCPMessageModel : NSObject

@end

//篮球相关消息
@interface MatchBaskectItem :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              state;
@property (nonatomic , assign) NSInteger              seconds;
@property (nonatomic , strong) NSArray <NSNumber *>              * hostScores;
@property (nonatomic , strong) NSArray <NSNumber *>              * awayScores;

@end


@interface MatchBaskectTCPMessage :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , strong) NSArray <MatchBaskectItem *>              * data;

@end
