//
//  MatchIntelligenceModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchIntelligenceModel.h"

@implementation MatchIntelligenceRecommendInfoDTO

//- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
//
//}

- (void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    
    if ([key isEqualToString:@"guestHandicapTrends"]) {
        self.guestHandicapTrends = [[[self.guestHandicapTrends stringByReplacingOccurrencesOfString:@"W" withString:@"胜"] stringByReplacingOccurrencesOfString:@"L" withString:@"负"] stringByReplacingOccurrencesOfString:@"D" withString:@"平"];
    }
    if ([key isEqualToString:@"guestRecentTrends"]) {
        self.guestRecentTrends = [[[self.guestRecentTrends stringByReplacingOccurrencesOfString:@"W" withString:@"胜"] stringByReplacingOccurrencesOfString:@"L" withString:@"负"] stringByReplacingOccurrencesOfString:@"D" withString:@"平"];
    }
    if ([key isEqualToString:@"hostHandicapTrends"]) {
        self.hostHandicapTrends = [[[self.hostHandicapTrends stringByReplacingOccurrencesOfString:@"W" withString:@"胜"] stringByReplacingOccurrencesOfString:@"L" withString:@"负"] stringByReplacingOccurrencesOfString:@"D" withString:@"平"];
    }
    if ([key isEqualToString:@"hostRecentTrends"]) {
        self.hostRecentTrends = [[[self.hostRecentTrends stringByReplacingOccurrencesOfString:@"W" withString:@"胜"] stringByReplacingOccurrencesOfString:@"L" withString:@"负"] stringByReplacingOccurrencesOfString:@"D" withString:@"平"];
    }
}

@end

@implementation MatchIntelligenceModel

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    NSMutableArray *datas = @[].mutableCopy;
    if (self.recommendInfoDTO) {
        MatchIntelligenceRecommendInfoDTO *dto = self.recommendInfoDTO;
        NSMutableArray *objs_host = @[].mutableCopy;
        [objs_host addObject:[CommonUtils isEqualToNonNull:dto.hostName replace:@"主队"]];
        [objs_host addObject:[CommonUtils isEqualToNonNull:dto.hostRecentTrends replace:@"暂无"]];
        [objs_host addObject:[CommonUtils isEqualToNonNull:dto.hostHandicapTrends replace:@"暂无"]];
        if (objs_host.count) [datas addObject:objs_host];
        
        NSMutableArray *objs_guest = @[].mutableCopy;
        [objs_guest addObject:[CommonUtils isEqualToNonNull:dto.guestName replace:@"客队"]];
        [objs_guest addObject:[CommonUtils isEqualToNonNull:dto.guestRecentTrends replace:@"暂无"]];
        [objs_guest addObject:[CommonUtils isEqualToNonNull:dto.guestHandicapTrends replace:@"暂无"]];
        if (objs_guest.count) [datas addObject:objs_guest];
    }
//    if (datas.count) {
//        [datas insertObject:@[@"球队", @"近况走势", @"盘路走势"] atIndex:0];
//    }
    self.datas = datas;
    
    self.myHeight = (self.datas.count + ((self.datas.count != 0)?1:0)) *30.0;
    /// 间隔
    if (self.myHeight != 0.0) self.myHeight += (8.0 *2);
}

@end

@implementation MatchIntelligencePreModel

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    __block double hostHeight = 0.0;
    [self.hostPreInfo enumerateObjectsUsingBlock:^(MatchIntelligencePreItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        hostHeight += obj.myHeight;
    }];
    if (hostHeight > 0.0) {
        hostHeight += (self.hostPreInfo.count * 30.0 + 5.0);
        self.hostHeight = (hostHeight + 40.0);
    }else {
        self.hostHeight = 240.0;
    }
    __block double guestHeight = 0.0;
    [self.guestPreInfo enumerateObjectsUsingBlock:^(MatchIntelligencePreItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        guestHeight += obj.myHeight;
    }];
    if (guestHeight > 0.0) {
        guestHeight += (self.guestPreInfo.count * 30.0 + 5.0);
        self.guestHeight = (guestHeight + 40.0);
    }else {
        self.guestHeight = 240.0;
    }
}

- (void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    
    /// 35- 30.0为头部高度 5.0为尾部高度
    /// 有利消息
    if ([key isEqualToString:@"hostInfo"]) {
        self.hostPreInfo = [self handlePreInfo:_hostInfo];
    }
    if ([key isEqualToString:@"guestInfo"]) {
        self.guestPreInfo = [self handlePreInfo:_guestInfo];
    }
}

- (NSArray *)handlePreInfo:(NSArray<NSString *> *)info {
    NSMutableArray *pres = info.mutableCopy;
    [info enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        MatchIntelligencePreItem *item = [MatchIntelligencePreItem new];
        if ([obj containsString:@"【有利】"]) {
            item.content = [obj stringByReplacingOccurrencesOfString:@"【有利】" withString:@""];
            item.negative = YES;
        }
        if ([obj containsString:@"【不利】"]) {
            item.content = [obj stringByReplacingOccurrencesOfString:@"【不利】" withString:@""];
            item.negative = NO;
        }
        CGFloat height = [obj sizeWithDefaultLabelEdgeWithFont:GetFont(12.0) andMaxSize:CGSizeMake(kScreen_Width - 30.0 - 16.0, CGFLOAT_MAX) numberOfLines:0].height;
        if (height > 0.0) {
            item.myHeight += height;
        }else {
            item.myHeight = 0.0;
        }
        
        [pres replaceObjectAtIndex:idx withObject:item];
    }];
    return pres.copy;
}

@end

@implementation MatchIntelligencePreItemModel

- (void)setPreInfo:(NSArray<NSString *> *)preInfo {
//    _preInfo = preInfo;
    NSMutableArray *pres = preInfo.mutableCopy;
    [preInfo enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([obj containsString:@"【有利】"]) {
            obj = [obj stringByReplacingOccurrencesOfString:@"【有利】" withString:@""];
        }
        if ([obj containsString:@"【不利】"]) {
            obj = [obj stringByReplacingOccurrencesOfString:@"【不利】" withString:@""];
        }
        [pres replaceObjectAtIndex:idx withObject:obj];
    }];
    _preInfo = pres.copy;
}

@end

@implementation MatchIntelligencePreItem

@end

