//
//  MatchExponentialChangeModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface MatchExponentialChangeOddsItem :NSObject
@property (nonatomic , strong) NSArray <NSString *>              * instantOdds;
@property (nonatomic , copy) NSString              * changeTime;
@property (nonatomic , strong) NSArray <NSNumber *>              * changeStatus;
@property (nonatomic , copy) NSString              * payBackRatio;
@end

@interface MatchExponentialChangeModel : NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              comId;
@property (nonatomic , strong) NSArray <MatchExponentialChangeOddsItem *>              * odds;
@end

