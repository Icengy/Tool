//
//  ScreenModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface BasketLeaguesModel :NSObject
@property (nonatomic , copy) NSString              *leagueId;
@property (nonatomic , copy) NSString              * shortNameZh;
@property (nonatomic , assign) NSInteger             matchCount;
@property(nonatomic, assign) BOOL selected;
@end

@interface AllItem :NSObject
@property (nonatomic , copy) NSString              * firstLetter;
@property (nonatomic , strong) NSArray <BasketLeaguesModel *>              * events;
@end

@interface BasketScreenModel :NSObject
@property (nonatomic , strong) NSArray <AllItem *>              * all;
@property (nonatomic , strong) BasketLeaguesModel              * nba;
@property (nonatomic , strong) NSArray <BasketLeaguesModel *>              * lotteries;
@end

@interface LeaguesModel : NSObject
@property(nonatomic, strong)NSString *leagueName;
@property(nonatomic, strong)NSString *leagueId;
@property(nonatomic, strong)NSString *number;
@property(nonatomic, assign)NSInteger selected;
@end

@interface LeaguesList : NSObject
@property(nonatomic, strong)NSString *letter;
@property(nonatomic, strong)NSArray<LeaguesModel *> *league;
@end

@interface ScreenModel : NSObject
@property(nonatomic, assign)NSInteger followMatchCount; // 关注比赛总数，等于0不显示
@property(nonatomic, assign)NSInteger matchType;
@property(nonatomic, strong)NSArray<LeaguesList *> *leagues;
@end
