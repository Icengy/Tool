//
//  MatchTCPMessageModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchTCPMessageModel.h"
//比赛开始
@implementation MatchStartMessageModel

@end
//红牌
@implementation MatchRedCardMessageModel

@end
//黄牌
@implementation MatchYellowCardMessageModel;

@end
//角球
@implementation MatchCornerMessageModel

@end
//进球
@implementation MatchGoalMessageModel

@end
//半场结束
@implementation MatchHalfEndMessageModel

@end
//比赛结束
@implementation MatchEndMessageModel

@end

@implementation MatchTCPMessageModel

@end

@implementation MatchBaskectItem

@end


@implementation MatchBaskectTCPMessage
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"data":@"MatchBaskectItem"};
}
@end
