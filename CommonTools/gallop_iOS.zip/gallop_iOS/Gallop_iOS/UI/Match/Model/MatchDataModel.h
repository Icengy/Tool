//
//  MatchDataModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MatchDetailNums : NSObject

@property (nonatomic,strong) NSString *totalCount;
@property (nonatomic,strong) NSString *winCount;
@property (nonatomic,strong) NSString *drawCount;
@property (nonatomic,strong) NSString *loseCount;
@property (nonatomic,strong) NSString *inCount;
@property (nonatomic,strong) NSString *outCount;
@property (nonatomic,strong) NSString *winRate;

@end

@interface SameMatchDetailNums : NSObject

@property (nonatomic,strong) NSString *total;
@property (nonatomic,strong) NSString *lose;
@property (nonatomic,strong) NSString *win;
@property (nonatomic,strong) NSString *flow;
@property (nonatomic,strong) NSString *rate;

@end

@interface HostGuestMatchListItem :NSObject

@property (nonatomic , copy) NSString              * startTime;
@property (nonatomic , copy) NSString              * league;
@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * hostScore;
@property (nonatomic , copy) NSString              * guestScore;
@property (nonatomic , copy) NSString              * halfHostScore;
@property (nonatomic , copy) NSString              * halfGuestScore;
@property (nonatomic , copy) NSString              * odds;
@property (nonatomic , copy) NSString              * result;

@end

@interface MatchDataBaseModel : NSObject

@property (nonatomic , assign) NSInteger              index;
@property (nonatomic , assign) CGFloat              hostHeight;
@property (nonatomic , assign) CGFloat              guestHeight;

@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * hostFlag;
@property (nonatomic , copy) NSString              * guestFlag;

@property (nonatomic , strong) NSArray <HostGuestMatchListItem *>              *hostMatchList;
@property (nonatomic , strong) NSArray <HostGuestMatchListItem *>              *guestMatchList;

@end

#pragma mark - 近期战绩
@interface MatchDataModel : MatchDataBaseModel

@property (nonatomic , assign) BOOL              showRecent;

@property (nonatomic , copy) NSString              * hostResultInfo;
@property (nonatomic , copy) NSString              * guestResultInfo;

@property (nonatomic , strong) MatchDetailNums              * hostResultDetail;
@property (nonatomic , strong) MatchDetailNums              * guestResultDetail;

@end


#pragma mark - 相同历史盘口
@interface SameMatchDataModel : MatchDataBaseModel

@property (nonatomic,strong) SameMatchDetailNums *hostDataTotal;
@property (nonatomic,strong) SameMatchDetailNums *guestDataTotal;

@end
