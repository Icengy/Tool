//
//  ChatTCPMessageModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ChatTCPMessageModel.h"

@implementation ChatTCPResponseModel

@end

@implementation ChatTCPMessageModel

@end

@implementation ChatTCPInitModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"messageList" : @"ChatTCPMessageModel",
             };
}
@end
