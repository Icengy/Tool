//
//  MatchInstantListModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/19.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
//即时列表
@interface InstantProcessLine : NSObject
@property (nonatomic, assign) NSInteger guestCorner;
@property (nonatomic, assign) NSInteger guestRedCard;
@property (nonatomic, assign) NSInteger guestYellowCard;
@property (nonatomic, assign) NSInteger hostCorner;
@property (nonatomic, assign) NSInteger hostRedCard;
@property (nonatomic, assign) NSInteger hostYellowCard;
@end

@interface InstantMatcth : NSObject
@property (nonatomic, assign) NSInteger elapsedTime;
@property (nonatomic, assign) NSInteger firstGuestScore;
@property (nonatomic, assign) NSInteger firstHostScore;
@property (nonatomic, assign) NSInteger guestCorner;
@property (nonatomic, copy) NSString * guestName;
@property (nonatomic, copy) NSString * guestIcon;
@property (nonatomic, copy) NSString * instantGuestRank;
@property (nonatomic, assign) NSInteger guestRedCard;
@property (nonatomic, assign) NSInteger guestScore;
@property (nonatomic, assign) NSInteger guestYellowCard;
@property (nonatomic, assign) NSInteger halfGuestScore;
@property (nonatomic, assign) NSInteger halfHostScore;
@property (nonatomic, assign) NSInteger hasExpert;
@property (nonatomic, assign) NSInteger hasInformation;
@property (nonatomic, assign) NSInteger hostCorner;
@property (nonatomic, copy) NSString * hostName;
@property (nonatomic, copy) NSString * hostIcon;
@property (nonatomic, copy) NSString * instantHostRank;
@property (nonatomic, assign) NSInteger hostRedCard;
@property (nonatomic, assign) NSInteger hostScore;
@property (nonatomic, assign) NSInteger hostYellowCard;
@property (nonatomic, assign) NSInteger isFollowed;
@property (nonatomic, assign) NSInteger isNeutralSite;
@property (nonatomic, copy) NSString * league;
@property (nonatomic, copy) NSString * leagueColor;
@property (nonatomic, assign) NSInteger liveType;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, copy) NSString * matchSite;
@property (nonatomic, strong) NSArray<InstantProcessLine *> * processLineList;
@property (nonatomic, assign) NSInteger startTime;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, copy) NSString *totalScore;
@property (nonatomic, copy) NSString *resultInfo;
@property (nonatomic, copy) NSString *lotteryNo;
@property (nonatomic, copy) NSString *handicap;
@end

@interface MatchInstantListModel : NSObject
@property (nonatomic, strong) NSArray<InstantMatcth *> * finishedMatchList;
@property (nonatomic, strong) NSArray<InstantMatcth *> * matchList;
@property (nonatomic, assign) NSInteger page;
@property (nonatomic, assign) NSInteger pageCount;
@property (nonatomic, assign) NSInteger pageSize;
@end

//关注列表
@interface FollowListModel : NSObject
@property (nonatomic, assign) NSInteger date;
@property (nonatomic, strong) NSMutableArray<InstantMatcth *> * matchList;
@end


@interface MatchFollowListModel : NSObject
@property (nonatomic, strong) NSMutableArray<FollowListModel *> *progressList;
@property (nonatomic, strong) NSMutableArray<FollowListModel *> *notStartList;
@property (nonatomic, strong) NSMutableArray<FollowListModel *> *finishedList;
@end
