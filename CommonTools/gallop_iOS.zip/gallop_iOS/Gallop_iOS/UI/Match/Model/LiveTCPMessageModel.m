//
//  LiveTCPMessageModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/25.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "LiveTCPMessageModel.h"

@interface LiveTCPTechnologyChangeModel ()

@property (nonatomic ,strong) NSMutableArray <NSDictionary *>*technologyList;

@end

@implementation LiveTCPTechnologyChangeModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.technologyList = [NSMutableArray new];
    }
    return self;
}

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    [self configureTechnologys];
}

- (void)judgeTechnologyNamed:(NSString *)name value:(id)value {
    if ([CommonUtils isEqualToNonNull:value] && [value containsString:@","]) {
        [self.technologyList addObject:@{name:value}];
    }
}

- (void)configureTechnologys {
    if (self.technologyList.count) [self.technologyList removeAllObjects];

    [self judgeTechnologyNamed:@"角球" value:self.corner];
    [self judgeTechnologyNamed:@"半场角球" value:self.halfCorner];
    [self judgeTechnologyNamed:@"红牌" value:self.redCard];
    [self judgeTechnologyNamed:@"黄牌" value:self.yellowCard];
    [self judgeTechnologyNamed:@"射门" value:self.shot];
    [self judgeTechnologyNamed:@"射正" value:self.shotOnTarget];
    [self judgeTechnologyNamed:@"进攻" value:self.attack];
    [self judgeTechnologyNamed:@"危险进攻" value:self.dangerousAttack];
    [self judgeTechnologyNamed:@"射门不中" value:self.shotAside];
    [self judgeTechnologyNamed:@"射门被挡" value:self.blockedShots];
    [self judgeTechnologyNamed:@"任意球" value:self.freeKick];
    [self judgeTechnologyNamed:@"半场控球率" value:self.halfControl];
    [self judgeTechnologyNamed:@"传球" value:self.pass];
    [self judgeTechnologyNamed:@"传球成功率" value:self.passSuccess];
    [self judgeTechnologyNamed:@"犯规" value:self.foul];
    [self judgeTechnologyNamed:@"越位" value:self.offside];
    [self judgeTechnologyNamed:@"头球" value:self.headGoal];
    [self judgeTechnologyNamed:@"头球成功" value:self.headGoalSuccess];
    [self judgeTechnologyNamed:@"铲球" value:self.slideTackle];
    [self judgeTechnologyNamed:@"过人" value:self.dribblingPastOpponents];
    [self judgeTechnologyNamed:@"界外球" value:self.outOfBounds];
    [self judgeTechnologyNamed:@"中柱" value:self.hitPost];
    [self judgeTechnologyNamed:@"成功抢断" value:self.stealSuccess];
    [self judgeTechnologyNamed:@"阻截" value:self.intercept];
    [self judgeTechnologyNamed:@"助攻" value:self.assist];
    
    self.technologys = self.technologyList.copy;
}

@end

@implementation OddsListItem

@end

@implementation AsiaOddsDTO
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"oddsList" : @"OddsListItem"
             };
}
@end

@implementation GoalOddsDTO
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"oddsList" : @"OddsListItem"
             };
}
@end

@implementation LiveTCPExponentailChangeModel

@end

@implementation LiveTCPUpdateALLImportantEventModel

@end

@implementation LiveTCPImportantEventModel

@end

@implementation LiveTCPImportantEventList
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"eventList" : @"LiveTCPImportantEventModel"
             };
}
@end

@implementation LiveTCPMessageModel

@end

@implementation LiveTCPInitMessageModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"messageList" : @"LiveTCPMessageModel",
             };
}
@end

@implementation LiveTCPUpdateMessageModel

@end

@implementation LiveTCPBasketLiveModel


@end
