//
//  ChatTCPMessageModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ChatTCPResponseModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , assign) NSInteger              success;
@property (nonatomic , copy) NSString              * content;
@property (nonatomic , copy) NSString              * failMessage;

@end

@interface ChatTCPMessageModel : NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , assign) NSInteger              userId;
@property (nonatomic , copy) NSString              * userName;
@property (nonatomic , copy) NSString              * userAvatar;
@property (nonatomic , copy) NSString              * content;
@end


@interface ChatTCPInitModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              userId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , assign) NSInteger              isForbidden;
@property (nonatomic , assign) NSString               *cancelForbiddenTime;
@property (nonatomic , strong) NSArray <ChatTCPMessageModel *>              * messageList;

@end
