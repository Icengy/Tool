//
//  MatchFilterModel.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MatchFilter : NSObject

/// 标题
@property (nonatomic, copy) NSString *title;
/// 是否选中
@property (nonatomic, assign) BOOL selected;

@end

@interface MatchFilterModel : NSObject

/// 标题
@property (nonatomic ,copy) NSString *title;

@property (nonatomic ,strong) NSArray <MatchFilter *>*filters;

@end

NS_ASSUME_NONNULL_END
