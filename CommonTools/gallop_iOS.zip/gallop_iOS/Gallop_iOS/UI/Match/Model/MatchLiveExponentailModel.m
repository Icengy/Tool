//
//  MatchLiveExponentailModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchLiveExponentailModel.h"

@implementation ExponentailDataItem

@end

@implementation MatchLiveExponentailModel
+ (NSDictionary *)mj_objectClassInArray {
	return @{
		@"data" : @"ExponentailDataItem"
	};
}
@end
