//
//  LiveTCPMessageModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/25.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LiveTCPTechnologyChangeModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , copy) NSString              * corner;
@property (nonatomic , copy) NSString              * halfCorner;
@property (nonatomic , copy) NSString              * redCard;
@property (nonatomic , copy) NSString              * yellowCard;
@property (nonatomic , copy) NSString              * shot;
@property (nonatomic , copy) NSString              * shotOnTarget;
@property (nonatomic , copy) NSString              * attack;
@property (nonatomic , copy) NSString              * dangerousAttack;
@property (nonatomic , copy) NSString              * shotAside;
@property (nonatomic , copy) NSString              * blockedShots;
@property (nonatomic , copy) NSString              * freeKick;
@property (nonatomic , copy) NSString              * halfControl;
@property (nonatomic , copy) NSString              * pass;
@property (nonatomic , copy) NSString              * passSuccess;
@property (nonatomic , copy) NSString              * foul;
@property (nonatomic , copy) NSString              * offside;
@property (nonatomic , copy) NSString              * headGoal;
@property (nonatomic , copy) NSString              * headGoalSuccess;
@property (nonatomic , copy) NSString              * slideTackle;
@property (nonatomic , copy) NSString              * dribblingPastOpponents;
@property (nonatomic , copy) NSString              * outOfBounds;
@property (nonatomic , copy) NSString              * hitPost;
@property (nonatomic , copy) NSString              * stealSuccess;
@property (nonatomic , copy) NSString              * intercept;
@property (nonatomic , copy) NSString              * assist;

@property (nonatomic , copy) NSArray <NSDictionary *>* technologys;

@end

@interface OddsListItem :NSObject
@property (nonatomic , copy) NSString              * matchTime;
@property (nonatomic , assign) NSInteger              hostScore;
@property (nonatomic , assign) NSInteger              awayScore;
@property (nonatomic , copy) NSString              * startOdds;
@property (nonatomic , copy) NSString              * instantOdds;
@property (nonatomic , copy) NSString              * startOddsChangeStatus;
@property (nonatomic , copy) NSString              * changeStatus;

@end

@interface AsiaOddsDTO :NSObject
@property (nonatomic , assign) NSInteger              companyId;
@property (nonatomic , assign) NSInteger              oddsType;
@property (nonatomic , strong) NSArray <OddsListItem *>              * oddsList;

@end

@interface GoalOddsDTO :NSObject
@property (nonatomic , assign) NSInteger              companyId;
@property (nonatomic , assign) NSInteger              oddsType;
@property (nonatomic , strong) NSArray <OddsListItem *>              * oddsList;

@end


@interface LiveTCPExponentailChangeModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , assign) NSInteger              matchId;
/// 亚赔数据
@property (nonatomic , strong) AsiaOddsDTO              * asiaOddsDTO;
/// 大小球数据
@property (nonatomic , strong) GoalOddsDTO              * goalOddsDTO;

@end

@interface LiveTCPUpdateALLImportantEventModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              type;
@end

@interface LiveTCPImportantEventModel :NSObject
@property (nonatomic , assign) NSInteger              messageId;
@property (nonatomic , assign) NSInteger              recordId;
@property (nonatomic , assign) NSInteger              recordOrder;
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              type;
@property (nonatomic , assign) NSInteger              matchTime;
@property (nonatomic , assign) NSInteger              eventType;
@property (nonatomic , assign) NSInteger              hostGuest;
@property (nonatomic , assign) NSInteger              hostScore;
@property (nonatomic , assign) NSInteger              guestScore;
@property (nonatomic , copy) NSString              * playerName;
@property (nonatomic , copy) NSString              * helperName;
@property (nonatomic , copy) NSString              * upPlayerName;
@property (nonatomic , copy) NSString              * downPlayerName;
@end

@interface LiveTCPImportantEventList : NSObject
@property (nonatomic, strong) NSArray<LiveTCPImportantEventModel *> *eventList;
@end

@interface LiveTCPMessageModel : NSObject
@property (nonatomic, strong) NSString * content;
@property (nonatomic, assign) NSInteger iconType;
@property (nonatomic, assign) NSInteger recordId;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@end

@interface LiveTCPInitMessageModel : NSObject
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, strong) NSArray<LiveTCPMessageModel *> * messageList;
@property (nonatomic, assign) NSInteger type;
@end

@interface LiveTCPUpdateMessageModel : NSObject
@property (nonatomic, assign) NSInteger guestAttack;
@property (nonatomic, assign) NSInteger guestControl;
@property (nonatomic, assign) NSInteger guestCorner;
@property (nonatomic, assign) NSInteger guestDangerousAttack;
@property (nonatomic, copy) NSString * guestName;
@property (nonatomic, assign) NSInteger guestRedCard;
@property (nonatomic, assign) NSInteger guestScore;
@property (nonatomic, assign) NSInteger guestShotAside;
@property (nonatomic, assign) NSInteger guestShotOnTarget;
@property (nonatomic, assign) NSInteger guestYellowCard;
@property (nonatomic, assign) NSInteger halfGuestScore;
@property (nonatomic, assign) NSInteger halfHostScore;
@property (nonatomic, assign) NSInteger hostAttack;
@property (nonatomic, assign) NSInteger hostControl;
@property (nonatomic, assign) NSInteger hostCorner;
@property (nonatomic, assign) NSInteger hostDangerousAttack;
@property (nonatomic, copy) NSString * hostName;
@property (nonatomic, assign) NSInteger hostRedCard;
@property (nonatomic, assign) NSInteger hostScore;
@property (nonatomic, assign) NSInteger hostShotAside;
@property (nonatomic, assign) NSInteger hostShotOnTarget;
@property (nonatomic, assign) NSInteger hostYellowCard;
@property (nonatomic, assign) NSInteger matchId;
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, assign) NSInteger type;
@end

@interface LiveTCPBasketLiveModel : NSObject
@property (nonatomic, assign) NSInteger messageId;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic,strong) NSArray*data;
@end
