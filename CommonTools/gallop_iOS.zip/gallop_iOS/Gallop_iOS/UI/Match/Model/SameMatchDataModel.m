//
//  SameMatchDataModel.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/9/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SameMatchDataModel.h"
@implementation SameNums
@end
@implementation SameMatchSub
@end
@implementation SameMatchDataModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"hostList" : @"SameMatchSub",
             @"guestList" : @"SameMatchSub"
             };
}
@end
