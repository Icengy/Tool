//
//  MatchLineUPModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface LineupModel : NSObject
@property (nonatomic, strong) NSArray * events;
@property (nonatomic, copy) NSString * flag;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, assign) NSInteger number;
@property (nonatomic, copy) NSString * place;
@property (nonatomic, copy) NSString * playerId;
@property (nonatomic, copy) NSString * price;
@property (nonatomic, assign) BOOL isHost;
@end


@interface PlaceArrModel : NSObject
@property (nonatomic, strong) NSArray <LineupModel *>*m_0;
@property (nonatomic, strong) NSArray <LineupModel *>*m_1;
@property (nonatomic, strong) NSArray <LineupModel *>*m_2;
@property (nonatomic, strong) NSArray <LineupModel *>*m_3;
@property (nonatomic, strong) NSArray <LineupModel *>*m_4;
@property (nonatomic, strong) NSArray <LineupModel *>*m_5;
@end


@interface MatchLineUPModel : NSObject

@property (nonatomic, copy) NSString *hostName;
@property (nonatomic, copy) NSString *guestName;
@property (nonatomic, copy) NSString *hostId;
@property (nonatomic, copy) NSString *guestId;
@property (nonatomic, assign) NSInteger hostPrice;
@property (nonatomic, assign) NSInteger guestPrice;
@property (nonatomic, copy) NSString * hostLiveupType;
@property (nonatomic, copy) NSString * guestLiveupType;


/// 阵容数据
@property (nonatomic, strong) NSArray<LineupModel *> * guestFirstLineup;
@property (nonatomic, strong) NSArray<LineupModel *> * guestSecondLineup;
@property (nonatomic, strong) NSArray<LineupModel *> * hostFirstLineup;
@property (nonatomic, strong) NSArray<LineupModel *> * hostSecondLineup;

@property (nonatomic, assign) BOOL isHost;

@property (nonatomic, assign) CGFloat hostLineupHeight;
@property (nonatomic, assign) CGFloat guestLineupHeight;


/// 队员map数据
@property (nonatomic, strong) PlaceArrModel * hostFirstLineupMap;
@property (nonatomic, strong) PlaceArrModel * guestFirstLineupMap;

/// 身价是否展示
@property (nonatomic, assign) BOOL showStartingPriceSquad;
/// 身价高度
@property (nonatomic, assign) CGFloat startingPriceHeight;
/// 球员map展示
@property (nonatomic, assign) BOOL showPlayerMapSquad;
/// 球员map
@property (nonatomic, assign) CGFloat playerMapHeight;

@end
