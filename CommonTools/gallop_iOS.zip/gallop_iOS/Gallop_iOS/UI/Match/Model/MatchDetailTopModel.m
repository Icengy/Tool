//
//  MatchDetailTopModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/23.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchDetailTopModel.h"
@implementation MatchBasketHost

@end

@implementation MatchBasketAway

@end

@implementation MatchBasketModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"matchId":@"id"};
}

@end

@implementation MatchBasketEvent
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"eventId":@"id"};
}
@end


@implementation MatchBasketTeam
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"teamId":@"id"};
}
@end

@implementation MatchBasketTopModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"matchId":@"id"};
}
@end

@implementation MatchDetailTopModel

@end
