//
//  BasketballListModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface infoMapModel :NSObject
@property (nonatomic , copy) NSString              * nameZh;
@property (nonatomic , copy) NSString              * nameZht;
@property (nonatomic , copy) NSString              * nameEn;
@property (nonatomic , copy) NSString              * shortNameZh;
@property (nonatomic , copy) NSString              * shortNameZht;
@property (nonatomic , copy) NSString              * shortNameEn;
@property (nonatomic , copy) NSString              * logo;

@end

@interface Host :NSObject
@property (nonatomic , assign) NSInteger              teamId;
@property (nonatomic , strong) NSArray <NSNumber *>              * scores;

@end

@interface Away :NSObject
@property (nonatomic , assign) NSInteger              teamId;
@property (nonatomic , strong) NSArray <NSNumber *>              * scores;

@end

@interface AsiaDish : NSObject
@property (nonatomic , copy) NSString              *handicap;
@property (nonatomic , copy) NSString              *host;
@property (nonatomic , copy) NSString              *away;
@property (nonatomic , assign) NSInteger		   closed;
@end

@interface BsDish : NSObject
@property (nonatomic , copy) NSString              *handicap;
@property (nonatomic , copy) NSString              *host;
@property (nonatomic , copy) NSString              *away;
@end

@interface BasketballItem :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              eventId;
@property (nonatomic , assign) NSInteger              startTime;
@property (nonatomic , assign) NSInteger              seconds;
@property (nonatomic , assign) NSInteger              state;
@property (nonatomic , strong) Host              * host;
@property (nonatomic , strong) Away              * away;
@property (nonatomic , strong) NSArray <NSNumber *>              * flags;
@property (nonatomic , copy) NSString              * issueNum;//竞彩标识
@property (nonatomic , assign) BOOL              follow;
@property (nonatomic , strong) AsiaDish          * asia;
@property (nonatomic , strong) BsDish            * bs;

@end

@interface BasketballMatches :NSObject
@property (nonatomic , strong) NSArray <BasketballItem *>              * ends;
@property (nonatomic , strong) NSArray <BasketballItem *>              * unStarts;
@property (nonatomic , strong) NSArray <BasketballItem *>              * ongoings;

@end


@interface BasketballListModel : NSObject
@property (nonatomic , strong) BasketballMatches              * matches;
@property (nonatomic , strong) NSDictionary              * teams;
@property (nonatomic , strong) NSDictionary              * events;
@end
