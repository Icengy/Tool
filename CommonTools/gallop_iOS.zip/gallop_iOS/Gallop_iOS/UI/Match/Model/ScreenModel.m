//
//  ScreenModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ScreenModel.h"
@implementation BasketLeaguesModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"leagueId" : @"id"};
}
@end

@implementation AllItem :NSObject
+ (NSDictionary *)mj_objectClassInArray {
	return @{
		@"events" : @"BasketLeaguesModel"
	};
}
@end

@implementation BasketScreenModel :NSObject
+ (NSDictionary *)mj_objectClassInArray {
	return @{
		@"all" : @"AllItem",
		@"lotteries" : @"BasketLeaguesModel"
	};
}
@end

@implementation LeaguesModel

@end

@implementation LeaguesList
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"league" : @"LeaguesModel"
             };
}
@end

@implementation ScreenModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"leagues" : @"LeaguesList"
             };
}
@end
