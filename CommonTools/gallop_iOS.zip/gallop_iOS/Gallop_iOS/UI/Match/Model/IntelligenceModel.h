//
//  IntelligenceModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/10.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface ChangedOnPlayerListItem :NSObject
@property (nonatomic , copy) NSString              * playerId;
@property (nonatomic , copy) NSString              * playerName;
@property (nonatomic , copy) NSString              * techComments;
@end

@interface HostFirstLineupAnalise :NSObject

@property (nonatomic , assign) NSInteger              lastMatchId;
@property (nonatomic , copy) NSString              * lineupComment;
@property (nonatomic , strong) NSArray <ChangedOnPlayerListItem *>              * changedOnPlayerList;
@property (nonatomic , strong) NSArray <ChangedOnPlayerListItem *>              * changedOffPlayerList;

@property (nonatomic, assign) CGFloat myHeight;
@property (nonatomic ,strong) NSArray <NSArray *>*datas;

@end


@interface IntelligenceEurasianModel : NSObject
@property (nonatomic , assign) NSInteger              hostTeamId;
@property (nonatomic , copy) NSString              * hostTeamName;
@property (nonatomic , copy) NSString              * hostFlag;
@property (nonatomic , assign) NSInteger              awayTeamId;
@property (nonatomic , copy) NSString              * awayTeamName;
@property (nonatomic , copy) NSString              * awayFlag;
@property (nonatomic , copy) NSString              * asiaOdds;
@property (nonatomic , copy) NSString              * assessAsiaOdds;
@property (nonatomic , copy) NSString              * oddsChangeStatus;

@property (nonatomic , strong) NSArray <NSString *>              * hostLeavePlayerComments;
@property (nonatomic , strong) NSArray <NSString *>              * awayLeavePlayerComments;
@property (nonatomic , assign) NSInteger            checkStatus;
@property (nonatomic , assign) double              	euroWinOdds;
@property (nonatomic , assign) double              	euroDrawOdds;
@property (nonatomic , assign) double              	euroLoseOdds;

@property (nonatomic ,assign) CGFloat myHeight;
@property (nonatomic ,strong) NSArray <NSArray *>*datas;


/// 阵容解读
@property (nonatomic , strong) HostFirstLineupAnalise              * hostFirstLineupAnalise;
@property (nonatomic , strong) HostFirstLineupAnalise              * awayFirstLineupAnalise;

@property (nonatomic ,assign) NSInteger squadIndex;
@property (nonatomic ,assign) CGFloat squadHostHeight;
@property (nonatomic ,assign) CGFloat squadGuestHeight;

@end

@interface IntelligenceModel : NSObject
@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * awayName;
@property (nonatomic,strong) NSString              * hostFlag;
@property (nonatomic,strong) NSString              * awayFlag;
@property (nonatomic , copy) NSString              * hostWinRate;
@property (nonatomic , copy) NSString              * awayWinRate;
@property (nonatomic , copy) NSString              * hostBaseInfo;
@property (nonatomic , copy) NSString              * awayBaseInfo;
@property (nonatomic , copy) NSString              * euroOddsWinRate;
@property (nonatomic , copy) NSString              * euroOddsDrawRate;
@property (nonatomic , copy) NSString              * euroOddsFailRate;
@property (nonatomic , copy) NSString              * euroOddsWin;
@property (nonatomic , copy) NSString              * euroOddsDraw;
@property (nonatomic , copy) NSString              * euroOddsFail;
@property (nonatomic , copy) NSString              * asianOddsWinRate;
@property (nonatomic , copy) NSString              * asianOddsDrawRate;
@property (nonatomic , copy) NSString              * asianOddsFailRate;
@property (nonatomic , copy) NSString              * asianOddsWin;
@property (nonatomic , copy) NSString              * asianOddsHandicap;
@property (nonatomic , copy) NSString              * asianOddsFail;
@property (nonatomic , copy) NSString              * scoreOddsBigRate;
@property (nonatomic , copy) NSString              * scoreOddsHandicapRate;
@property (nonatomic , copy) NSString              * scoreOddsSmallRate;
@property (nonatomic , copy) NSString              * scoreOddsBig;
@property (nonatomic , copy) NSString              * scoreOddsHandicap;
@property (nonatomic , copy) NSString              * scoreOddsSmall;
@property (nonatomic , copy) NSString              * tenHostWin;
@property (nonatomic , copy) NSString              * tenHostDraw;
@property (nonatomic , copy) NSString              * tenHostFail;
@property (nonatomic , copy) NSString              * tenAwayWin;
@property (nonatomic , copy) NSString              * tenAwayDraw;
@property (nonatomic , copy) NSString              * tenAwayFail;
@property (nonatomic , copy) NSString              * tenHostGoalsIn;
@property (nonatomic , copy) NSString              * tenHostGoalsOut;
@property (nonatomic , copy) NSString              * tenAwayGoalsIn;
@property (nonatomic , copy) NSString              * tenAwayGoalsOut;
@property (nonatomic , copy) NSString              * rankHostWin;
@property (nonatomic , copy) NSString              * rankHostDraw;
@property (nonatomic , copy) NSString              * rankHostFail;
@property (nonatomic , copy) NSString              * rankAwayWin;
@property (nonatomic , copy) NSString              * rankAwayDraw;
@property (nonatomic , copy) NSString              * rankAwayFail;
@property (nonatomic , copy) NSString              * rankHostWinRate;
@property (nonatomic , copy) NSString              * rankAwayWinRate;
@property (nonatomic , copy) NSString              * confrontHostWin;
@property (nonatomic , copy) NSString              * confrontHostDraw;
@property (nonatomic , copy) NSString              * confrontHostFail;
@property (nonatomic , copy) NSString              * confrontAwayWin;
@property (nonatomic , copy) NSString              * confrontAwayDraw;
@property (nonatomic , copy) NSString              * confrontAwayFail;
@property (nonatomic , copy) NSString              * confrontHostWinRate;
@property (nonatomic , copy) NSString              * confrontAwayWinRate;
@property (nonatomic , copy) NSString              * hostStatistics;
@property (nonatomic , copy) NSString              * awayStatistics;

@end
