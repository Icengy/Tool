//
//  OddsConversionModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/19.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OddsMapListItem :NSObject
@property (nonatomic,  strong) NSString *   		hostAsiaOdds;
@property (nonatomic,  strong) NSString *   		awayAsiaOdds;
@property (nonatomic,  strong) NSString *   		handicap;
@end

@interface OddsConversionModel : NSObject
@property (nonatomic , strong) NSArray <OddsMapListItem *>              * oddsMapList;
@property (nonatomic , assign) CGFloat              hostWinRatio;
@property (nonatomic , assign) CGFloat              drawRatio;
@property (nonatomic , assign) CGFloat              awayWinRatio;
@property (nonatomic , assign) NSInteger              mainHandicap;
@end
