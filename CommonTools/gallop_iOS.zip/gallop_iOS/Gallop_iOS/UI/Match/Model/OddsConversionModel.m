//
//  OddsConversionModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/19.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "OddsConversionModel.h"
@implementation OddsMapListItem

@end

@implementation OddsConversionModel
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"oddsMapList" : @"OddsMapListItem"};
}
@end
