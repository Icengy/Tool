//
//  MatchIntelligenceModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface MatchIntelligenceRecommendInfoDTO :NSObject

@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * hostRecentTrends;
@property (nonatomic , copy) NSString              * guestRecentTrends;
@property (nonatomic , copy) NSString              * hostHandicapTrends;
@property (nonatomic , copy) NSString              * guestHandicapTrends;
@property (nonatomic , copy) NSString              * confidenceTeam;
@property (nonatomic , copy) NSString              * confidenceIndex;
@property (nonatomic , copy) NSString              * briefIntroduction;
@property (nonatomic , copy) NSString              * hostWin;
@property (nonatomic , copy) NSString              * hostDraw;
@property (nonatomic , copy) NSString              * hostLose;

@end

@interface MatchIntelligenceModel : NSObject

@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;
@property (nonatomic , copy) NSString              * recommend;
@property (nonatomic , strong) MatchIntelligenceRecommendInfoDTO    * recommendInfoDTO;

@property (nonatomic , assign) CGFloat myHeight;
@property (nonatomic,strong) NSArray <NSArray *>*datas;

@end

@interface MatchIntelligencePreItem : NSObject

@property (nonatomic , copy) NSString * content;
@property (nonatomic , assign) double myHeight;
/// yes：有利的消息 no：不利的消息
@property (nonatomic , assign) BOOL negative;


@end

@interface MatchIntelligencePreItemModel : NSObject

@property (nonatomic , strong) NSArray <MatchIntelligencePreItem *> * preInfo;

//@property (nonatomic,assign) CGFloat negativeHeight;
//@property (nonatomic,assign) CGFloat positiveHeight;

@end

/// 赛前情报
@interface MatchIntelligencePreModel : NSObject

@property (nonatomic , copy) NSString              * hostName;
@property (nonatomic , copy) NSString              * guestName;

@property (nonatomic , strong) NSArray <NSString *> * hostInfo;
@property (nonatomic , strong) NSArray <NSString *> * guestInfo;

@property (nonatomic , strong) NSArray <MatchIntelligencePreItem *> * hostPreInfo;
@property (nonatomic , strong) NSArray <MatchIntelligencePreItem *> * guestPreInfo;

@property (nonatomic, assign) NSInteger index;
@property (nonatomic, assign) CGFloat hostHeight;
@property (nonatomic, assign) CGFloat guestHeight;

@end
