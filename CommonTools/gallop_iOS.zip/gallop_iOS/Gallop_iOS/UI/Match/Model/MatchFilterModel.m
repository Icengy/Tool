//
//  MatchFilterModel.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchFilterModel.h"

@implementation MatchFilterModel

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"filters" : @"MatchFilter"};
}

@end

@implementation MatchFilter

@end
