//
//  TeamSpecail.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TeamSpecailItem : NSObject
@property (nonatomic,strong) NSString*content;
@property (nonatomic,assign) int type;
@property (nonatomic,assign) CGFloat myH;
@end

@interface TeamSpecailStyle : NSObject
@property (nonatomic,strong) NSString*content;
@property (nonatomic,assign) CGFloat myH;
@end

@interface SpecialSection : NSObject
@property (nonatomic,strong) NSString *moduleName;
@property (nonatomic,strong) NSString *intelText;
@property (nonatomic,strong, nullable) NSString *htmlText;
@end

@interface SpecialOrigin : NSObject

@property (nonatomic,strong) NSArray <NSString *>*veryStrong;
@property (nonatomic,strong) NSArray <NSString *>*strong;
@property (nonatomic,strong) NSArray <NSString *>*teamStyle;
@property (nonatomic,strong) NSArray <NSString *>*weak;
@property (nonatomic,strong) NSArray <NSString *>*veryWeak;

@end


@interface TeamSpecail : NSObject

@property (nonatomic,strong) NSString *hostName;
@property (nonatomic,strong) NSString *awayName;
@property (nonatomic,strong) NSString *hostFlag;
@property (nonatomic,strong) NSString *awayFlag;
@property (nonatomic,strong) NSString *awayId;
@property (nonatomic,strong) NSString *hostId;

/// 独家红料
@property (nonatomic,strong) NSArray <SpecialSection *> *customizeModule;
/// 球队特色
@property (nonatomic,strong) SpecialOrigin *hostTeamStyle;
@property (nonatomic,strong) SpecialOrigin *awayTeamStyle;

@property (nonatomic, strong) NSArray <NSArray *>*hostSpecials;
@property (nonatomic, strong) NSArray <NSArray *>*guestSpecials;

@property (nonatomic,assign) CGFloat hostHeight;
@property (nonatomic,assign) CGFloat guestHeight;
@property (nonatomic,assign) NSInteger styleIndex;
@property (nonatomic,assign) BOOL showSpecials;

@end



