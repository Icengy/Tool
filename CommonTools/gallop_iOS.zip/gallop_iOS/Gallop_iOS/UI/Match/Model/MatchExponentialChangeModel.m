//
//  MatchExponentialChangeModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchExponentialChangeModel.h"

@implementation MatchExponentialChangeOddsItem :NSObject

@end

@implementation MatchExponentialChangeModel
+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"odds" : @"MatchExponentialChangeOddsItem"
             };
}
@end
