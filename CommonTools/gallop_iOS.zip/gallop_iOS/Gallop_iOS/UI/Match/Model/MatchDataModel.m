//
//  MatchDataModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchDataModel.h"

@implementation MatchDetailNums

@end

@implementation SameMatchDetailNums

@end

@implementation HostGuestMatchListItem

@end

@implementation MatchDataBaseModel

+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{
        @"hostMatchList": @[@"hostMatchList", @"hostList"],
        @"guestMatchList": @[@"guestMatchList", @"guestList"]
    };
}

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"hostMatchList" : @"HostGuestMatchListItem",
             @"guestMatchList" : @"HostGuestMatchListItem"
             };
}

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    
}

- (void)setValue:(id)value forKey:(NSString *)key {
    [super setValue:value forKey:key];
    
    if ([key isEqualToString:@"hostMatchList"] ||
        [key isEqualToString:@"hostList"]) {
        NSInteger count = [value count];
        
        self.hostHeight = (count?(50.0 *count+40.0+35.0+1.0*(count-1)):200.0) + 40.0;
    }
    if ([key isEqualToString:@"guestMatchList"] ||
        [key isEqualToString:@"guestList"]) {
        NSInteger count = [value count];
        
        self.guestHeight = (count?(50.0 *count+40.0+35.0+1.0*(count-1)):200.0) + 40.0;
    }
}

@end

@implementation MatchDataModel

@end

@implementation SameMatchDataModel

@end
