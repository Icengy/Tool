//
//  IntelligenceModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/10.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "IntelligenceModel.h"
@implementation ChangedOnPlayerListItem

@end

@implementation HostFirstLineupAnalise

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"changedOnPlayerList" : @"ChangedOnPlayerListItem",
             @"changedOffPlayerList" : @"ChangedOnPlayerListItem"
             };
}

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    NSMutableArray *datas = @[].mutableCopy;
    [self.changedOnPlayerList enumerateObjectsUsingBlock:^(ChangedOnPlayerListItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx >= self.changedOffPlayerList.count - 1) {
            *stop = YES;
        }
        [datas addObject:@[obj,self.changedOffPlayerList[idx]]];
    }];
    self.datas = datas.copy;
    
    CGFloat height = 40.0;
    if ([CommonUtils isEqualToNonNull:self.lineupComment]) {
        /// 文字描述高度
        height += 30.0;
    }
    /// 头部+内容高度/占位图
    height += (self.datas.count?(44.0*(self.datas.count + 1) + 10.0):200.0);
    /// 底部间距
    self.myHeight = height;
}

@end


@implementation IntelligenceEurasianModel

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    
    if (self.hostFirstLineupAnalise || self.awayFirstLineupAnalise) {
        self.squadHostHeight = self.hostFirstLineupAnalise?self.hostFirstLineupAnalise.myHeight:240.0;
        self.squadGuestHeight = self.awayFirstLineupAnalise?self.awayFirstLineupAnalise.myHeight:240.0;
    }
    
    NSMutableArray *datas = @[].mutableCopy;
    CGFloat height = 0.0;
    
    if ([CommonUtils isEqualToNonNull:self.asiaOdds]) {
        NSArray *asiaOdds = [self.asiaOdds componentsSeparatedByString:@","];
        if (asiaOdds.count) {
            height += 30.0;
            NSMutableArray *array = asiaOdds.mutableCopy;
            [array insertObject:@"初盘水平" atIndex:0];
            [array insertObject:@"亚指" atIndex:0];
            
            [array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                [array replaceObjectAtIndex:idx withObject:@{@"title":[CommonUtils isEqualToNonNull:obj replace:@"-"],@"color":[NSNumber numberWithInt:0]}];
            }];
            
            [datas addObject:array.copy];
        }
    }
    if ([CommonUtils isEqualToNonNull:self.assessAsiaOdds]) {
        NSArray *asiaOdds = [self.assessAsiaOdds componentsSeparatedByString:@","];
        if (asiaOdds.count) {
            height += 30.0;
            NSMutableArray *array = asiaOdds.mutableCopy;
            [array insertObject:@"换算水平" atIndex:0];
            [array insertObject:@"亚指" atIndex:0];
            
            NSArray *change = [self.oddsChangeStatus componentsSeparatedByString:@","];
            int equalColor = 0;
            int hightColor = 0xDE3C31;
            int lowColor = 0x18A9C5;
            
            [array enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                int color = 0;
                if (change.count && idx > 1) {
                    NSInteger index = idx - 2;
                    color = [change[index] integerValue] == 0 ? equalColor : [change[index] integerValue] == 1 ? hightColor : lowColor;
                }
                [array replaceObjectAtIndex:idx withObject:@{@"title":[CommonUtils isEqualToNonNull:obj replace:@"-"],@"color":[NSNumber numberWithInt:color]}];
            }];
            
            
            [datas addObject:array.copy];
        }
    }
    if (height != 0.0) height += (30.0 + 8.0*2);
    
    self.datas = datas.copy;
    self.myHeight = height;
}

@end

@implementation IntelligenceModel

@end
