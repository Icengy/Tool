//
//  MatchDetailTopModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/23.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MatchBasketHost :NSObject
@property (nonatomic , assign) NSInteger              teamId;
@property (nonatomic , strong) NSArray <NSNumber *>              * scores;

@end

@interface MatchBasketAway :NSObject
@property (nonatomic , assign) NSInteger              teamId;
@property (nonatomic , strong) NSArray <NSNumber *>              * scores;

@end

@interface MatchBasketModel :NSObject
@property (nonatomic , assign) NSInteger              matchId;
@property (nonatomic , assign) NSInteger              eventId;
@property (nonatomic , assign) NSInteger              startTime;
@property (nonatomic , assign) NSInteger              seconds;
@property (nonatomic , assign) NSInteger              state;
@property (nonatomic , strong) MatchBasketHost              * host;
@property (nonatomic , strong) MatchBasketAway              * away;
@property (nonatomic , strong) NSArray <NSNumber *>              * flags;
@property (nonatomic , assign) NSInteger              follow;

@end

@interface MatchBasketEvent :NSObject
@property (nonatomic , assign) NSInteger              eventId;
@property (nonatomic , copy) NSString              * nameZh;
@property (nonatomic , copy) NSString              * nameZht;
@property (nonatomic , copy) NSString              * nameEn;
@property (nonatomic , copy) NSString              * shortNameZh;
@property (nonatomic , copy) NSString              * shortNameZht;
@property (nonatomic , copy) NSString              * shortNameEn;
@property (nonatomic , copy) NSString              * logo;
@end


@interface MatchBasketTeam :NSObject
@property (nonatomic , assign) NSInteger              teamId;
@property (nonatomic , assign) NSInteger              eventId;
@property (nonatomic , copy) NSString              * nameZh;
@property (nonatomic , copy) NSString              * nameZht;
@property (nonatomic , copy) NSString              * shortNameZh;
@property (nonatomic , copy) NSString              * shortNameZht;
@property (nonatomic , copy) NSString              * shortNameEn;
@property (nonatomic , copy) NSString              * logo;
@property (nonatomic , copy) NSString              * rank;
@end

@interface MatchBasketTopModel : NSObject
@property (nonatomic , strong) MatchBasketModel				* match;
@property (nonatomic , strong) MatchBasketEvent             * event;
@property (nonatomic , strong) MatchBasketTeam              * hostTeam;
@property (nonatomic , strong) MatchBasketTeam              * awayTeam;
@property (nonatomic , assign) BOOL 						hasIntegral;
@property (nonatomic , strong) NSArray <NSNumber *>         * tabs;
@end

@interface MatchDetailTopModel : NSObject
@property (nonatomic, strong) NSString * guestFlag;
@property (nonatomic, strong) NSString * guestHalfScore;
@property (nonatomic, strong) NSString * guestName;
@property (nonatomic, strong) NSString * guestScore;
@property (nonatomic, strong) NSString * hostFlag;
@property (nonatomic, assign) NSInteger hostId;
@property (nonatomic, assign) NSInteger guestId;
@property (nonatomic, assign) NSInteger leagueId;
@property (nonatomic, strong) NSString * hostHalfScore;
@property (nonatomic, strong) NSString * hostName;
@property (nonatomic, strong) NSString * hostScore;
@property (nonatomic, assign) NSInteger isFollowed;
@property (nonatomic, assign) NSInteger liveType;
@property (nonatomic, assign) NSInteger openTime;
@property (nonatomic, assign) NSInteger startTime;
@property (nonatomic, assign) NSInteger status;
@property (nonatomic, strong) NSString * title;
@property (nonatomic, strong) NSString * hostRank;
@property (nonatomic, strong) NSString * guestRank;
@property (nonatomic, assign) NSUInteger weather;
@property (nonatomic, strong) NSString *temperature;
@property (nonatomic, strong) NSString *matchSite;
@property (nonatomic, assign) NSUInteger allowChat;
@end

NS_ASSUME_NONNULL_END
