//
//  TeamSpecail.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "TeamSpecail.h"
@implementation TeamSpecailItem

- (CGFloat)myH {
    CGFloat height =  [self.content sizeWithFont:GetFont(12.0) andMaxSize:CGSizeMake(kScreen_Width - 40.0 - 30.0, CGFLOAT_MAX) numberOfLines:0 withEdge:UIEdgeInsetsMake(5.0, 10.0, 5.0, 0.0)].height;
    return height;
}

@end

@implementation TeamSpecailStyle

- (CGFloat)myH {
    CGFloat height =  [self.content sizeWithFont:GetFont(12.0) andMaxSize:CGSizeMake(kScreen_Width - 30.0, CGFLOAT_MAX) numberOfLines:0 withEdge:UIEdgeInsetsMake(5.0, 10.0, 5.0, 0.0)].height;
    return height;
}

@end

@implementation SpecialOrigin

@end

@implementation SpecialSection

//+ (NSString *)html5StringWithContent:(NSString *_Nullable)content withTitle:(NSString *_Nullable)title {
//    if (![self isEqualToNonNull:content]) return nil;
//
//    [content stringByReplacingOccurrencesOfString:@"&amp;quot" withString:@"'"];
//    content = [content stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
//    content = [content stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
//    content = [content stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
//
//    NSString *htmls = [NSString stringWithFormat:@"<html> \n"
//                       "<head> \n"
//                       "<meta name=\"viewport\" content=\"initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" /> \n"
//                       "<style type=\"text/css\"> \n"
//                       "body {font-size:15px;}\n"
//                       "</style> \n"
//                       "</head> \n"
//                       "<body>"
//                       "<script type='text/javascript'>"
//                       "window.onload = function(){\n"
//                       "var $img = document.getElementsByTagName('img');\n"
//                       "for(var p in  $img){\n"
//                       " $img[p].style.width = '100%%';\n"
//                       "$img[p].style.height ='auto'\n"
//                       "}\n"
//                       "}"
//                       "</script>%@"
//                       "</body>"
//                       "</html>",content];
//
//    return htmls;
//}

- (NSString *)htmlText {
    NSString *content = self.intelText;
    if (![CommonUtils isEqualToNonNull:content]) return nil;
    
    [content stringByReplacingOccurrencesOfString:@"&amp;quot" withString:@"'"];
    content = [content stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
    content = [content stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
    content = [content stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
    
    NSString *htmls = [NSString stringWithFormat:@"<html> \n"
                       "<head> \n"
                       "<meta name=\"viewport\" content=\"initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" /> \n"
                       "<style type=\"text/css\"> \n"
                       "body {font-size:15px;}\n"
                       "</style> \n"
                       "</head> \n"
                       "<body>"
                       "<script type='text/javascript'>"
                       "window.onload = function(){\n"
                       "var $img = document.getElementsByTagName('img');\n"
                       "for(var p in  $img){\n"
                       " $img[p].style.width = '100%%';\n"
                       "$img[p].style.height ='auto'\n"
                       "}\n"
                       "}"
                       "</script>%@"
                       "</body>"
                       "</html>",content];
    
    return htmls;
//    return [self attributedStringWithHTMLString:self.intelText];
}

- (NSAttributedString *)attributedStringWithHTMLString:(NSString *)htmlString {
    if (![CommonUtils isEqualToNonNull:htmlString]) {
        return nil;
    }
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&quot;" withString:@"\""];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&apos;" withString:@"'"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&lt;" withString:@"<"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&gt;" withString:@">"];
    htmlString = [htmlString stringByReplacingOccurrencesOfString:@"&amp;" withString:@"&"];
    
    NSDictionary *options = @{ NSDocumentTypeDocumentAttribute : NSHTMLTextDocumentType,
                               NSCharacterEncodingDocumentAttribute :@(NSUTF8StringEncoding)
                               };
    
    NSData *data = [htmlString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableAttributedString *aStr = [[NSMutableAttributedString alloc] initWithData:data options:options documentAttributes:nil error:nil];
    [aStr addAttribute:NSFontAttributeName value:fcFont(16) range:NSMakeRange(0, aStr.length)];
    return aStr;
}

@end

@implementation TeamSpecail

- (void)mj_didConvertToObjectWithKeyValues:(NSDictionary *)keyValues {
    [@[@0, @0] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [self handleStyleDatas:idx];
    }];
}

- (void)handleStyleDatas:(NSInteger)index {
    
    SpecialOrigin *origin = index ? self.hostTeamStyle:self.awayTeamStyle;
    
    __block CGFloat totalHeight = 0.0;
    NSMutableArray *datas = @[].mutableCopy;
    __block BOOL showSpe = self.showSpecials;
    [@[@0, @0, @0,] enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSDictionary *dict = [self handleStyleDataItem:idx withOrigin:origin];
        totalHeight += [[dict objectForKey:@"height"] floatValue];
        NSArray *data = [dict objectForKey:@"data"];
        [datas addObject:data];
        if (!showSpe) {
            showSpe = data.count;
        }
    }];
    
    self.showSpecials = showSpe;
    if (showSpe) {
        totalHeight = ((totalHeight > 0.0) ? (totalHeight + 10.0): 200.0) + 40.0;
        
        if (index) {
            self.hostHeight = totalHeight;
            self.hostSpecials = datas.copy;
        }else {
            self.guestHeight = totalHeight;
            self.guestSpecials = datas.copy;
        }
    }
}

- (NSDictionary *)handleStyleDataItem:(NSInteger)index withOrigin:(SpecialOrigin *)origin {
    
    __block CGFloat height = 0.0;
    NSMutableArray *datas = @[].mutableCopy;
    if (index == 2) {
        NSArray <NSString *>*teamStyle = origin.teamStyle;
        
        [teamStyle enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            TeamSpecailItem *item = [TeamSpecailItem new];
            item.type = 0;
            item.content = obj;
//            item.content = arc4random()%2?obj:@"新英伦革命上仗赢波重返胜轨，球队士气大振，今天面对上遭遇一场完败的纽约红牛，新英伦革命有望再下一城。";
            height += item.myH;
            [datas addObject:item];
        }];
    }else {
        NSArray <NSString *>*very_data = index ? origin.veryWeak:origin.veryStrong;
        NSArray <NSString *>*data = index ? origin.weak:origin.strong;
        
        [very_data enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            TeamSpecailItem *item = [TeamSpecailItem new];
            item.type = index ? 4 : 1;
            item.content = obj;
//            item.content = arc4random()%2?obj:@"新英伦革命上仗赢波重返胜轨，球队士气大振，今天面对上遭遇一场完败的纽约红牛，新英伦革命有望再下一城。";
            height += item.myH;
            [datas addObject:item];
        }];
        [data enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            TeamSpecailItem *item = [TeamSpecailItem new];
            item.type = index ? 3 : 2;
            item.content = obj;
//            item.content = arc4random()%2?obj:@"新英伦革命上仗赢波重返胜轨，球队士气大振，今天面对上遭遇一场完败的纽约红牛，新英伦革命有望再下一城。";
            height += item.myH;
            [datas addObject:item];
        }];
    }
    if (height > 0) height += 30.0;
    return @{@"data":datas.copy, @"height": @(height)};
}

+ (NSDictionary *)mj_objectClassInArray {
    return @{@"goodHArr" : @"TeamSpecailItem",
             @"badHArr" : @"TeamSpecailItem",
             @"styleHArr" : @"TeamSpecailStyle",
             @"goodGArr" : @"TeamSpecailItem",
             @"badGArr" : @"TeamSpecailItem",
             @"styleGArr" : @"TeamSpecailStyle",
             @"customizeModule" : @"SpecialSection",
    };
}
@end
