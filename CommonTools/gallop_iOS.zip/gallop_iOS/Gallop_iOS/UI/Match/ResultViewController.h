//
//  ResultViewController.h
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

#import "MatchScheduleResultResetDelegate.h"

@interface ResultViewController : ESChildViewController

@property(nonatomic, weak) id <MatchScheduleResultResetDelegate> resetDelegate;

@property(nonatomic, strong)NSString *selectedDate;
/// 1足球 2篮球
@property (nonatomic, assign) NSInteger field;

@end
