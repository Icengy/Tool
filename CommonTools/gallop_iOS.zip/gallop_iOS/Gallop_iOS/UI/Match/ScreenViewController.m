//
//  ScreenViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//
//#import "UIFont+changeFont.h"
#import "ScreenViewController.h"
#import "LXSegmentScrollView.h"
#import "PointExtenButton.h"
#import "screenCollectionViewCell.h"
#import "DSCollectionViewIndex.h"
#import "ScreenCollectionViewSectionHeader.h"
#import "CYBaseCollectionView.h"

#define kScreenCollectionViewCellIdentifier @"ScreenCollectionViewCellIdentifier"
#define kScreenCollectionViewSectionHeader @"ScreenCollectionViewSectionHeader"

@interface ScreenViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,LXSegmentScrollViewDelegate,ScreenCollectionViewCellDelegate,DSCollectionViewIndexDelegate,UICollectionViewDelegateFlowLayout>
@property(nonatomic, strong)CYBaseCollectionView      *collectionView;
@property(nonatomic, strong)DSCollectionViewIndex *collectionViewIndex;
@property(nonatomic, strong)NSMutableArray *rows;  //索引数组
@property(nonatomic, strong)UILabel *flotageLabel;//中间显示的背景框
@property(nonatomic, strong)UIView  *flotageView; //选中字母改变背景

@property(nonatomic, strong)LXSegmentScrollView *segment;
@property(nonatomic, strong)UIView              *bottomView;
@property(nonatomic, strong)PointExtenButton    *seleteAllBtn;
@property(nonatomic, strong)UILabel     *seletedMatchLabel;
@property(nonatomic, strong)CYButton    *comfirmButton;

@property(nonatomic, strong)ScreenModel *screenModel;
@property(nonatomic, strong)NSMutableArray *dataList;
@property(nonatomic, strong)NSMutableArray *seletedList;
@property(nonatomic, assign)NSInteger  seletedCount;
@end

@implementation ScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"赛事筛选";
    [self setupView];
    [self loadData];
}

- (void)setScreenModel:(ScreenModel *)screenModel {
    //用于整合数据
    NSMutableArray *tmpArr = [NSMutableArray array];
    [self.dataList removeAllObjects];
    [self.seletedList removeAllObjects];
    self.seletedCount = 0;
    [self.dataList addObjectsFromArray:screenModel.leagues];
    self.seleteAllBtn.selected = YES;
    for (LeaguesList *list in self.dataList) {
        for (LeaguesModel *model in list.league) {
			[self.seletedList addObject:model];
			self.seletedCount += model.number.integerValue;
            [tmpArr addObject:model];
        }
    }

    //设置默认选项卡位置
    self.matchType = screenModel.matchType == -1 ? 0 : screenModel.matchType;
    [self.segment.segmentToolView setDefaultIndex:(self.matchType + 1)];
    [self setSeletedMatchCount:self.seletedCount];
    [self.collectionView reloadData];
    
    //设置索引
    if (self.matchType != 0) {
        //非全部标签 整合数据
        self.dataList = tmpArr;
    }
    [self configCollectionIndex];
}
#pragma mark - private method
- (void)setupView {

    [self.view addSubview:self.segment];
    [self.view addSubview:self.collectionView];
    [self.view addSubview:self.bottomView];
    [self.bottomView addSubview:self.seleteAllBtn];
    [self.bottomView addSubview:self.seletedMatchLabel];
    [self.bottomView addSubview:self.comfirmButton];
}

- (void)setSeletedMatchCount:(NSInteger)count {
    NSMutableAttributedString *str = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"已选%@场",@(count)]];
    NSRange range = [[str string] rangeOfString:@(count).stringValue];
    [str addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(255, 177, 46) range:range];
    self.seletedMatchLabel.attributedText = str;
    
    self.comfirmButton.enabled = count;
}

- (void)loadData {
    [ESNetworkService getScreenList:self.matchType pageType:self.pageType date:self.date response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                ScreenModel *model = [ScreenModel mj_objectWithKeyValues:dict[@"data"]];
                self.screenModel = model;
            });
        }
    }];
}

- (void)configCollectionIndex {
    if (_collectionViewIndex) {
        [_collectionViewIndex removeFromSuperview];
        _collectionViewIndex = nil;
        _collectionViewIndex.collectionDelegate = nil;
    }
    
    if (self.matchType != 0) {
        return;
    }
    
    _collectionViewIndex = [[DSCollectionViewIndex alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-20, 0, 20, SCREEN_HEIGHT)];    //创建索引条
    [self.view addSubview:_collectionViewIndex];
    
    _rows = [NSMutableArray array];
    NSMutableArray *sections = [NSMutableArray array];    //创建字母数组   @[@"A", @"D", @"F", @"M", @"N", @"Z"];
    int indexsInt = -1;    //更新索引数组元素的数值
    NSString *tempStr = @"temp";    //交换字母,用来判断该字母是否存在的数值
    for (LeaguesList *list in self.dataList) {
        NSString *firstLetterStirng = list.letter;
        
        if (firstLetterStirng == tempStr) {   //判断该字母是否为上一位存在的
            [_rows[indexsInt] addObject:firstLetterStirng];   //加入对应数组中
        }else{
            [sections addObject:firstLetterStirng];   //字母数组添加新字母
            NSMutableArray *array = [NSMutableArray array];   //生成新字母数组
            [array addObject:firstLetterStirng];
            [_rows addObject:array];     //索引数组添加新字母数组
            indexsInt = indexsInt + 1;    //索引数组count+1
            tempStr = firstLetterStirng;    //上一位字母更换为新字母
        }
    }
    
    _collectionViewIndex.titleIndexes = sections;   //设置数组
    [_collectionViewIndex setHeight:_collectionViewIndex.titleIndexes.count * 16];
    [_collectionViewIndex setY:(SCREEN_HEIGHT - _collectionViewIndex.titleIndexes.count * 16) / 2];
    
    _collectionViewIndex.collectionDelegate = self;
    _collectionViewIndex.isFrameLayer = NO;    //是否有边框线
    
    //中间显示的背景框
    _flotageLabel = [[UILabel alloc] initWithFrame:(CGRect){(SCREEN_WIDTH - 32 ) / 2,(SCREEN_HEIGHT - 32) / 2,32,32}];
    _flotageLabel.backgroundColor = RGBCOLOR(204, 204, 204);
    _flotageLabel.hidden = YES;
    _flotageLabel.layer.cornerRadius = 16;
    _flotageLabel.clipsToBounds = YES;
    _flotageLabel.textAlignment = NSTextAlignmentCenter;
    _flotageLabel.textColor = [UIColor whiteColor];
    _flotageLabel.font = GetFont(18);
    [self.view addSubview:_flotageLabel];
    
    //选中字母改变背景
    _flotageView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 16)];
    _flotageView.hidden = YES;
    _flotageView.alpha = 0.5;
    _flotageView.layer.cornerRadius = 8;
    _flotageView.backgroundColor = [UIColor grayColor];
    [_collectionViewIndex addSubview:self.flotageView];
}

#pragma mark- DSCollectionViewIndexDelegate

-(void)collectionViewIndex:(DSCollectionViewIndex *)collectionViewIndex didselectionAtIndex:(NSInteger)index withTitle:(NSString *)title{
    [MobClick event:@"match4"];
    
    NSInteger tempInt = 0;
    NSArray *array = [NSArray array];
    for (int i=0; i<index ; i++) {    //根据循环rows数组得到需要滑动到的位置
        array = _rows[i];
        tempInt = tempInt + array.count;
    }
    
    _flotageLabel.text = title;
    
    [_flotageView setY:index * 16];
    
    if (self.collectionView.contentSize.height < CGRectGetHeight(self.collectionView.frame)) {
        return;
    }
    
    [self.collectionView layoutIfNeeded];
    UICollectionViewLayoutAttributes *attributes = [self.collectionView layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:tempInt]];
    CGRect rect = attributes.frame;
    CGPoint point = CGPointMake(0, rect.origin.y - 30);
    [self.collectionView setContentOffset:point animated:YES];
}

-(void)collectionViewIndexTouchesBegan:(DSCollectionViewIndex *)collectionViewIndex{
    _flotageLabel.alpha = 1;
    _flotageLabel.hidden = NO;
    //
    _flotageView.hidden = NO;
}

-(void)collectionViewIndexTouchesEnd:(DSCollectionViewIndex *)collectionViewIndex{
    void (^animation)(void) = ^{
        self.flotageLabel.alpha = 0;
        self.flotageView.hidden = YES;
    };
    
    [UIView animateWithDuration:0.4 animations:animation completion:^(BOOL finished) {
        self.flotageLabel.hidden = YES;
    }];
}


#pragma mark - LXSegmentScrollViewDelegate
- (void)segementSeletedChange:(NSInteger)index {
    NSArray *pageArr = @[@"全部",@"热门",@"竞彩",@"足彩",@"单场"];
    [MobClick event:@"match3" attributes:@{@"tab":pageArr[index]}];
    
    if (index == self.matchType) {
        return;
    }
    self.matchType = index;
	[self.dataList removeAllObjects];
	[self.collectionView reloadData];
    [self loadData];
}

#pragma mark - cellDelegate
- (void)leaguesBtnClick:(LeaguesModel *)model {
    if (model.selected == YES) {
        [self.seletedList removeObject:model];
        self.seletedCount -= model.number.integerValue;
    } else {
        [self.seletedList addObject:model];
        self.seletedCount += model.number.integerValue;
    }
    NSInteger total = 0;
    if (self.matchType != 0) {
        total += self.dataList.count;
    } else {
        for (LeaguesList *list in self.dataList) {
            total += list.league.count;
        }
    }
    if (self.seletedList.count == total) {
        self.seleteAllBtn.selected = YES;
    } else {
        self.seleteAllBtn.selected = NO;
    }
    [self setSeletedMatchCount:self.seletedCount];
    model.selected = !model.selected;
}

#pragma mark UICollectionLayout代理
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.matchType != 0) {
        return  CGSizeMake((SCREEN_WIDTH - 43) / 3.0 - 0.1, 33);
    }
    return  CGSizeMake((SCREEN_WIDTH - 60) / 3.0 - 0.1, 33);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    if (self.matchType != 0) {
        return  UIEdgeInsetsMake(-20, 10, 0, 10);
    }
    return  UIEdgeInsetsMake(0, 10, 0, 27);
}

#pragma mark UICollectionView代理
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (self.matchType != 0) {
        return self.dataList.count;
    }
    LeaguesList *list = self.dataList[section];
    return list.league.count;
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    if (self.matchType != 0) {
        return QM_IS_ARRAY_NIL(self.dataList) ? 0 : 1;
    }
    return self.dataList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    LeaguesModel *model;
    
    if (self.matchType != 0) {
        model = self.dataList[indexPath.row];
    } else {
        LeaguesList *list = self.dataList[indexPath.section];
        model = list.league[indexPath.row];
    }
    
    screenCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kScreenCollectionViewCellIdentifier forIndexPath:indexPath];
    [cell configCellWithModel:model];
    cell.cellDelegate = self;
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    ScreenCollectionViewSectionHeader *view = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kScreenCollectionViewSectionHeader forIndexPath:indexPath];
    if (self.matchType != 0) {
        view.letterLabel.text = @"";
		[view setHeight:0.01];
    } else {
        LeaguesList *list = self.dataList[indexPath.section];
        view.letterLabel.text = list.letter;
    }
    return view;
}

#pragma mark - action
- (void)seleteAllBtnClick:(PointExtenButton *)button {
    [MobClick event:@"match5"];
    
    button.selected = !button.selected;
    self.seletedCount = 0;
    [self.seletedList removeAllObjects];
    if (self.matchType != 0) {
        for (LeaguesModel *model in self.dataList) {
            if (button.selected) {
                [self.seletedList addObject:model];
            }
            model.selected = button.selected;
            self.seletedCount += button.selected ? model.number.integerValue : 0;
        }
    } else {
        for (LeaguesList *list in self.dataList) {
            if (button.selected) {
                [self.seletedList addObjectsFromArray:list.league];
            }
            for (LeaguesModel *model in list.league) {
                model.selected = button.selected;
                self.seletedCount += button.selected ? model.number.integerValue : 0;
            }
        }
    }
    [self setSeletedMatchCount:self.seletedCount];
    [self.collectionView reloadData];
}

- (void)confirmButtonClick {
    NSArray *tabArr = @[@"全部",@"热门",@"竞彩",@"足彩",@"单场"];
    NSArray *pageArr = @[@"即时页",@"赛程页",@"赛果页",@"关注页"];
    [MobClick event:@"match6" attributes:@{@"tab":tabArr[self.matchType],@"source":pageArr[self.pageType]}];
    
    NSMutableArray *strArr = [NSMutableArray array];
    for (LeaguesModel *model in self.seletedList) {
        [strArr addObject:model.leagueId];
    }
    if (QM_IS_ARRAY_NIL(strArr)) {
        [[LPUnitily sharedManager] showToastWithText:@"请选择您想看的联赛标签"];
        return;
    }
    NSString *leagueStr = [strArr componentsJoinedByString:@","];
    
	ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
	model.screenIsAll = self.seleteAllBtn.selected ? @"1" : @"0";
	model.screenMatchType = @(self.matchType).stringValue;
	model.screenLeague = leagueStr;
	NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:[SystemManager footBallScreenCache]];
	tmpArr[self.pageType] = model;
	[SystemManager setFootBallScreenCache:tmpArr];
	//刷新列表
    [[NSNotificationCenter defaultCenter] postNotificationName:kMatchScreenChange object:@(self.pageType)];
	[self back:nil];
}

#pragma mark - lazy init
- (NSMutableArray *)dataList {
    if (!_dataList) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}
- (NSMutableArray *)seletedList {
    if (!_seletedList) {
        _seletedList = [NSMutableArray array];
    }
    return _seletedList;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc]init];
        layout.scrollDirection = UICollectionViewScrollDirectionVertical;
        layout.minimumInteritemSpacing = 10;
        layout.minimumLineSpacing = 12.5;
        layout.headerReferenceSize = CGSizeMake(SCREEN_WIDTH - 0.1, 30);
        _collectionView = [[CYBaseCollectionView alloc] initWithFrame:CGRectMake(0, NavBarHeight + 36, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight - TabBarHeight - 27) collectionViewLayout:layout];
        _collectionView.backgroundColor = self.view.backgroundColor;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.alwaysBounceVertical = YES;
        [_collectionView registerClass:[screenCollectionViewCell class] forCellWithReuseIdentifier:kScreenCollectionViewCellIdentifier];
        [_collectionView registerClass:[ScreenCollectionViewSectionHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kScreenCollectionViewSectionHeader];
    }
    return _collectionView;
}

- (LXSegmentScrollView *)segment {
    if (!_segment) {
        _segment = [[LXSegmentScrollView alloc] initWithFrame:CGRectMake(0,NavBarHeight, SCREEN_WIDTH,36) titleArray:[NSArray arrayWithObjects:@"全部",@"热门",@"竞彩",@"足彩",@"单场", nil] contentViewArray:nil];
        _segment.segmentToolView.selectLine.hidden = YES;
        _segment.segmentDelegate = self;
    }
    return _segment;
}

- (UIView *)bottomView {
    if (!_bottomView) {
        _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - TabBarHeight + 9, SCREEN_WIDTH, 40)];
        _bottomView.backgroundColor = [UIColor whiteColor];
    }
    return _bottomView;
}

- (PointExtenButton *)seleteAllBtn {
    if (!_seleteAllBtn) {
        _seleteAllBtn = [[PointExtenButton alloc] initWithFrame:CGRectMake(15, 11, 18, 18)];
        [_seleteAllBtn setImage:GetImage(@"match_screen_chose_btn") forState:UIControlStateNormal];
        [_seleteAllBtn setImage:GetImage(@"match_screen_chose_btn_seleted") forState:UIControlStateSelected];
        _seleteAllBtn.selected = NO;
        [_seleteAllBtn addTarget:self action:@selector(seleteAllBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _seleteAllBtn;
}

- (UILabel *)seletedMatchLabel {
    if (!_seletedMatchLabel) {
        _seletedMatchLabel = [[UILabel alloc] initWithFrame:CGRectMake(44, 11, 200, 18)];
        _seletedMatchLabel.textColor = RGBCOLOR(168, 168, 168);
        _seletedMatchLabel.font = GetFont(12);
    }
    return _seletedMatchLabel;
}

- (CYButton *)comfirmButton {
    if (!_comfirmButton) {
        _comfirmButton = [[CYButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 85, 0, 85, 40)];
        _comfirmButton.backgroundPrams(ColorAppRed, nil, UIControlStateNormal).backgroundPrams(Color99, nil, UIControlStateDisabled);
        [_comfirmButton setTitle:@"确定" forState:UIControlStateNormal];
        _comfirmButton.titleLabel.font = GetFont(14);
        [_comfirmButton addTarget:self action:@selector(confirmButtonClick) forControlEvents:UIControlEventTouchUpInside];
    }
    return _comfirmButton;
}

@end
