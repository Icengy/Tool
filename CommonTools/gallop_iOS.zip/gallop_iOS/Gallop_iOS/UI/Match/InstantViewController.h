//
//  InstantViewController.h
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface InstantViewController : ESChildViewController
@property (nonatomic, assign) NSInteger field;//1:足球 2:篮球
@end
