//
//  IntelligenceTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "IntelligenceTableViewCell.h"
#import "MatchIntelligenceModel.h"


@interface IntelligenceTableViewCell ()

@property(nonatomic, assign)NSInteger matchId;
@property(nonatomic, strong)MatchIntelligenceModel *model;
@property(nonatomic, strong)NSMutableArray *contentArr;

@property(nonatomic, strong)UISegmentedControl *segmentControl;
@property(nonatomic, strong)UIView  *thirdHeadBgView;
@property(nonatomic, strong)UILabel *thirdHeadLabel;
@property(nonatomic, strong)UIView  *secondContentLabelBgView;
@property(nonatomic, strong)UIView  *thirdContentLabelBgView;
@property(nonatomic, strong)UILabel *secondContentLabel;
@property(nonatomic, strong)UILabel *thirdContentLabel;
//遮盖圆角用
@property(nonatomic, strong)UIView  *cornerBackView;

@end

@implementation IntelligenceTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.contentView.backgroundColor = [UIColor clearColor];
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

#pragma mark - data
- (void)configcellWithModel:(id)model isRecommend:(BOOL)isRecommend {
    //remake
    [self.secondContentLabelBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView);
        make.left.right.equalTo(self.contentView);
    }];
    [self.secondContentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(6.5, 10, 6.5, 10));
    }];
    
    [self.thirdHeadBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.secondContentLabelBgView.mas_bottom);
        make.left.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 0));
    }];
    [self.thirdHeadLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.thirdHeadBgView);
        make.left.equalTo(self.thirdHeadBgView).offset(10);
    }];
    [self.cornerBackView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.right.equalTo(self.contentView);
        make.top.equalTo(self.thirdHeadBgView.mas_bottom);
        make.height.mas_equalTo(4);
    }];
    [self.thirdContentLabelBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.right.equalTo(self.contentView);
        make.top.equalTo(self.thirdHeadBgView.mas_bottom);
        make.bottom.equalTo(self.contentView);
    }];
    [self.segmentControl mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.thirdContentLabelBgView);
        make.height.mas_equalTo(31);
    }];
    [self.thirdContentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(40, 10, 6.5, 10));
    }];
    //
    self.model = model;
    if (!QM_IS_STR_NIL(self.model.hostName) && !isRecommend) {
        [self.segmentControl setTitle:self.model.hostName forSegmentAtIndex:0];
    }
    if (!QM_IS_STR_NIL(self.model.guestName) && !isRecommend) {
        [self.segmentControl setTitle:self.model.guestName forSegmentAtIndex:1];
    }
    if (self.model.recommendInfoDTO && isRecommend) {
        MatchIntelligenceRecommendInfoDTO *dto = self.model.recommendInfoDTO;
        //心水推荐
        NSMutableParagraphStyle *paraStyle = [[NSMutableParagraphStyle alloc] init];
        paraStyle.lineBreakMode = NSLineBreakByCharWrapping;
        paraStyle.alignment = NSTextAlignmentLeft;
        paraStyle.lineSpacing = 5; //设置行间距
        NSDictionary *dic = @{NSFontAttributeName:GetFont(13), NSParagraphStyleAttributeName:paraStyle, NSKernAttributeName:@0.0f
                              };
        NSMutableAttributedString *attributeStr = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"信心指数: %@ %@\n对战成绩: %@ %@胜 %@平 %@负\n%@",dto.confidenceTeam,dto.confidenceIndex,dto.hostName,dto.hostWin,dto.hostDraw,dto.hostLose,dto.briefIntroduction] attributes:dic];
        [attributeStr addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(58, 58, 58) range:[attributeStr.string rangeOfString:@"信心指数:"]];
        [attributeStr addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(58, 58, 58) range:[attributeStr.string rangeOfString:@"对战成绩:"]];
        [attributeStr addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(240, 72, 68) range:[attributeStr.string rangeOfString:dto.confidenceTeam]];
        NSRange range = NSMakeRange([attributeStr.string rangeOfString:@"对战成绩:"].location + 6, dto.hostName.length);
        [attributeStr addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(240, 72, 68) range:range];
        range = NSMakeRange([attributeStr.string rangeOfString:@"胜"].location - dto.hostWin.length, dto.hostWin.length);
        [attributeStr addAttribute:NSForegroundColorAttributeName value:RGBCOLOR(240, 72, 68) range:range];
        range = NSMakeRange([attributeStr.string rangeOfString:@"负"].location - dto.hostLose.length, dto.hostLose.length);
        [attributeStr addAttribute:NSForegroundColorAttributeName value:ColorLoss range:range];
        range = NSMakeRange([attributeStr.string rangeOfString:@"平"].location - dto.hostDraw.length, dto.hostDraw.length);
        [attributeStr addAttribute:NSForegroundColorAttributeName value:ColorDaw range:range];
        self.secondContentLabel.attributedText = attributeStr;
        self.secondContentLabelBgView.hidden = NO;
    } else {
        self.secondContentLabelBgView.hidden = YES;
        [self.thirdHeadBgView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView);
        }];
    }
//    if (!QM_IS_ARRAY_NIL(self.model.hostInfo) && !isRecommend) {
//        NSString *hostInfoStr = [self.model.hostInfo componentsJoinedByString:@"\n"];
//        self.thirdContentLabel.text = hostInfoStr;
//        self.thirdContentLabelBgView.hidden = NO;
//        self.cornerBackView.hidden = NO;
//        self.thirdHeadBgView.hidden = NO;
//        [self.secondContentLabelBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.contentView);
//            make.left.right.equalTo(self.contentView);
//        }];
//    } else {
//        self.thirdContentLabelBgView.hidden = YES;
//        self.thirdHeadBgView.hidden = YES;
//        self.cornerBackView.hidden = YES;
//        [self.secondContentLabelBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.contentView);
//            make.left.right.equalTo(self.contentView);
//            make.bottom.equalTo(self.contentView);
//        }];
//    }
}

-(void)swithHostGuest:(id)sender{
//    UISegmentedControl* control = (UISegmentedControl*)sender;
//    switch (control.selectedSegmentIndex) {
//        case 0:
//        {
//            NSString *hostInfoStr;
//            if (QM_IS_ARRAY_NIL(self.model.hostInfo)) {
//                hostInfoStr = @"";
//            } else {
//                hostInfoStr = [self.model.hostInfo componentsJoinedByString:@"\n"];
//            }
//            self.thirdContentLabel.text = hostInfoStr;
//        }
//            break;
//        case 1:
//        {
//            NSString *guestInfoStr;
//            if (QM_IS_ARRAY_NIL(self.model.guestInfo)) {
//                guestInfoStr = @"";
//            } else {
//                guestInfoStr = [self.model.guestInfo componentsJoinedByString:@"\n"];
//            }
//            self.thirdContentLabel.text = guestInfoStr;
//        }
//            break;
//
//        default:
//            break;
//
//    }
//
//    if (!self.thirdContentLabel.text.length && self.secondContentLabelBgView.hidden == YES) {
//        self.thirdContentLabelBgView.hidden = YES;
//        self.cornerBackView.hidden = YES;
//        self.thirdHeadBgView.hidden = YES;
//    } else {
//        self.thirdContentLabelBgView.hidden = NO;
//        self.thirdHeadBgView.hidden = NO;
//        self.cornerBackView.hidden = NO;
//    }
//    [self.contentView layoutIfNeeded];
//    if (self.clickBlock) {
//        self.clickBlock();
//    }
}

#pragma mark - lazy init
- (UISegmentedControl *)segmentControl {
    if (!_segmentControl) {
        _segmentControl = [[UISegmentedControl alloc] initWithItems:@[@"主队",@"客队"]];
        [_segmentControl setTitleTextAttributes:@{NSFontAttributeName:GetFont(12),NSForegroundColorAttributeName:[UIColor whiteColor]} forState:UIControlStateSelected];
        [_segmentControl setTitleTextAttributes:@{NSFontAttributeName:GetFont(12),NSForegroundColorAttributeName:RGBCOLOR(168, 168, 168)} forState:UIControlStateNormal];
        [_segmentControl setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        [_segmentControl setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(255, 177, 46)] forState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
        _segmentControl.layer.borderColor = RGBCOLOR(255, 177, 46).CGColor;
        _segmentControl.layer.borderWidth = 0.5;
        _segmentControl.selectedSegmentIndex = 0;
        
        //去掉中间的分割线
        UIImage *_dividerImage= [UIImage new];
        [_segmentControl setDividerImage:_dividerImage forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
        
        [_segmentControl addTarget:self action:@selector(swithHostGuest:) forControlEvents:UIControlEventValueChanged];
        
        [self.thirdContentLabelBgView addSubview:_segmentControl];
    }
    
    
    return _segmentControl;
}

- (UIView *)thirdHeadBgView {
    if (!_thirdHeadBgView) {
        _thirdHeadBgView = [[UIView alloc] init];
        _thirdHeadBgView.backgroundColor = RGBCOLOR(244, 244, 244);
        _thirdHeadBgView.hidden = YES;
        [self.contentView addSubview:_thirdHeadBgView];
    }
    return _thirdHeadBgView;
}

- (UILabel *)thirdHeadLabel {
    if (!_thirdHeadLabel) {
        _thirdHeadLabel = [[UILabel alloc] init];
        _thirdHeadLabel.text = @"赛前情报";
        _thirdHeadLabel.textColor = RGBCOLOR(58, 58, 58);
        _thirdHeadLabel.font = GetFont(14);
        [self.thirdHeadBgView addSubview:_thirdHeadLabel];
    }
    return _thirdHeadLabel;
}

- (UIView *)secondContentLabelBgView {
    if (!_secondContentLabelBgView) {
        _secondContentLabelBgView = [UIView new];
        _secondContentLabelBgView.backgroundColor = [UIColor whiteColor];
        _secondContentLabelBgView.layer.cornerRadius = 4;
        //遮盖圆角
        UIView *cornerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 4)];
        cornerView.backgroundColor = [UIColor whiteColor];
        _secondContentLabelBgView.hidden = YES;
        [_secondContentLabelBgView addSubview:cornerView];
        
        [self.contentView addSubview:_secondContentLabelBgView];
    }
    return _secondContentLabelBgView;
}

- (UIView *)thirdContentLabelBgView {
    if (!_thirdContentLabelBgView) {
        _thirdContentLabelBgView = [UIView new];
        _thirdContentLabelBgView.backgroundColor = [UIColor whiteColor];
        _thirdContentLabelBgView.layer.cornerRadius = 4;
        _thirdContentLabelBgView.hidden = YES;
        [self.contentView addSubview:_thirdContentLabelBgView];
    }
    return _thirdContentLabelBgView;
}

- (UILabel *)secondContentLabel {
    if (!_secondContentLabel) {
        _secondContentLabel = [UILabel new];
        _secondContentLabel.textColor = RGBCOLOR(168, 168, 168);
        _secondContentLabel.font = GetFont(12);
        _secondContentLabel.numberOfLines = 0;
        _secondContentLabel.text = @"";
        [self.secondContentLabelBgView addSubview:_secondContentLabel];
    }
    return _secondContentLabel;
}

- (UILabel *)thirdContentLabel {
    if (!_thirdContentLabel) {
        _thirdContentLabel = [UILabel new];
        _thirdContentLabel.textColor = RGBCOLOR(168, 168, 168);
        _thirdContentLabel.font = GetFont(12);
        _thirdContentLabel.numberOfLines = 0;
        _thirdContentLabel.text = @"";
        [_thirdContentLabel setLabelSpace:3 withFont:GetFont(12)];
        [self.thirdContentLabelBgView addSubview:_thirdContentLabel];
    }
    return _thirdContentLabel;
}

- (UIView *)cornerBackView {
    if (!_cornerBackView) {
        _cornerBackView = [UIView new];
        _cornerBackView.backgroundColor = [UIColor whiteColor];
        _cornerBackView.hidden = YES;
        [self.contentView addSubview:_cornerBackView];
    }
    return _cornerBackView;
}

@end
