//
//  MatchLiveExponentailTableCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/7/23.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MatchLiveExponentailTableCell : ESChildTableViewCell

- (void)configCellWithModel:(id)model;

@end

NS_ASSUME_NONNULL_END
