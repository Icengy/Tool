//
//  InstantTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//
#import "InstantTableViewCell.h"
#import "PointExtenButton.h"
#import "MatchInstantListModel.h"

#import "MatchInstantTableCellDelegate.h"

@interface InstantTableViewCell()
@property(nonatomic, strong)UIView                      *containerView;
@property(nonatomic, strong)UIView                  *headView;
@property(nonatomic, strong)UILabel          *typeLabel;
@property(nonatomic, strong)UILabel          *startTimeLabel;
@property(nonatomic, strong)UILabel          *secondsLabel;
@property(nonatomic, strong)UILabel          *currentTimeLabel;
@property(nonatomic, strong)UILabel          *dishLabel;
@property(nonatomic, strong)UILabel          *raceIdentLabel;
@property(nonatomic, strong)PointExtenButton *focusButton;

@property(nonatomic, strong)UIView                  *matchView;
@property(nonatomic, strong)UILabel         *hostTeamLabel;
@property(nonatomic, strong)UILabel         *instantHostRankLabel;
@property(nonatomic, strong)UILabel         *awayTeamLabel;
@property(nonatomic, strong)UILabel         *awayRankLabel;
@property(nonatomic, strong)UILabel         *scoreLabel;
@property(nonatomic, strong)UILabel         *halfInfoLabel;
@property(nonatomic, strong)UIImageView		*hostCornerImageView;
@property(nonatomic, strong)UILabel			*hostCornerLabel;
@property(nonatomic, strong)UIImageView		*awayCornerImageView;
@property(nonatomic, strong)UILabel			*awayCornerLabel;
@property(nonatomic, strong)UILabel         *redCardLabel;
@property(nonatomic, strong)UILabel         *yellowCardLabel;
@property(nonatomic, strong)UILabel         *awayRedCardLabel;
@property(nonatomic, strong)UILabel         *awayYellowCardLabel;
@property(nonatomic, strong)UIImageView     *liveImageView;
@property(nonatomic, strong)UILabel         *expertsLabel;
@property(nonatomic, strong)UILabel         *intelligenceLabel;

@property(nonatomic, strong)UIView                  *progressView;
@property(nonatomic, strong)UIView  *sepratorLine;

@property(nonatomic, strong)UIView                  *extroInfoView;
@property(nonatomic, strong)UILabel *extroLabel;

@property(nonatomic, strong)InstantMatcth *matchModel;
@end

@implementation InstantTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)hostOrGuestGoal:(BOOL)isHost {
    //进球处理
    self.hostTeamLabel.textColor = isHost ? RGBCOLOR(240, 72, 68) : ColorAppBlack;
    self.awayTeamLabel.textColor = isHost ? ColorAppBlack : RGBCOLOR(240, 72, 68);
    self.layer.shadowColor = [UIColor redColor].CGColor;
    self.layer.masksToBounds = NO;
    self.layer.shadowRadius = 8;
    self.layer.shadowOffset = CGSizeMake(0.0f,0.0f);
    self.layer.shadowOpacity = 0.0f;
    CABasicAnimation *animation =[CABasicAnimation animationWithKeyPath:@"shadowOpacity"];
    animation.fromValue = [NSNumber numberWithFloat:0.0f];
    animation.toValue = [NSNumber numberWithFloat:1.0f];
    animation.autoreverses = YES;
    animation.duration = 0.5f;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    [self.layer addAnimation:animation forKey:@"aAlpha"];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //还原状态
        self.hostTeamLabel.textColor = ColorAppBlack;
        self.awayTeamLabel.textColor = ColorAppBlack;
        [self.layer removeAllAnimations];
    });
}

- (void)configCellWithModel:(id)model cellType:(MatchCellType)type{
	if (![model isKindOfClass:[InstantMatcth class]]) {
		return;
	}
    _matchModel = model;
    //比赛信息
    self.typeLabel.text = _matchModel.league;
    self.typeLabel.textColor = [UIColor colorWithHexString:_matchModel.leagueColor];
    self.startTimeLabel.text = [CMMUtility timeConvertWithTimeStamp:@(_matchModel.startTime).stringValue andTimeFormat:@"HH:mm"];
    self.currentTimeLabel.text = [NSString stringWithFormat:@"%@'",@(_matchModel.elapsedTime)];
    if (MatchCellTypeInstant == type || MatchCellTypeFouces == type) {
        self.currentTimeLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.elapsedTime)];
    }
    self.currentTimeLabel.textColor = ColorAppBlack;
    if (_matchModel.status == 0) {
        self.currentTimeLabel.text = @"未";
        self.currentTimeLabel.textColor = RGBCOLOR(58, 58, 58);
    } else if (_matchModel.status == 1 && _matchModel.elapsedTime > 45) {
        //上半场
        self.currentTimeLabel.text = @"45+";
    } else if (_matchModel.status == 2) {
        self.currentTimeLabel.text = @"中";
    } else if (_matchModel.status == 3 && _matchModel.elapsedTime > 90) {
        //下半场
        self.currentTimeLabel.text = @"90+";
    } else if (_matchModel.status == 4 && _matchModel.elapsedTime > 120) {
        self.currentTimeLabel.text = @"120+";
    } else if (_matchModel.status == 5) {
        self.currentTimeLabel.text = @"点球";
    } else if (_matchModel.status == 6) {
        self.currentTimeLabel.text = @"完";
        self.currentTimeLabel.textColor = RGBCOLOR(240, 72, 68);
    }
    //仅即时列表秒点闪烁
    BOOL needShowSecond = ((type == MatchCellTypeInstant || MatchCellTypeFouces == type) && ([self.currentTimeLabel.text isEqualToString:@(_matchModel.elapsedTime).stringValue] || [self.currentTimeLabel.text containsString:@"+"]));
    if (needShowSecond) {
        self.secondsLabel.hidden = NO;
        [self.secondsLabel.layer addAnimation:[self opacityForever_Animation:0.5] forKey:@"opacityForever"];
    } else {
        self.secondsLabel.hidden = YES;
    }
    //竞彩标识
    self.raceIdentLabel.text = QM_IS_STR_NIL(_matchModel.lotteryNo) ? @"" : _matchModel.lotteryNo;
    
    //盘口
    if (QM_IS_STR_NIL(_matchModel.handicap)) {
        self.dishLabel.hidden = YES;
    } else {
        self.dishLabel.hidden = NO;
        self.dishLabel.text = _matchModel.handicap;
        if (QM_IS_STR_NIL(_matchModel.lotteryNo)) {
            [self.dishLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self.focusButton.mas_left).offset(-10);
                make.centerY.equalTo(self.headView);
                make.height.mas_equalTo(17);
            }];
        } else {
            [self.dishLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self.raceIdentLabel.mas_left).offset(-10);
                make.centerY.equalTo(self.headView);
                make.height.mas_equalTo(17);
            }];
        }
    }
    //关注
    if (MatchCellTypeResult == type) {
        self.focusButton.hidden = YES;
		[self.raceIdentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(self.headView).offset(-10);
			make.centerY.equalTo(self.headView);
			make.height.mas_equalTo(17);
		}];
    } else {
        self.focusButton.hidden = NO;
		[self.raceIdentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(self.focusButton.mas_left).offset(-10);
			make.centerY.equalTo(self.headView);
			make.height.mas_equalTo(17);
		}];
        self.focusButton.selected = _matchModel.isFollowed ? YES:NO;
    }
    
    //主客队
    self.hostTeamLabel.text = _matchModel.hostName.length > 6 ? [_matchModel.hostName substringToIndex:6] : _matchModel.hostName;
    self.awayTeamLabel.text = _matchModel.guestName.length > 6 ? [_matchModel.guestName substringToIndex:6] : _matchModel.guestName;
    self.instantHostRankLabel.text = QM_STR_NOT_NIL(_matchModel.instantHostRank);
    self.awayRankLabel.text = QM_STR_NOT_NIL(_matchModel.instantGuestRank);
    
    //红黄牌
    if (_matchModel.hostRedCard > 0) {
        self.redCardLabel.hidden = NO;
        self.redCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.hostRedCard)];
    } else {
        self.redCardLabel.hidden = YES;
    }
    
    if (_matchModel.hostYellowCard > 0) {
        self.yellowCardLabel.hidden = NO;
        self.yellowCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.hostYellowCard)];
    } else {
        self.yellowCardLabel.hidden = YES;
    }
    
    if (_matchModel.guestRedCard > 0) {
        self.awayRedCardLabel.hidden = NO;
        self.awayRedCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.guestRedCard)];
    } else {
        self.awayRedCardLabel.hidden = YES;
    }
    
    if (_matchModel.guestYellowCard > 0) {
        self.awayYellowCardLabel.hidden = NO;
        self.awayYellowCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.guestYellowCard)];
    } else {
        self.awayYellowCardLabel.hidden = YES;
    }
    
    //比分
    if (_matchModel.status == 0) {
        self.scoreLabel.text = @"VS";
        self.scoreLabel.textColor = ColorAppBlack;
    } else {
        self.scoreLabel.textColor = RGBCOLOR(240, 72, 68);
        self.scoreLabel.text = [NSString stringWithFormat:@"%@ : %@",@(_matchModel.hostScore),@(_matchModel.guestScore)];
    }
    
    //直播标识
    if (_matchModel.liveType == 0) {
        self.liveImageView.hidden = YES;
    } else if (_matchModel.liveType == 2) {
        self.liveImageView.hidden = NO;
        self.liveImageView.image = [UIImage imageNamed:@"match_live_video"];
    } else {
        self.liveImageView.hidden = NO;
        self.liveImageView.image = [UIImage imageNamed:@"match_live_animation"];
    }
    
    //情报专家标识
    self.expertsLabel.hidden = _matchModel.hasExpert == 1 ? NO:YES;
    if (_matchModel.hasInformation == 0) {
        self.intelligenceLabel.hidden = YES;
        [self.expertsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.matchView).offset(-15);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.equalTo(self.hostTeamLabel);
        }];
    } else {
        self.intelligenceLabel.hidden = NO;
        [self.expertsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.intelligenceLabel.mas_left).offset(-8);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.equalTo(self.hostTeamLabel);
        }];
    }
    
    //半场信息
    self.halfInfoLabel.text = @"";
    NSMutableString *halfStr = [NSMutableString string];
    if (_matchModel.halfHostScore >= 0 && _matchModel.status >= 3 && _matchModel.status <= 6) {
        [halfStr appendFormat:@"半(%@:%@)  ",@(_matchModel.halfHostScore),@(_matchModel.halfGuestScore)];
    }
    self.halfInfoLabel.text = halfStr.length > 0 ? halfStr : @"";
    self.halfInfoLabel.hidden  = halfStr.length > 0 ? NO : YES;
	
	if (_matchModel.hostCorner >= 0 && _matchModel.status != 0) {
		self.hostCornerImageView.hidden = NO;
		self.hostCornerLabel.hidden = NO;
		self.awayCornerImageView.hidden = NO;
		self.awayCornerLabel.hidden = NO;
		
		self.hostCornerLabel.text = @(_matchModel.hostCorner).stringValue;
		self.awayCornerLabel.text = @(_matchModel.guestCorner).stringValue;
		
		[self.yellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(self.halfInfoLabel);
			make.left.equalTo(self.hostCornerImageView.mas_left).offset(-12);
			make.size.mas_equalTo(CGSizeMake(9, 14));
		}];
		
		[self.awayYellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(self.halfInfoLabel);
			make.left.equalTo(self.awayCornerImageView.mas_right).offset(12);
			make.size.mas_equalTo(CGSizeMake(9, 14));
		}];
	} else {
		self.hostCornerImageView.hidden = YES;
		self.hostCornerLabel.hidden = YES;
		self.awayCornerImageView.hidden = YES;
		self.awayCornerLabel.hidden = YES;
		[self.yellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(self.halfInfoLabel);
			make.right.equalTo(self.halfInfoLabel.mas_left).offset(-9);
			make.size.mas_equalTo(CGSizeMake(9, 14));
		}];
		
		[self.awayYellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(self.halfInfoLabel);
			make.left.equalTo(self.halfInfoLabel.mas_right).offset(9);
			make.size.mas_equalTo(CGSizeMake(9, 14));
		}];
	}
   
    //进度条
    if (!_matchModel.processLineList.count) {
        [self.progressView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(0.01);
            make.top.equalTo(self.matchView.mas_bottom);
            make.left.right.equalTo(self.containerView);
        }];
        self.progressView.hidden = YES;
    } else {
        [self.progressView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(67);
            make.top.equalTo(self.matchView.mas_bottom);
            make.left.right.equalTo(self.containerView);
        }];
        self.progressView.hidden = NO;
    }
    
    //额外信息
    self.extroLabel.text = @"";
    if (MatchCellTypeInstant == type) {
        if (_matchModel.firstHostScore >= 0 && _matchModel.status == 6) {
            //已完结才展示首回合比分
            self.extroLabel.text = [NSString stringWithFormat:@"首回合  %@ %@:%@ %@",_matchModel.hostName,@(_matchModel.firstHostScore),@(_matchModel.firstGuestScore),_matchModel.guestName];
        } else if (_matchModel.isNeutralSite) {
            NSString *str = @"中立场";
            str = [str stringByAppendingString:(_matchModel.matchSite.length?[NSString stringWithFormat:@":%@",_matchModel.matchSite]:@"")];
            self.extroLabel.text = str;
        }
    } else if (MatchCellTypeResult == type) {
        if (_matchModel.resultInfo.length > 0) {
            self.extroLabel.text = _matchModel.resultInfo;
        } else if (_matchModel.totalScore.length > 0) {
            self.extroLabel.text = [NSString stringWithFormat:@"两回合总分  %@ %@ %@",_matchModel.hostName,_matchModel.totalScore,_matchModel.guestName];
        } else if (_matchModel.isNeutralSite) {
            NSString *str = @"中立场";
            str = [str stringByAppendingString:(_matchModel.matchSite.length?[NSString stringWithFormat:@":%@",_matchModel.matchSite]:@"")];
            self.extroLabel.text = str;
        }
    }
    if (self.extroLabel.text.length > 0) {
        self.extroInfoView.hidden = NO;
        [self.extroInfoView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.containerView);
            make.height.mas_equalTo(20);
            make.top.equalTo(self.progressView.mas_bottom);
            make.bottom.equalTo(self.containerView);
        }];
    } else {
        self.extroInfoView.hidden = YES;
        [self.extroInfoView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.right.equalTo(self.containerView);
            make.height.mas_equalTo(0.01);
            make.top.equalTo(self.progressView.mas_bottom);
            make.bottom.equalTo(self.containerView);
        }];
    }
    
//    动态布局
    if (self.hostCornerImageView.hidden && self.awayCornerImageView.hidden && self.yellowCardLabel.hidden && self.redCardLabel.hidden && self.awayYellowCardLabel && self.awayRedCardLabel) {
		[self.hostTeamLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(self.matchView);
			make.right.equalTo(self.scoreLabel.mas_left).offset(-9);
		}];
    } else {
		[self.hostTeamLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.matchView).offset(9);
			make.right.equalTo(self.scoreLabel.mas_left).offset(-9);
		}];
    }
}

- (void)setupView {
    self.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView);
        make.left.equalTo(self.contentView);
        make.right.equalTo(self.contentView);
        make.bottom.equalTo(self.contentView).offset(-6);
    }];
    
    //headView
    [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.containerView);
        make.height.mas_equalTo(28);
    }];
    [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.headView).offset(10);
        make.centerY.equalTo(self.headView);
    }];
    [self.startTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.typeLabel.mas_right).offset(18);
        make.width.mas_lessThanOrEqualTo(60);
        make.centerY.equalTo(self.headView);
    }];
    [self.currentTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.headView);
    }];
    [self.secondsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.currentTimeLabel.mas_right);
        make.centerY.equalTo(self.currentTimeLabel);
    }];
    [self.focusButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.headView).offset(-9.5);
        make.size.mas_equalTo(CGSizeMake(16, 16));
        make.centerY.equalTo(self.headView);
    }];
    [self.raceIdentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.focusButton.mas_left).offset(-10);
        make.centerY.equalTo(self.headView);
        make.height.mas_equalTo(17);
    }];
    [self.dishLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.raceIdentLabel.mas_left).offset(-10);
        make.centerY.equalTo(self.headView);
        make.height.mas_equalTo(17);
    }];
    
    //matchView
    [self.matchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headView.mas_bottom);
        make.left.equalTo(self.containerView);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 60));
    }];
	//主队
    [self.hostTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.matchView).offset(9);
        make.right.equalTo(self.scoreLabel.mas_left).offset(-9);
    }];
	[self.instantHostRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.hostTeamLabel);
		make.right.equalTo(self.hostTeamLabel.mas_left).offset(-8);
	}];
	
	//比分
	[self.scoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.matchView);
		make.centerY.equalTo(self.hostTeamLabel);
	}];
	
	//客队
	[self.awayTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.hostTeamLabel);
		make.left.equalTo(self.scoreLabel.mas_right).offset(9);
	}];
    [self.awayRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.awayTeamLabel);
		make.left.equalTo(self.awayTeamLabel.mas_right).offset(8);
    }];
	//
	[self.liveImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.hostTeamLabel);
		make.left.equalTo(self.matchView).offset(15);
		make.size.mas_equalTo(CGSizeMake(15, 15));
	}];
	[self.intelligenceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.matchView).offset(-15);
		make.centerY.equalTo(self.hostTeamLabel);
		make.size.mas_equalTo(CGSizeMake(15, 15));
	}];
	[self.expertsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.hostTeamLabel);
		make.right.equalTo(self.intelligenceLabel.mas_left).offset(-8);
		make.size.mas_equalTo(CGSizeMake(15, 15));
	}];
	
	//第二行
	[self.halfInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.matchView);
		make.bottom.equalTo(self.matchView).offset(-6.5);
		make.height.mas_equalTo(16);
		make.width.mas_greaterThanOrEqualTo(40);
	}];
	
	[self.hostCornerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.halfInfoLabel.mas_left).offset(-9);
		make.centerY.equalTo(self.halfInfoLabel);
	}];
	
	[self.awayCornerLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.halfInfoLabel.mas_right).offset(9);
		make.centerY.equalTo(self.halfInfoLabel);
	}];
	
	[self.hostCornerImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.hostCornerLabel.mas_left).offset(-5);
		make.centerY.equalTo(self.halfInfoLabel);
		make.size.mas_equalTo(CGSizeMake(12, 12));
	}];
	
	[self.awayCornerImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.awayCornerLabel.mas_right).offset(5);
		make.centerY.equalTo(self.halfInfoLabel);
		make.size.mas_equalTo(CGSizeMake(12, 12));
	}];
	
	[self.yellowCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.halfInfoLabel);
		make.right.equalTo(self.hostCornerImageView.mas_left).offset(-12);
		make.size.mas_equalTo(CGSizeMake(9, 14));
	}];
	[self.redCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.halfInfoLabel);
		make.right.equalTo(self.yellowCardLabel.mas_left).offset(-5);
		make.size.mas_equalTo(CGSizeMake(9, 14));
	}];
	
	[self.awayYellowCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.halfInfoLabel);
		make.left.equalTo(self.awayCornerImageView.mas_right).offset(12);
		make.size.mas_equalTo(CGSizeMake(9, 14));
	}];
	
    [self.awayRedCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.halfInfoLabel);
        make.left.equalTo(self.awayYellowCardLabel.mas_right).offset(5);
        make.size.mas_equalTo(CGSizeMake(9, 14));
    }];
    
    //progressView
    [self.progressView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.matchView.mas_bottom);
        make.left.right.equalTo(self.containerView);
        make.height.mas_equalTo(67);
    }];
    [self.sepratorLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.progressView);
        make.height.mas_equalTo(0.5);
    }];
    
    //extroInfoView
    [self.extroInfoView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.containerView);
        make.height.mas_equalTo(20);
        make.top.equalTo(self.progressView.mas_bottom);
        make.bottom.equalTo(self.containerView);
    }];
    [self.extroLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.centerY.equalTo(self.extroInfoView);
    }];
}

#pragma mark 秒点闪烁动画
- (CABasicAnimation *)opacityForever_Animation:(float)time
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation.fromValue = [NSNumber numberWithFloat:1.0f];
    animation.toValue = [NSNumber numberWithFloat:0.0f];
    animation.autoreverses = YES;
    animation.duration = time;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    return animation;
}

#pragma mark - action
- (void)focusAction:(UIButton *)focusBtn {
    if ([self.cellDelegate respondsToSelector:@selector(focusStateChange:matchId:)]) {
        //关注状态变化通知刷新
        [self.cellDelegate focusStateChange:focusBtn matchId:_matchModel.matchId];
    }
}

#pragma mark - lazy init
- (UIView *)containerView {
    if (!_containerView) {
        _containerView = [UIView new];
        _containerView.backgroundColor = [UIColor whiteColor];
        _containerView.layer.cornerRadius = 5;
        _containerView.clipsToBounds = YES;
        [self.contentView addSubview:_containerView];
    }
    return _containerView;
}
//headView
- (UIView *)headView {
    if (!_headView) {
        _headView = [UIView new];
		_headView.backgroundColor = [UIColor whiteColor];
		UILabel *sepratorLabel = [UILabel new];
		sepratorLabel.backgroundColor = RGBCOLOR(244, 244, 244);
		[_headView addSubview:sepratorLabel];
		[sepratorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.bottom.left.equalTo(_headView);
			make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 1));
		}];
        [self.contentView addSubview:_headView];
    }
    return _headView;
}

- (UILabel *)typeLabel {
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.textColor = RGBCOLOR(58, 58, 58);
        _typeLabel.font = GetFont(12);
        [self.headView addSubview:_typeLabel];
    }
    return _typeLabel;
}

- (UILabel *)startTimeLabel {
    if (!_startTimeLabel) {
        _startTimeLabel = [UILabel new];
        _startTimeLabel.textColor = RGBCOLOR(58, 58, 58);
        _startTimeLabel.font = GetFont(12);
        [self.headView addSubview:_startTimeLabel];
    }
    return _startTimeLabel;
}

- (UILabel *)secondsLabel {
    if (!_secondsLabel) {
        _secondsLabel = [UILabel new];
        _secondsLabel.textColor = ColorAppBlack;
        _secondsLabel.font = GetFont(12);
        _secondsLabel.text = @"'";
        _secondsLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_secondsLabel];
    }
    return _secondsLabel;
}

- (UILabel *)currentTimeLabel {
    if (!_currentTimeLabel) {
        _currentTimeLabel = [UILabel new];
        _currentTimeLabel.font = GetFont(12);
        _currentTimeLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_currentTimeLabel];
    }
    return _currentTimeLabel;
}

- (UILabel *)dishLabel {
    if (!_dishLabel) {
        _dishLabel = [UILabel new];
        _dishLabel.textColor = RGBCOLOR(58, 58, 58);
        _dishLabel.font = GetFont(12);
        _dishLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_dishLabel];
    }
    return _dishLabel;
}

- (UILabel *)raceIdentLabel {
    if (!_raceIdentLabel) {
        _raceIdentLabel = [UILabel new];
        _raceIdentLabel.textColor = RGBCOLOR(58, 58, 58);
        _raceIdentLabel.font = GetFont(12);
        _raceIdentLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_raceIdentLabel];
    }
    return _raceIdentLabel;
}

- (PointExtenButton *)focusButton {
    if (!_focusButton) {
        _focusButton = [[PointExtenButton alloc] init];
        [_focusButton setImage:[UIImage imageNamed:@"match_unfocus_gray_icon"] forState:UIControlStateNormal];
        [_focusButton setImage:[UIImage imageNamed:@"match_fouces_btn"] forState:UIControlStateSelected];
        _focusButton.selected = NO;
        [_focusButton addTarget:self action:@selector(focusAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.headView addSubview:_focusButton];
    }
    return _focusButton;
}

//mathView
- (UIView *)matchView {
    if (!_matchView) {
        _matchView = [UIView new];
        _matchView.backgroundColor = [UIColor whiteColor];
        [self.containerView addSubview:_matchView];
    }
    return _matchView;
}

- (UIImageView *)hostCornerImageView {
	if (!_hostCornerImageView) {
		_hostCornerImageView = [UIImageView new];
		_hostCornerImageView.image = GetImage(@"match_corner_gray_icon");
		[self.matchView addSubview:_hostCornerImageView];
	}
	return _hostCornerImageView;
}

- (UIImageView *)awayCornerImageView {
	if (!_awayCornerImageView) {
		_awayCornerImageView = [UIImageView new];
		_awayCornerImageView.image = GetImage(@"match_corner_gray_icon");
		[self.matchView addSubview:_awayCornerImageView];
	}
	return _awayCornerImageView;
}

- (UILabel *)hostCornerLabel {
	if (!_hostCornerLabel) {
		_hostCornerLabel = [UILabel new];
		_hostCornerLabel.textColor = RGBCOLOR(58, 58, 58);
		_hostCornerLabel.font = fcFont(12);
		[self.matchView addSubview:_hostCornerLabel];
	}
	return _hostCornerLabel;
}

- (UILabel *)awayCornerLabel {
	if (!_awayCornerLabel) {
		_awayCornerLabel = [UILabel new];
		_awayCornerLabel.textColor = RGBCOLOR(58, 58, 58);
		_awayCornerLabel.font = fcFont(12);
		[self.matchView addSubview:_awayCornerLabel];
	}
	return _awayCornerLabel;
}

- (UILabel *)redCardLabel {
    if (!_redCardLabel) {
        _redCardLabel = [UILabel new];
        _redCardLabel.textColor = [UIColor whiteColor];
        _redCardLabel.textAlignment = NSTextAlignmentCenter;
        _redCardLabel.font = GetFont(10);
        _redCardLabel.backgroundColor = RGBCOLOR(240, 72, 68);
        [self.matchView addSubview:_redCardLabel];
    }
    return _redCardLabel;
}

- (UILabel *)yellowCardLabel {
    if (!_yellowCardLabel) {
        _yellowCardLabel = [UILabel new];
        _yellowCardLabel.textColor = [UIColor whiteColor];
        _yellowCardLabel.textAlignment = NSTextAlignmentCenter;
        _yellowCardLabel.backgroundColor = RGBCOLOR(255, 205, 46);
        _yellowCardLabel.font = GetFont(10);
        [self.matchView addSubview:_yellowCardLabel];
    }
    return _yellowCardLabel;
}

- (UILabel *)awayRedCardLabel {
    if (!_awayRedCardLabel) {
        _awayRedCardLabel = [UILabel new];
        _awayRedCardLabel.textColor = [UIColor whiteColor];
        _awayRedCardLabel.textAlignment = NSTextAlignmentCenter;
        _awayRedCardLabel.font = GetFont(10);
        _awayRedCardLabel.backgroundColor = RGBCOLOR(240, 72, 68);
        [self.matchView addSubview:_awayRedCardLabel];
    }
    return _awayRedCardLabel;
}

- (UILabel *)awayYellowCardLabel {
    if (!_awayYellowCardLabel) {
        _awayYellowCardLabel = [UILabel new];
        _awayYellowCardLabel.textColor = [UIColor whiteColor];
        _awayYellowCardLabel.textAlignment = NSTextAlignmentCenter;
        _awayYellowCardLabel.backgroundColor = RGBCOLOR(255, 205, 46);
        _awayYellowCardLabel.font = GetFont(10);
        [self.matchView addSubview:_awayYellowCardLabel];
    }
    return _awayYellowCardLabel;
}

- (UILabel *)hostTeamLabel {
    if (!_hostTeamLabel) {
        _hostTeamLabel = [UILabel new];
        _hostTeamLabel.textColor = ColorAppBlack;
        _hostTeamLabel.font = GetBoldFont(14);
        _hostTeamLabel.textAlignment = NSTextAlignmentRight;
        [self.matchView addSubview:_hostTeamLabel];
    }
    return _hostTeamLabel;
}

- (UILabel *)instantHostRankLabel {
    if (!_instantHostRankLabel) {
        _instantHostRankLabel = [UILabel new];
        _instantHostRankLabel.textColor = RGBCOLOR(58, 58, 58);
        _instantHostRankLabel.font = GetFont(12);
        [self.matchView addSubview:_instantHostRankLabel];
    }
    return _instantHostRankLabel;
}

- (UILabel *)awayTeamLabel {
    if (!_awayTeamLabel) {
        _awayTeamLabel = [UILabel new];
        _awayTeamLabel.textColor = ColorAppBlack;
        _awayTeamLabel.font = GetBoldFont(14);
        _awayTeamLabel.textAlignment = NSTextAlignmentLeft;
        [self.matchView addSubview:_awayTeamLabel];
    }
    return _awayTeamLabel;
}

- (UILabel *)awayRankLabel {
    if (!_awayRankLabel) {
        _awayRankLabel = [UILabel new];
        _awayRankLabel.textColor = RGBCOLOR(58, 58, 58);
        _awayRankLabel.font = GetFont(12);
        [self.matchView addSubview:_awayRankLabel];
    }
    return _awayRankLabel;
}

- (UILabel *)scoreLabel {
    if (!_scoreLabel) {
        _scoreLabel = [UILabel new];
        _scoreLabel.textColor = ColorAppBlack;
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
        _scoreLabel.font = GetBoldFont(16);
        [self.matchView addSubview:_scoreLabel];
    }
    return _scoreLabel;
}

- (UIImageView *)liveImageView {
    if (!_liveImageView) {
        _liveImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"match_live_animation"]];
        [self.matchView addSubview:_liveImageView];
    }
    return _liveImageView;
}

- (UILabel *)halfInfoLabel {
    if (!_halfInfoLabel) {
        _halfInfoLabel = [UILabel new];
        _halfInfoLabel.textColor = RGBCOLOR(58, 58, 58);
        _halfInfoLabel.font = GetFont(12);
        _halfInfoLabel.textAlignment = NSTextAlignmentCenter;
        [self.matchView addSubview:_halfInfoLabel];
    }
    return _halfInfoLabel;
}

- (UILabel *)expertsLabel {
    if (!_expertsLabel) {
        _expertsLabel = [UILabel new];
        _expertsLabel.textColor = ColorAppGreen;
        _expertsLabel.font = GetFont(9);
        _expertsLabel.backgroundColor = [UIColor whiteColor];
        _expertsLabel.text = @"专";
        _expertsLabel.textAlignment = NSTextAlignmentCenter;
        _expertsLabel.layer.cornerRadius = 7.5;
        _expertsLabel.layer.borderColor = ColorAppGreen.CGColor;
        _expertsLabel.layer.borderWidth = 1.0f;
        _expertsLabel.clipsToBounds = YES;
        [self.matchView addSubview:_expertsLabel];
    }
    return _expertsLabel;
}

- (UILabel *)intelligenceLabel {
    if (!_intelligenceLabel) {
        _intelligenceLabel = [UILabel new];
        _intelligenceLabel.textColor = RGBCOLOR(240, 72, 68);
        _intelligenceLabel.font = GetFont(9);
        _intelligenceLabel.backgroundColor = [UIColor whiteColor];
        _intelligenceLabel.text = @"报";
        _intelligenceLabel.textAlignment = NSTextAlignmentCenter;
        _intelligenceLabel.layer.cornerRadius = 7.5;
        _intelligenceLabel.layer.borderColor = RGBCOLOR(240, 72, 68).CGColor;
        _intelligenceLabel.layer.borderWidth = 1.0f;
        _intelligenceLabel.clipsToBounds = YES;
        [self.matchView addSubview:_intelligenceLabel];
    }
    return _intelligenceLabel;
}

//progressView
- (UIView *)progressView {
    if (!_progressView) {
        _progressView = [UIView new];
        _progressView.backgroundColor = [UIColor whiteColor];
        [self.containerView addSubview:_progressView];
    }
    return _progressView;
}

- (UIView *)sepratorLine {
    if (!_sepratorLine) {
        _sepratorLine = [UIView new];
        _sepratorLine.backgroundColor = RGBCOLOR(244, 244, 244);
        [self.progressView addSubview:_sepratorLine];
    }
    return _sepratorLine;
}
//extroInfoView
- (UIView *)extroInfoView {
    if (!_extroInfoView) {
        _extroInfoView = [UIView new];
        _extroInfoView.backgroundColor = RGBCOLOR(255, 210, 210);
        [self.containerView addSubview:_extroInfoView];
    }
    return _extroInfoView;
}

- (UILabel *)extroLabel {
    if (!_extroLabel) {
        _extroLabel = [UILabel new];
        _extroLabel.textColor = RGBCOLOR(58, 58, 58);
        _extroLabel.font = GetFont(11);
        _extroLabel.textAlignment = NSTextAlignmentCenter;
        [self.extroInfoView addSubview:_extroLabel];
    }
    return _extroLabel;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
