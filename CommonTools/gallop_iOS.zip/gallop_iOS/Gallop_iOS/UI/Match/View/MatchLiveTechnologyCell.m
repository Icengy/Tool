//
//  MatchLiveTechnologyCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/23.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchLiveTechnologyCell.h"
#import "LiveTCPMessageModel.h"

@interface MatchLiveTechnologyCell()
@property (nonatomic,strong) UILabel *hostLabel;
@property (nonatomic,strong) UIView  *hostView;
@property (nonatomic,strong) UIView  *hostValueView;

@property (nonatomic,strong) UILabel *typeLabel;

@property (nonatomic,strong) UILabel *guestLabel;
@property (nonatomic,strong) UIView  *guestValueView;
@property (nonatomic,strong) UIView  *guestView;
@end

@implementation MatchLiveTechnologyCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = UIColor.whiteColor;
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self.contentView addSubview:self.typeLabel];
    [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView);
        make.centerX.equalTo(self.contentView);
        make.width.mas_equalTo(self.contentView.mas_width).multipliedBy(0.25);
    }];
    
    /// 主队
    [self.contentView addSubview:self.hostView];
    [self.hostView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(15.0);
        make.bottom.equalTo(self.typeLabel.mas_bottom);
        make.height.offset(6.0);
        make.right.equalTo(self.typeLabel.mas_left);
    }];
    [self.hostView addSubview:self.hostValueView];
    [self.hostValueView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.bottom.equalTo(self.hostView);
        make.width.equalTo(self.hostView.mas_width).multipliedBy(0.0);
    }];
    [self.hostLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.hostView.mas_left).offset(4.0);
        make.top.equalTo(self.contentView.mas_top);
        make.bottom.equalTo(self.hostView.mas_top);
    }];
    
    /// 客队
    [self.contentView addSubview:self.guestView];
    [self.guestView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView).offset(-15.0);
        make.bottom.equalTo(self.typeLabel.mas_bottom);
        make.height.offset(6.0);
        make.left.equalTo(self.typeLabel.mas_right);
    }];
    [self.guestView addSubview:self.guestValueView];
    [self.guestValueView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(self.guestView);
        make.width.equalTo(self.guestView.mas_width).multipliedBy(0.0);
    }];
    [self.guestLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.guestView.mas_right).offset(-4.0);
        make.top.equalTo(self.contentView.mas_top);
        make.bottom.equalTo(self.guestView.mas_top);
    }];
}

- (void)setTechnology:(NSDictionary *)technology {
    _technology = technology;
    
    self.typeLabel.text = _technology.allKeys.lastObject;
    NSString *str = _technology.allValues.lastObject;
    
    NSString *hostCountStr = [str componentsSeparatedByString:@","].firstObject;
    NSString *guestCountStr = [str componentsSeparatedByString:@","].lastObject;
    
    self.hostLabel.text = [NSString stringWithFormat:@"%@次", hostCountStr];
    [self.hostLabel addAttributedText:hostCountStr withAttributeds:@{NSFontAttributeName: [UIFont addPingFangSCRegular:12.0],
                                                                     NSForegroundColorAttributeName: ColorMatchHost}];
    self.guestLabel.text = [NSString stringWithFormat:@"%@次", guestCountStr];
    [self.guestLabel addAttributedText:guestCountStr withAttributeds:@{NSFontAttributeName: [UIFont addPingFangSCRegular:12.0],
                                                                       NSForegroundColorAttributeName: ColorMatchGuest}];
    if ([self.typeLabel.text isEqualToString:@"越位"]) {
        WTCLog(@"");
    }
    double hostRate = 0.0;
    double guestRate = 0.0;
    double sum = hostCountStr.doubleValue + guestCountStr.doubleValue;
    if (sum > 0) {
        hostRate += hostCountStr.doubleValue / sum;
        guestRate += guestCountStr.doubleValue / sum;
    }
    [self.hostValueView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.right.bottom.equalTo(self.hostView);
        make.width.equalTo(self.hostView.mas_width).multipliedBy(hostRate);
    }];
    [self.guestValueView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(self.guestView);
        make.width.equalTo(self.guestView.mas_width).multipliedBy(guestRate);
    }];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [UIView animateWithDuration:0.3 animations:^{
            [self setNeedsLayout];
        }];
    });
}

#pragma mark - lazy init
- (UILabel *)hostLabel {
    if (!_hostLabel) {
        _hostLabel = [UILabel new];
        _hostLabel.textColor = ColorMainNormalBlack;
        _hostLabel.font = GetFont(10);
        _hostLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_hostLabel];
    }
    return _hostLabel;
}

- (UIView *)hostView {
    if (!_hostView) {
        _hostView = [UIView new];
        _hostView.backgroundColor = ColorDefaultGrayBackground;
        [_hostView addRoundedCorners:(UIRectCornerAllCorners) withRadii:3.0];
    }
    return _hostView;
}

- (UIView *)hostValueView {
    if (!_hostValueView) {
        _hostValueView = [UIView new];
        _hostValueView.backgroundColor = ColorMatchHost;
        [_hostValueView addRoundedCorners:(UIRectCornerTopLeft | UIRectCornerBottomLeft) withRadii:3.0];
    }
    return _hostValueView;
}

- (UILabel *)typeLabel {
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.textColor = Color99;
        _typeLabel.font = GetFont(12.0);
        _typeLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _typeLabel;
}

- (UILabel *)guestLabel {
    if (!_guestLabel) {
        _guestLabel = [UILabel new];
        _guestLabel.textColor = RGBCOLOR(58, 58, 58);
        _guestLabel.font = GetFont(10);
        _guestLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_guestLabel];
    }
    return _guestLabel;
}

- (UIView *)guestView {
    if (!_guestView) {
        _guestView = [UIView new];
        _guestView.backgroundColor = ColorDefaultGrayBackground;
        [_guestView addRoundedCorners:(UIRectCornerAllCorners) withRadii:3.0];
    }
    return _guestView;
}

- (UIView *)guestValueView {
    if (!_guestValueView) {
        _guestValueView = [UIView new];
        _guestValueView.backgroundColor = ColorMatchGuest;
        [_guestValueView addRoundedCorners:(UIRectCornerTopRight | UIRectCornerBottomRight) withRadii:3.0];
    }
    return _guestValueView;
}



@end
