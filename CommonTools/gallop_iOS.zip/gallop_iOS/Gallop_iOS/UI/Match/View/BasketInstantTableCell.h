//
//  BasketInstantTableCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/8/31.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

#import "MatchInstantTableCellDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface BasketInstantTableCell : ESTableViewCell

@property(nonatomic, weak)id<MatchInstantTableCellDelegate> cellDelegate;
- (void)configCellWithModel:(id)model eventMap:(NSDictionary *)eventDict teamMap:(NSDictionary *)teamDict cellType:(MatchCellType)type;
//YES - 主队得分 NO - 客队得分
- (void)scroreChange:(BOOL)isHostOrGuest;

@end

NS_ASSUME_NONNULL_END
