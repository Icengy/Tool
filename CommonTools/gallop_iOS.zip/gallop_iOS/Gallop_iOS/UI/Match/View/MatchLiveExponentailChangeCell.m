//
//  MatchLiveExponentailChangeCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchLiveExponentailChangeCell.h"
#import "MatchLiveExponentailModel.h"

@interface MatchLiveExponentailChangeCell()
@property(nonatomic, strong)UILabel *runtimeLabel;
@property(nonatomic, strong)UILabel *scoreLabel;
@property(nonatomic, strong)UILabel *hostLabel;
@property(nonatomic, strong)UILabel *panLabel;
@property(nonatomic, strong)UILabel *guestLabel;
@property(nonatomic, strong)UILabel *timeLabel;
@end

@implementation MatchLiveExponentailChangeCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[@[self.runtimeLabel,self.scoreLabel,self.hostLabel,self.panLabel,self.guestLabel] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:0 leadSpacing:0 tailSpacing:100];
	[@[self.runtimeLabel,self.scoreLabel,self.hostLabel,self.panLabel,self.guestLabel,self.timeLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.contentView);
		make.height.mas_equalTo(30);
	}];
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentView);
		make.width.mas_equalTo(100);
	}];
}

- (void)configCellWithModel:(ExponentailDataItem *)model {
	self.runtimeLabel.text = model.matchMin;
	self.scoreLabel.text = model.score;
	self.timeLabel.text = model.changeTime;

	//color
	UIColor *equalColor = RGBCOLOR(58, 58, 58);
	UIColor *hightColor = RGBCOLOR(240, 72, 68);
	UIColor *lowColor = ColorAppGreen;
	
	if (model.runningOddsType == 3 || model.runningOddsType == 6 || model.runningOddsType == 7) {
		self.guestLabel.text = @"";
		self.panLabel.text = @"封";
		self.hostLabel.text = @"";
		self.panLabel.textColor = hightColor;
	} else {
		self.hostLabel.text = model.odds1;
		self.panLabel.text = model.odds2;
		self.guestLabel.text = model.odds3;
		
		self.hostLabel.textColor = model.changeOdds1 > 0 ? hightColor : model.changeOdds1 < 0 ? lowColor : equalColor;
		self.panLabel.textColor = model.changeOdds2 > 0 ? hightColor : model.changeOdds2 < 0 ? lowColor : equalColor;
		self.guestLabel.textColor = model.changeOdds3 > 0 ? hightColor : model.changeOdds3 < 0 ? lowColor : equalColor;
	}
}

#pragma mark - lazy init
- (UILabel *)runtimeLabel {
	if (!_runtimeLabel) {
		_runtimeLabel = [UILabel new];
		_runtimeLabel.textColor = RGBCOLOR(240, 72, 68);
		_runtimeLabel.font = GetFont(12);
		_runtimeLabel.adjustsFontSizeToFitWidth = YES;
		_runtimeLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_runtimeLabel];
	}
	return _runtimeLabel;
}

- (UILabel *)scoreLabel {
	if (!_scoreLabel) {
		_scoreLabel = [UILabel new];
		_scoreLabel.textColor = RGBCOLOR(58, 58, 58);
		_scoreLabel.font = GetFont(12);
		_scoreLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_scoreLabel];
	}
	return _scoreLabel;
}

- (UILabel *)hostLabel {
	if (!_hostLabel) {
		_hostLabel = [UILabel new];
		_hostLabel.textColor = RGBCOLOR(58, 58, 58);
		_hostLabel.font = GetFont(12);
		_hostLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_hostLabel];
	}
	return _hostLabel;
}

- (UILabel *)panLabel {
	if (!_panLabel) {
		_panLabel = [UILabel new];
		_panLabel.textColor = RGBCOLOR(58, 58, 58);
		_panLabel.font = GetFont(12);
		_panLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_panLabel];
	}
	return _panLabel;
}

- (UILabel *)guestLabel {
	if (!_guestLabel) {
		_guestLabel = [UILabel new];
		_guestLabel.textColor = RGBCOLOR(58, 58, 58);
		_guestLabel.font = GetFont(12);
		_guestLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_guestLabel];
	}
	return _guestLabel;
}

- (UILabel *)timeLabel {
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.textColor = RGBCOLOR(58, 58, 58);
		_timeLabel.font = GetFont(12);
		_timeLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}

@end

