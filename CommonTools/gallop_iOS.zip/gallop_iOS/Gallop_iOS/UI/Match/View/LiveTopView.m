//
//  LiveTopView.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/24.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "LiveTopView.h"
#import "MatchDetailTopModel.h"
@interface LiveTopView ()
@property(nonatomic, strong)UIImageView         *backImageView;
@property(nonatomic, strong)UIView              *shortHeadView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *title_top_constraint;
@property(nonatomic, weak) IBOutlet UIStackView              *titleContentView;
@property(nonatomic, weak) IBOutlet UILabel             *titleLabel;
@property(nonatomic, weak) IBOutlet CYButton     *leagueBtn;

@property (weak, nonatomic) IBOutlet UIStackView *contentView;

@property(nonatomic, weak) IBOutlet UILabel             *startTimeLabel;
@property(nonatomic, weak) IBOutlet UILabel             *currentTimeLabel;
@property(nonatomic, weak) IBOutlet UILabel             *secondsLabel;
@property(nonatomic, weak) IBOutlet UILabel             *scoreLabel;
@property(nonatomic, weak) IBOutlet UILabel             *halfScoreLabel;
@property(nonatomic, weak) IBOutlet UIView              *liveBtnContentView;

@property(nonatomic, weak) IBOutlet CYButton            *animationLiveBtn;
@property(nonatomic, weak) IBOutlet CYButton            *videoLiveBtn;
@property(nonatomic, weak) IBOutlet UIView *liveSepratorView;

@property(nonatomic, strong)UIImageView         *hostTeamImageView;
@property(nonatomic, strong)UIImageView         *awayTeamImageView;
@property(nonatomic, strong)UILabel             *hostTeamLabel;
@property(nonatomic, strong)UILabel             *awayTeamLabel;
@property(nonatomic, strong)UILabel             *instantHostRankLabel;
@property(nonatomic, strong)UILabel             *instantGuestRankLabel;

@property(nonatomic, strong)MatchDetailTopModel *model;
@property(nonatomic) CGSize imageSize;

@end

@implementation LiveTopView

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.title_top_constraint.constant = kStatusBarHeight;
    self.startTimeLabel.adjustsFontSizeToFitWidth = YES;
    
    [self setupView];
}

- (void)setupView {
    
//    [self addSubview:self.backBtn];
////    [self addSubview:self.focusBtn];
////    [self addSubview:self.shareBtn];
//    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerY.height.equalTo(self.titleContentView);
//        make.left.equalTo(self.mas_left);
//        make.width.equalTo(self.backBtn.mas_height);
//    }];
//
    self.imageSize = CGSizeMake(kScreen_Width/375.0*60.0, kScreen_Width/375.0*60.0);
 
    [self.secondsLabel.layer addAnimation:[self opacityForever_Animation:0.5] forKey:nil];
    [self.secondsLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.currentTimeLabel.mas_right);
    }];
    
    self.videoLiveBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.videoLiveBtn.backgroundPrams([RGBCOLOR(0, 0, 0) colorWithAlphaComponent:0.19], nil, UIControlStateNormal);
    self.animationLiveBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.animationLiveBtn.backgroundPrams([RGBCOLOR(0, 0, 0) colorWithAlphaComponent:0.19], nil, UIControlStateNormal);
    self.liveBtnContentView.hidden = YES;
    
    [self.hostTeamImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.mas_centerX).offset(-kScreen_Width/4.5);
        make.top.equalTo(self.contentView.mas_top).offset(10.0);
        make.size.sizeOffset(self.imageSize);
    }];
    [self.hostTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.hostTeamImageView.mas_bottom).offset(15.0);
        make.centerX.equalTo(self.hostTeamImageView);
        make.width.mas_lessThanOrEqualTo(100);
    }];
    [self.instantHostRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.hostTeamImageView);
        make.top.equalTo(self.hostTeamLabel.mas_bottom).offset(5);
        make.bottom.equalTo(self.contentView.mas_bottom);
    }];

    
    [self.awayTeamImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_centerX).offset(kScreen_Width/4.5);
        make.centerY.equalTo(self.hostTeamImageView);
        make.size.sizeOffset(self.imageSize);
    }];
    [self.awayTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_lessThanOrEqualTo(100);
        make.centerY.equalTo(self.hostTeamLabel);
        make.centerX.equalTo(self.awayTeamImageView);
    }];
    [self.instantGuestRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.awayTeamImageView);
        make.centerY.equalTo(self.instantHostRankLabel);
    }];
}

#pragma mark - action
- (void)focusAction:(UIButton *)sender {
    if ([self.liveTopViewDelegate respondsToSelector:@selector(focusAction:)]) {
        [self.liveTopViewDelegate focusAction:sender];
    }
}

- (void)shareAction {
    if ([self.liveTopViewDelegate respondsToSelector:@selector(shareAction)]) {
        [self.liveTopViewDelegate shareAction];
    }
}

- (IBAction)animationLiveBtnClick:(id)sender {
    //动画直播
    if ([self.liveTopViewDelegate respondsToSelector:@selector(animationLiveBtnClick)]) {
        [self.liveTopViewDelegate animationLiveBtnClick];
    }
}

- (IBAction)videoLiveBtnClick:(id)sender {
    //视频直播
    if ([self.liveTopViewDelegate respondsToSelector:@selector(videoLiveBtnClick)]) {
        [self.liveTopViewDelegate videoLiveBtnClick];
    }
}

- (void)backBtnClick {
    if ([self.liveTopViewDelegate respondsToSelector:@selector(backBtnClick)]) {
        [self.liveTopViewDelegate backBtnClick];
    }
}

- (void)teamClick:(UITapGestureRecognizer *)tap {
    BOOL isHost;
    if (tap.view.tag == 10001) {
        isHost = YES;
    } else {
        isHost = NO;
    }
    if ([self.liveTopViewDelegate respondsToSelector:@selector(teamClick:isHost:)]) {
        [self.liveTopViewDelegate teamClick:self.model isHost:isHost];
    }
}

- (IBAction)leagueBtnClick:(id)sender {
    if ([self.liveTopViewDelegate respondsToSelector:@selector(leagueBtnClick)]) {
        [self.liveTopViewDelegate leagueBtnClick];
    }
}

#pragma mark - config
- (void)hideHead:(BOOL)hide {
	if (hide) {
		//收缩
		self.titleContentView.hidden = YES;
		self.startTimeLabel.hidden = YES;
		self.shortHeadView.hidden = NO;
	} else {
		//展开
		self.titleContentView.hidden = NO;
		self.startTimeLabel.hidden = NO;
		self.shortHeadView.hidden = YES;
	}
}

- (void)configTopView:(MatchDetailTopModel *)model {

    self.model = model;
    self.titleLabel.text = model.title;
    
//    if (model.status == 6) {
//        self.focusBtn.hidden = YES;
//    } else {
//        self.focusBtn.hidden = NO;
//        self.focusBtn.selected = model.isFollowed;
//    }
    
    self.startTimeLabel.text = [CMMUtility timeConvertWithTimeStamp:@(model.startTime).stringValue andTimeFormat:@"yyyy-MM-dd HH:mm"];
    
    //比赛进行时间
    self.currentTimeLabel.text = [NSString stringWithFormat:@"%@",@(model.openTime)];
    if (model.status == 0) {
        self.currentTimeLabel.text = @"未";
    } else if (model.status == 1 && model.openTime > 45) {
        //上半场
        self.currentTimeLabel.text = @"45+";
    } else if (model.status == 2) {
        self.currentTimeLabel.text = @"中";
    } else if (model.status == 3 && model.openTime > 90) {
        //下半场
        self.currentTimeLabel.text = @"90+";
    } else if (model.status == 4 && model.openTime > 120) {
        self.currentTimeLabel.text = @"120+";
    } else if (model.status == 5) {
        self.currentTimeLabel.text = @"点球";
    } else if (model.status == 6) {
        self.currentTimeLabel.text = @"完";
    }
    BOOL needShowSecond = [self.currentTimeLabel.text isEqualToString:@(model.openTime).stringValue] || [self.currentTimeLabel.text containsString:@"+"];
    if (needShowSecond) {
        //显示闪烁秒点
        self.secondsLabel.hidden = NO;
    } else {
        self.secondsLabel.hidden = YES;
    }
    //
    if (!QM_IS_STR_NIL(model.hostFlag)) {
        [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:model.hostFlag]  options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        } completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
            if (image) {
                self.hostTeamImageView.image = image;
            } else {
                self.hostTeamImageView.image = [UIImage imageNamed:@"host"];
            }
        }];
    }else{
        self.hostTeamImageView.image = [UIImage imageNamed:@"host"];
    }
    
    if (!QM_IS_STR_NIL(model.guestFlag)) {
        [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:model.guestFlag]  options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        } completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
            if (image) {
                self.awayTeamImageView.image = image;
            } else {
                self.awayTeamImageView.image = [UIImage imageNamed:@"guest"];
            }
        }];
    }else{
        self.awayTeamImageView.image = [UIImage imageNamed:@"guest"];
    }
    self.hostTeamLabel.font = GetFont(12.0);
    self.awayTeamLabel.font = GetFont(12.0);
    self.hostTeamLabel.text = model.hostName;
    self.awayTeamLabel.text = model.guestName;
    //比分
    if (model.status == 0) {
        self.scoreLabel.text = @"VS";
    } else {
        self.scoreLabel.text = [NSString stringWithFormat:@"%@ : %@",model.hostScore,model.guestScore];
    }
    
    //半场比分
    if (model.hostHalfScore.integerValue >= 0 && model.guestHalfScore.integerValue >= 0 && model.status >= 3 && model.status <= 6) {
        self.halfScoreLabel.hidden = NO;
        self.halfScoreLabel.text = [NSString stringWithFormat:@"(%@:%@)",model.hostHalfScore,model.guestHalfScore];
    } else {
        self.halfScoreLabel.hidden = YES;
    }
    
    if (model.liveType == 0) {
        self.liveBtnContentView.hidden = YES;
    } else if (model.liveType == 1) {
        //animation
        self.liveBtnContentView.hidden = NO;
        self.animationLiveBtn.hidden = NO;
        self.videoLiveBtn.hidden = YES;
    } else if (model.liveType == 2) {
        //video
        self.liveBtnContentView.hidden = NO;
        self.animationLiveBtn.hidden = YES;
        self.videoLiveBtn.hidden = NO;
    } else {
        //both
        self.liveBtnContentView.hidden = NO;
        self.animationLiveBtn.hidden = NO;
        self.videoLiveBtn.hidden = NO;
    }
    self.liveSepratorView.hidden = (self.animationLiveBtn.hidden ||
                                    self.videoLiveBtn.hidden);
    
    self.instantHostRankLabel.text = model.hostRank;
    self.instantGuestRankLabel.text = model.guestRank;
    
}

- (void)configBasketTopView:(MatchBasketTopModel *)model {
//	self.backImageView.image = GetImage(@"basket_topView_bg");
	self.titleLabel.text = [NSString stringWithFormat:@"%@",model.event.shortNameZh];
	//篮球暂无分享功能 收藏按钮位置靠右
	
//	if (model.match.state >= 10) {
//		self.focusBtn.hidden = YES;
//	} else {
//		self.focusBtn.hidden = NO;
//		self.focusBtn.selected = model.match.follow;
//	}
	
	if (!model.hasIntegral) {
		self.leagueBtn.hidden = YES;
	} else {
		self.leagueBtn.hidden = NO;
	}
	
	self.startTimeLabel.text = [CMMUtility timeConvertWithTimeStamp:@(model.match.startTime).stringValue andTimeFormat:@"yyyy-MM-dd HH:mm"];
	
	//比赛进行时间
	NSArray *stateArr = @[@"未",@"第一节",@"第一节完",@"第二节",@"第二节完",@"第三节",@"第三节完",@"第四节", @"加时",@"完",@"中断",@"取消",@"延期",@"腰斩"];
	if (model.match.state > 0) {
		self.currentTimeLabel.text = stateArr[model.match.state - 1];
	}
	NSString *minute = [NSString stringWithFormat:@"00%ld",model.match.seconds / 60];
	minute = [minute substringWithRange:NSMakeRange(minute.length - 2, 2)];
	NSString *second = [NSString stringWithFormat:@"00%ld",model.match.seconds % 60];
	second = [second substringWithRange:NSMakeRange(second.length - 2, 2)];
	if (model.match.state == 2 || model.match.state == 4 || model.match.state == 6 || model.match.state == 8 || model.match.state == 9) {
		self.currentTimeLabel.text = [self.currentTimeLabel.text stringByAppendingString:[NSString stringWithFormat:@" %@:%@",minute,second]];
	}
	
    // 隐藏秒数
	self.secondsLabel.hidden = YES;
	
	//
	if (!QM_IS_STR_NIL(model.awayTeam.logo)) {
		[[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:model.awayTeam.logo]  options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
		} completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
			if (image) {
				self.hostTeamImageView.image = image;
			} else {
				self.hostTeamImageView.image = [UIImage imageNamed:@"guest"];
			}
		}];
	}else{
		self.hostTeamImageView.image = [UIImage imageNamed:@"guest"];
	}
	
	if (!QM_IS_STR_NIL(model.hostTeam.logo)) {
		[[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:model.hostTeam.logo]  options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
		} completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
			if (image) {
				self.awayTeamImageView.image = image;
			} else {
				self.awayTeamImageView.image = [UIImage imageNamed:@"host"];
			}
		}];
	}else{
		self.awayTeamImageView.image = [UIImage imageNamed:@"host"];
	}
	
	self.hostTeamLabel.text = model.awayTeam.shortNameZh;
	self.awayTeamLabel.text = model.hostTeam.shortNameZh;
	//比分
	int awaySum = [[model.match.away.scores valueForKeyPath:@"@sum.intValue"] intValue];
	int hostSum = [[model.match.host.scores valueForKeyPath:@"@sum.intValue"] intValue];
	if (model.match.state == 1) {
		self.scoreLabel.text = @"VS";
	} else {
		self.scoreLabel.text = [NSString stringWithFormat:@"%d : %d", awaySum,hostSum];
	}
	
	int halfAway = model.match.away.scores[0].intValue + model.match.away.scores[1].intValue;
	int hostAway = model.match.host.scores[0].intValue + model.match.host.scores[1].intValue;
	//半场比分
	if (halfAway >= 0 && hostAway >= 0 && model.match.state >= 5) {
		self.halfScoreLabel.hidden = NO;
		self.halfScoreLabel.text = [NSString stringWithFormat:@"(%d:%d)",halfAway,hostAway];
	} else {
		self.halfScoreLabel.hidden = YES;
	}
	
	
	self.instantHostRankLabel.text = model.awayTeam.rank;
	self.instantGuestRankLabel.text = model.hostTeam.rank;

    //隐藏直播部分
    self.liveBtnContentView.hidden = YES;
    
	//分享按钮暂时隐藏
	self.shareBtn.hidden = YES;
	//暂时禁用队伍图标点击
	self.hostTeamImageView.userInteractionEnabled = NO;
	self.awayTeamImageView.userInteractionEnabled = NO;
}

#pragma mark 秒点闪烁动画
- (CABasicAnimation *)opacityForever_Animation:(float)time
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"opacity"];//必须写opacity才行。
    animation.fromValue = [NSNumber numberWithFloat:1.0f];
    animation.toValue = [NSNumber numberWithFloat:0.0f];//这是透明度。
    animation.autoreverses = YES;
    animation.duration = time;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    return animation;
}

#pragma mark - lazy init
- (UIImageView *)backImageView {
    if (!_backImageView) {
        _backImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"match_topView_bg"]];
        _backImageView.hidden = YES;
        [self addSubview:_backImageView];
    }
    return _backImageView;
}

- (CYButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [CYButton buttonWithType:UIButtonTypeCustom]
        .imagePrams(GetNavigationImage(@"nav_return_white"), UIControlStateNormal)
        .actionPrams(self, @selector(backBtnClick), UIControlEventTouchUpInside);
        _backBtn.hidden = YES;
    }
    return _backBtn;
}

- (UIView *)shortHeadView {
	if (!_shortHeadView) {
		_shortHeadView = [UIView new];
		_shortHeadView.hidden = YES;
		_shortHeadView.backgroundColor = [UIColor clearColor];
		[self addSubview:_shortHeadView];
		[_shortHeadView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.height.mas_equalTo(17);
			make.top.equalTo(self.titleContentView);
			make.centerX.equalTo(self);
			make.width.mas_equalTo(SCREEN_WIDTH - 125);
		}];
		UILabel *label = [UILabel new];
		label.textAlignment = NSTextAlignmentCenter;
		label.text = self.scoreLabel.text;
		label.font = fcBoldFont(14);
		label.textColor = [UIColor whiteColor];
		[_shortHeadView addSubview:label];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.center.equalTo(_shortHeadView);
		}];
		
		UILabel *label1 = [UILabel new];
		label1.textAlignment = NSTextAlignmentCenter;
		label1.text = self.hostTeamLabel.text;
		label1.font = fcBoldFont(14);
		label1.textColor = [UIColor whiteColor];
		[_shortHeadView addSubview:label1];
		[label1 mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(_shortHeadView);
			make.right.equalTo(label.mas_left).offset(-8);
			make.left.greaterThanOrEqualTo(_shortHeadView);
		}];
		
		UILabel *label2 = [UILabel new];
		label2.textAlignment = NSTextAlignmentCenter;
		label2.text = self.awayTeamLabel.text;
		label2.font = fcBoldFont(14);
		label2.textColor = [UIColor whiteColor];
		[_shortHeadView addSubview:label2];
		[label2 mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerY.equalTo(_shortHeadView);
			make.left.equalTo(label.mas_right).offset(8);
			make.right.lessThanOrEqualTo(_shortHeadView);
		}];
	}
	return _shortHeadView;
}

- (CYButton *)focusBtn {
    if (!_focusBtn) {
        _focusBtn = [CYButton buttonWithType:UIButtonTypeCustom]
        .imagePrams(GetNavigationImage(@"match_unfouces_btn"), UIControlStateNormal)
        .imagePrams(GetNavigationImage(@"match_fouces_btn"), UIControlStateSelected)
        .actionPrams(self, @selector(focusAction:), UIControlEventTouchUpInside);
        _focusBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    }
    return _focusBtn;
}

- (CYButton *)shareBtn {
    if (!_shareBtn) {///nav_return_white/match_share_btn
        _shareBtn = [CYButton buttonWithType:UIButtonTypeCustom]
        .imagePrams(GetNavigationImage(@"match_share_btn"), UIControlStateNormal)
        .actionPrams(self, @selector(shareAction), UIControlEventTouchUpInside)
        .backgroundPrams(UIColor.arcrandomColor, nil, UIControlStateNormal);
        _shareBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    }
    return _shareBtn;
}


- (UIImageView *)hostTeamImageView {
    if (!_hostTeamImageView) {
        _hostTeamImageView = [[UIImageView alloc] init];
        _hostTeamImageView.layer.cornerRadius = self.imageSize.height/2;
        _hostTeamImageView.clipsToBounds = YES;
        _hostTeamImageView.tag = 10001;
        _hostTeamImageView.contentMode = UIViewContentModeScaleAspectFit;
        _hostTeamImageView.backgroundColor = RGBCOLORV(0xF4F4F4);
        _hostTeamImageView.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(teamClick:)];
        [_hostTeamImageView addGestureRecognizer:tap];
        [self addSubview:_hostTeamImageView];
    }
    return _hostTeamImageView;
}

- (UIImageView *)awayTeamImageView {
    if (!_awayTeamImageView) {
        _awayTeamImageView = [UIImageView new];
        _awayTeamImageView.layer.cornerRadius = self.imageSize.height/2;
        _awayTeamImageView.clipsToBounds = YES;
        _awayTeamImageView.userInteractionEnabled = YES;
        _awayTeamImageView.contentMode = UIViewContentModeScaleAspectFit;
        _awayTeamImageView.backgroundColor = RGBCOLORV(0xF4F4F4);
        _awayTeamImageView.tag = 10002;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(teamClick:)];
        [_awayTeamImageView addGestureRecognizer:tap];
        [self addSubview:_awayTeamImageView];
    }
    return _awayTeamImageView;
}

- (UILabel *)hostTeamLabel {
    if (!_hostTeamLabel) {
        _hostTeamLabel = [UILabel new];
        _hostTeamLabel.textColor = [UIColor whiteColor];

        _hostTeamLabel.font = GetFont(14);
        _hostTeamLabel.numberOfLines = 0;
		_hostTeamLabel.textAlignment = NSTextAlignmentCenter;

        [self addSubview:_hostTeamLabel];
    }
    return _hostTeamLabel;
}

- (UILabel *)awayTeamLabel {
    if (!_awayTeamLabel) {
        _awayTeamLabel = [UILabel new];
        _awayTeamLabel.textColor = [UIColor whiteColor];

        _awayTeamLabel.font = GetFont(14);
        _awayTeamLabel.numberOfLines = 0;
		_awayTeamLabel.textAlignment = NSTextAlignmentCenter;

        [self addSubview:_awayTeamLabel];
    }
    return _awayTeamLabel;
}

- (UILabel *)instantHostRankLabel {
    if (!_instantHostRankLabel) {
        _instantHostRankLabel = [UILabel new];
        _instantHostRankLabel.textColor = [UIColor whiteColor];
        _instantHostRankLabel.font = GetFont(9);
        _instantHostRankLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_instantHostRankLabel];
    }
    return _instantHostRankLabel;
}

- (UILabel *)instantGuestRankLabel {
    if (!_instantGuestRankLabel) {
        _instantGuestRankLabel = [UILabel new];
        _instantGuestRankLabel.textColor = [UIColor whiteColor];
        _instantGuestRankLabel.font = GetFont(9);
        _instantGuestRankLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_instantGuestRankLabel];
    }
    return _instantGuestRankLabel;
}

@end
