//
//  MatchLiveExponentailCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/24.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchLiveExponentailCell.h"
#import "LiveTCPMessageModel.h"

@interface MatchLiveExponentailCell()

@property (nonatomic ,strong) NSArray <UILabel *>* views;

@property(nonatomic, strong)UILabel *timeLabel;
@property(nonatomic, strong)UILabel *scoreLabel;
@property(nonatomic, strong)UILabel *firstStartLabel;
@property(nonatomic, strong)UILabel *secondStartLabel;
@property(nonatomic, strong)UILabel *thirdStartLabel;
@property(nonatomic, strong)UILabel *firstCurrentLabel;
@property(nonatomic, strong)UILabel *secondCurrentLabel;
@property(nonatomic, strong)UILabel *thirdCurrentLabel;

////分割线
//@property(nonatomic, strong)UIView  *sepratorLine1;
//@property(nonatomic, strong)UIView  *sepratorLine2;
//@property(nonatomic, strong)UIView  *sepratorLine3;
//@property(nonatomic, strong)UIView  *sepratorLine4;
@end

@implementation MatchLiveExponentailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        
        [self setupView];
    }
    return self;
}

- (void)setupView {
    
//    self.insets = kCustomViewDefaultInset;
    self.backgroundColor = UIColor.whiteColor;
    self.corners = UIRectCornerAllCorners;
    self.cornersRadii = 3.0;
    
    [self.contentView addSubview:self.timeLabel];
    [self.contentView addSubview:self.scoreLabel];
    [self.contentView addSubview:self.firstStartLabel];
    [self.contentView addSubview:self.secondStartLabel];
    [self.contentView addSubview:self.thirdStartLabel];
    [self.contentView addSubview:self.firstCurrentLabel];
    [self.contentView addSubview:self.secondCurrentLabel];
    [self.contentView addSubview:self.thirdCurrentLabel];
    self.views = @[self.timeLabel,self.scoreLabel,self.firstStartLabel,self.secondStartLabel,self.thirdStartLabel,self.firstCurrentLabel,self.secondCurrentLabel,self.thirdCurrentLabel];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.views mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:0 leadSpacing:0.0 tailSpacing:0.0];
    [self.views mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.centerY.equalTo(self.contentView);
    }];
}

- (void)setRow:(NSInteger)row {
    _row = row;
    self.contentView.backgroundColor = (row % 2)?UIColor.whiteColor:ColorDefaultLightGrayBackground;
}

- (void)configCellWithModel:(OddsListItem *)model isLastCell:(BOOL)isLastCell {
    self.timeLabel.text = model.matchTime;
    self.scoreLabel.text = [NSString stringWithFormat:@"%@-%@",@(model.hostScore),@(model.awayScore)];
    NSArray *startArr = [model.startOdds componentsSeparatedByString:@","];
    NSArray *currentArr = [model.instantOdds componentsSeparatedByString:@","];
    
    self.firstStartLabel.text = startArr[0];
    self.secondStartLabel.text = startArr[1];
    self.thirdStartLabel.text = startArr[2];
    self.firstCurrentLabel.text = currentArr[0];
    self.secondCurrentLabel.text = currentArr[1];
    self.thirdCurrentLabel.text = currentArr[2];
    //color
    UIColor *equalColor = ColorMainNormalBlack;
    UIColor *hightColor = RGBCOLOR(240, 72, 68);
    UIColor *lowColor = ColorAppGreen;
    
    if ([self.timeLabel.text isEqualToString:@"未"]) {
        self.timeLabel.textColor = hightColor;
    } else if ([self.timeLabel.text isEqualToString:@"中"]) {
        self.timeLabel.textColor = RGBCOLOR(0, 145, 255);
    } else {
        self.timeLabel.textColor = equalColor;
    }
    
    NSArray<NSString *> *changeArr = [model.startOddsChangeStatus componentsSeparatedByString:@","];
    self.firstCurrentLabel.textColor = changeArr[0].integerValue == 0 ? equalColor : changeArr[0].integerValue == 1 ? hightColor : lowColor;
    self.secondCurrentLabel.textColor = changeArr[1].integerValue == 0 ? equalColor : changeArr[1].integerValue == 1 ? hightColor : lowColor;
    self.thirdCurrentLabel.textColor = changeArr[2].integerValue == 0 ? equalColor : changeArr[2].integerValue == 1 ? hightColor : lowColor;
    
    //闪烁动画
    UIColor *equalColorbg = [UIColor whiteColor];
    UIColor *hightColorbg = RGBACOLOR(240, 72, 68, 0.33);
    UIColor *lowColorbg = RGBACOLOR(21, 21, 26, 0.33);
    
    if (!isLastCell || QM_IS_STR_NIL(model.changeStatus) || [model.changeStatus isEqualToString:@"0,0,0"]) {
        return;
    }
    
    NSArray<NSString *> *currentChangeArr = [model.changeStatus componentsSeparatedByString:@","];
    
    self.firstCurrentLabel.backgroundColor = currentChangeArr[0].integerValue == 0 ? equalColorbg : currentChangeArr[0].integerValue == 1 ? hightColorbg : lowColorbg;
    self.secondCurrentLabel.backgroundColor = currentChangeArr[1].integerValue == 0 ? equalColorbg : currentChangeArr[1].integerValue == 1 ? hightColorbg : lowColorbg;
    self.thirdCurrentLabel.backgroundColor = currentChangeArr[2].integerValue == 0 ? equalColorbg : currentChangeArr[2].integerValue == 1 ? hightColorbg : lowColorbg;
    
    model.changeStatus = @"0,0,0"; //重置
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.firstCurrentLabel.backgroundColor = equalColorbg;
        self.secondCurrentLabel.backgroundColor = equalColorbg;
        self.thirdCurrentLabel.backgroundColor = equalColorbg;
    });
}

#pragma mark - lazy init
- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [UILabel new];
        _timeLabel.textColor = ColorMainNormalBlack;
        _timeLabel.font = GetFont(10);
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.numberOfLines = 0;
    }
    return _timeLabel;
}

- (UILabel *)scoreLabel {
    if (!_scoreLabel) {
        _scoreLabel = [UILabel new];
        _scoreLabel.textColor = ColorMainNormalBlack;
        _scoreLabel.font = GetFont(10);
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
        _scoreLabel.numberOfLines = 0;
    }
    return _scoreLabel;
}

- (UILabel *)firstStartLabel {
    if (!_firstStartLabel) {
        _firstStartLabel = [UILabel new];
        _firstStartLabel.textColor = ColorMainNormalBlack;
        _firstStartLabel.font = GetFont(10);
        _firstStartLabel.textAlignment = NSTextAlignmentCenter;
        
    }
    return _firstStartLabel;
}

- (UILabel *)secondStartLabel {
    if (!_secondStartLabel) {
        _secondStartLabel = [UILabel new];
        _secondStartLabel.textColor = ColorMainNormalBlack;
        _secondStartLabel.font = GetFont(10);
        _secondStartLabel.textAlignment = NSTextAlignmentCenter;
        _secondStartLabel.numberOfLines = 0;
        
    }
    return _secondStartLabel;
}

- (UILabel *)thirdStartLabel {
    if (!_thirdStartLabel) {
        _thirdStartLabel = [UILabel new];
        _thirdStartLabel.textColor = ColorMainNormalBlack;
        _thirdStartLabel.font = GetFont(10);
        _thirdStartLabel.textAlignment = NSTextAlignmentCenter;
        
    }
    return _thirdStartLabel;
}

- (UILabel *)firstCurrentLabel {
    if (!_firstCurrentLabel) {
        _firstCurrentLabel = [UILabel new];
        _firstCurrentLabel.textColor = ColorMainNormalBlack;
        _firstCurrentLabel.font = GetFont(10);
        _firstCurrentLabel.textAlignment = NSTextAlignmentCenter;
        
    }
    return _firstCurrentLabel;
}

- (UILabel *)secondCurrentLabel {
    if (!_secondCurrentLabel) {
        _secondCurrentLabel = [UILabel new];
        _secondCurrentLabel.textColor = ColorMainNormalBlack;
        _secondCurrentLabel.font = GetFont(10);
        _secondCurrentLabel.textAlignment = NSTextAlignmentCenter;
        _secondCurrentLabel.numberOfLines = 0;
        
    }
    return _secondCurrentLabel;
}

- (UILabel *)thirdCurrentLabel {
    if (!_thirdCurrentLabel) {
        _thirdCurrentLabel = [UILabel new];
        _thirdCurrentLabel.textColor = ColorMainNormalBlack;
        _thirdCurrentLabel.font = GetFont(10);
        _thirdCurrentLabel.textAlignment = NSTextAlignmentCenter;
        
    }
    return _thirdCurrentLabel;
}
@end
