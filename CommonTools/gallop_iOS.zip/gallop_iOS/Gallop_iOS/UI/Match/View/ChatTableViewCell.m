//
//  ChatTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/20.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ChatTableViewCell.h"
#import "ChatTCPMessageModel.h"

@interface ChatTableViewCell()

@property(nonatomic, strong) UIImageView *headImageView;
@property(nonatomic, strong) CYLabel *messageLabel;

@property(nonatomic, strong)ChatTCPMessageModel *model;

@end

@implementation ChatTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.backgroundColor = UIColor.clearColor;
        self.contentView.backgroundColor = self.backgroundColor;
        [self setupView];
    }
    return self;
}

- (void)setupView {
//    [self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.contentView).offset(15);
//        make.top.equalTo(self.contentView).offset(8);
//        make.size.mas_equalTo(CGSizeMake(18, 18));
//    }];
    [self.messageLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.headImageView.mas_right).offset(8);
        make.top.equalTo(self.headImageView);
        make.bottom.equalTo(self.contentView);
        make.right.equalTo(self.contentView).offset(-16);
    }];
}

- (void)configCellWithModel:(id)model {
//    [self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.userAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
    NSMutableAttributedString *str;
    if ([model isKindOfClass:[NSString class]]) {
        str = [[NSMutableAttributedString alloc] initWithString:model];
        
        [str addAttribute:NSForegroundColorAttributeName value:RGBCOLORV(0x999999) range:NSMakeRange(0, [model length])];
    }else {
        self.model = model;
        
        if ([self.model.content isEqualToString:@"加入聊天室"]) {
            //进入聊天室消息
            str = [[NSMutableAttributedString alloc] initWithString:[NSMutableString stringWithFormat:@"%@  %@",QM_IS_STR_NIL(self.model.userName)?@"" : self.model.userName,self.model.content]];
            [str addAttribute:NSForegroundColorAttributeName value:ColorAppRed range:NSMakeRange(self.model.userName.length + 1,self.model.content.length + 1)];
            
        } else {
            str = [[NSMutableAttributedString alloc] initWithString:[NSMutableString stringWithFormat:@"%@: %@",QM_IS_STR_NIL(self.model.userName)?@"" : self.model.userName,self.model.content]];
            
            if (self.model.userId == [App_Utility.currentUser.userId integerValue]) {
                [str addAttribute:NSForegroundColorAttributeName value:ColorAppRed range:NSMakeRange(0, self.model.userName.length + 1)];
            } else {
                [str addAttribute:NSForegroundColorAttributeName value:RGBCOLORV(0x999999) range:NSMakeRange(0, self.model.userName.length + 1)];
            }
        }
    }

    //设置行高
    NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
    style.alignment = NSTextAlignmentLeft;
    style.lineSpacing = 4;
    style.lineBreakMode = NSLineBreakByCharWrapping;
    [str addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, [str length])];

    self.messageLabel.attributedText = str;
}

#pragma mark - lazy init
- (UIImageView *)headImageView {
    if (!_headImageView) {
        _headImageView = [UIImageView new];
        _headImageView.layer.cornerRadius = 9;
        _headImageView.clipsToBounds = YES;
        [self.contentView addSubview:_headImageView];
    }
    return _headImageView;
}

- (CYLabel *)messageLabel {
    if (!_messageLabel) {
        _messageLabel = [CYLabel new];
        _messageLabel.font = GetFont(12);
        _messageLabel.textColor = ColorMainNormalBlack;
        _messageLabel.numberOfLines = 0;
        _messageLabel.edgeInsets = UIEdgeInsetsMake(5.0, 5.0, 0.0, 5.0);
        [self.contentView addSubview:_messageLabel];
    }
    return _messageLabel;
}

@end
