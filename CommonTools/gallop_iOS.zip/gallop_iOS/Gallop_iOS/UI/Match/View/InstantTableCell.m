//
//  InstantTableCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/7/12.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "InstantTableCell.h"

#import "MatchInstantListModel.h"

@interface InstantTableCell ()

/// 顶部比赛状态
@property (weak, nonatomic) IBOutlet UIStackView *status_stack;
@property (weak, nonatomic) IBOutlet UILabel *statusLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondLabel;

/// 顶部联赛名称/比赛时间/比赛视频类型/专家标识
@property (weak, nonatomic) IBOutlet UIStackView *league_stack;
@property (weak, nonatomic) IBOutlet UILabel *leagueLabel;
@property (weak, nonatomic) IBOutlet UILabel *matchTimeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *videoTypeLabel;
/// 专家标识
@property (weak, nonatomic) IBOutlet UIImageView *expertMark;

/// 顶部handicap/场次/收藏
@property (weak, nonatomic) IBOutlet UIStackView *collection_stack;
@property (weak, nonatomic) IBOutlet UILabel *handicapLabel;
@property (weak, nonatomic) IBOutlet UILabel *raceIdentLabel;
@property (weak, nonatomic) IBOutlet CYButton *collectionBtn;

/// 分数stack 主队分数/间隔/客队分数
@property (weak, nonatomic) IBOutlet UIStackView *score_stack;
@property (weak, nonatomic) IBOutlet UILabel *hostScoreLabel;
@property (weak, nonatomic) IBOutlet UILabel *guestScoreLabel;
@property (weak, nonatomic) IBOutlet UILabel *scoreSpaceLabel;

/// 主队信息 名称/排名/黄牌数/红牌数
@property (weak, nonatomic) IBOutlet UIStackView *hostName_stack;
@property (weak, nonatomic) IBOutlet UILabel *hostNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *hostRankLabel;
@property (weak, nonatomic) IBOutlet UILabel *hostRedCardNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *hostYellowCardNumLabel;

@property (weak, nonatomic) IBOutlet UILabel *teamSpaceLabel;

/// 客队信息 名称/排名/黄牌数/红牌数
@property (weak, nonatomic) IBOutlet UIStackView *guestName_stack;
@property (weak, nonatomic) IBOutlet UILabel *guestNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *guestRankLabel;
@property (weak, nonatomic) IBOutlet UILabel *guestRedCardNumLabel;
@property (weak, nonatomic) IBOutlet UILabel *guestYellowCardNumLabel;

/// 比赛位置
@property (weak, nonatomic) IBOutlet UILabel *locationLabel;

/// 比赛信息 半场比分/角球对比
@property (weak, nonatomic) IBOutlet UIStackView *half_stack;
@property (weak, nonatomic) IBOutlet UILabel *halfScoreLabel;
@property (weak, nonatomic) IBOutlet UIStackView *corner_stack;
@property (weak, nonatomic) IBOutlet UILabel *cornerContrastLabel;

@property (assign, nonatomic) MatchCellType type;
@property (strong, nonatomic) InstantMatcth *model;

@end

@implementation InstantTableCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _secondLabel.hidden = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)hostOrGuestGoal:(BOOL)isHost {
    
}

- (void)configCellWithModel:(id)model cellType:(MatchCellType)type {
    if (![model isKindOfClass:[InstantMatcth class]]) {
        return;
    }
    self.type = type;
    self.model = model;
}

- (void)setModel:(InstantMatcth *)model {
    _model = model;
    _leagueLabel.text = _model.league;
    _leagueLabel.textColor = [UIColor colorWithHexString:_model.leagueColor];
    
    _matchTimeLabel.text = [CMMUtility timeConvertWithTimeStamp:@(_model.startTime).stringValue andTimeFormat:@"HH:mm"];
    
    BOOL hiddenSource = NO;
    UIColor *statusColor = ColorMainNormalBlack;
    NSString *statusText = [NSString stringWithFormat:@"%@'",@(_model.elapsedTime)];
    if (MatchCellTypeInstant == _type ||
        MatchCellTypeFouces == _type) {
        statusText = @(_model.elapsedTime).stringValue;
    }
    switch (_model.status) {
        case 0:/// 未开始
        {
            hiddenSource = YES;
            statusText = @"未";
            break;
        }
        case 1:/// 上半场
        {
            statusColor = ColorMatchHost;
            if (_model.elapsedTime > 45) {
                statusText = @"45+";
            }
            
            break;
        }
        case 2:/// 中场
        {
            statusText = @"中";
            break;
        }
        case 3: {/// 下半场
            statusColor = ColorMatchHost;
            if (_model.elapsedTime > 90) {
                statusText = @"90+";
            }
            break;
        }
        case 4: {
            statusColor = ColorMatchHost;
            if (_model.elapsedTime > 120) {
                statusText = @"120+";
            }
            break;
        }
        case 5: {
            statusText = @"点球";
            break;
        }
        case 6: {
            statusText = @"完";
            statusColor = RGBCOLORV(0x999999);
            break;
        }
            
        default:
            break;
    }
    _statusLabel.text = statusText;
    _statusLabel.textColor = statusColor;
    _secondLabel.textColor = statusColor;
    
    _score_stack.hidden = hiddenSource;
    _teamSpaceLabel.hidden = !hiddenSource;
    
    //仅即时列表秒点闪烁
    BOOL needShowSecond = ((_type == MatchCellTypeInstant ||
                            _type == MatchCellTypeFouces) &&
                           ([_statusLabel.text isEqualToString:@(_model.elapsedTime).stringValue] ||
                            [_statusLabel.text containsString:@"+"]));
    if (needShowSecond) {
        _secondLabel.hidden = NO;
        [_secondLabel.layer addAnimation:[self opacityForever_Animation:0.5] forKey:@"opacityForever"];
    } else {
        _secondLabel.hidden = YES;
    }
    //竞彩标识
    _raceIdentLabel.hidden = ![CommonUtils isEqualToNonNull:_model.lotteryNo];
    _raceIdentLabel.text = [CommonUtils isEqualToNonNull:_model.lotteryNo replace:@""];
    // 盘口
    _handicapLabel.hidden = ![CommonUtils isEqualToNonNull:_model.handicap];
    _handicapLabel.text = _model.handicap;
    // 关注
    if (MatchCellTypeResult == _type) {
        _collectionBtn.hidden = YES;
    }else {
        _collectionBtn.hidden = NO;
        _collectionBtn.selected = _model.isFollowed ? YES:NO;
    }
    // 主客队/排名
    _hostNameLabel.text = _model.hostName.length > 6 ? [_model.hostName substringToIndex:6] : _model.hostName;
    _guestNameLabel.text = _model.guestName.length > 6 ? [_model.guestName substringToIndex:6] : _model.guestName;
    _hostRankLabel.text = [CommonUtils isEqualToNonNull:_model.instantHostRank replace:@""];
    _guestRankLabel.text = [CommonUtils isEqualToNonNull:_model.instantGuestRank replace:@""];
    
    //红黄牌
    _hostRedCardNumLabel.hidden = !_model.hostRedCard;
    _hostRedCardNumLabel.text = @(_model.hostRedCard).stringValue;
    
    _hostYellowCardNumLabel.hidden = !_model.hostYellowCard;
    _hostYellowCardNumLabel.text = @(_model.hostYellowCard).stringValue;
    
    _guestRedCardNumLabel.hidden = !_model.guestRedCard;
    _guestRedCardNumLabel.text = @(_model.guestRedCard).stringValue;
    
    _guestYellowCardNumLabel.hidden = !_model.guestYellowCard;
    _guestYellowCardNumLabel.text = @(_model.guestYellowCard).stringValue;
    
    // 半场信息
    _halfScoreLabel.text = @"";
    NSMutableString *halfStr = [NSMutableString string];
    if (_model.halfHostScore >= 0 && _model.status >= 3 && _model.status <= 6) {
        [halfStr appendFormat:@"半(%@:%@)  ",@(_model.halfHostScore),@(_model.halfGuestScore)];
    }
    _halfScoreLabel.text = halfStr.length > 0 ? halfStr : @"";
    _halfScoreLabel.hidden  = halfStr.length > 0 ? NO : YES;
    
    // 角球
    if (_model.status != 0 && (_model.hostCorner != 0 || _model.guestCorner != 0)) {
        _corner_stack.hidden = NO;
        _cornerContrastLabel.text = [NSString stringWithFormat:@"%@:%@",@(_model.hostCorner), @(_model.guestCorner)];
    }else {
        _corner_stack.hidden = YES;
    }
    
    _expertMark.hidden = _model.hasExpert == 1 ? NO : YES;
}


- (IBAction)clickToCollection:(CYButton *)sender {
    sender.selected = !sender.selected;
}

#pragma mark - 秒点闪烁动画
- (CABasicAnimation *)opacityForever_Animation:(float)time
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation.fromValue = [NSNumber numberWithFloat:1.0f];
    animation.toValue = [NSNumber numberWithFloat:0.0f];
    animation.autoreverses = YES;
    animation.duration = time;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    return animation;
}



@end
