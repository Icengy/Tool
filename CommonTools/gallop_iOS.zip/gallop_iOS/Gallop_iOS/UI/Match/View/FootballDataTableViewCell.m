//
//  FootballDataTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "FootballDataTableViewCell.h"

#import "TYTabButtonPagerController.h"
#import "IntelligenceDataClassifyChildViewController.h"

#import "LotteryData.h"
#import "MatchIntelligenceModel.h"

//篮球情报
#import "BasketIntelligenceModel.h"

@interface FootballDataTableViewCell()<TYTabPagerControllerDelegate, TYPagerControllerDataSource>

@property (nonatomic, strong) TYTabButtonPagerController *pageController;
@property (nonatomic, strong) NSMutableArray <NSString *> *pageTitles;
@property (nonatomic, strong) NSMutableArray <IntelligenceDataClassifyChildViewController *> *pageChilds;

@property (nonatomic,strong) LotteryDataList *footballmodel;
@property (nonatomic,strong) MatchIntelligencePreModel *preModel;

@property (nonatomic,strong) BasketIntelligenceModel *basketModel;

@end

@implementation FootballDataTableViewCell

- (UIViewController *)controller {
    return self.pageController;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    
    _pageTitles = @[].mutableCopy;
    _pageChilds = @[].mutableCopy;
    
    ///
    [self handlePageData];
    
    [self.contentView addSubview:self.pageController.view];
    @weakify(self);
    self.pageController.didScrollToTabPageIndexHandle = ^(NSInteger index) {
        @strongify(self);
        [self handleHostMark:index];
    };
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.pageController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView);
    }];
}

- (void)setModel:(id)model {
    _model = model;
    
    /// 足彩数据
    if ([model isKindOfClass:[LotteryDataList class]]) {
        self.footballmodel = model;
    }
    /// 赛前情报
    if ([model isKindOfClass:[MatchIntelligencePreModel class]]) {
        self.preModel = model;
    }
    /// 篮球数据
    if ([model isKindOfClass:[BasketIntelligenceModel class]]) {
        self.basketModel = model;
    }
    
    [self.pageController reloadData];
    [_pageChilds enumerateObjectsUsingBlock:^(IntelligenceDataClassifyChildViewController * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj reloadData];
    }];
}

- (void)setFootballmodel:(LotteryDataList *)footballmodel {
    _footballmodel = footballmodel;
    
    self.pageController.defaultIndex = _footballmodel.index;
    [self handlePageData];
}

- (void)setPreModel:(MatchIntelligencePreModel *)preModel {
    _preModel = preModel;
    
    self.pageController.defaultIndex = _preModel.index;
    [self handlePrePageData];
}

- (void)setBasketModel:(BasketIntelligenceModel *)basketModel {
    _basketModel = basketModel;
    
    self.pageController.defaultIndex = _basketModel.matchIntel.analysis_index;
    [self handleBasketPageData];
}

#pragma mark - TYPagerControllerDataSource
- (NSInteger)numberOfControllersInPagerController {
    return _pageTitles.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return _pageTitles[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return _pageChilds[index];
}

#pragma mark -
- (void)handlePageData {
    if (_pageTitles.count) [_pageTitles removeAllObjects];
    _pageTitles = @[[CommonUtils isEqualToNonNull:self.footballmodel.guestName replace:@"客队"],
                    [CommonUtils isEqualToNonNull:self.footballmodel.hostName replace:@"主队"]].mutableCopy;
    if (_pageChilds.count) [_pageChilds removeAllObjects];
    
    [_pageTitles enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        IntelligenceDataClassifyChildViewController *childVC = [[IntelligenceDataClassifyChildViewController alloc] init];
        childVC.isHost = !idx;
        [childVC configCellWithModel:idx?self.footballmodel.lotters_guest:self.footballmodel.lotters_host withType:1];
        [_pageChilds addObject:childVC];
    }];
}

- (void)handlePrePageData {
    if (_pageTitles.count) [_pageTitles removeAllObjects];
    _pageTitles = @[[CommonUtils isEqualToNonNull:self.preModel.guestName replace:@"客队"],
                    [CommonUtils isEqualToNonNull:self.preModel.hostName replace:@"主队"]].mutableCopy;
    if (_pageChilds.count) [_pageChilds removeAllObjects];
    
    [_pageTitles enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        IntelligenceDataClassifyChildViewController *childVC = [[IntelligenceDataClassifyChildViewController alloc] init];
        childVC.isHost = !idx;
        [childVC configCellWithModel:idx?self.preModel.guestPreInfo:self.preModel.hostPreInfo withType:0];
        [_pageChilds addObject:childVC];
    }];
}

- (void)handleBasketPageData {
    if (_pageTitles.count) [_pageTitles removeAllObjects];
    _pageTitles = @[[CommonUtils isEqualToNonNull:self.basketModel.awayName replace:@"客队"],
                    [CommonUtils isEqualToNonNull:self.basketModel.homeName replace:@"主队"]].mutableCopy;
    if (_pageChilds.count) [_pageChilds removeAllObjects];
    
    [_pageTitles enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        IntelligenceDataClassifyChildViewController *childVC = [[IntelligenceDataClassifyChildViewController alloc] init];
        childVC.isHost = !idx;
        [childVC configCellWithModel:idx ? self.basketModel.matchIntel.hostLetters : self.basketModel.matchIntel.guestLetters withType:2];
        [_pageChilds addObject:childVC];
    }];
}

- (void)handleHostMark:(NSInteger)index {
    if ([self.model isKindOfClass:[LotteryDataList class]]) {
        LotteryDataList *baseModel = (LotteryDataList *)self.model;
        if (!baseModel || baseModel.index == index) {
            return;
        }
        baseModel.index = index;
        self.model = baseModel;
    }
    if ([self.model isKindOfClass:[MatchIntelligencePreModel class]]) {
        MatchIntelligencePreModel *baseModel = (MatchIntelligencePreModel *)self.model;
        if (!baseModel || baseModel.index == index) {
            return;
        }
        baseModel.index = index;
        self.model = baseModel;
    }
    if ([self.model isKindOfClass:[BasketIntelligenceModel class]]) {
        BasketIntelligenceModel *baseModel = (BasketIntelligenceModel *)self.model;
        if (!baseModel || baseModel.matchIntel.analysis_index == index) {
            return;
        }
        baseModel.matchIntel.analysis_index = index;
        self.model = baseModel;
    }
    
    if ([self.delegate respondsToSelector:@selector(childTableCell:didScrollToHostPageBlock:)]) {
        [self.delegate childTableCell:self didScrollToHostPageBlock:index];
    }
}

#pragma mark -
- (TYTabButtonPagerController *)pageController {
    if (!_pageController) {
        _pageController = [[TYTabButtonPagerController alloc] init];
        _pageController.dataSource = self;
        _pageController.barStyle = TYPagerBarStyleProgressView;
        _pageController.contentTopEdging = 40.0;
        _pageController.collectionLayoutEdging = 15.0;
        _pageController.cellSpacing = 15.0;
        _pageController.progressBottomEdging = 3.0;
        _pageController.progressHeight = 3.0;
        _pageController.contentScrollEnabled = NO;
        
        _pageController.normalTextFont = [UIFont addPingFangSCRegular:12];
        _pageController.selectedTextFont = [UIFont addPingFangSCMedium:14];
        _pageController.progressColor = ColorMainAppRed;
        _pageController.normalTextColor = ColorMainNormalBlack;
        _pageController.selectedTextColor = ColorMainAppRed;
        _pageController.customShadowColor = UIColor.clearColor;
        
    }return _pageController;
}

@end
