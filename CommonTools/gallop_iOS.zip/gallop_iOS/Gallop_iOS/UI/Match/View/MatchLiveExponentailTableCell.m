//
//  MatchLiveExponentailTableCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/7/23.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchLiveExponentailTableCell.h"

#import "MatchLiveExponentailChildViewController.h"

@interface MatchLiveExponentailTableCell ()

@property (nonatomic, strong) MatchLiveExponentailChildViewController *childViewController;

@end

@implementation MatchLiveExponentailTableCell

- (ESChildViewController *)controller {
    return self.childViewController;
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self.contentView addSubview:self.childViewController.view];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.childViewController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.contentView);
    }];
}

- (void)configCellWithModel:(id)model {
    
    self.childViewController.datas = model;
}

#pragma mark - lazy init
- (MatchLiveExponentailChildViewController *)childViewController {
    if (!_childViewController) {
        _childViewController = [[MatchLiveExponentailChildViewController alloc] init];
    }return _childViewController;
}

@end
