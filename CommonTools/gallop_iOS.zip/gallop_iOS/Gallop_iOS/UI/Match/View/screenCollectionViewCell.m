//
//  screenCollectionViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "screenCollectionViewCell.h"

@interface screenCollectionViewCell ()
@property(nonatomic, strong)LeaguesModel *model;
@property(nonatomic, strong)BasketLeaguesModel *basketModel;
@property(nonatomic, strong)UIButton *leaguesBtn;
@property(nonatomic, strong)UIImageView *cornerImageView;
@end

@implementation screenCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self.contentView addSubview:self.leaguesBtn];
        [self.contentView addSubview:self.cornerImageView];
    }
    return self;
}

- (void)configCellWithModel:(id)model {
	if ([model isKindOfClass:[BasketLeaguesModel class]]) {
		self.basketModel = model;
		[self.leaguesBtn setTitle:[NSString stringWithFormat:@"%@ (%ld)",self.basketModel.shortNameZh,self.basketModel.matchCount] forState:UIControlStateNormal];
		self.cornerImageView.hidden = !self.basketModel.selected;
		self.leaguesBtn.selected = self.basketModel.selected;
	} else {
		self.model = model;
		[self.leaguesBtn setTitle:[NSString stringWithFormat:@"%@ (%@)",self.model.leagueName,self.model.number] forState:UIControlStateNormal];
		self.cornerImageView.hidden = !self.model.selected;
		self.leaguesBtn.selected = self.model.selected;
	}
}

#pragma mark - action
- (void)leaguesBtnClick:(UIButton *)button {
	if (self.basketModel) {
		self.cornerImageView.hidden = !self.cornerImageView.hidden;
		button.selected = !button.selected;
		if ([self.cellDelegate respondsToSelector:@selector(leaguesBtnClick:)]) {
			[self.cellDelegate leaguesBtnClick:self.basketModel];
		}
	} else {
		self.cornerImageView.hidden = !self.cornerImageView.hidden;
		button.selected = !button.selected;
		if ([self.cellDelegate respondsToSelector:@selector(leaguesBtnClick:)]) {
			[self.cellDelegate leaguesBtnClick:self.model];
		}
	}
}

#pragma mark - lazy init
- (UIButton *)leaguesBtn {
    if (!_leaguesBtn) {
        _leaguesBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, (SCREEN_WIDTH - 50) / 3, 33)];
        [_leaguesBtn setTitleColor:RGBCOLOR(168, 168, 168) forState:UIControlStateNormal];
        [_leaguesBtn setTitleColor:ColorSubTitle forState:UIControlStateSelected];
        _leaguesBtn.titleLabel.font = GetFont(12);
        [_leaguesBtn setBackgroundImage:[UIImage imageWithColor:[UIColor whiteColor]] forState:UIControlStateNormal];
        [_leaguesBtn addTarget:self action:@selector(leaguesBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _leaguesBtn.layer.cornerRadius = 6;
        _leaguesBtn.clipsToBounds = YES;
    }
    return _leaguesBtn;
}

- (UIImageView *)cornerImageView {
    if (!_cornerImageView) {
        _cornerImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 12, 12)];
        _cornerImageView.image = GetImage(@"match_screen_seletedmark_icon");
        _cornerImageView.userInteractionEnabled = NO;
        _cornerImageView.hidden = YES;
    }
    return _cornerImageView;
}

- (void)setSelected:(BOOL)selected {
    [super setSelected:selected];
}
@end
