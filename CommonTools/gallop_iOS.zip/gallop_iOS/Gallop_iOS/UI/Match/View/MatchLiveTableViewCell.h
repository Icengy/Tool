//
//  MatchLiveTableViewCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/25.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MatchLiveTableViewCell : UITableViewCell
- (void)configCellWithModel:(id)model;
@end

NS_ASSUME_NONNULL_END
