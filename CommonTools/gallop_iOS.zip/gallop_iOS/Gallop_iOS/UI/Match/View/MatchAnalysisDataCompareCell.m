//
//  MatchAnalysisDataCompareCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/9/6.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchAnalysisDataCompareCell.h"

@interface MatchAnalysisDataCompareCell()
@property(nonatomic, strong)UILabel *teamLabel;
@property(nonatomic, strong)UILabel *firstLabel;
@property(nonatomic, strong)UILabel *secondLabel;
@property(nonatomic, strong)UILabel *thirdLabel;
@property(nonatomic, strong)UILabel *fourLabel;
@property(nonatomic, strong)UILabel *fiveLabel;
@property(nonatomic, strong)UILabel *sixLabel;
@property(nonatomic, strong)UILabel *sevenLabel;
@property (nonatomic,strong)NSMutableArray*labelArr;
@property(nonatomic, strong)UILabel *noneDataLabel;
@end

@implementation MatchAnalysisDataCompareCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

//sectionHeadView


- (void)setupView {
    [self.teamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(80, 30));
        make.centerY.equalTo(self.contentView);
    }];
    [@[self.firstLabel,self.secondLabel,self.thirdLabel,self.fourLabel,self.fiveLabel,self.sixLabel,self.sevenLabel] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:(SCREEN_WIDTH - 50) / 7 leadSpacing:80 tailSpacing:0];
    [@[self.firstLabel,self.secondLabel,self.thirdLabel,self.fourLabel,self.fiveLabel,self.sixLabel,self.sevenLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
        make.height.mas_equalTo(30);
    }];
    [self.noneDataLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.bottom.equalTo(self.contentView);
    }];
     self.labelArr = [NSMutableArray arrayWithCapacity:0];
    [self.labelArr addObject:self.firstLabel];
    [self.labelArr addObject:self.secondLabel];
    [self.labelArr addObject:self.thirdLabel];
    [self.labelArr addObject:self.fourLabel];
    [self.labelArr addObject:self.fiveLabel];
    [self.labelArr addObject:self.sixLabel];
    [self.labelArr addObject:self.sevenLabel];
    
    
}

- (void)configCellWithModel:(id)model {
//    self.teamLabel.text = model.cname;
//    self.firstLabel.text = model.start[0];
//    self.secondLabel.text = model.start[1];
//    self.thirdLabel.text = model.start[2];
//    self.fourLabel.text = model.instant[0];
//    self.fiveLabel.text = model.instant[1];
//    self.sixLabel.text = model.instant[2];
}

#pragma mark - lazy init
- (UILabel *)teamLabel {
    if (!_teamLabel) {
        _teamLabel = [UILabel new];
        _teamLabel.textColor = RGBCOLOR(58, 58, 58);
        _teamLabel.font = GetFont(12);
        _teamLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_teamLabel];
    }
    return _teamLabel;
}

- (UILabel *)firstLabel {
    if (!_firstLabel) {
        _firstLabel = [UILabel new];
        _firstLabel.textColor = RGBCOLOR(58, 58, 58);
        _firstLabel.font = GetFont(12);
        _firstLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_firstLabel];
    }
    return _firstLabel;
}

- (UILabel *)secondLabel {
    if (!_secondLabel) {
        _secondLabel = [UILabel new];
        _secondLabel.textColor = RGBCOLOR(58, 58, 58);
        _secondLabel.font = GetFont(12);
        _secondLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_secondLabel];
    }
    return _secondLabel;
}
- (UILabel *)noneDataLabel {
    if (!_noneDataLabel) {
        _noneDataLabel = [UILabel new];
        _noneDataLabel.text = @"暂无内容";
        _noneDataLabel.textColor = RGBCOLOR(168, 168, 168);
        _noneDataLabel.textAlignment = NSTextAlignmentCenter;
        _noneDataLabel.backgroundColor = [UIColor whiteColor];
        _noneDataLabel.font = GetFont(12);
        _noneDataLabel.hidden = YES;
        [self.contentView addSubview:_noneDataLabel];
    }
    return _noneDataLabel;
}
- (UILabel *)thirdLabel {
    if (!_thirdLabel) {
        _thirdLabel = [UILabel new];
        _thirdLabel.textColor = RGBCOLOR(58, 58, 58);
        _thirdLabel.font = GetFont(12);
        _thirdLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_thirdLabel];
    }
    return _thirdLabel;
}

- (UILabel *)fourLabel {
    if (!_fourLabel) {
        _fourLabel = [UILabel new];
        _fourLabel.textColor = RGBCOLOR(58, 58, 58);
        _fourLabel.font = GetFont(12);
        _fourLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_fourLabel];
    }
    return _fourLabel;
}

- (UILabel *)fiveLabel {
    if (!_fiveLabel) {
        _fiveLabel = [UILabel new];
        _fiveLabel.textColor = RGBCOLOR(58, 58, 58);
        _fiveLabel.font = GetFont(12);
        _fiveLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_fiveLabel];
    }
    return _fiveLabel;
}

- (UILabel *)sixLabel {
    if (!_sixLabel) {
        _sixLabel = [UILabel new];
        _sixLabel.textColor = RGBCOLOR(58, 58, 58);
        _sixLabel.font = GetFont(12);
        _sixLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_sixLabel];
    }
    return _sixLabel;
}

- (UILabel *)sevenLabel {
    if (!_sevenLabel) {
        _sevenLabel = [[UILabel alloc] init];
        _sevenLabel.textColor = RGBCOLOR(58, 58, 58);
        _sevenLabel.font = GetFont(12);
        _sevenLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_sevenLabel];
    }
    return _sevenLabel;
}
-(void)setName:(NSString *)name
{
    _name = name;
    dispatch_main_async_safe(^{
        self.teamLabel.text = name;
    });
}
-(void)setArr:(NSArray *)arr
{
    _arr = arr;
    if (!QM_IS_ARRAY_NIL(arr)) {
        
		dispatch_main_async_safe((^{
			self.noneDataLabel.hidden = YES;
			for (int i = 0; i<7; i++) {
				
				NSString*text = arr[i];
				
				switch (i) {
					case 0:
					{
					self.firstLabel.text = text;
					}
						break;
					case 1:
					{
					self.secondLabel.text = text;
					}
						break;
					case 2:
					{
					self.thirdLabel.text = text;
					}
						break;
					case 3:
					{
					self.fourLabel.text = text;
					}
						break;
					case 4:
					{
					self.fiveLabel.text = [NSString stringWithFormat:@"%@%%",text];
					}
						break;
					case 5:
					{
					self.sixLabel.text = [NSString stringWithFormat:@"%@%%",text];
					}
						break;
					case 6:
					{
					self.sevenLabel.text = [NSString stringWithFormat:@"%@%%",text];
					
					}
						break;
						
					default:
						break;
				}
			}
		}));
    }else{
        dispatch_main_async_safe(^{
            self.noneDataLabel.hidden = NO;
        });
    }
    
}
@end
