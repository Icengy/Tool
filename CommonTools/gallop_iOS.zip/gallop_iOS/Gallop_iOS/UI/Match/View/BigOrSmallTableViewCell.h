//
//  BigOrSmallTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/10/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

@class BigAndSmallData;
NS_ASSUME_NONNULL_BEGIN

@interface BigOrSmallTableViewCell : ESChildTableViewCell

@property (nonatomic,strong) BigAndSmallData *model;

@end

NS_ASSUME_NONNULL_END
