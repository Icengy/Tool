//
//  MatchImportantEventTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/9/4.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchImportantEventTableViewCell.h"
#import "LiveTCPMessageModel.h"

@interface MatchImportantEventTableViewCell ()
@property(nonatomic, strong)UIView      *typeBgView;
@property(nonatomic, strong)UIView *toplineView;
@property(nonatomic, strong)UIView *bottomlineView;
@property(nonatomic, strong)UILabel *timeLabel;
@property(nonatomic, strong)UIImageView *typeImageView;
@property(nonatomic, strong)UILabel *leftLabel;
@property(nonatomic, strong)UIImageView *leftTypeImageView;
@property(nonatomic, strong)UIImageView *leftTopImageView;
@property(nonatomic, strong)UIImageView *leftBottomImageView;
@property(nonatomic, strong)UILabel *rightLabel;
@property(nonatomic, strong)UIImageView *rightTypeImageView;
@property(nonatomic, strong)UIImageView *rightTopImageView;
@property(nonatomic, strong)UIImageView *rightBottomImageView;
@end

@implementation MatchImportantEventTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
//    self.backgroundColor =UIColor.whiteColor;
//    self.contentView.backgroundColor = [UIColor clearColor];
    
    [self.toplineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(0.5, 15));
    }];
    [self.typeBgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.toplineView.mas_bottom).offset(1.5);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.typeBgView);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [self.typeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.typeBgView);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(22, 22));
    }];
    [self.bottomlineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.typeBgView.mas_bottom).offset(1.5);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(0.5, 15));
        make.bottom.equalTo(self.contentView);
    }];
    [self.leftTypeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.typeBgView);
        make.right.equalTo(self.typeBgView.mas_left).offset(-10);
		make.size.mas_equalTo(CGSizeMake(18, 18));
    }];
	[self.leftTopImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.leftLabel).offset(-20);
		make.size.mas_equalTo(CGSizeMake(18, 18));
		make.right.equalTo(self.typeBgView.mas_left).offset(-10);
	}];
	[self.leftBottomImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.leftLabel);
		make.size.mas_equalTo(CGSizeMake(18, 18));
		make.right.equalTo(self.typeBgView.mas_left).offset(-10);
	}];
    [self.leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.typeBgView);
        make.right.equalTo(self.leftTypeImageView.mas_left).offset(-10);
        make.left.greaterThanOrEqualTo(self.contentView);
    }];
    [self.rightTypeImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.leftTypeImageView);
        make.left.equalTo(self.typeBgView.mas_right).offset(10);
		make.size.mas_equalTo(CGSizeMake(18, 18));
    }];
	[self.rightTopImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.typeBgView.mas_right).offset(10);
		make.bottom.equalTo(self.rightLabel).offset(-20);
		make.size.mas_equalTo(CGSizeMake(18, 18));
	}];
	[self.rightBottomImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.typeBgView.mas_right).offset(10);
		make.bottom.equalTo(self.rightLabel);
		make.size.mas_equalTo(CGSizeMake(18, 18));
	}];
    [self.rightLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.leftTypeImageView);
        make.left.equalTo(self.rightTypeImageView.mas_right).offset(10);
		make.right.lessThanOrEqualTo(self.contentView);
    }];
}

- (void)prepareForReuse {
    [super prepareForReuse];
    //reset
    
    self.timeLabel.text = @"";
    self.leftLabel.textColor = ColorMainNormalBlack;
    self.rightLabel.textColor = ColorMainNormalBlack;
    self.leftLabel.text = @"";
    self.rightLabel.text = @"";
    self.typeImageView.hidden = YES;
    self.leftTypeImageView.hidden = YES;
    self.rightTypeImageView.hidden = YES;
	self.leftTopImageView.hidden = YES;
	self.leftBottomImageView.hidden = YES;
	self.rightTopImageView.hidden = YES;
	self.rightBottomImageView.hidden = YES;
    self.typeImageView.image = nil;
    self.leftTypeImageView.image = nil;
    self.rightTypeImageView.image = nil;
    self.toplineView.hidden = NO;
    self.bottomlineView.hidden = NO;
}

- (void)configCellWithModel:(LiveTCPImportantEventModel *)model isLastCell:(BOOL)isLastCell{
    //事件时间
    if (model.matchTime > 0) {
        self.timeLabel.text = [NSString stringWithFormat:@"%@'",@(model.matchTime)];
    } else {
        self.timeLabel.text = @"";
    }
    
    //事件
    switch (model.eventType) {
        case 1: {
            NSString *str = [NSString stringWithFormat:@"%@:%@",@(model.hostScore),@(model.guestScore)];
			str = [str stringByAppendingString:[NSString stringWithFormat:@"\n%@",model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName]];
            //去除首尾换行
            str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSUInteger length = str.length;
            if (!QM_IS_STR_NIL(model.helperName)) {
                str = [str stringByAppendingString:[NSString stringWithFormat:@"\n%@",model.helperName.length > 8 ?  [model.helperName substringToIndex:8] : model.helperName]];
            }
            NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:str];
            [attStr addAttribute:NSForegroundColorAttributeName value:ColorAppBlack range:NSMakeRange(0, length)];
            if (attStr.length > length) {
                [attStr addAttribute:NSForegroundColorAttributeName value:ColorMainNormalBlack range:NSMakeRange(length, attStr.length - length)];
            }
            //行距
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
            if ([str containsString:@"\n"]) {
                [paragraphStyle setLineSpacing:5];
            }
            if (model.hostGuest == 1) {
                [paragraphStyle setAlignment:NSTextAlignmentRight];
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.leftLabel.attributedText = attStr;
            } else {
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.rightLabel.attributedText = attStr;
            }
        }
            break;
        case 3: {
            if (model.hostGuest == 1) {
                self.leftLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            } else {
                self.rightLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            }
        }
            break;
        case 4: {
            if (model.hostGuest == 1) {
                self.leftLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            } else {
                self.rightLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            }
        }
            break;
        case 5: {
            self.leftLabel.text = [NSString stringWithFormat:@"%@:%@",@(model.hostScore),@(model.guestScore)];
            self.leftLabel.textColor = ColorAppBlack;
        }
            break;
        case 6: {
            self.leftLabel.text = [NSString stringWithFormat:@"%@:%@",@(model.hostScore),@(model.guestScore)];
            self.leftLabel.textColor = ColorAppBlack;
        }
            break;
        case 7: {
            if (model.hostGuest == 1) {
                self.leftLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            } else {
                self.rightLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            }
        }
            break;
        case 8: {
            NSString *str;
            if (model.hostScore >= 0) {
                str= [NSString stringWithFormat:@"%@:%@",@(model.hostScore),@(model.guestScore)];
            } else {
                str = @"";
            }
            str = [str stringByAppendingString:[NSString stringWithFormat:@"\n%@",model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName]];
            //去除首尾换行
            str = [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSUInteger length = str.length;
            if (!QM_IS_STR_NIL(model.helperName)) {
                str = [str stringByAppendingString:[NSString stringWithFormat:@"\n%@",model.helperName.length > 8 ?  [model.helperName substringToIndex:8] : model.helperName]];
            }
            NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:str];
            [attStr addAttribute:NSForegroundColorAttributeName value:ColorAppBlack range:NSMakeRange(0, length)];
            if (attStr.length > length) {
                [attStr addAttribute:NSForegroundColorAttributeName value:ColorMainNormalBlack range:NSMakeRange(length, attStr.length - length)];
            }
            //行距
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
            if ([str containsString:@"\n"]) {
                [paragraphStyle setLineSpacing:5];
            }
            if (model.hostGuest == 1) {
                [paragraphStyle setAlignment:NSTextAlignmentRight];
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.leftLabel.attributedText = attStr;
            } else {
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.rightLabel.attributedText = attStr;
            }
        }
            break;
        case 9: {
            if (model.hostGuest == 1) {
                self.leftLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            } else {
                self.rightLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            }
        }
            break;
        case 10: {
            NSString *str = model.upPlayerName.length > 8 ? [model.upPlayerName substringToIndex:8] : model.upPlayerName;
            NSUInteger length = str.length;
            if (!QM_IS_STR_NIL(model.downPlayerName)) {
                str = [str stringByAppendingString:[NSString stringWithFormat:@"\n%@",model.downPlayerName.length > 8 ?  [model.downPlayerName substringToIndex:8] : model.downPlayerName]];
            }
            NSMutableAttributedString *attStr = [[NSMutableAttributedString alloc] initWithString:str];
            [attStr addAttribute:NSForegroundColorAttributeName value:ColorAppBlack range:NSMakeRange(0, length)];
            if (attStr.length > length) {
                [attStr addAttribute:NSForegroundColorAttributeName value:ColorMainNormalBlack range:NSMakeRange(length, attStr.length - length)];
            }
            //行距
            NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
            if ([str containsString:@"\n"]) {
                [paragraphStyle setLineSpacing:5];
            }
            if (model.hostGuest == 1) {
                [paragraphStyle setAlignment:NSTextAlignmentRight];
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.leftLabel.attributedText = attStr;
            } else {
                [attStr addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, attStr.length)];
                self.rightLabel.attributedText = attStr;
            }
        }
            break;
        case 11: {
            if (model.hostGuest == 1) {
                self.leftLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            } else {
                self.rightLabel.text = model.playerName.length > 8 ?  [model.playerName substringToIndex:8] : model.playerName;
            }
        }
            break;
            
        default:
            break;
    }
    
    //分割线
    if (model.eventType == 0) {
        self.toplineView.hidden = YES;
    }
    if (model.eventType == 6 || isLastCell) {
        self.bottomlineView.hidden = YES;
    }
    NSArray *iconArr = @[@"match_whistle_icon",@"match_goal_icon",@"match_corner_icon",@"match_yellowCard_icon",@"match_redCard_icon",@"match_half_icon",@"match_end_icon",@"match_penalty_icon",@"match_own_goal_icon",@"match_yellow_red_icon",@"match_exchangePerson_icon",@"match_goal_miss_icon"];
    if (model.eventType == 0 || model.eventType == 5 || model.eventType == 6) {
        self.typeImageView.image = GetImage(iconArr[model.eventType]);
        self.typeImageView.hidden = NO;
        return;
    }
	
	if ((model.eventType == 8 || model.eventType == 1) && !QM_IS_STR_NIL(model.helperName)) {
		//进球有助攻
		if (model.hostGuest == 1) {
			//主场事件
			self.leftTopImageView.hidden = NO;
			self.leftBottomImageView.hidden = NO;
			self.leftTopImageView.image = GetImage(iconArr[model.eventType]);
			self.leftBottomImageView.image = GetImage(@"match_assists_icon");
		} else {
			//客场事件
			self.rightTopImageView.hidden = NO;
			self.rightBottomImageView.hidden = NO;
			self.rightTopImageView.image = GetImage(iconArr[model.eventType]);
			self.rightBottomImageView.image = GetImage(@"match_assists_icon");
		}
		return;
	}
	
	if (model.eventType == 10) {
		//换人
		if (model.hostGuest == 1) {
			//主场事件
			self.leftTopImageView.hidden = NO;
			self.leftBottomImageView.hidden = NO;
			self.leftTopImageView.image = GetImage(@"match_upPlayer_icon");
			self.leftBottomImageView.image = GetImage(@"match_downPlayer_icon");
		} else {
			//客场事件
			self.rightTopImageView.hidden = NO;
			self.rightBottomImageView.hidden = NO;
			self.rightTopImageView.image = GetImage(@"match_upPlayer_icon");
			self.rightBottomImageView.image = GetImage(@"match_downPlayer_icon");
		}
		return;
	}
	
    if (model.hostGuest == 1) {
        //主场事件
        self.leftTypeImageView.hidden = NO;
        self.leftTypeImageView.image = GetImage(iconArr[model.eventType]);
    } else {
        //客场事件
        self.rightTypeImageView.hidden = NO;
        self.rightTypeImageView.image = GetImage(iconArr[model.eventType]);
    }
}


#pragma mark - lazy init
- (UIView *)typeBgView {
    if (!_typeBgView) {
        _typeBgView = [UIView new];
        _typeBgView.backgroundColor = RGBCOLOR(244, 244, 244);
        _typeBgView.layer.cornerRadius = 15;
        [self.contentView addSubview:_typeBgView];
    }
    return _typeBgView;
}

- (UIView *)toplineView {
    if (!_toplineView) {
        _toplineView = [[UIView alloc] init];
        _toplineView.backgroundColor = RGBCOLOR(214, 214, 214);
        [self.contentView addSubview:_toplineView];
    }
    return _toplineView;
}

- (UIView *)bottomlineView {
    if (!_bottomlineView) {
        _bottomlineView = [[UIView alloc] init];
        _bottomlineView.backgroundColor = RGBCOLOR(214, 214, 214);
        [self.contentView addSubview:_bottomlineView];
    }
    return _bottomlineView;
}

- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.textColor = ColorMainNormalBlack;
        _timeLabel.font = GetFont(12);
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_timeLabel];
    }
    return _timeLabel;
}

- (UIImageView *)typeImageView {
    if (!_typeImageView) {
        _typeImageView = [[UIImageView alloc] init];
        [self.typeBgView addSubview:_typeImageView];
    }
    return _typeImageView;
}

- (UILabel *)leftLabel {
    if (!_leftLabel) {
        _leftLabel = [[UILabel alloc] init];
        _leftLabel.textColor = ColorMainNormalBlack;
        _leftLabel.font = GetFont(12);
        _leftLabel.numberOfLines = 0;
        _leftLabel.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_leftLabel];
    }
    return _leftLabel;
}

- (UILabel *)rightLabel {
    if (!_rightLabel) {
        _rightLabel = [UILabel new];
        _rightLabel.textColor = ColorMainNormalBlack;
        _rightLabel.font = GetFont(12);
        _rightLabel.numberOfLines = 0;
        [self.contentView addSubview:_rightLabel];
    }
    return _rightLabel;
}

- (UIImageView *)leftTypeImageView {
    if (!_leftTypeImageView) {
        _leftTypeImageView = [[UIImageView alloc] init];
        [self.typeBgView addSubview:_leftTypeImageView];
    }
    return _leftTypeImageView;
}

- (UIImageView *)rightTypeImageView {
    if (!_rightTypeImageView) {
        _rightTypeImageView = [[UIImageView alloc] init];
        [self.typeBgView addSubview:_rightTypeImageView];
    }
    return _rightTypeImageView;
}

- (UIImageView *)leftTopImageView {
	if (!_leftTopImageView) {
		_leftTopImageView = [[UIImageView alloc] init];
		[self.typeBgView addSubview:_leftTopImageView];
	}
	return _leftTopImageView;
}

- (UIImageView *)rightTopImageView {
	if (!_rightTopImageView) {
		_rightTopImageView = [[UIImageView alloc] init];
		[self.typeBgView addSubview:_rightTopImageView];
	}
	return _rightTopImageView;
}

- (UIImageView *)leftBottomImageView {
	if (!_leftBottomImageView) {
		_leftBottomImageView = [[UIImageView alloc] init];
		[self.typeBgView addSubview:_leftBottomImageView];
	}
	return _leftBottomImageView;
}

- (UIImageView *)rightBottomImageView {
	if (!_rightBottomImageView) {
		_rightBottomImageView = [[UIImageView alloc] init];
		[self.typeBgView addSubview:_rightBottomImageView];
	}
	return _rightBottomImageView;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

@end
