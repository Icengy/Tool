//
//  FootballDataTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

@interface FootballDataTableViewCell : ESChildTableViewCell

@property (nonatomic, strong) id model;

//- (void)configCellWithModel:(id)model;
//- (void)configBasketCellWithModel:(id)model;

@end


