//
//  MatchLiveExponentailHeaderView.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/9.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchLiveExponentailHeaderView.h"

@interface MatchLiveExponentailHeaderView ()
@property(nonatomic, strong) UILabel *timeLabel;
@property(nonatomic, strong) UILabel *scoreLabel;
@property(nonatomic, strong) UILabel *firstLabel;
@property(nonatomic, strong) UILabel *secondLabel;
@end

@implementation MatchLiveExponentailHeaderView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (id)init {
    if (self = [super init]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    
    [self addSubview:self.timeLabel];
    [self addSubview:self.scoreLabel];
    [self addSubview:self.firstLabel];
    [self addSubview:self.secondLabel];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    __block CGFloat width = self.width/8;
    [self.timeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left);
        make.width.offset(width);
    }];
    [self.scoreLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.timeLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(1.0);
    }];
    [self.firstLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.scoreLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(3.0);
    }];
    [self.secondLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.firstLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(3.0);
    }];
    NSArray <UIView *>*views = @[self.timeLabel, self.scoreLabel, self.firstLabel, self.secondLabel];
    [views mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.height.equalTo(self);
    }];
}

#pragma mark -
- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [UILabel new];
        _timeLabel.textColor = ColorMainNormalBlack;
        _timeLabel.font = GetFont(12);
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.numberOfLines = 0;
        _timeLabel.text = @"时间";
    }
    return _timeLabel;
}

- (UILabel *)scoreLabel {
    if (!_scoreLabel) {
        _scoreLabel = [UILabel new];
        _scoreLabel.textColor = ColorMainNormalBlack;
        _scoreLabel.font = GetFont(12);
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
        _scoreLabel.numberOfLines = 0;
        _scoreLabel.text = @"比分";
    }
    return _scoreLabel;
}

- (UILabel *)firstLabel {
    if (!_firstLabel) {
        _firstLabel = [UILabel new];
        _firstLabel.textColor = ColorMainNormalBlack;
        _firstLabel.font = GetFont(12);
        _firstLabel.textAlignment = NSTextAlignmentCenter;
        _firstLabel.text = @"开盘";
    }
    return _firstLabel;
}
    
- (UILabel *)secondLabel {
    if (!_secondLabel) {
        _secondLabel = [UILabel new];
        _secondLabel.textColor = ColorMainNormalBlack;
        _secondLabel.font = GetFont(12);
        _secondLabel.textAlignment = NSTextAlignmentCenter;
        _secondLabel.text = @"即时";
    }
    return _secondLabel;
}


@end
