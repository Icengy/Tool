//
//  MatchLiveExponentailHeaderCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchLiveExponentailHeaderCell.h"

@interface MatchLiveExponentailHeaderCell ()
@property(nonatomic, strong) UILabel *timeLabel;
@property(nonatomic, strong) UILabel *scoreLabel;
@property(nonatomic, strong) UILabel *firstLabel;
@property(nonatomic, strong) UILabel *secondLabel;
@end

@implementation MatchLiveExponentailHeaderCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setupView];
    }
    return self;
}

- (void)setupView {
    
    self.insets = kCustomViewDefaultInset;
    
    [self.contentView addSubview:self.timeLabel];
    [self.contentView addSubview:self.scoreLabel];
    [self.contentView addSubview:self.firstLabel];
    [self.contentView addSubview:self.secondLabel];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    __block CGFloat width = self.contentView.width/8;
    [self.timeLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView.mas_left);
        make.width.offset(width);
    }];
    [self.scoreLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.timeLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(1.0);
    }];
    [self.firstLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.scoreLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(3.0);
    }];
    [self.secondLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.firstLabel.mas_right);
        make.width.equalTo(self.timeLabel.mas_width).multipliedBy(3.0);
    }];
    NSArray <UIView *>*views = @[self.timeLabel, self.scoreLabel, self.firstLabel, self.secondLabel];
    [views mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.height.equalTo(self.contentView);
    }];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

#pragma mark -
- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [UILabel new];
        _timeLabel.textColor = ColorMainNormalBlack;
        _timeLabel.font = GetFont(12);
        _timeLabel.textAlignment = NSTextAlignmentCenter;
        _timeLabel.numberOfLines = 0;
        _timeLabel.text = @"时间";
    }
    return _timeLabel;
}

- (UILabel *)scoreLabel {
    if (!_scoreLabel) {
        _scoreLabel = [UILabel new];
        _scoreLabel.textColor = ColorMainNormalBlack;
        _scoreLabel.font = GetFont(12);
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
        _scoreLabel.numberOfLines = 0;
        _scoreLabel.text = @"比分";
    }
    return _scoreLabel;
}

- (UILabel *)firstLabel {
    if (!_firstLabel) {
        _firstLabel = [UILabel new];
        _firstLabel.textColor = ColorMainNormalBlack;
        _firstLabel.font = GetFont(12);
        _firstLabel.textAlignment = NSTextAlignmentCenter;
        _firstLabel.text = @"开盘";
    }
    return _firstLabel;
}
    
- (UILabel *)secondLabel {
    if (!_secondLabel) {
        _secondLabel = [UILabel new];
        _secondLabel.textColor = ColorMainNormalBlack;
        _secondLabel.font = GetFont(12);
        _secondLabel.textAlignment = NSTextAlignmentCenter;
        _secondLabel.text = @"即时";
    }
    return _secondLabel;
}

@end
