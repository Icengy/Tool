//
//  ExponentialEuropChangeTableViewCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExponentialEuropChangeTableViewCell : UITableViewCell
- (void)configCellWithModel:(id)model;
@end
