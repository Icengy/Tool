//
//  ScreenCollectionViewSectionHeader.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/8.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ScreenCollectionViewSectionHeader.h"

@implementation ScreenCollectionViewSectionHeader
-(id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    
    if (self) {
        self.letterLabel = [[UILabel alloc] initWithFrame:CGRectMake(16, 5, 20, 20)];
        self.letterLabel.textColor = RGBCOLOR(58, 58, 58);
        self.letterLabel.font = GetFont(14);
        self.backgroundColor = [UIColor clearColor];
        [self addSubview:self.letterLabel];
    }
    
    return self;
}
@end
