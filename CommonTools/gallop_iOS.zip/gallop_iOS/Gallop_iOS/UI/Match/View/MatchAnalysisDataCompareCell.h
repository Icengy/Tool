//
//  MatchAnalysisDataCompareCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/9/6.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CompareData.h"
//高度 30
@interface MatchAnalysisDataCompareCell : UITableViewCell
@property (nonatomic,strong) NSArray*arr;
@property (nonatomic,strong) NSString*name;
@end
