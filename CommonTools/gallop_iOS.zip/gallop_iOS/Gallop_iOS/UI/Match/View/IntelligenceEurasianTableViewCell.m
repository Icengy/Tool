//
//  IntelligenceEurasianTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/10/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "IntelligenceEurasianTableViewCell.h"
#import "IntelligenceModel.h"

@interface IntelligenceEurasianTableViewCell()
@property(nonatomic, strong)UILabel *typeLabel;
@property(nonatomic, strong)UILabel *startTitleLabel;
@property(nonatomic, strong)UILabel *currentTitleLabel;
@property(nonatomic, strong)UILabel *firstStartLabel;
@property(nonatomic, strong)UILabel *secondStartLabel;
@property(nonatomic, strong)UILabel *thirdStartLabel;
@property(nonatomic, strong)UILabel *firstCurrentLabel;
@property(nonatomic, strong)UILabel *secondCurrentLabel;
@property(nonatomic, strong)UILabel *thirdCurrentLabel;

@property(nonatomic, strong)UILabel *tipLabel;
@end

@implementation IntelligenceEurasianTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView);
    }];
    [@[self.typeLabel,self.startTitleLabel,self.firstStartLabel,self.secondStartLabel,self.thirdStartLabel] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:0 leadSpacing:0 tailSpacing:0];
    [@[self.typeLabel,self.currentTitleLabel,self.firstCurrentLabel,self.secondCurrentLabel,self.thirdCurrentLabel] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:0 leadSpacing:0 tailSpacing:0];
    [@[self.firstStartLabel,self.secondStartLabel,self.thirdStartLabel,self.startTitleLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(6);
    }];
    [@[self.firstCurrentLabel,self.secondCurrentLabel,self.thirdCurrentLabel,self.currentTitleLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.contentView).offset(-36);
    }];
	
	[self.tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.contentView);
		make.size.mas_equalTo(CGSizeMake(300, 30));
		make.centerX.equalTo(self.contentView);
	}];
    
    //分割线
    UIView *seperator1 = [UIView new];
    seperator1.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator1];
    [seperator1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.typeLabel);
        make.size.mas_equalTo(CGSizeMake(0.5, 60));
    }];

    UIView *seperator2 = [UIView new];
    seperator2.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator2];
    [seperator2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.firstStartLabel.mas_left);
        make.size.mas_equalTo(CGSizeMake(0.5, 60));
    }];

    UIView *seperator3 = [UIView new];
    seperator3.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator3];
    [seperator3 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.firstStartLabel);
        make.size.mas_equalTo(CGSizeMake(0.5, 60));
    }];

    UIView *seperator4 = [UIView new];
    seperator4.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator4];
    [seperator4 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.secondStartLabel);
        make.size.mas_equalTo(CGSizeMake(0.5, 60));
    }];
    
    UIView *seperator5 = [UIView new];
    seperator5.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator5];
    [seperator5 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(30);
        make.left.equalTo(self.typeLabel.mas_right);
        make.right.equalTo(self.contentView);
        make.height.mas_equalTo(0.5);
    }];
    
    UIView *seperator6 = [UIView new];
    seperator6.backgroundColor = RGBCOLOR(244, 244, 244);
    [self.contentView addSubview:seperator6];
    [seperator6 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(0.5);
        make.centerX.equalTo(self.contentView);
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH - 30, 0.5));
    }];
	
	UIView *seperator7 = [UIView new];
	seperator7.backgroundColor = RGBCOLOR(244, 244, 244);
	[self.contentView addSubview:seperator7];
	[seperator7 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.contentView).offset(-30);
		make.centerX.equalTo(self.contentView);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH - 30, 0.5));
	}];
}

- (void)configCellWithModel:(IntelligenceEurasianModel *)model {
    self.typeLabel.text = @"亚指";
    NSArray *startOddArr = [model.asiaOdds componentsSeparatedByString:@","];
    NSArray *currentOddArr = [model.assessAsiaOdds componentsSeparatedByString:@","];
    NSArray<NSString *> *changeArr = [model.oddsChangeStatus componentsSeparatedByString:@","];
    self.firstStartLabel.text = startOddArr[0];
    self.secondStartLabel.text = startOddArr[1];
    self.thirdStartLabel.text = startOddArr[2];
    self.firstCurrentLabel.text = currentOddArr[0];
    self.secondCurrentLabel.text = currentOddArr[1];
    self.thirdCurrentLabel.text = currentOddArr[2];
    //color
    UIColor *equalColor = RGBCOLOR(58, 58, 58);
    UIColor *hightColor = RGBCOLOR(240, 72, 68);
    UIColor *lowColor = RGBCOLOR(24, 169, 197);
    self.firstCurrentLabel.textColor = changeArr[0].integerValue == 0 ? equalColor : changeArr[0].integerValue == 1 ? hightColor : lowColor;
    self.secondCurrentLabel.textColor = changeArr[1].integerValue == 0 ? equalColor : changeArr[1].integerValue == 1 ? hightColor : lowColor;
    self.thirdCurrentLabel.textColor = changeArr[2].integerValue == 0 ? equalColor : changeArr[2].integerValue == 1 ? hightColor : lowColor;
}

#pragma mark - lazy init
- (UILabel *)typeLabel {
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.textColor = RGBCOLOR(58, 58, 58);
        _typeLabel.font = GetFont(12);
        _typeLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_typeLabel];
    }
    return _typeLabel;
}
- (UILabel *)startTitleLabel {
    if (!_startTitleLabel) {
        _startTitleLabel = [[UILabel alloc] init];
        _startTitleLabel.textColor = RGBCOLOR(58, 58, 58);
        _startTitleLabel.text = @"初盘水位";
        _startTitleLabel.font = GetFont(12);
        _startTitleLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_startTitleLabel];
    }
    return _startTitleLabel;
}
- (UILabel *)currentTitleLabel {
    if (!_currentTitleLabel) {
        _currentTitleLabel = [[UILabel alloc] init];
        _currentTitleLabel.textColor = RGBCOLOR(58, 58, 58);
        _currentTitleLabel.text = @"换算水位";
        _currentTitleLabel.font = GetFont(12);
        _currentTitleLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_currentTitleLabel];
    }
    return _currentTitleLabel;
}

- (UILabel *)firstStartLabel {
    if (!_firstStartLabel) {
        _firstStartLabel = [UILabel new];
        _firstStartLabel.textColor = RGBCOLOR(58, 58, 58);
        _firstStartLabel.font = GetFont(12);
        _firstStartLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_firstStartLabel];
    }
    return _firstStartLabel;
}

- (UILabel *)secondStartLabel {
    if (!_secondStartLabel) {
        _secondStartLabel = [UILabel new];
        _secondStartLabel.textColor = RGBCOLOR(58, 58, 58);
        _secondStartLabel.font = GetFont(12);
        _secondStartLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_secondStartLabel];
    }
    return _secondStartLabel;
}

- (UILabel *)thirdStartLabel {
    if (!_thirdStartLabel) {
        _thirdStartLabel = [UILabel new];
        _thirdStartLabel.textColor = RGBCOLOR(58, 58, 58);
        _thirdStartLabel.font = GetFont(12);
        _thirdStartLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_thirdStartLabel];
    }
    return _thirdStartLabel;
}

- (UILabel *)firstCurrentLabel {
    if (!_firstCurrentLabel) {
        _firstCurrentLabel = [UILabel new];
        _firstCurrentLabel.textColor = RGBCOLOR(58, 58, 58);
        _firstCurrentLabel.font = GetFont(12);
        _firstCurrentLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_firstCurrentLabel];
    }
    return _firstCurrentLabel;
}

- (UILabel *)secondCurrentLabel {
    if (!_secondCurrentLabel) {
        _secondCurrentLabel = [UILabel new];
        _secondCurrentLabel.textColor = RGBCOLOR(58, 58, 58);
        _secondCurrentLabel.font = GetFont(12);
        _secondCurrentLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_secondCurrentLabel];
    }
    return _secondCurrentLabel;
}

- (UILabel *)thirdCurrentLabel {
    if (!_thirdCurrentLabel) {
        _thirdCurrentLabel = [UILabel new];
        _thirdCurrentLabel.textColor = RGBCOLOR(58, 58, 58);
        _thirdCurrentLabel.font = GetFont(12);
        _thirdCurrentLabel.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_thirdCurrentLabel];
    }
    return _thirdCurrentLabel;
}

- (UILabel *)tipLabel {
	if (!_tipLabel) {
		_tipLabel = [UILabel new];
		_tipLabel.text = @"自定义欧赔查看更多数据>>";
		_tipLabel.textColor = RGBCOLOR(58, 58, 58);
		_tipLabel.font = GetFont(12);
		_tipLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_tipLabel];
	}
	return _tipLabel;
}
@end

