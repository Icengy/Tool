//
//  ChatRuleView.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/20.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ChatRuleView : UIView

@end

NS_ASSUME_NONNULL_END
