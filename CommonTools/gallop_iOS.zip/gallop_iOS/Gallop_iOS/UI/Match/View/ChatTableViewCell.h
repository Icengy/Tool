//
//  ChatTableViewCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/20.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

@interface ChatTableViewCell : ESTableViewCell
- (void)configCellWithModel:(id)model;
@end
