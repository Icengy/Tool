//
//  OddsConversionTableViewCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/19.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "OddsConversionTableViewCell.h"
#import "OddsConversionModel.h"

@interface OddsConversionTableViewCell()
@property (nonatomic,strong) UILabel *hostLabel;
@property (nonatomic,strong) UILabel *panLabel;
@property (nonatomic,strong) UILabel *guestLabel;
@end

@implementation OddsConversionTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[@[self.hostLabel,self.panLabel,self.guestLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.contentView);
	}];

	[@[self.hostLabel,self.panLabel,self.guestLabel] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:0 leadSpacing:30 tailSpacing:30];
	
	[self.panImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.contentView);
		make.centerY.equalTo(self.contentView);
		make.size.mas_equalTo(CGSizeMake(47, 28));
	}];
}

- (void)configCellWithModel:(OddsMapListItem *)model {
	self.hostLabel.text = [NSString stringWithFormat:@"%.2f",model.hostAsiaOdds.doubleValue];
	self.panLabel.text = model.handicap;
	self.guestLabel.text = [NSString stringWithFormat:@"%.2f",model.awayAsiaOdds.doubleValue];
}

#pragma mark - lazy init
- (UILabel *)hostLabel {
	if (!_hostLabel) {
		_hostLabel = [UILabel new];
		_hostLabel.textColor = RGBCOLOR(58, 58, 58);
		_hostLabel.font = GetFont(11);
		_hostLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_hostLabel];
	}
	return _hostLabel;
}

- (UILabel *)panLabel {
	if (!_panLabel) {
		_panLabel = [UILabel new];
		_panLabel.textColor = RGBCOLOR(58, 58, 58);
		_panLabel.font = GetFont(11);
		_panLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_panLabel];
	}
	return _panLabel;
}

- (UILabel *)guestLabel {
	if (!_guestLabel) {
		_guestLabel = [UILabel new];
		_guestLabel.textColor = RGBCOLOR(58, 58, 58);
		_guestLabel.font = GetFont(11);
		_guestLabel.textAlignment = NSTextAlignmentCenter;
		[self.contentView addSubview:_guestLabel];
	}
	return _guestLabel;
}

- (UIImageView *)panImageView {
	if (!_panImageView) {
		_panImageView = [UIImageView new];
		_panImageView.image = GetImage(@"match_panMain_icon");
		_panImageView.hidden = YES;
		[self.contentView addSubview:_panImageView];
	}
	return _panImageView;
}
@end
