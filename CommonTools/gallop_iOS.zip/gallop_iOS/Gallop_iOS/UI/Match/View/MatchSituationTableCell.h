//
//  MatchSituationTableCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/8/25.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface MatchSituationTableCell : ESChildTableViewCell

@property(nonatomic,copy) void(^clickToShowIllustrationBlock)(id sender);
@property (nonatomic, strong) NSArray *datas;

@end

NS_ASSUME_NONNULL_END
