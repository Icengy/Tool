//
//  ResultViewController.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ResultViewController.h"
#import "InstantTableViewCell.h"
#import "MatchInstantListModel.h"
#import "TimeSliderView.h"
#import "UICustomDatePicker.h"
#import "MatchDetailViewController.h"
#import "BasketballTableViewCell.h"
#import "BasketballListModel.h"

#import <BRPickerView/BRDatePickerView.h>

@interface ResultViewController ()<MatchInstantTableCellDelegate,TimeSliderViewDelegate>
@property(nonatomic, strong) NSMutableArray *dataList;
@property(nonatomic, strong) BasketballListModel *basketballModel;

@property(nonatomic, strong) TimeSliderView *slider;
@end

@implementation ResultViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSMutableArray array];
    // 获取当前时间
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    // 得到当前时间（世界标准时间 UTC/GMT）
    NSDate *nowDate = [NSDate date];
    
    self.selectedDate = [dateFormatter stringFromDate:nowDate];
    [self setupView];
    
}

- (void)setupView {
    
    [self.view addSubview:self.slider];
    [self.slider mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.view);
        make.height.offset(45.0);
    }];
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.slider.mas_bottom);
        make.bottom.left.right.equalTo(self.view);
    }];
    self.tableView.contentOffset = CGPointMake(0, 100);
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.estimatedRowHeight = 172;
    [self.tableView registerCell:[InstantTableViewCell class]];
    [self.tableView registerCell:[BasketballTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadData:nil];
}
- (void)matchScreenChange:(NSNotification *)notify {
    if (!self.isViewLoaded || !self.view.window) {
        return;
    }
    if ([notify.object integerValue] == 2) {
        //刷新列表
        [self loadData:nil];
    }
}

- (void)loadData:(id)sedner {
    [ES_HttpService showLoading:!sedner];
    if (!QM_IS_ARRAY_NIL(self.dataList)) {
        self.tableView.contentOffset = CGPointZero;
    }
    //请求列表数据
    @weakify(self)
	if (self.field == 2) {
		//篮球
		[ESNetworkService getEndBaskectballList:self.selectedDate response:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				BasketballListModel *model = [BasketballListModel  mj_objectWithKeyValues:data];
                self.basketballModel = model;
                [self.dataList removeAllObjects];
                [self.dataList addObjectsFromArray:model.matches.ongoings];
                [self.dataList addObjectsFromArray:model.matches.unStarts];
                [self.dataList addObjectsFromArray:model.matches.ends];
                
                self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
				
			} else {
                self.tableView.placeHolderText = @"";
                [self.dataList removeAllObjects];
			}
            dispatch_main_async_safe(^{
                [self.tableView updataFreshFooter:YES];
                self.tableView.mj_footer.hidden = !self.dataList.count;
                [self.tableView reloadData];
            });
		}];
	} else {
		//足球
		[ESNetworkService getSchedulesList:2 date:self.selectedDate sclassId:0 response:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				MatchInstantListModel *model = [MatchInstantListModel  mj_objectWithKeyValues:data];
                
                [self.dataList removeAllObjects];
                [self.dataList addObjectsFromArray:model.matchList];
                self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
			} else {
                self.tableView.placeHolderText = @"";
                [self.dataList removeAllObjects];
			}
            dispatch_main_async_safe(^{
                [self.tableView updataFreshFooter:YES];
                self.tableView.mj_footer.hidden = !self.dataList.count;
                [self.tableView reloadData];
            });
		}];
	}
}

#pragma mark - instantCellDelegate
- (void)focusStateChange:(UIButton *)focusBtn matchId:(NSInteger)matchId{
    //赛果不展示关注按钮
}


#pragma mark - tableView delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (self.field == 2) {
		//篮球
		BasketballTableViewCell *cell = [tableView dequeueReusableCell:[BasketballTableViewCell class]];
		cell.cellDelegate = self;
		[cell configCellWithModel:self.dataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeResult];
		return cell;
	} else {
		//足球
		InstantTableViewCell *cell = [tableView dequeueReusableCell:[InstantTableViewCell class]];
		cell.cellDelegate = self;
		[cell configCellWithModel:self.dataList[indexPath.row] cellType:MatchCellTypeResult];
		return cell;
	}
}

//选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
    liveVC.field = self.field;
	if (self.field == 2) {
		//篮球
        BasketballItem *matchModel = self.dataList[indexPath.row];
		
		liveVC.matchId = matchModel.matchId;
		liveVC.sourcePage = @"篮球比赛赛果页";
    }else {
        
        InstantMatcth *matchModel = self.dataList[indexPath.row];
 
        liveVC.matchId = matchModel.matchId;
        liveVC.needHidePlan = (matchModel.hasExpert == 1) ? NO : YES;
        liveVC.sourcePage = @"比赛赛果页";
    }
    
    [self.navigationController pushViewController:liveVC animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  self.dataList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
}

#pragma mark - TimeSliderDelegat
-(void)didSelectItemsWithDate:(NSString *)dateStr {
    [self handleSelectValue:dateStr];
}

- (void)showDateView {
    
    //赛程：未来30天；赛果为过去30天
    // 1.创建日期选择器
    BRDatePickerView *datePickerView = [[BRDatePickerView alloc]init];
    // 2.设置属性
    datePickerView.pickerMode = BRDatePickerModeYMD;
    datePickerView.title = @"请选择日期";
    datePickerView.selectValue = self.selectedDate;
    NSDate *currentData = [NSDate date];
    datePickerView.minDate = [currentData br_getNewDate:currentData addDays:-29];
    datePickerView.maxDate = currentData;
    @weakify(self)
    datePickerView.resultBlock = ^(NSDate *selectDate, NSString *selectValue) {
        @strongify(self)
        WTCLog(@"选择的值：%@", selectValue);
        [self handleSelectValue:selectValue];
    };
    // 3.显示
    [datePickerView show];
}

- (void)handleSelectValue:(NSString *)selectValue {
    if ([selectValue isEqualToString:self.selectedDate]) {
        return;
    }
    if (![self.slider.selectedDate isEqualToString:selectValue]) {
        self.slider.selectedDate = selectValue;
    }
    //埋点
    NSUInteger day = [CMMUtility getDayDifferenceWithStr:selectValue];
    if (self.field == 1) {
        [MobClick event:@"match10" attributes:@{@"isCalendar":@(YES),@"day":@(day)}];
    }else{
        [MobClick event:@"basketball10" attributes:@{@"isCalendar":@(YES),@"day":@(day)}];
    }
    
    //清空筛选缓存
    if (self.field == 1) {
        ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
        model.screenIsAll = @"1";
        model.screenMatchType = @"-1";
        model.screenLeague = @"-1";
        NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:[SystemManager footBallScreenCache]];
        tmpArr[2] = model;
        [SystemManager setFootBallScreenCache:tmpArr];
    } else {
        ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
        model.screenIsAll = @"1";
        model.screenMatchType = @"-1";
        model.screenLeague = @"-1";
        NSMutableArray *tmpArr = [NSMutableArray arrayWithArray:[SystemManager basketScreenCache]];
        tmpArr[2] = model;
        [SystemManager setBasketScreenCache:tmpArr];
    }
    self.selectedDate = selectValue;
    
    if (self.resetDelegate && [self.resetDelegate respondsToSelector:@selector(resetItemViewController:)]) {
        [self.resetDelegate resetItemViewController:self];
    }
    
    [self loadData:nil];
}

#pragma mark -
- (TimeSliderView *)slider {
    if (!_slider) {
        _slider = [[TimeSliderView alloc] init];
        _slider.delegate = self;
        _slider.type = TimeSliderTypeHistory;
    }return _slider;
}


@end
