//
//  GallopMatchCategoryViewController.h
//  Gallop_iOS
//
//  Created by icengy on 2021/4/27.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESChildViewController.h"

NS_ASSUME_NONNULL_BEGIN

@class GallopMatchCategoryViewController;
@protocol GallopMatchCategoryViewControllerDelegate <NSObject>

@required

/// 滑动到当前子控制器的index
/// @param itemController 当前控制器
/// @param index 对应子控制器的index
- (void)viewController:(GallopMatchCategoryViewController *)itemController didScrollToTabPageIndex:(NSInteger)index;

@end

@interface GallopMatchCategoryViewController : ESChildViewController

@property (nonatomic, weak) id <GallopMatchCategoryViewControllerDelegate> delegate;

@property (nonatomic, assign, readonly) NSUInteger currentIndex;
@property (nonatomic, strong, readonly) ESChildViewController *currentChildVC;

/// 1足球 2篮球
@property (nonatomic, assign) NSInteger field;

@end

NS_ASSUME_NONNULL_END
