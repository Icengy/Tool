//
//  FocusViewController.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "FocusViewController.h"
#import "MatchDetailViewController.h"

#import "InstantTableViewCell.h"
#import "MatchInstantListModel.h"
#import "MatchTCPMessageModel.h"
#import "BasketballListModel.h"
#import "BasketballTableViewCell.h"


@interface FocusViewController ()<MatchInstantTableCellDelegate>
@property(nonatomic, strong)BasketballListModel *basketballModel;
@property(nonatomic, strong)NSMutableArray *dataList;
@property(nonatomic, strong)NSMutableArray *finishDataList;

@end

@implementation FocusViewController {
    NSTimer * _timeCountTimer;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSMutableArray array];
	self.finishDataList = [NSMutableArray array];
    
//    self.fllowMatchCount = 0;
//	self.fllowBasketMatchCount = 0;
    [self setupView];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveGlobalMatchUpdateTCPMessage:) name:kGlobalMatchUpdateTCPMessage object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshData) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadData:nil];
}

- (void)receiveGlobalMatchUpdateTCPMessage:(NSNotification *)notify {
    @weakify(self)
    dispatch_main_async_safe(^{
        @strongify(self)
        [self handleGlobalMatchUpdateTCPMessage:notify];
    });
}

- (void)handleGlobalMatchUpdateTCPMessage:(NSNotification *)notify {
    if (!self.isViewLoaded || !self.view.window) {
        return;
    }
	if (self.field == 2) {
		//篮球
		return;
	}
	
    __block NSInteger sectionIndex = -1;
    __block NSInteger rowIndex = -1;
    MatchStartMessageModel *model = notify.object;
    NSInteger matchId = model.matchId;
    [self.dataList enumerateObjectsUsingBlock:^(FollowListModel *list, NSUInteger section, BOOL * _Nonnull sectionStop) {
        [list.matchList enumerateObjectsUsingBlock:^(InstantMatcth *data, NSUInteger row, BOOL * _Nonnull rowStop) {
            if (data.matchId == matchId) {
                rowIndex = row;
                sectionIndex = section;
                *sectionStop = YES;
                *rowStop = YES;
            }
        }];
    }];
    if (rowIndex == -1 || sectionIndex == -1) {
        return;
    }
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:rowIndex inSection:sectionIndex];
    //事件处理
    if ([notify.object isKindOfClass:[MatchStartMessageModel class]]) {
        //比赛开始
        MatchStartMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            match.status = model.status;
            if (model.status == 1 ) {
                match.elapsedTime = 0;
            }
            if (model.status == 3) {
                match.elapsedTime = 45;
            }
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    if ([notify.object isKindOfClass:[MatchRedCardMessageModel class]]) {
        //红牌
        MatchRedCardMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            if (model.hostGuest == 1) {
                //主队
                match.hostRedCard = model.currentCount;
            } else {
                //客队
                match.guestRedCard = model.currentCount;
            }
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    if ([notify.object isKindOfClass:[MatchYellowCardMessageModel class]]) {
        //黄牌
        MatchYellowCardMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            if (model.hostGuest == 1) {
                //主队
                match.hostYellowCard = model.currentCount;
            } else {
                //客队
                match.guestYellowCard = model.currentCount;
            }
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    if ([notify.object isKindOfClass:[MatchCornerMessageModel class]]) {
        //角球
        MatchCornerMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            if (model.hostGuest == 1) {
                //主队
                match.hostCorner = model.currentCount;
            } else {
                //客队
                match.guestCorner = model.currentCount;
            }
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    if ([notify.object isKindOfClass:[MatchGoalMessageModel class]]) {
        //进球
        MatchGoalMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            match.hostScore = model.hostScore;
            match.guestScore = model.guestScore;
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            //进球高亮闪烁
            InstantTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
            [cell hostOrGuestGoal:(model.hostGuest == 1 ? YES : NO)];
        });
    }
    if ([notify.object isKindOfClass:[MatchHalfEndMessageModel class]]) {
        //半场结束
        MatchHalfEndMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            match.hostScore = model.hostScore;
            match.guestScore = model.guestScore;
            match.status = 2;
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    if ([notify.object isKindOfClass:[MatchEndMessageModel class]]) {
        //比赛结束
        MatchEndMessageModel *model = notify.object;
        dispatch_main_async_safe(^{
            FollowListModel *list = self.dataList[indexPath.section];
            InstantMatcth *match = list.matchList[indexPath.row];
            match.hostScore = model.hostScore;
            match.guestScore = model.guestScore;
            match.status = 6;
            [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
}

#pragma mark - timer
- (void)timeCount {
    //未开赛/已经结束不再计时
    for (FollowListModel *list in self.dataList) {
        for (InstantMatcth *match in list.matchList) {
            if (match.status != 0 && match.status != 6) {
                match.elapsedTime += 1;
            }
        }
    }
    [self.tableView reloadData];
}

- (void)initTimer {
    dispatch_main_async_safe(^{
        [self destoryTimer];
        _timeCountTimer = [NSTimer timerWithTimeInterval:1*60  target:self selector:@selector(timeCount) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timeCountTimer forMode:NSRunLoopCommonModes];
    })
}

- (void)destoryTimer {
    dispatch_main_async_safe(^{
        if (_timeCountTimer) {
            if ([_timeCountTimer respondsToSelector:@selector(isValid)]){
                if ([_timeCountTimer isValid]){
                    [_timeCountTimer invalidate];
                    _timeCountTimer = nil;
                }
            }
        }
    })
}

- (void)setupView {
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.top.equalTo(self.view);
    }];
    self.tableView.contentOffset = CGPointMake(0, 100);
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.estimatedRowHeight = 172;
    [self.tableView registerCell:[InstantTableViewCell class]];
    [self.tableView registerCell:[BasketballTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
    
    [[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        dispatch_main_async_safe(^{
            [self loadData:nil];
        });
    }];
}


- (void)refreshData {
    if (![App_Utility checkCurrentUser]) {
        return;
    }
    [self loadData:nil];
}

- (void)loadData:(id)sedner {
	if (![App_Utility checkCurrentUser]) {
        [self endAllFreshing:self.tableView];
        
		[CMMUtility showToastWithText:@"请先登录再关注比赛"];
		[App_Utility showLoginViewController];
        return;
	}
    [ES_HttpService showLoading:!sedner];
    
    if (!QM_IS_ARRAY_NIL(self.dataList) || !QM_IS_ARRAY_NIL(self.finishDataList)) {
//        [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
        self.tableView.contentOffset = CGPointZero;
    }
    //请求列表数据
    @weakify(self)
	if (self.field == 2) {
		//篮球
		[ESNetworkService getBasketFollowList:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				BasketballListModel *model = [BasketballListModel  mj_objectWithKeyValues:data];
                self.basketballModel = model;
                [self.dataList removeAllObjects];
                [self.finishDataList removeAllObjects];
                [self.dataList addObjectsFromArray:model.matches.ongoings];
                [self.dataList addObjectsFromArray:model.matches.unStarts];
                [self.finishDataList addObjectsFromArray:model.matches.ends];
			} else {
                [self.dataList removeAllObjects];
                [self.finishDataList removeAllObjects];
                self.tableView.placeHolderText = @"";
			}
            
            dispatch_main_async_safe(^{
                NSUInteger count = self.dataList.count + self.finishDataList.count;
                //更新总关注计数
                [[NSNotificationCenter defaultCenter] postNotificationName:kFllowBasketMatchCountChange object:@(count)];
                
                [self.tableView updataFreshFooter:YES];
                self.tableView.mj_footer.hidden = !count;
                [self.tableView reloadData];
            });
		}];
	} else {
		//足球
		[ESNetworkService getFollowListResponse:^(id dict, ESError *error) {
			@strongify(self)
            [self endAllFreshing:self.tableView];
            [self destoryTimer];
            
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				MatchFollowListModel *model = [MatchFollowListModel  mj_objectWithKeyValues:data];
				dispatch_main_async_safe(^{
					NSUInteger count = 0;
					[self.dataList removeAllObjects];
					for (FollowListModel *finishLitModel in model.finishedList) {
						//用于识别已经结束比赛
						count += finishLitModel.matchList.count;
						finishLitModel.date = -1;
					}
					for (FollowListModel *progressModel in model.progressList) {
						//用于识别正在进行比赛
						count += progressModel.matchList.count;
						progressModel.date = -2;
					}
					[self.dataList addObjectsFromArray:model.progressList];
					//未开始比赛列表处理
					NSDate *dateNow = [NSDate date];//现在时间
					NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
					[formatter setDateFormat:@"yyyy-MM-dd"];
					NSString *dateNowStr = [formatter stringFromDate:dateNow];
					for (FollowListModel *notStartModel in model.notStartList) {
						count += notStartModel.matchList.count;
						NSString *dateStr = [CMMUtility timeConvertWithTimeStamp:@(notStartModel.date).stringValue andTimeFormat:@"yyyy-MM-dd"];
						if ([dateStr isEqualToString:dateNowStr]) {
							//当天未开始的比赛移到即时列表中展示
							notStartModel.date = -2;
							if (self.dataList.count == 0) {
								[self.dataList addObject:notStartModel];
							} else {
								[((FollowListModel *)self.dataList[0]).matchList addObjectsFromArray:notStartModel.matchList];
							}
						} else {
							[self.dataList addObject:notStartModel];
						}
					}
					[self.dataList addObjectsFromArray:model.finishedList];
                    
                    [self.tableView updataFreshFooter:YES];
                    self.tableView.mj_footer.hidden = !count;
					[self.tableView reloadData];
					//开启比赛时间计时器
					[self initTimer];
					//更新总关注计数
                    [[NSNotificationCenter defaultCenter] postNotificationName:kFllowMatchCountChange object:@(count)];
				});
			} else {
                dispatch_main_async_safe(^{
                    [self.dataList removeAllObjects];
                    [self.finishDataList removeAllObjects];
                    self.tableView.placeHolderText = @"";
                    [self.tableView reloadData];
                });
            }
		}];
	}
}

#pragma mark - instantCellDelegate
- (void)focusStateChange:(UIButton *)focusBtn matchId:(NSInteger)matchId {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
    if (self.field == 1) {
        [MobClick event:@"match8" attributes:@{@"tab":@"关注",@"isFllow":@(!focusBtn.selected)}];
        
        [ESNetworkService focusMatch:!focusBtn.selected matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    focusBtn.selected = !focusBtn.selected;
                    [self loadData:nil];
                });
            }
        }];
    }
    if (self.field == 2) {
        [MobClick event:@"basketball8" attributes:@{@"tab":@"关注",@"isFllow":@(!focusBtn.selected)}];
        
        NSUInteger type = (!focusBtn.selected ? 1 : 0);
        [ESNetworkService focusBasketMatch:type matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    focusBtn.selected = !focusBtn.selected;
                    
                    [self loadData:nil];
                });
            }
        }];
    }
}


#pragma mark - tableView delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (self.field == 2) {
		//篮球
		BasketballTableViewCell *cell = [tableView dequeueReusableCell:[BasketballTableViewCell class]];
		cell.cellDelegate = self;
		if (indexPath.section == 1) {
			[cell configCellWithModel:self.finishDataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeFouces];
		} else {
			[cell configCellWithModel:self.dataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeFouces];
		}
		return cell;
	} else {
		InstantTableViewCell *cell = [tableView dequeueReusableCell:[InstantTableViewCell class]];
		cell.cellDelegate = self;
		FollowListModel *model = self.dataList[indexPath.section];
		[cell configCellWithModel:model.matchList[indexPath.row] cellType:MatchCellTypeFouces];
		return cell;
	}
}

//选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
    liveVC.field = self.field;
    
    if (self.field == 2) {
        //篮球
        BasketballItem *matchModel;
        if (indexPath.section == 1) {
            matchModel  = self.finishDataList[indexPath.row];
        } else {
            matchModel = self.dataList[indexPath.row];
        }
        
        liveVC.matchId = matchModel.matchId;
        liveVC.sourcePage = @"篮球比赛关注页";
    }else {
        InstantMatcth *matchModel;
        if (indexPath.section == 1) {
            matchModel  = self.finishDataList[indexPath.row];
        } else {
            matchModel = self.dataList[indexPath.row];
        }
        
        liveVC.matchId = matchModel.matchId;
        liveVC.needHidePlan = (matchModel.hasExpert == 1) ? NO : YES;
        liveVC.sourcePage = @"比赛关注页";
    }
    [self.navigationController pushViewController:liveVC animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if (self.field == 2) {
		if (QM_IS_ARRAY_NIL(self.finishDataList)) {
			return 1;
		} else {
			return 2;
		}
	} else {
		return self.dataList.count;
	}
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (self.field == 2) {
		return section == 1 ? self.finishDataList.count : self.dataList.count;
	}
    FollowListModel *model = self.dataList[section];
    return  model.matchList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	if (self.field == 2) {
		return section == 1 ? 30 : 12;
	}
    FollowListModel *model = self.dataList[section];
    if (model.date == -1 || model.date > 0) {
        return 30;
    } else {
        return 12;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	if (self.field == 2) {
		//篮球
		UILabel *headLabel = [[UILabel alloc] init];
		if (section == 1) {
			headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 30);
			headLabel.text = @"已结束";
			headLabel.textColor = ColorSubTitle;
			headLabel.textAlignment = NSTextAlignmentCenter;
			headLabel.font = GetFont(12);
		} else {
			headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 12);
		}
		return headLabel;
	}
	
    UILabel *headLabel = [[UILabel alloc] init];
    FollowListModel *model = self.dataList[section];
    if (model.date == -1 || model.date > 0) {
        NSString *title = (model.date == -1) ? @"已结束":[CMMUtility timeConvertWithTimeStamp:@(model.date).stringValue andTimeFormat:@"yyyy-MM-dd"];
        headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 30);
        headLabel.text = title;
        headLabel.textColor = ColorSubTitle;
        headLabel.textAlignment = NSTextAlignmentCenter;
        headLabel.font = GetFont(12);
    } else {
        headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 12);
    }
    return headLabel;
}


@end
