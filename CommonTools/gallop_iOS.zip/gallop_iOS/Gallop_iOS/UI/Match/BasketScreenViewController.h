//
//  BasketScreenViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface BasketScreenViewController : MatchDetailItemViewController

@property(nonatomic, strong)NSString *date;
@property(nonatomic, assign)NSInteger pageType;
@property(nonatomic, assign)NSInteger matchType;

@end
