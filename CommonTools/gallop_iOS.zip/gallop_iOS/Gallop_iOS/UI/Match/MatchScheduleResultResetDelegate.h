//
//  MatchScheduleResultResetDelegate.h
//  Gallop_iOS
//
//  Created by lcy on 2021/9/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol MatchScheduleResultResetDelegate <NSObject>

- (void)resetItemViewController:(UIViewController *)itemViewController;

@end

NS_ASSUME_NONNULL_END
