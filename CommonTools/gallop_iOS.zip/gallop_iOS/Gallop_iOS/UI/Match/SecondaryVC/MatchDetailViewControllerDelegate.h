//
//  MatchDetailViewControllerDelegate.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MatchDetailItemViewController;

NS_ASSUME_NONNULL_BEGIN

@protocol MatchDetailViewControllerDelegate <NSObject>

-(void)changeViewWith:(BOOL)hideHead;
- (void)matchDetailItemViewController:(MatchDetailItemViewController *)itemVC scrollViewDidScroll:(UIScrollView *)scrollView;

@end

NS_ASSUME_NONNULL_END
