//
//  MatchFilterViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchFilterViewController.h"

#import "MatchFilterTableViewCell.h"

@interface MatchFilterViewController () <UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *content_height_constraint;

@property (weak, nonatomic) IBOutlet CYButton *closeBtn;
@property (weak, nonatomic) IBOutlet CYButton *confirmBtn;

@end

@implementation MatchFilterViewController

- (instancetype)init {
    if (self = [super init]) {
        self.modalPresentationStyle = UIModalPresentationOverFullScreen;
//        self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
    }return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.fd_prefersNavigationBarHidden = YES;
    self.view.backgroundColor = [ColorMainNormalBlack colorWithAlphaComponent:0.3];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickToClose:)];
    tap.delegate = self;
    [self.view addGestureRecognizer:tap];
    
    self.closeBtn.imagePrams(GetImage(@"top_close"), UIControlStateNormal);
    
    [self.contentView addSubview:self.tableView];
    self.tableView.backgroundColor = UIColor.whiteColor;
    self.tableView.scrollEnabled = NO;
    self.tableView.hidePlaceHolder = YES;
    self.tableView.rowHeight = 50.0;
    
    self.tableView.sectionFooterHeight = CGFLOAT_MIN;
    self.tableView.tableFooterView = [UIView new];
    
    [self.tableView registerNibCell:[MatchFilterTableViewCell class]];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.tableView reloadData];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];

    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self.contentView);
        make.top.equalTo(self.closeBtn.mas_bottom).offset(1);
        make.bottom.equalTo(self.confirmBtn.mas_top).offset(-10);
    }];
}

- (void)setDataSource:(NSMutableArray *)dataSource {
    [super setDataSource:dataSource];
    
    [self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.height.offset(50.0 *dataSource.count);
    }];
    [self.view setNeedsLayout];
}

#pragma mark - tableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MatchFilterTableViewCell *cell = [tableView dequeueReusableCell:[MatchFilterTableViewCell class]];
    cell.filter = [self.dataSource objectAtIndex:indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return self.dataSource.count?1.0:CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [CYView new].backgroundPrams(ColorDefaultGrayBackground);
}

#pragma mark -
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isDescendantOfView:self.contentView]) {
        return NO;
    }
    return YES;
}

#pragma mark -
- (IBAction)clickToClose:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)clickToConfirm:(id)sender {
    @weakify(self);
    [self dismissViewControllerAnimated:YES completion:^{
        @strongify(self);
        if (self.clickToConfirm) self.clickToConfirm();
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
