//
//  MatchFilterViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"
#import "MatchFilterModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface MatchFilterViewController : ESViewController

@property(nonatomic, copy) NSString *markTitle;
@property(nonatomic,strong)void(^clickToConfirm)(void);

@end

NS_ASSUME_NONNULL_END
