//
//  MatchDetailViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "MatchDetailViewController.h"

#import "MatchDetailTopModel.h"
#import "LiveTCPMessageModel.h"
#import "MatchTCPMessageModel.h"
#import "WTCSocketService.h"
#import "WTCChatSocketService.h"

#import "LiveTopView.h"
#import "MatchLiveView.h"
#import "MatchWeatherTableViewCell.h"
#import "MatchDetailShortTitleView.h"

#import "CYTabTitleBar.h"
#import "CYTabChildModel.h"

/// 足球模块
#import "LiveViewController.h"
#import "ChatViewController.h"
#import "SquadViewController.h"
#import "ExponentialViewController.h"
#import "IntelligenceViewController.h"
#import "PlanViewController.h"
#import "AnalyseViewController.h"
/// 篮球模块
#import "BasketLiveViewController.h"
#import "BasketChatViewController.h"
#import "BasketDataViewController.h"
#import "BasketIntelligenceViewController.h"
#import "BasketExponentailViewController.h"
#import "BasketStatisticViewController.h"

//球队详情
#import "TeamViewController.h"
//联赛积分
#import "LeagueViewController.h"
#import "BasketLeagueViewController.h"
//分享
#import "ESShareViewController.h"

#import "UIBarButtonItem+CreateExt.h"


@interface MatchDetailViewController () <LiveTopViewDelegate, MatchLiveViewDelegate, GallopNavigationBarDelegate>
//Data
@property (nonatomic, strong) NSURL               *liveURL;
@property (nonatomic, copy) NSString *            bgImageName;
@property (nonatomic, assign) BOOL                hideHead;
/// 是否正在直播
@property (nonatomic, assign) BOOL   isLiving;
@property (nonatomic, assign) double topHeight;
@property (nonatomic, assign) double liveingHeight;
@property (nonatomic, assign) BOOL   needShowTitleMenu;
@property (nonatomic, assign) double childContentHeight;


@property (nonatomic, strong) MatchDetailTopModel *matchDetailTopModel;
@property (nonatomic, strong) MatchBasketTopModel *matchBasketDetailTopModel;

//View
@property (nonatomic, strong) LiveTopView         *topView;
@property (nonatomic, strong) MatchDetailShortTitleView         *shortTitleView;
//@property (nonatomic, strong) UITapGestureRecognizer *naviTap;

@property (nonatomic, strong) MatchLiveView       *liveView;

@property (nonatomic ,strong) CYTabTitleBar  *titleBarView;

//分享
@property (nonatomic, strong) UIStackView    *stack;
@property (nonatomic, strong) CYButton    *focusBtn;
@property (nonatomic, strong) CYButton    *shareBtn;
@property (nonatomic, strong) UIImageView *bgView;

@end

@implementation MatchDetailViewController
{
    NSTimer * _timeCountTimer;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [[WTCSocketService instance] SRWebSocketClose];
    [[WTCChatSocketService instance] SRWebSocketClose];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.needShowTitleMenu = NO;
    
    NSString *url = [NSString stringWithFormat:MatchLiveUrl,@(self.matchId),@([LPUnitily getTimeSp])];
    self.liveURL = [NSURL URLWithString:url];
    self.bgImageName = (self.field == 1)?@"match_topView_bg":@"basket_topView_bg";
    
    self.topHeight = (kScreen_Width*200.0/375.0 + kStatusBarHeight);
    self.liveingHeight = (kScreen_Width*240.0/375.0 + kStatusBarHeight);
    self.isLiving = NO;
    
    self.childsArray = [self getChildsArray];
    
    [self setupView];
    
    [self loadData];
    
    /// 足球长链
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveTCPMessage:) name:kMatchUpdateTCPMessage object:nil];
    /// 蓝球长链
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveTCPMessage:) name:kGlobalMatchBaskectTCPMessage object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectScocket) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didChildsEndRefresh) name:kDidEndRefreshForChildViewControllerNotification object:nil];

    /// 背景图
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImage *image =  GetImage(self.bgImageName);
        self.bgView.frame = CGRectMake(0, 0, kScreen_Width, kScreen_Height);
        self.bgView.image = image;
//        [self.tableView insertSubview:self.bgView atIndex:0];
        self.tableView.backgroundView = self.bgView;
    });
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleImageContent;
    
    [self showNavi];
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    [LPUnitily.keyWindow viewWithTag:12345].hidden = YES;
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    [LPUnitily.keyWindow viewWithTag:12345].hidden = YES;
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
    
//    [self.navigationController.navigationBar removeGestureRecognizer:self.tap];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    //防止内存泄露
    [self destoryTimer];
}

#pragma mark - view&data
- (void)setupView {
    self.view.backgroundColor = ColorDefaultGrayBackground;
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem createBarItemWithImage:@"nav_return_white" withHightImg:nil target:self action:@selector(backBtnClick)];
    self.navigationItem.titleView = self.shortTitleView;
    
    GallopNavigationBar *bar = (GallopNavigationBar *)self.navigationController.navigationBar;
    bar.gallopDelegate = self;
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.stack];
    
    self.tableView.multipleGestureEnable = YES;
    [self.view addSubview:self.tableView];
    self.tableView.contentInset = kTableViewDetailtContentInset;
    self.tableView.backgroundColor = UIColor.clearColor;
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
    
    [self.tableView registerCell:[ESTableViewCell class]];
    [self.tableView registerCell:[MatchWeatherTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadItemData:)];
    
    self.titleBarController.delegate = self;
    self.titleBarController.dataSource = self;
    self.titleBarController.contentScrollEnabled = NO;
    [self addChildViewController:self.titleBarController];
    self.titleBarController.backgroundColor = self.view.backgroundColor;
    
    self.currentIndex = 0;
}

- (void)configureFootball:(NSDictionary *)data {
    self.matchDetailTopModel = [MatchDetailTopModel mj_objectWithKeyValues:data];
    
    [self.topView configTopView:self.matchDetailTopModel];
    self.shortTitleView.model = self.matchDetailTopModel;
    self.focusBtn.selected = self.matchDetailTopModel.isFollowed;
    self.focusBtn.hidden = self.matchDetailTopModel.status == 6;
    
    self.childsArray = [self getChildsArray];
    self.titleBarView.dataArray = self.childsArray;
    
//    //埋点
//    BOOL animation = self.matchDetailTopModel.liveType == 1 || self.matchDetailTopModel.liveType == 3;
//    BOOL video = self.matchDetailTopModel.liveType == 2 || self.matchDetailTopModel.liveType == 3;
//    NSString *status = self.matchDetailTopModel.status == 0 ? @"未开赛" : self.matchDetailTopModel.status == 6 ? @"已结束" : @"进行中";
//    [MobClick event:@"match11"  attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage,@"animation":@(animation),@"video":@(video),@"status":status}];
    
    NSUInteger index = 0;
    if (!self.needHidePlan) {
        index = (self.matchDetailTopModel.allowChat == 1) ? 6 : 5;
    }else if (self.matchDetailTopModel.status == 0) {
        //未开赛默认展示分析页
        index = (self.matchDetailTopModel.allowChat == 1) ? 2 : 1;
    }
    self.currentIndex = index;
    
    dispatch_main_async_safe((^{
        //开启比赛时间计时器
        [self initTimer];
        [self.tableView reloadData];
        [self.titleBarController reloadData];
        
        if (index) {
            [self.titleBarController moveToControllerAtIndex:index animated:YES];
        }
    }));
}

- (void)configurebasketball:(NSDictionary *)data {
    self.matchBasketDetailTopModel = [MatchBasketTopModel mj_objectWithKeyValues:data];
    
    [self.topView configBasketTopView:self.matchBasketDetailTopModel];
    self.shortTitleView.model = self.matchBasketDetailTopModel;
    self.focusBtn.selected = self.matchBasketDetailTopModel.match.follow;
    self.focusBtn.hidden = self.matchBasketDetailTopModel.match.state == 6;
    
    self.childsArray = [self getChildsArray];
    self.titleBarView.dataArray = self.childsArray;
    
//    //埋点
//    BOOL animation = self.matchBasketDetailTopModel.match.flags[0].intValue == 1;
//    BOOL video = self.matchBasketDetailTopModel.match.flags[1].intValue == 1;
//    NSString *status = self.matchBasketDetailTopModel.match.state == 1 ? @"未开赛" : self.matchBasketDetailTopModel.match.state == 10 ? @"已结束" : @"进行中";
//    [MobClick event:@"basketball11"  attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage,@"animation":@(animation),@"video":@(video),@"status":status}];
    
    __block NSInteger index = 0;
    if (self.matchBasketDetailTopModel.match.state == 1 &&
        self.matchBasketDetailTopModel.tabs[2].integerValue == 1) {
        [self.childsArray enumerateObjectsUsingBlock:^(CYTabChildModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj.childTitle isEqualToString:@"数据"]) {
                index = idx;
                *stop = YES;
            }
        }];
    }
    
    self.currentIndex = index;
    
    dispatch_main_async_safe((^{
//        [self initTimer];
        [self.tableView reloadData];
        [self.titleBarController reloadData];
        
        if (index) {
            [self.titleBarController moveToControllerAtIndex:index animated:YES];
        }
    }));
}

- (void)loadData {
    
    @weakify(self)
    if (self.field == 1) {
        
        [ESNetworkService getLiveTopList:self.matchId response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict&&[dict[@"code"] integerValue] == 0) {
                [self connectScocket];
                
                NSDictionary *data = [dict objectForKey:@"data"];
                if (!QM_IS_DICT_NIL(data)) {
                    [self configureFootball:data];
                }
            }
        }];
    }else {
        
        [ESNetworkService getBasketLiveTopList:self.matchId response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict&&[dict[@"code"] integerValue] == 0) {
                [self connectScocket];
                
                NSDictionary *data = [dict objectForKey:@"data"];
                if (!QM_IS_DICT_NIL(data)) {
                    [self configurebasketball:data];
                }
            }
        }];
    }
}

- (void)loadItemData:(id)sender {
    if (self.matchId) {
        if (self.field == 1 && !self.matchDetailTopModel) {
            [self loadData];
        }
        if (self.field == 2 && !self.matchBasketDetailTopModel) {
            [self loadData];
        }
    }
    [[self.childsArray objectAtIndex:self.currentIndex].childViewController loadData:sender];
}

#pragma mark - UITableView
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0 && self.field == 1 && (self.matchDetailTopModel.weather ||
                                            !QM_IS_STR_NIL(self.matchDetailTopModel.matchSite))) {
        return self.isLiving ? 0 : 2;
    }
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (!self.isLiving) {
            switch (indexPath.row) {
                case 1:
                    return 25.0;
                    break;
                    
                default:
                    return UITableViewAutomaticDimension;
                    break;
            }
        }
    }else if (indexPath.section == 1) {
        return self.childContentHeight;
    }
    return CGFLOAT_MIN;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
//    if (self.field == 1 &&
//        indexPath.section == 0 &&
//        !self.isLiving) {
//        if (self.matchDetailTopModel.weather || !QM_IS_STR_NIL(self.matchDetailTopModel.matchSite)) {
//
//            MatchWeatherTableViewCell *cell = [tableView dequeueReusableCell:[MatchWeatherTableViewCell class]];
//            /// 天气+位置模块
//            cell.model = self.matchDetailTopModel;
//
//            return cell;
//        }
//    }
//    [tableView insertSubview:self.bgView atIndex:0];
    if (indexPath.section == 0) {
        switch (indexPath.row) {
            case 1:
            {
                MatchWeatherTableViewCell *cell = [tableView dequeueReusableCell:[MatchWeatherTableViewCell class]];
                /// 天气+位置模块
                cell.model = self.matchDetailTopModel;
                
                return cell;
                break;
            }
                
            default:
            {
                ESTableViewCell *cell = [tableView dequeueDefaultESCell:@"matchDetail_topView"];
                cell.backgroundColor = UIColor.clearColor;
                
                [cell.contentView addSubview:self.topView];
                [self.topView mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.edges.equalTo(cell.contentView);
                }];
                return cell;
                break;
            }
        }
    }
    
    if (indexPath.section == 1) {
        ESTableViewCell *cell = [tableView dequeueReusableCell:[ESTableViewCell class]];
        cell.itemView = self.titleBarController.view;
        return cell;
    }
    return [tableView dequeueReusableCell:[ESTableViewCell class]];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section) return 40.0;
    /// 静态view展示高度
    return self.isLiving?self.liveingHeight:CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section) {
        self.titleBarView.dataArray = self.childsArray;
        return self.titleBarView;
    }
    if (self.isLiving) {
        
        self.liveView.matchDetailTopModel = self.matchDetailTopModel;
        return self.liveView;
    }
    
//    return self.topView;
    return [CYView new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [CYView new];
}

//- (void)tableView:(UITableView *)tableView willDisplayCell:(nonnull UITableViewCell *)cell forRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
//    [tableView insertSubview:self.bgView atIndex:0];
//}
//
//- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
//    [tableView insertSubview:self.bgView atIndex:0];
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark -
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
//    if (!decelerate) {
//        [self.tableView beginUpdates];
//        self.childContentHeight = kScreen_Height - CGRectGetMaxY([self.titleBarView convertRect:self.titleBarView.bounds toView:self.view]);
//        [self.tableView endUpdates];
//    }
}
/**
 *  滚动完毕就会调用（如果是人为拖拽scrollView导致滚动完毕，才会调用这个方法）
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
//    [self.tableView beginUpdates];
//    self.childContentHeight = kScreen_Height - CGRectGetMaxY([self.titleBarView convertRect:self.titleBarView.bounds toView:self.view]);
//    [self.tableView endUpdates];
}

/**
 *  滚动完毕就会调用（如果不是人为拖拽scrollView导致滚动完毕，才会调用这个方法）
 */
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView {
//    [self.tableView beginUpdates];
//    self.childContentHeight = kScreen_Height - CGRectGetMaxY([self.titleBarView convertRect:self.titleBarView.bounds toView:self.view]);
//    [self.tableView endUpdates];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    self.offsetY = scrollView.contentOffset.y;
    
    [self showNavi];
    
    double bottomCellOffset = [self.tableView rectForSection:self.tableView.numberOfSections - 1].origin.y - NavBarHeight;
    [self tableViewDidScroll:scrollView bottomCellOffset:bottomCellOffset];
}

- (void)showNavi {
    __block CGFloat alpha = self.offsetY / NavBarHeight;
//    WTCLog(@"alpha = %.2f, self.offsetY = %.2f",alpha, self.offsetY);
//    [self.navigationController setNavigationBarHidden:(alpha <= 0.0) animated:NO];
    
    self.shortTitleView.hidden = alpha <= 0.0;
    self.shortTitleView.alpha = alpha;
    
    self.navigationController.navigationBar.translucent = (alpha >= 1.0f) ? NO : YES;
    UIImage *image = [[UIImage imageNamed:self.bgImageName] resizableImageWithCapInsets:UIEdgeInsetsZero];

    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *barApp = self.navigationController.navigationBar.standardAppearance;
        barApp.backgroundImage = [UIImage changeAlphaOfImageWith:alpha withImage:image];
        barApp.shadowImage = [UIImage new];
        
        self.navigationController.navigationBar.standardAppearance = barApp;
    }else {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage changeAlphaOfImageWith:alpha withImage:image] forBarMetrics:UIBarMetricsDefault];
        [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    }
}

#pragma mark - TYPagerControllerDelegate
- (void)pagerController:(TYTabPagerController *)pagerController didScrollToTabPageIndex:(NSInteger)index {
    NSLog(@"didScrollToTabPageIndex - %@",@(index));
    self.currentIndex = index;
    self.titleBarView.currentIndex = self.currentIndex;
}

#pragma mark - webSocket
- (void)receiveTCPMessage:(NSNotification *)notify {
    if ([notify.object isKindOfClass:[LiveTCPUpdateMessageModel class]]) {
        //技术统计更新
        LiveTCPUpdateMessageModel *model = notify.object;
        
        //校验是否为本场比赛长连接数据
        if (self.matchId != model.matchId) {
            return;
        }
        
        self.matchDetailTopModel.hostScore = @(model.hostScore).stringValue;
        self.matchDetailTopModel.guestScore = @(model.guestScore).stringValue;
        self.matchDetailTopModel.status = model.status;
        dispatch_main_async_safe(^{
            [self.topView configTopView:self.matchDetailTopModel];
            self.shortTitleView.model = self.matchDetailTopModel;
            
            self.focusBtn.hidden = self.matchDetailTopModel.status == 6;
            self.focusBtn.selected = self.matchDetailTopModel.isFollowed;
            
        });
    }
    if ([notify.object isKindOfClass:[MatchBaskectTCPMessage class]]) {
        MatchBaskectTCPMessage *model = notify.object;
        
        for (MatchBaskectItem *item in model.data) {
            if (item.matchId == self.matchId) {
                self.matchBasketDetailTopModel.match.host.scores = item.hostScores;
                self.matchBasketDetailTopModel.match.away.scores = item.awayScores;
                self.matchBasketDetailTopModel.match.state = item.state;
                self.matchBasketDetailTopModel.match.seconds = item.seconds;
                dispatch_main_async_safe(^{
                    [self.topView configBasketTopView:self.matchBasketDetailTopModel];
                    self.shortTitleView.model = self.matchBasketDetailTopModel;
                    
                    self.focusBtn.hidden = self.matchBasketDetailTopModel.match.state == 6;
                    self.focusBtn.selected = self.matchBasketDetailTopModel.match.follow;
                });
            }
        }
    }
}

- (void)didChildsEndRefresh {
//    [self.tableView endAllFreshing];
    [self endAllFreshing:self.tableView];
}

- (void)connectScocket {
    if ([WTCSocketService instance].socketReadyState == SR_OPEN) {
        return;
    }
    NSString*timeString = [NSString stringWithFormat:@"%0.f", [[NSDate date] timeIntervalSince1970]*1000];
    [[WTCSocketService instance] SRWebSocketOpenWithURLString:[NSString stringWithFormat:@"%@/live?liveToken=%@&&time=%@&&from=ios&&matchId=%@&&version=%@&&liveType=%@",wsHostUrl,[AppConfig generateLiveToken:@"/live" time:timeString],timeString,@(self.matchId),@([AppConfig getCurrentAppVersion]).stringValue,@(1)]];
}

#pragma mark - LiveTopViewDelegate
- (void)animationLiveBtnClick {
    [ESNetworkService completeLiveTastWithResponse:^(id dict, ESError *error) {
        if (dict && [[dict objectForKey:@"code"] integerValue] == 0) {
            [MobClick event:@"match12"];
            //动画直播
            self.isLiving = YES;
            self.needShowTitleMenu = YES;
            
            [self.liveView loadRequest];
            
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:(UITableViewRowAnimationTop)];
        }
    }];
}

- (void)videoLiveBtnClick {
    [MobClick event:@"match13"];
    [ESNetworkService completeLiveTastWithResponse:^(id dict, ESError *error) {
        if (dict && [[dict objectForKey:@"code"] integerValue] == 0) {
            //视频直播
            self.isLiving = YES;
            self.needShowTitleMenu = YES;
            
            [self.liveView loadRequest];
            
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:(UITableViewRowAnimationTop)];
        }
    }];
}

- (void)backBtnClick {
    if (self.isLiving) {
        self.isLiving = NO;
        self.needShowTitleMenu = NO;
        
        dispatch_main_async_safe(^{
            [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationTop];
        });
//        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationTop];
    } else {
        [self back:nil];
    }
}

- (void)teamClick:(MatchDetailTopModel *)model isHost:(BOOL)isHost {
    TeamViewController *vc = [[TeamViewController alloc] init];
    vc.field = self.field;
    vc.teamId = isHost ? model.hostId : model.guestId;
    vc.leagueId = model.leagueId;
    vc.sourcePage = SourcePageMatch;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)leagueBtnClick {
    LeagueViewController *leagueVc = [LeagueViewController new];
    leagueVc.leagueId = self.matchDetailTopModel.leagueId;
    [self.navigationController pushViewController:leagueVc animated:YES];
}

- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

#pragma mark - MatchLiveViewDelegate
- (void)liveView:(MatchLiveView *)liveView webViewClick:(id)sender {
    self.needShowTitleMenu = !self.needShowTitleMenu;
}

#pragma mark - GallopNavigationBarDelegate
- (BOOL)navigationBar:(UINavigationBar *)navigationBar shouldReceiveTouch:(UITouch *)touch {
    if (self.field == 2) {
        if (!self.matchBasketDetailTopModel.hasIntegral) {
            return NO;
        }
    }
    if (self.offsetY / NavBarHeight > 0.3) {
        return NO;
    }
    CGPoint point = [touch locationInView:[touch view]];
    if (point.x < self.shortTitleView.x || point.x > (self.shortTitleView.x + self.shortTitleView.width)) {
        return NO;
    }
    if ([touch.view isDescendantOfView:self.navigationItem.leftBarButtonItem.customView] ||
        [touch.view isDescendantOfView:self.shareBtn] ||
        [touch.view isDescendantOfView:self.focusBtn]) {
        return NO;
    }
    return YES;
}

- (void)navigationBar:(UINavigationBar *)navigationBar didTouch:(UITouch *)touch {
    
    if (self.field == 1) {
        LeagueViewController *leagueVc = [LeagueViewController new];
        leagueVc.leagueId = self.matchDetailTopModel.leagueId;
        leagueVc.field = self.field;
        if (leagueVc.leagueId) {
            [self.navigationController pushViewController:leagueVc animated:YES];
        }
    }
    if (self.field == 2) {
        BasketLeagueViewController *leagueVc = [BasketLeagueViewController new];
        leagueVc.leagueId = self.matchBasketDetailTopModel.event.eventId;
        leagueVc.field = self.field;
        [self.navigationController pushViewController:leagueVc animated:YES];
    }
    
}

#pragma mark - timer
- (void)timeCount {
    //未开赛/已经结束不再计时
    if (self.matchDetailTopModel.status != 0 && self.matchDetailTopModel.status != 6) {
        self.matchDetailTopModel.openTime += 1;
        [self.topView configTopView:self.matchDetailTopModel];
        self.shortTitleView.model = self.matchDetailTopModel;
        self.focusBtn.selected = self.matchDetailTopModel.isFollowed;
        if (self.field == 1) {
            self.focusBtn.hidden = self.matchDetailTopModel.status == 6;
        }else {
            self.focusBtn.hidden = YES;
        }
    }
}

- (void)initTimer {
    dispatch_main_async_safe(^{
        [self destoryTimer];
        _timeCountTimer = [NSTimer timerWithTimeInterval:1 * 60 target:self selector:@selector(timeCount) userInfo:nil repeats:YES];
        [[NSRunLoop currentRunLoop] addTimer:_timeCountTimer forMode:NSRunLoopCommonModes];
    })
}

- (void)destoryTimer {
    dispatch_main_async_safe(^{
        if (_timeCountTimer) {
            if ([_timeCountTimer respondsToSelector:@selector(isValid)]){
                if ([_timeCountTimer isValid]){
                    [_timeCountTimer invalidate];
                    _timeCountTimer = nil;
                }
            }
        }
    })
}

#pragma mark - action
- (void)focusAction:(UIButton *)focusBtn {
    [MobClick event:@"match14" attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage,@"isFollow":@(!focusBtn.selected)}];
    
    [ESNetworkService focusMatch:!focusBtn.selected matchId:self.matchId response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                focusBtn.selected = !focusBtn.selected;
//                [[NSNotificationCenter defaultCenter] postNotificationName:kMatchFoucesStateChange object:@(-1)];
            });
        } else {
            if (dict && [dict[@"code"] integerValue] == NeedLoginCode) {
                [CMMUtility showToastWithText:@"请先登录再关注比赛"];
            }
        }
    }];
}

- (void)shareAction {
    //分享
    [ESNetworkService getMatchShareUrl:self.matchId response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                [self shareWithModel:dict[@"data"]];
            });
        }
    }];
}

#pragma mark -
- (void)setIsLiving:(BOOL)isLiving {
    _isLiving = isLiving;
    
    if (_isLiving) {
        self.childContentHeight = (kScreen_Height - self.liveingHeight - 40.0);
    }else {
        self.childContentHeight = (kScreen_Height - NavBarHeight - 40.0);
    }
    
    self.topView.hidden = _isLiving;
    self.tableView.scrollEnabled = !_isLiving;
    [self.childsArray enumerateObjectsUsingBlock:^(CYTabChildModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.childViewController.isLiving = _isLiving;
    }];
}

- (void)setNeedShowTitleMenu:(BOOL)needShowTitleMenu {
    _needShowTitleMenu = needShowTitleMenu;
    
    if (self.isLiving) {
        [self.navigationController setNavigationBarHidden:!_needShowTitleMenu animated:YES];
        self.navigationItem.titleView.hidden = !_needShowTitleMenu;
        self.navigationItem.titleView.alpha = _needShowTitleMenu?1.0:0.0;
        
        if (_needShowTitleMenu) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                self.needShowTitleMenu = !self.needShowTitleMenu;
            });
        }
    }else {
        [self.navigationController setNavigationBarHidden:NO animated:YES];
        [self showNavi];
    }
}

#pragma mark -
- (NSArray <CYTabChildModel *>*)getChildsArray {

    NSMutableArray <CYTabChildModel *>*childs = @[].mutableCopy;
    if (self.field == 1) {
        /// 直播
        [childs addObject:[self liveModel:@"直播"]];
        
        if (self.matchDetailTopModel.allowChat == 1) {
            [childs addObject:[self liveModel:@"聊天"]];
        }
        [childs addObjectsFromArray:@[[self liveModel:@"数据"],
                                      [self liveModel:@"情报"],
                                      [self liveModel:@"指数"],
                                      [self liveModel:@"阵容"]]];
        
        if (!self.needHidePlan) {
            [childs addObject:[self liveModel:@"方案"]];
        }
    }else {
        /// self.matchDetailTopModel.tabs[0].intValue
        ///0直播 6统计 1聊天 2数据 3情报 4指数
        if (self.matchBasketDetailTopModel.tabs[0].intValue == 1) {
            [childs addObject:[self liveModel:@"直播"]];
        }
        if (self.matchBasketDetailTopModel.tabs[6].intValue == 1) {
            [childs addObject:[self liveModel:@"统计"]];
        }
        if (self.matchBasketDetailTopModel.tabs[1].intValue == 1) {
            [childs addObject:[self liveModel:@"聊天"]];
        }
        if (self.matchBasketDetailTopModel.tabs[2].intValue == 1) {
            [childs addObject:[self liveModel:@"数据"]];
        }
        if (self.matchBasketDetailTopModel.tabs[3].intValue == 1) {
            [childs addObject:[self liveModel:@"情报"]];
        }
        if (self.matchBasketDetailTopModel.tabs[4].intValue == 1) {
            [childs addObject:[self liveModel:@"指数"]];
        }
    }

    return childs.copy;
}

/// 直播model
- (CYTabChildModel *)liveModel:(NSString *)childTitle {
    CYTabChildModel *model = [CYTabChildModel new];
    model.childTitle = childTitle;
    model.field = self.field;
    
    if ([childTitle isEqualToString:@"直播"]) {
        if (self.field == 1) {
            LiveViewController *liveViewController = [[LiveViewController alloc] init];
            liveViewController.matchId = self.matchId;
            liveViewController.delegate = self;
            
            liveViewController.hostName = self.matchDetailTopModel.hostName;
            liveViewController.guestName = self.matchDetailTopModel.guestName;
            
            model.childViewController = liveViewController;
        }else {
            BasketLiveViewController *liveViewController = [[BasketLiveViewController alloc] init];
            liveViewController.matchId = self.matchId;
            liveViewController.delegate = self;
            
            model.childViewController = liveViewController;
        }
    }else if ([childTitle isEqualToString:@"聊天"]) {
        ChatViewController *chatViewController = [[ChatViewController alloc] init];
        chatViewController.delegate = self;
        chatViewController.field = self.field;
        chatViewController.matchId = self.matchId;
        
        model.childViewController = chatViewController;
//        if (self.field == 1) {
//
//        }else {
//            BasketChatViewController *chatViewController = [[BasketChatViewController alloc] init];
//            chatViewController.delegate = self;
//            chatViewController.matchId = self.matchId;
//
//            model.childViewController = chatViewController;
//        }

    }else if ([childTitle isEqualToString:@"数据"]) {
        if (self.field == 1) {
            AnalyseViewController *analyseViewController = [[AnalyseViewController alloc] init];
            analyseViewController.delegate = self;
            analyseViewController.matchId = self.matchId;
            
            model.childViewController = analyseViewController;
        }else {
            BasketDataViewController *analyseViewController = [[BasketDataViewController alloc] init];
            analyseViewController.delegate = self;
            analyseViewController.matchId = self.matchId;
            
            model.childViewController = analyseViewController;
        }

    }else if ([childTitle isEqualToString:@"情报"]) {
        if (self.field == 1) {
            IntelligenceViewController *intelligenceViewController = [[IntelligenceViewController alloc] init];
            intelligenceViewController.delegate = self;
            intelligenceViewController.matchId = self.matchId;
            
            intelligenceViewController.hostName = self.matchDetailTopModel.hostName;
            intelligenceViewController.guestName = self.matchDetailTopModel.guestName;
            
            model.childViewController = intelligenceViewController;
        }else {
            BasketIntelligenceViewController *intelligenceViewController = [[BasketIntelligenceViewController alloc] init];
            intelligenceViewController.delegate = self;
            intelligenceViewController.matchId = self.matchId;
            
            model.childViewController = intelligenceViewController;
        }
    }else if ([childTitle isEqualToString:@"指数"]) {
        ExponentialViewController *exponentialViewController = [[ExponentialViewController alloc] init];
        exponentialViewController.delegate = self;
        exponentialViewController.matchId = self.matchId;
        exponentialViewController.field = self.field;
        
        model.childViewController = exponentialViewController;
//        if (self.field == 1) {
//
//        }else {
//            BasketExponentailViewController *exponentialViewController = [[BasketExponentailViewController alloc] init];
//            exponentialViewController.delegate = self;
//            exponentialViewController.matchId = self.matchId;
//
//            model.childViewController = exponentialViewController;
//        }
    }else if ([childTitle isEqualToString:@"阵容"]) {
        SquadViewController *squadViewController = [[SquadViewController alloc] init];
        squadViewController.delegate = self;
        squadViewController.matchId = self.matchId;
        
        model.childViewController = squadViewController;
    }else if ([childTitle isEqualToString:@"方案"]) {
        PlanViewController *planViewController = [[PlanViewController alloc] init];
        planViewController.delegate = self;
        planViewController.matchId = self.matchId;
        
        model.childViewController = planViewController;
    }else if ([childTitle isEqualToString:@"统计"]) {
        BasketStatisticViewController *statisticViewController = [[BasketStatisticViewController alloc] init];
        statisticViewController.delegate = self;
        statisticViewController.matchId = self.matchId;
        
        model.childViewController = statisticViewController;
    }
    
    return model;
}

#pragma mark - lazy init
- (LiveTopView *)topView {
    if (!_topView) {
        _topView = [LiveTopView shareInstance];
        _topView.liveTopViewDelegate = self;
    }
    return _topView;
}

- (MatchDetailShortTitleView *)shortTitleView {
    if (!_shortTitleView) {
        _shortTitleView = [MatchDetailShortTitleView shareInstance];
        _shortTitleView.field = self.field;
        _shortTitleView.hidden = YES;
    }return _shortTitleView;
}

//- (UITapGestureRecognizer *)naviTap {
//    if (!_naviTap) {
//        _naviTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(leagueBtnClick)];
//        _naviTap.delegate = self;
//    }return _naviTap;
//}

- (MatchLiveView *)liveView {
    if (!_liveView) {
        _liveView = [MatchLiveView shareInstanceWithURL:self.liveURL];
        _liveView.delegate = self;
    }return _liveView;
}

- (UIImageView *)bgView {
    if (!_bgView) {
        _bgView = [[UIImageView alloc] init];
        _bgView.contentMode = UIViewContentModeTop;
    }return _bgView;
}

- (CYTabTitleBar *)titleBarView {
    if (!_titleBarView) {
        _titleBarView = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([CYTabTitleBar class]) owner:self options:nil].lastObject;
        _titleBarView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 40.0);
        _titleBarView.sliderColor = ColorMainAppRed;
        _titleBarView.normalItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCRegular:12],
                                                             NSForegroundColorAttributeName:ColorMainNormalBlack};
        _titleBarView.selectedItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCBold:14],
                                                             NSForegroundColorAttributeName:ColorMainAppRed};
        [_titleBarView addRoundedCorners:(UIRectCornerTopLeft | UIRectCornerTopRight) withRadii:12.0];
        @weakify(self);
        _titleBarView.clickIndexBlock = ^(NSInteger index) {
            @strongify(self);
            if (self.currentIndex != index) {
                self.currentIndex = index;
                [self.titleBarController moveToControllerAtIndex:self.currentIndex animated:YES];
            }
        };
    } return _titleBarView;
}

- (CYButton *)focusBtn {
    if (!_focusBtn) {
        _focusBtn = [CYButton buttonWithType:UIButtonTypeCustom]
        .imagePrams(GetNavigationImage(@"match_unfouces_btn"), UIControlStateNormal)
        .imagePrams(GetNavigationImage(@"match_fouces_btn"), UIControlStateSelected)
        .actionPrams(self, @selector(focusAction:), UIControlEventTouchUpInside);
        _focusBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        
        _focusBtn.bounds = CGRectMake(0, 0, kNavBarHeight, kNavBarHeight);
    }
    return _focusBtn;
}

- (CYButton *)shareBtn {
    if (!_shareBtn) {
        _shareBtn = [CYButton buttonWithType:UIButtonTypeCustom]
        .imagePrams(GetNavigationImage(@"match_share_btn"), UIControlStateNormal)
        .actionPrams(self, @selector(shareAction), UIControlEventTouchUpInside);
        _shareBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        
        _shareBtn.bounds = CGRectMake(0, 0, kNavBarHeight, kNavBarHeight);
    }
    return _shareBtn;
}

- (UIStackView *)stack {
    if (!_stack) {
        _stack = [[UIStackView alloc] initWithArrangedSubviews:@[self.shareBtn, self.focusBtn]];
        _stack.spacing = 8.0;
        _stack.axis = UILayoutConstraintAxisHorizontal;
//        _stack.alignment = UIStackViewAlignmentFill;
//        _stack.distribution = UIStackViewDistributionFill;
    }return _stack;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
