//
//  MatchDetailViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/2.
//  Copyright © 2021 homosum. All rights reserved.
//
// 比赛页面
//

#import "CYBaseItemParentViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface MatchDetailViewController : CYBaseItemParentViewController

/// 1足球 2篮球
@property (nonatomic ,assign) NSInteger field;
/// 比赛ID
@property (nonatomic, assign) NSInteger matchId;
/// 是否需要隐藏方案
@property (nonatomic, assign) BOOL needHidePlan;
@property (nonatomic, strong) NSString *sourcePage;//埋点使用字段

@end

NS_ASSUME_NONNULL_END
