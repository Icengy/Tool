//
//  MatchSettingsViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/31.
//  Copyright © 2019 homosum. All rights reserved.
//
//#import "UIFont+changeFont.h"
#import "MatchSettingsViewController.h"
#import "PushSetTableViewCell.h"
#import "DetailPostButton.h"
@interface MatchSettingsViewController ()<PushSetTableViewCellDelegate>
@property (nonatomic, strong)NSNumber *isSoundEnable;
@property (nonatomic,strong)NSNumber *isVibrateEnabel;
@property (nonatomic,strong)NSNumber *isOnlyCareEnabel;
@end


@implementation MatchSettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.isSoundEnable = @(NO);
    self.isVibrateEnabel = @(NO);
    self.isOnlyCareEnabel = @(NO);
    
    self.navigationItem.title = @"比赛设置";
    
    self.dataSource = [NSMutableArray arrayWithArray:@[@"声音",@"震动",@"仅提示我关注的"]];
    
    
    [self setupView];
    [self reloadData];
    
    
    // Do any additional setup after loading the view.
}

-(void)setupView{
    [self.view setFrame:CGRectMake(0, 0, kScreen_Width, kScreen_Height)];
    
    [self.tableView setFrame:CGRectMake(15, NavBarHeight + 10, kScreen_Width-30, kScreen_Width-NavBarHeight-10)];
    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.tableView];
}
-(void)toBack
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)reloadData{
    [ESNetworkService getGoalNotfiySetting:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSDictionary*data = dict[@"data"];
            dispatch_main_async_safe(^{
                self.isOnlyCareEnabel = data[@"showRange"];
                self.isVibrateEnabel = data[@"shake"];
                self.isSoundEnable = data[@"sound"];
                [self.tableView reloadData];
            });
        }
    }];
}
-(void)didClickSwitchWithPushSetTableViewCell:(PushSetTableViewCell *)cell
{
      NSIndexPath*indexPath = [self.tableView indexPathForCell:cell];
    switch (indexPath.row) {
        case 0:
        {
            //点击switch开关声音，接口成功后改变self.isSoundEnable
            BOOL isV = ![self.isSoundEnable boolValue];
            [ESNetworkService setGoalNotify:isV shake:self.isVibrateEnabel.boolValue showAll:self.isOnlyCareEnabel.boolValue response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        self.isSoundEnable = @(isV);
                        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                    });
                }
            }];
        }
            break;
        case 1:
        {
            //震动
            BOOL isV = !self.isVibrateEnabel.boolValue;
            [ESNetworkService setGoalNotify:self.isSoundEnable.boolValue shake:isV showAll:self.isOnlyCareEnabel.boolValue response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        self.isVibrateEnabel = @(isV);
                        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                    });
                }
            }];
        }
            break;
        case 2:
        {
            //仅提示我关注的
            BOOL isV = !self.isOnlyCareEnabel.boolValue;
            [ESNetworkService setGoalNotify:self.isSoundEnable.boolValue shake:self.isVibrateEnabel.boolValue showAll:isV response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        self.isOnlyCareEnabel = @(isV);
                        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                    });
                }
            }];
        }
            break;
            
        default:
            break;
    }
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
        return self.dataSource.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *string = @"PushSetTableViewCell";
    PushSetTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:string];
    if (cell==nil) {
        cell=[[PushSetTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:string];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.delegate = self;
    cell.textL.text = self.dataSource[indexPath.row];
    NSArray*arr = @[self.isSoundEnable,self.isVibrateEnabel,self.isOnlyCareEnabel];
    cell.openS.on = [arr[indexPath.row] boolValue];
    cell.backgroundColor = [UIColor clearColor];
    return cell;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 45;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 35.0f;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView*v = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
    UILabel*titleL = [[UILabel alloc] init];
    [v addSubview:titleL];
    titleL.text = @"进球提示";
    titleL.font = GetFont(14.0);
    titleL.textColor = ColorSubTitle;
    [titleL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(v);
        make.left.mas_equalTo(v).offset(15);
    }];
    v.backgroundColor = ColorGrayBack;
    return v;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //最后一行添加圆角
    CGFloat cornerRadius = 6.0f;
    cell.backgroundColor = UIColor.clearColor;
    
    CAShapeLayer *layer = [[CAShapeLayer alloc] init];
    CAShapeLayer *backgroundLayer = [[CAShapeLayer alloc] init];
    CGMutablePathRef pathRef = CGPathCreateMutable();
    CGRect bounds = CGRectInset(cell.bounds, 0, 0);
    
    if (indexPath.row == [tableView numberOfRowsInSection:indexPath.section]-1) {
        CGPathMoveToPoint(pathRef, nil, CGRectGetMinX(bounds), CGRectGetMinY(bounds));
        CGPathAddArcToPoint(pathRef, nil, CGRectGetMinX(bounds), CGRectGetMaxY(bounds), CGRectGetMidX(bounds), CGRectGetMaxY(bounds), cornerRadius);
        CGPathAddArcToPoint(pathRef, nil, CGRectGetMaxX(bounds), CGRectGetMaxY(bounds), CGRectGetMaxX(bounds), CGRectGetMidY(bounds), cornerRadius);
        CGPathAddLineToPoint(pathRef, nil, CGRectGetMaxX(bounds), CGRectGetMinY(bounds));
    } else {
        CGPathAddRect(pathRef, nil, bounds);
    }
    layer.path = pathRef;
    backgroundLayer.path = pathRef;
    CFRelease(pathRef);
    layer.fillColor = [UIColor whiteColor].CGColor;
    
    UIView *roundView = [[UIView alloc] initWithFrame:bounds];
    [roundView.layer insertSublayer:layer atIndex:0];
    roundView.backgroundColor = UIColor.clearColor;
    cell.backgroundView = roundView;
    
    UIView *selectedBackgroundView = [[UIView alloc] initWithFrame:bounds];
    backgroundLayer.fillColor = [UIColor cyanColor].CGColor;
    [selectedBackgroundView.layer insertSublayer:backgroundLayer atIndex:0];
    selectedBackgroundView.backgroundColor = UIColor.clearColor;
    cell.selectedBackgroundView = selectedBackgroundView;
    
}

@end
