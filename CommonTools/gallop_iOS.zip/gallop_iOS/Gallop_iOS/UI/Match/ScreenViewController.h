//
//  ScreenViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface ScreenViewController : ESViewController
@property(nonatomic, strong)NSString *date;
@property(nonatomic, assign)NSInteger pageType;
@property(nonatomic, assign)NSInteger matchType;
@end
