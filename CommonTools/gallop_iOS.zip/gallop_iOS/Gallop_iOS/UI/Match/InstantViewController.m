//
//  InstantViewController.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "InstantViewController.h"
#import "InstantTableViewCell.h"
#import "BasketballTableViewCell.h"
#import "MatchInstantListModel.h"
#import "MatchTCPMessageModel.h"
#import "BasketballListModel.h"

#import "MatchDetailViewController.h"

#define kPageSize 20

@interface InstantViewController ()<MatchInstantTableCellDelegate>
@property(nonatomic, strong)UIButton *refreshBtn;

@property(nonatomic, strong)BasketballListModel *basketballModel;
@property(nonatomic, strong)NSMutableArray *dataList;
@property(nonatomic, strong)NSMutableArray *finishDataList;
@property(nonatomic, assign)NSInteger currentPage;
//当前页面是否展示(用于判断是否显示缓存的进球通知)
@property(nonatomic, assign)BOOL viewDidApper;
@end

@implementation InstantViewController
{
    NSTimer * _timeCountTimer;
    NSInteger _timeCount;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataList = [NSMutableArray array];
    self.finishDataList = [NSMutableArray array];
    self.currentPage = 1;
    
    [self setupView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveGlobalMatchUpdateTCPMessage:) name:kGlobalMatchUpdateTCPMessage object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receiveGlobalMatchUpdateTCPMessage:) name:kGlobalMatchBaskectTCPMessage object:nil];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchScreenChange:) name:kMatchScreenChange object:nil];
    [[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        //登录成功后重新请求即时列表
        dispatch_main_async_safe(^{
            [self loadData:nil];
        });
    }];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willEnterForeground) name:UIApplicationDidBecomeActiveNotification object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.viewDidApper = YES;
    [self showGoalCache];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self loadData:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.viewDidApper = NO;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view);
    }];
}

#pragma mark -
- (void)showGoalCache {
    //计算需要刷新行
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
		if (self.field != 1) {
			//篮球无进球通知
			return;
		}
        if (!self.viewDidApper) {
                return;
        }
        if (QM_IS_ARRAY_NIL([SystemManager bgGoalCache])) {
            return ;
        }
        for (MatchGoalMessageModel *model in [SystemManager bgGoalCache]) {
            __block NSInteger index = -1;
            NSInteger matchId = model.matchId;
            [self.dataList enumerateObjectsUsingBlock:^(InstantMatcth *data, NSUInteger idx, BOOL * _Nonnull stop) {
                if (data.matchId == matchId) {
                    index = idx;
                    *stop = YES;
                }
            }];
            if (index == -1) {
                return;
            }
            NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                match.hostScore = model.hostScore;
                match.guestScore = model.guestScore;
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                //进球高亮闪烁
                InstantTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
//                InstantTableCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
                if ([self.tableView.visibleCells containsObject:cell]) {
                    [cell hostOrGuestGoal:(model.hostGuest == 1 ? YES : NO)];
                }
            });
        }
        [[SystemManager bgGoalCache] removeAllObjects];
    });
}

//app 进入前台
- (void)willEnterForeground {
    if (!self.isViewLoaded || !self.view.window) {
           return;
    }
    [self loadData:nil];
}

- (void)matchScreenChange:(NSNotification *)notify {
    if (!self.isViewLoaded || !self.view.window) {
        return;
    }
    if ([notify.object integerValue] == 0) {
        //刷新列表
        [self loadData:nil];
    }
}

- (void)receiveGlobalMatchUpdateTCPMessage:(NSNotification *)notify {
    @weakify(self)
    dispatch_main_async_safe(^{
        @strongify(self)
        [self handleGlobalMatchUpdateTCPMessage:notify];
    });
}

- (void)handleGlobalMatchUpdateTCPMessage:(NSNotification *)notify {
    if (!self.isViewLoaded || !self.view.window) {
        return;
    }
    
    if ([notify.object isKindOfClass:[MatchBaskectTCPMessage class]]) {
        //篮球通知
        if (self.field == 2) {
            //不在篮球模块不处理消息
            return;
        }
        MatchBaskectTCPMessage *model = notify.object;
        dispatch_main_async_safe(^{
            for (MatchBaskectItem *item in model.data) {
                [self.dataList enumerateObjectsUsingBlock:^(BasketballItem *data, NSUInteger idx, BOOL * _Nonnull stop) {
                    if (data.matchId == item.matchId) {
                        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:idx inSection:0];
                        //进球高亮闪烁
                        NSInteger hostSum = [[data.host.scores valueForKeyPath:@"@sum.integerValue"] integerValue];
                        NSInteger hostSum1 = [[item.hostScores valueForKeyPath:@"@sum.integerValue"] integerValue];
                        NSInteger awaySum = [[data.away.scores valueForKeyPath:@"@sum.integerValue"] integerValue];
                        NSInteger awaySum1 = [[item.awayScores valueForKeyPath:@"@sum.integerValue"] integerValue];
                        //更新数据
                        data.state = item.state;
                        data.seconds = item.seconds;
                        data.host.scores = item.hostScores;
                        data.away.scores = item.awayScores;
                        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                        
                        BasketballTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
                        if (hostSum != hostSum1) {
                            [cell scroreChange:YES];
                        }
                        if (awaySum != awaySum1) {
                            [cell scroreChange:NO];
                        }
                        *stop = YES;
                    }
                }];
            }
        });
        return;
    }
    if (self.field == 1) {
        //足球通知
        __block NSInteger index = -1;
        MatchStartMessageModel *model = notify.object;
        NSInteger matchId = model.matchId;
        [self.dataList enumerateObjectsUsingBlock:^(InstantMatcth *data, NSUInteger idx, BOOL * _Nonnull stop) {
            if (data.matchId == matchId) {
                index = idx;
                *stop = YES;
            }
        }];
        if (index == -1) {
            return;
        }
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        //事件处理
        if ([notify.object isKindOfClass:[MatchStartMessageModel class]]) {
            //比赛开始
            MatchStartMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                match.status = model.status;
                if (model.status == 1 ) {
                    match.elapsedTime = 0;
                }
                if (model.status == 3) {
                    match.elapsedTime = 45;
                }
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
        if ([notify.object isKindOfClass:[MatchRedCardMessageModel class]]) {
            //红牌
            MatchRedCardMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                if (model.hostGuest == 1) {
                    //主队
                    match.hostRedCard = model.currentCount;
                } else {
                    //客队
                    match.guestRedCard = model.currentCount;
                }
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
        if ([notify.object isKindOfClass:[MatchYellowCardMessageModel class]]) {
            //黄牌
            MatchYellowCardMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                if (model.hostGuest == 1) {
                    //主队
                    match.hostYellowCard = model.currentCount;
                } else {
                    //客队
                    match.guestYellowCard = model.currentCount;
                }
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
        if ([notify.object isKindOfClass:[MatchCornerMessageModel class]]) {
            //角球
            MatchCornerMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                if (model.hostGuest == 1) {
                    //主队
                    match.hostCorner = model.currentCount;
                } else {
                    //客队
                    match.guestCorner = model.currentCount;
                }
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
        if ([notify.object isKindOfClass:[MatchGoalMessageModel class]]) {
            //进球
            MatchGoalMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                match.hostScore = model.hostScore;
                match.guestScore = model.guestScore;
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
                //进球高亮闪烁
                InstantTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
//                InstantTableCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
                [cell hostOrGuestGoal:(model.hostGuest == 1 ? YES : NO)];
            });
        }
        if ([notify.object isKindOfClass:[MatchHalfEndMessageModel class]]) {
            //半场结束
            MatchHalfEndMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                match.hostScore = model.hostScore;
                match.guestScore = model.guestScore;
                match.status = 2;
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
        if ([notify.object isKindOfClass:[MatchEndMessageModel class]]) {
            //比赛结束
            MatchEndMessageModel *model = notify.object;
            dispatch_main_async_safe(^{
                InstantMatcth *match = self.dataList[indexPath.row];
                match.hostScore = model.hostScore;
                match.guestScore = model.guestScore;
                match.status = 6;
                [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
        }
    }
}

#pragma mark - timer
- (void)timeCount {
    //未开赛/已经结束不再计时
    for (InstantMatcth *match in self.dataList) {
        if (match.status != 0 && match.status != 6) {
            match.elapsedTime += 1;
        }
    }
    [self.tableView reloadData];
    //每隔五分钟重新请求一次
    _timeCount += 1;
    if (_timeCount >= 5) {
        if (!self.isViewLoaded || !self.view.window) {
               return;
        }
        [self loadData:nil];
    }
}

- (void)initTimer {
    dispatch_main_async_safe(^{
        [self destoryTimer];
        _timeCountTimer = [NSTimer timerWithTimeInterval:1 * 60  target:self selector:@selector(timeCount) userInfo:nil repeats:YES];
        _timeCount = 0;
        [[NSRunLoop currentRunLoop] addTimer:_timeCountTimer forMode:NSRunLoopCommonModes];
    })
}

- (void)destoryTimer {
    dispatch_main_async_safe(^{
        if (_timeCountTimer) {
            if ([_timeCountTimer respondsToSelector:@selector(isValid)]){
                if ([_timeCountTimer isValid]){
                    [_timeCountTimer invalidate];
                    _timeCountTimer = nil;
                }
            }
        }
    })
}

#pragma mark - data&View
- (void)setupView {
    [self.view addSubview:self.tableView];
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.estimatedRowHeight = 170.0;

    [self.tableView registerCell:[InstantTableViewCell class]];
    [self.tableView registerCell:[BasketballTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    if (self.field == 1) {
        [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
    }
    
    [self.refreshBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.view).offset(-15);
        make.bottom.equalTo(self.view).offset(-20);
        make.size.mas_equalTo(CGSizeMake(48, 48));
    }];
}

- (void)loadData:(id)sedner {
    
    [ES_HttpService showLoading:!sedner];
    
    if (self.field == 1 && sedner && [sedner isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
	//请求列表数据
	@weakify(self)
    [ESNetworkService getInstantListWithField:self.field withPage:self.currentPage pageSize:kPageSize Response:^(id dict, ESError *error) {
        
        @strongify(self)
        [self endAllFreshing:self.tableView];
        [self destoryTimer];
        if (dict && [dict[@"code"] integerValue] == 0) {
            NSDictionary *data = [dict objectForKey:@"data"];
            if (!QM_IS_DICT_NIL(data)) {
                if (self.currentPage == 1) {
                    if (!QM_IS_ARRAY_NIL(self.dataList) || !QM_IS_ARRAY_NIL(self.finishDataList)) {
                        self.tableView.contentOffset = CGPointZero;
                    }
                    if (self.dataList.count) [self.dataList removeAllObjects];
                    if (self.finishDataList.count) [self.finishDataList removeAllObjects];
                }
                if (self.field == 1) {
                    [self configureFootballData:data];
                }else {
                    [self configureBasketballData:data];
                }
            }else {
                self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
                [self.tableView reloadData];
            }
        }
    }];
}

- (void)configureFootballData:(NSDictionary *)dict {
    MatchInstantListModel *model = [MatchInstantListModel  mj_objectWithKeyValues:dict];
    
    if (model.matchList.count) [self.dataList addObjectsFromArray:model.matchList];
    if (model.finishedMatchList.count) [self.finishDataList addObjectsFromArray:model.finishedMatchList];
    
    NSInteger netCount = model.matchList.count + model.finishedMatchList.count;
    NSInteger localCount = self.dataList.count + self.finishDataList.count;
    dispatch_main_async_safe(^{
        
        [self.tableView updataFreshFooter:(localCount && netCount < kPageSize)];
        self.tableView.mj_footer.hidden = !localCount;
        self.tableView.placeHolderText = @"当前筛选条件下暂无赛事，请重新筛选";
        [self.tableView reloadData];
        
        //开启比赛时间计时器
        [self initTimer];
        
        [self showGoalCache];
    });
}

- (void)configureBasketballData:(id)dict {
    
    BasketballListModel *model = [BasketballListModel  mj_objectWithKeyValues:dict];
    self.basketballModel = model;
    
    [self.dataList addObjectsFromArray:model.matches.ongoings];
    [self.dataList addObjectsFromArray:model.matches.unStarts];
    [self.finishDataList addObjectsFromArray:model.matches.ends];
    
    NSInteger netCount = model.matches.ongoings.count + model.matches.unStarts.count + model.matches.ends.count;
    NSInteger localCount = self.dataList.count + self.finishDataList.count;
    dispatch_main_async_safe(^{
        [self.tableView updataFreshFooter:(localCount && netCount < kPageSize)];
        self.tableView.mj_footer.hidden = !netCount;
        [self.tableView reloadData];
    });
}

#pragma mark - action
- (void)refreshBtnClick {
    
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat: M_PI * 4.0];
    rotationAnimation.duration = 1;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = 1;
    [self.refreshBtn.layer addAnimation:rotationAnimation forKey:@"rotationAnimation0"];
//    [[LPUnitily sharedManager] showGotScoreViewWithModel:nil];
//    return;
    [self loadData:nil];
}

#pragma mark - instantCellDelegate
- (void)focusStateChange:(UIButton *)focusBtn matchId:(NSInteger)matchId {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
    if (self.field == 1) {
        [MobClick event:@"match8" attributes:@{@"tab":@"即时",@"isFllow":@(!focusBtn.selected)}];
        
        BOOL focusState = focusBtn.selected;
        [ESNetworkService focusMatch:!focusState matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    [self.dataList enumerateObjectsUsingBlock:^(InstantMatcth *model, NSUInteger idx, BOOL * _Nonnull stop) {
                        if (model.matchId == matchId) {
                            model.isFollowed = !focusState;
                            [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:idx inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
                            *stop = YES;
                        }
                    }];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:kMatchFoucesStateChange object:@(!focusState)];
                });
            }
        }];
    }
    if (self.field == 2) {
        [MobClick event:@"basketball8" attributes:@{@"tab":@"即时",@"isFllow":@(!focusBtn.selected)}];
        
        NSUInteger type = (!focusBtn.selected ? 1 : 0);
        [ESNetworkService focusBasketMatch:type matchId:matchId response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    focusBtn.selected = !focusBtn.selected;
                    [[NSNotificationCenter defaultCenter] postNotificationName:kMatchFoucesStateChange object:@(type)];
                });
            }
        }];
    }
}

#pragma mark - tableView delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (self.field == 2) {
		//篮球
//		BasketballTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:BasketballTableViewCellIdentifier];
        BasketballTableViewCell *cell = [tableView dequeueReusableCell:[BasketballTableViewCell class]];
		cell.cellDelegate = self;
		if (indexPath.section == 1) {
			[cell configCellWithModel:self.finishDataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeInstant];
		} else {
			[cell configCellWithModel:self.dataList[indexPath.row] eventMap:self.basketballModel.events teamMap:self.basketballModel.teams cellType:MatchCellTypeInstant];
		}
		return cell;
	} else {
		//足球
        InstantTableViewCell *cell = [tableView dequeueReusableCell:[InstantTableViewCell class]];
        cell.cellDelegate = self;
        if (indexPath.section == 1) {
            [cell configCellWithModel:self.finishDataList[indexPath.row] cellType:MatchCellTypeInstant];
        } else {
            [cell configCellWithModel:self.dataList[indexPath.row] cellType:MatchCellTypeInstant];
        }
        return cell;
        
//		InstantTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:InstantTableViewCellIdentifier];
//		cell.selectionStyle = UITableViewCellSelectionStyleNone;
//		cell.cellDelegate = self;
//		if (indexPath.section == 1) {
//			[cell configCellWithModel:self.finishDataList[indexPath.row] cellType:MatchCellTypeInstant];
//		} else {
//			[cell configCellWithModel:self.dataList[indexPath.row] cellType:MatchCellTypeInstant];
//		}
//		return cell;
	}
}

//选中cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
    liveVC.field = self.field;
    
	if (self.field == 2) {
		//篮球
		BasketballItem *matchModel;
		if (indexPath.section == 1) {
			matchModel  = self.finishDataList[indexPath.row];
		} else {
			matchModel = self.dataList[indexPath.row];
		}
		
		liveVC.matchId = matchModel.matchId;
		liveVC.sourcePage = @"篮球比赛即时页";
    }else {
        InstantMatcth *matchModel;
        if (indexPath.section == 1) {
            matchModel  = self.finishDataList[indexPath.row];
        } else {
            matchModel = self.dataList[indexPath.row];
        }
        
        liveVC.matchId = matchModel.matchId;
        liveVC.needHidePlan = (matchModel.hasExpert == 1) ? NO : YES;
        liveVC.sourcePage = @"比赛即时页";
    }
    [self.navigationController pushViewController:liveVC animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//    if (QM_IS_ARRAY_NIL(self.finishDataList)) {
//        return 1;
//    } else {
//        return 2;
//    }
    return QM_IS_ARRAY_NIL(self.finishDataList) ? 1:2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return section == 1 ? self.finishDataList.count : self.dataList.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return section == 1 ? 30.0 : 10.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [CYView new];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *headLabel = [[UILabel alloc] init];
    if (section == 1) {
        headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 30);
        headLabel.text = @"已结束";
        headLabel.textColor = ColorMainNormalBlack;
        headLabel.textAlignment = NSTextAlignmentCenter;
        headLabel.font = GetFont(10);
        headLabel.backgroundColor = ColorDefaultLightGrayBackground;
    } else {
        headLabel.frame = CGRectMake(0, 0, SCREEN_WIDTH, 10.0);
        headLabel.backgroundColor = UIColor.clearColor;
    }
    return headLabel;
}

#pragma mark - lazy init
- (UIButton *)refreshBtn {
    if (!_refreshBtn) {
        _refreshBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_refreshBtn addTarget:self action:@selector(refreshBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [_refreshBtn setImage:GetImage(@"match_refresh_btn") forState:UIControlStateNormal];
        _refreshBtn.layer.cornerRadius = 24;
        _refreshBtn.clipsToBounds = YES;
        [self.view addSubview:_refreshBtn];
    }
    return _refreshBtn;
}

@end
