//
//  MatchPlanManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchPlanManager.h"

#import "PlanModel.h"

@implementation MatchPlanManager

- (void)loadData:(nullable id)sender {
    
    if (sender && [sender isKindOfClass:[MJRefreshFooter class]]) {
        self.pageNum ++;
    }else {
        self.pageNum = 1;
    }
    [self loadData0:sender];
}

-(void)loadData0:(id)sender {
    
    [ESNetworkService matchPlanWithPage:self.pageNum
                               PageSize:self.pageSize
                                matchId:[self.matchId longLongValue]
                               Response:^(id dict, ESError *error) {
        NSArray *array = nil;
        NSInteger code = error.code;
        BOOL hiddenFooter = YES, noMoreData = NO;
        if (dict && [dict existWithKey:@"code"]) {
            code = [[dict objectForKey:@"code"] integerValue];
            /// 重置数据
            if (!(sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]])) {
                if (self.dataSource.count) [self.dataSource removeAllObjects];
            }
            
            id da = [dict objectForKey:@"data"];
            id data = [da objectForKey:@"data"];
            if ([data isKindOfClass:[NSString class]]) {
                array = [data objectFromJSONString];
            }
            if ([data isKindOfClass:[NSArray class]]) {
                array = data;
            }
            
            for (NSDictionary *dic in array) {
                PlanModel*model = [PlanModel mj_objectWithKeyValues:dic];
                NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
                NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
                for (NSDictionary*dic_info in matchInfo) {
                    MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
                    [arrM addObject:tag];
                }
                model.matchInfoArr = [arrM copy];
                [self.dataSource addObject:model];
            }
            hiddenFooter = !self.dataSource.count;
            noMoreData = (self.dataSource.count &&
                          array.count != self.pageSize);
        }
        
        if (self.delegate&&[self.delegate respondsToSelector:@selector(manager:didEndLoadDataWithSender:isRefresh:noDataFooter:)]) {
            [self.delegate manager:self didEndLoadDataWithSender:sender isRefresh:hiddenFooter noDataFooter:noMoreData];
        }
    }];
}
@end
