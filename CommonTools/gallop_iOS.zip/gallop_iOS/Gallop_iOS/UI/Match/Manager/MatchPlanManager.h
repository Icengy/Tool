//
//  MatchPlanManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "CYBaseManager.h"

NS_ASSUME_NONNULL_BEGIN

@interface MatchPlanManager : CYBaseManager

@property (nonatomic, copy) NSString *matchId;

@end

NS_ASSUME_NONNULL_END
