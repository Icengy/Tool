//
//  FocusViewController.h
//  Gallop_iOS
//
//  Created by caizx on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface FocusViewController : ESChildViewController
//@property(nonatomic, assign)NSUInteger fllowMatchCount;
//@property(nonatomic, assign)NSUInteger fllowBasketMatchCount;

/// 1足球 2篮球
@property (nonatomic, assign) NSInteger field;

@end
