//
//  MatchHomeViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/7/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchHomeViewController.h"

#import "TYTabButtonPagerController.h"
#import "GallopMatchCategoryViewController.h"

#import "WTCGlobalSockectService.h"
#import "ScreenViewController.h"
#import "BasketScreenViewController.h"
#import "MatchSettingsViewController.h"
#import "ScheduleViewController.h"
#import "ResultViewController.h"

#import "DataViewController.h"

#import "ScreenModel.h"

@interface MatchHomeViewController () <
TYTabPagerControllerDelegate, TYPagerControllerDataSource, GallopMatchCategoryViewControllerDelegate>
@property (nonatomic, strong) UIView *switchView;
@property (nonatomic, strong) UIView *rightBarView;
@property (nonatomic, strong) CYButton *dataBtn;
@property (nonatomic, strong) CYButton *screenBtn;
@property (nonatomic, strong) CYButton *matchSettingBtn;
@property (nonatomic, strong) UILabel *redCountLabel;

@property (nonatomic ,strong) TYTabButtonPagerController *titleBarController;

@property (nonatomic, strong) NSMutableArray <CYButton *>*switchBtnArray;
@property (nonatomic, strong) NSArray *titlesArray;
@property (nonatomic, strong) NSArray *controllsArray;
@property (nonatomic, strong) NSString *seletedDate;

@property (nonatomic, assign) NSInteger currentField;//0:足球 1:篮球

@property (nonatomic, strong, readonly) GallopMatchCategoryViewController *currentCategory;

@property (nonatomic, strong) ScreenModel *screenModel;
@end



@implementation MatchHomeViewController

- (GallopMatchCategoryViewController *)currentCategory {
    return [self.controllsArray objectAtIndex:self.currentField];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = ColorMainAppRed;
    
    self.currentField = [SystemManager lastHomePageIsBasket];
    
    self.switchBtnArray = [NSMutableArray new];
    self.titlesArray = @[@"足球", @"篮球"];
    
    self.navigationItem.titleView = self.switchView;
    
    self.rightBarView = [self rightView];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.rightBarView];
    
    [self initFlipTableView];
    [self initSockectConnect];
    [self observerInit];
    
    //显示功能引导
    [self showUseGuidPage];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleRedContent;
    
    [ESNetworkService customPostionCode:@"001"];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.titleBarController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(NavBarHeight);
        make.left.right.bottom.equalTo(self.view);
    }];
}

#pragma mark -
- (UIView *)rightView {
    UIView *wrapView = [[UIView alloc] init];
    
    UIStackView *stackView = [[UIStackView alloc] initWithArrangedSubviews:@[self.matchSettingBtn, self.screenBtn]];
    stackView.spacing = 15.0;
    stackView.axis = UILayoutConstraintAxisHorizontal;
    [wrapView addSubview:stackView];
    [stackView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
    }];
    
    return wrapView;
}

- (void)jumpToData {
    DataViewController *dataVC = [DataViewController new];
    dataVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:dataVC animated:YES];
}

-(void)initFlipTableView {
    
    NSMutableArray *controllers = @[].mutableCopy;
    [self.titlesArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        GallopMatchCategoryViewController *category = [[GallopMatchCategoryViewController alloc] init];
        category.field = (idx + 1);
        category.delegate = self;
        [controllers addObject:category];
    }];
    self.controllsArray = controllers.copy;
    
    [self addChildViewController:self.titleBarController];
    [self.view addSubview:self.titleBarController.view];
}

#pragma mark - useGuidPage
- (void)showUseGuidPage {
    if([[NSUserDefaults standardUserDefaults] boolForKey:@"didShowUseGuidPage"]) {
        return;
    }
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"didShowUseGuidPage"];
    UIImageView * imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    imageView.image = GetImage(@"appUseGuidPage");
    imageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideGuidPage:)];
    [imageView addGestureRecognizer:tap];
    [[UIApplication sharedApplication].keyWindow addSubview:imageView];
}

- (void)hideGuidPage:(UITapGestureRecognizer *)tap {
    [tap.view removeFromSuperview];
}

#pragma mark - 新增观察者
- (void)observerInit {
    [[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        //登录成功后重新请求筛选接口
        dispatch_main_async_safe(^{
            [self loadScreenData:YES];
            //重建tcp链接
            [[WTCGlobalSockectService instance] SRWebSocketClose];
            [self initSockectConnect];
        });
    }];
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        //前后台切换后重新请求筛选接口
        dispatch_main_async_safe(^{
            [self initSockectConnect];
            [self loadScreenData:YES];
        });
    }];
    [[NSNotificationCenter defaultCenter] addObserverForName:kADLunchFinish object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        //广告显示完成后请求筛选接口
        dispatch_main_async_safe(^{
            [self loadScreenData:YES];
        });
    }];
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(matchScreenChange:) name:kMatchScreenChange object:nil];
    /// 手动筛选后
    [[NSNotificationCenter defaultCenter] addObserverForName:kMatchScreenChange object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        dispatch_main_async_safe(^{
            [self loadScreenData:YES];
        });
    }];
}

#pragma mark -
- (NSInteger)numberOfControllersInPagerController {
    return self.controllsArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return self.titlesArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return self.controllsArray[index];
}

- (void)pagerController:(TYTabPagerController *)pagerController didScrollToTabPageIndex:(NSInteger)index {
    if (self.currentField != index) {
        self.currentField = index;
        
        if (self.currentField == 0) {
            [MobClick event:@"match7" attributes:@{@"tab":self.titlesArray[index]}];
            [ESNetworkService customPostionCode:[NSString stringWithFormat: @"00100100%@", @(index + 1)]];
        }else{
            [MobClick event:@"basketball7" attributes:@{@"tab":self.titlesArray[index]}];
            [ESNetworkService customPostionCode:[NSString stringWithFormat: @"00100200%@", @(index + 1)]];
        }
    }
    
}

#pragma mark -
- (void)viewController:(GallopMatchCategoryViewController *)itemController didScrollToTabPageIndex:(NSInteger)index {
//    self.matchSettingBtn.hidden = (index == 3);
    self.screenBtn.hidden = (index == 3);
    [self loadScreenData:NO];
}

#pragma mark -
- (void)switchViewControllerWithField:(NSInteger)field {
    if (!self.switchBtnArray.count) return;
    if (field > self.switchBtnArray.count - 1) return;
    CYButton *btn = [self.switchBtnArray objectAtIndex:field];
    
    [self swithBtnClick:btn];
}

#pragma mark - 切换足球/篮球
- (void)swithBtnClick:(UIButton *)btn {
    if (btn.selected) {
        return;
    } else {
        btn.selected = YES;
    }
    self.currentField = btn.tag - 10000;
    
    self.matchSettingBtn.hidden = self.currentField;
    self.screenBtn.hidden = (self.currentCategory.currentIndex == 3);
    [self loadScreenData:YES];
    
    if (self.currentField == 0) {
        //足球
        UIButton *btn = [self.switchView viewWithTag:10001];
        btn.selected = NO;
    } else {
        //篮球
        UIButton *btn = [self.switchView viewWithTag:10000];
        btn.selected = NO;
    }
    [SystemManager setLastHomePageIsBasket:self.currentField];
    [self.titleBarController moveToControllerAtIndex:self.currentField animated:YES];
}

#pragma mark - sockect
- (void)initSockectConnect {
    if ([WTCGlobalSockectService instance].socketReadyState == SR_OPEN) {
        return;
    }
    NSDate*now = [NSDate date];
    NSTimeInterval a=[now timeIntervalSince1970]*1000;
    NSString*timeString = [NSString stringWithFormat:@"%0.f", a];
    [[WTCGlobalSockectService instance] SRWebSocketOpenWithURLString:[NSString stringWithFormat:@"%@/match?liveToken=%@&&time=%@&&from=ios&&userId=%@&&version=%@",wsHostUrl,[AppConfig generateLiveToken:@"/match" time:timeString],timeString,App_Utility.currentUser.userId,@([AppConfig getCurrentAppVersion]).stringValue]];
}

#pragma screen action
- (void)loadScreenData:(BOOL)firstLoad {
    if (self.currentCategory.currentIndex == 3) {
        return;
    }
    if (self.currentField == 1) {
        //篮球
        NSUInteger matchType = [SystemManager basketScreenCache][self.currentCategory.currentIndex].screenMatchType.integerValue;
        [self.screenBtn setImage:[(matchType != -1)? GetImage(@"match_screen_select"):GetImage(@"match_screen") scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        if (matchType != -1) {
            //有筛选记录(设置筛选按钮状态)
            if (firstLoad) {
                if (!self.isViewLoaded || !self.view.window) {
                    return;
                }
                //第一次进入提示
                NSArray *arr = @[@"全部",@"NBA",@"竞彩"];
                [CMMUtility showToastWithText:[NSString stringWithFormat:@"已为您筛选【%@】比赛",arr[matchType]]];
            }
        }
    } else {
        //足球筛选提示
        NSUInteger matchType = [SystemManager footBallScreenCache][self.currentCategory.currentIndex].screenMatchType.integerValue;
        [self.screenBtn setImage:[(matchType != -1)? GetImage(@"match_screen_select"):GetImage(@"match_screen") scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        if (matchType != -1) {
            //有筛选记录(设置筛选按钮状态)
            if (firstLoad) {
                if (!self.isViewLoaded || !self.view.window) {
                    return;
                }
                //第一次进入提示
                NSArray *arr = @[@"全部",@"热门",@"竞彩",@"足彩",@"单场"];
                [CMMUtility showToastWithText:[NSString stringWithFormat:@"已为您筛选【%@】比赛",arr[matchType]]];
            }
        }
    }
}

- (void)clickScreenBtn {
    
    //重新获取时间
    ESChildViewController *controller = self.currentCategory.currentChildVC;
    NSString *seletedDate;
    if ([controller isKindOfClass:[ScheduleViewController class]]) {
        seletedDate = [(ScheduleViewController *)controller selectedDate];
    }
    if ([controller isKindOfClass:[ResultViewController class]]) {
        seletedDate = [(ResultViewController *)controller selectedDate];
    }
    self.seletedDate = [CommonUtils isEqualToNonNull:seletedDate replace:@""];
    
    if (self.currentField == 0) {
        //点击筛选按钮
        ScreenViewController *screenVc = [[ScreenViewController alloc] init];
        screenVc.date = self.seletedDate;
        screenVc.pageType = self.currentCategory.currentIndex;
        screenVc.matchType = [SystemManager footBallScreenCache][self.currentCategory.currentIndex].screenMatchType.integerValue;

        [self.navigationController pushViewController:screenVc animated:YES];
    } else {
        //点击筛选按钮
        BasketScreenViewController *screenVc = [[BasketScreenViewController alloc] init];
        screenVc.date = self.seletedDate;
        screenVc.pageType = self.currentCategory.currentIndex;
        screenVc.matchType = [SystemManager basketScreenCache][self.currentCategory.currentIndex].screenMatchType.integerValue;

        [self.navigationController pushViewController:screenVc animated:YES];
    }
}

- (void)clickSettingBtn {
    [MobClick event:@"match1"];
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    MatchSettingsViewController*vc = [MatchSettingsViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - lazy init
- (UIView *)switchView {
    if (!_switchView) {

        CGFloat tagWidth = 70.0, margin = 10.0, tagHeight = 30.0;
        
        _switchView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, (tagWidth *_titlesArray.count + margin *(_titlesArray.count - 1)), tagHeight)];
        
        if (self.switchBtnArray.count) [self.switchBtnArray removeAllObjects];
        
        for (int i = 0; i < _titlesArray.count; i ++) {
            CYButton *tagBtn = [CYButton buttonWithType:UIButtonTypeCustom];
            tagBtn.frame = CGRectMake(i * (tagWidth + margin), 0.0, tagWidth, tagHeight);
            [_switchView addSubview:tagBtn];
            [tagBtn setTitle:_titlesArray[i] forState:UIControlStateNormal];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:ColorMainAppDarkRed] forState:UIControlStateSelected];
            tagBtn.titleLabel.font = [UIFont addPingFangSCMedium:16];;
            tagBtn.tag = 10000 + i;
            tagBtn.layer.cornerRadius = tagBtn.height / 2;
            tagBtn.clipsToBounds = YES;
            
            tagBtn.selected = (i == self.currentField) ? YES:NO;
            
            [tagBtn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            
            [self.switchBtnArray addObject:tagBtn];
        }
    }
    return _switchView;
}

- (CYButton *)dataBtn {
    if (!_dataBtn) {
        _dataBtn = [[CYButton alloc] initWithFrame:CGRectMake(0, 0, 70, 44)];
        [_dataBtn addTarget:self action:@selector(jumpToData) forControlEvents:UIControlEventTouchUpInside];
        [_dataBtn setTitle:@"数据" forState:UIControlStateNormal];
        [_dataBtn setTitle:@"数据" forState:UIControlStateSelected];
        _dataBtn.titleLabel.font = [UIFont addPingFangSCBold:17];
        [_dataBtn setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        [_dataBtn setImage:[UIImage imageNamed:@"match_data"] forState:UIControlStateNormal];
        [_dataBtn setImage:[UIImage imageNamed:@"match_data"] forState:UIControlStateSelected];
        _dataBtn.imageEdgeInsets = UIEdgeInsetsMake(10, 0, 10, 0);
        _dataBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _dataBtn;
}

- (CYButton *)screenBtn {
    if (!_screenBtn) {
        _screenBtn = [CYButton buttonWithType:UIButtonTypeCustom];
        _screenBtn.frame = CGRectMake(0, 0, 44.0, 44.0);
        [_screenBtn addTarget:self action:@selector(clickScreenBtn) forControlEvents:UIControlEventTouchUpInside];
        [_screenBtn setImage:[[UIImage imageNamed:@"match_screen"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _screenBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        _screenBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
    }
    return _screenBtn;
}

- (CYButton *)matchSettingBtn {
    if (!_matchSettingBtn) {
        _matchSettingBtn = [CYButton buttonWithType:UIButtonTypeCustom];
        _matchSettingBtn.frame = CGRectMake(0, 0, 44.0, 44.0);
        [_matchSettingBtn addTarget:self action:@selector(clickSettingBtn) forControlEvents:UIControlEventTouchUpInside];
        [_matchSettingBtn setImage:[[UIImage imageNamed:@"match_setting"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        [_matchSettingBtn setImage:[[UIImage imageNamed:@"match_setting"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateSelected];
        _matchSettingBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        _matchSettingBtn.hidden = self.currentField;
    }
    return _matchSettingBtn;
}

- (UILabel *)redCountLabel {
    if (!_redCountLabel) {
        _redCountLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH / 8 * 7 + 15, 2, 15, 15)];
        _redCountLabel.textColor = [UIColor whiteColor];
        _redCountLabel.font = fcBoldFont(10);
        _redCountLabel.textAlignment = NSTextAlignmentCenter;
        _redCountLabel.backgroundColor = [UIColor redColor];
        _redCountLabel.layer.cornerRadius = 7.5;
        _redCountLabel.hidden = YES;
        _redCountLabel.adjustsFontSizeToFitWidth = YES;
        _redCountLabel.clipsToBounds = YES;
    }
    return _redCountLabel;
}

- (TYTabButtonPagerController *)titleBarController {
    if (!_titleBarController) {
        _titleBarController = [[TYTabButtonPagerController alloc] init];
        _titleBarController.contentTopEdging = 0.0f;
        _titleBarController.delegate = self;
        _titleBarController.dataSource = self;
        _titleBarController.contentScrollEnabled = NO;
        
        _titleBarController.defaultIndex = self.currentField;
    }return _titleBarController;
}

@end
