//
//  MineViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MineViewController.h"
#import "SettingViewController.h"
//#import "MessageCenterViewController.h"
#import "PushMessageViewController.h"
#import "CommunityHomePageViewController.h"
#import "ApplyExpertViewController.h"
#import "ExpertViewController.h"
#import "ApplyingViewController.h"
#import "PushCenterViewController.h"
#import "PayViewController.h"
#import "HistoryBuyViewController.h"
#import "MyFaDanViewController.h"
#import "CaiJinQuanViewController.h"
#import "MyExpertsViewController.h"
#import "SelectPlanViewController.h"
#import "ExpertDetailViewController.h"
#import "MatchHomeViewController.h"
#import "MyShopOrderViewController.h"
#import "WTCContentViewController.h"
#import "AdressManagerViewController.h"
#import "ShopCartViewController.h"
#import "ShopViewController.h"
#import "MyGradeCenterViewController.h"
//manager
#import "ImageDeliverManager.h"
//view
//#import "CYButton.h"
#import "MineTableViewCell.h"
#import "MineInviteTableCell.h"
//分享
#import "ESShareViewController.h"

#import "MineTableHeadView.h"
#import "CYCommonListHeaderView.h"

#define kMineTableHeadHeight (15.0+SCREEN_WIDTH *(60.0/375.0)+30.0+80.0+16.0)

@interface MineViewController ()<MineTableViewCellDelegate, UITableViewDelegate, UITableViewDataSource, MineTableHeadDelegate>

@property (nonatomic, strong) CYButton *messageB;
@property (nonatomic, strong) CYButton *settingB;

@property (nonatomic, strong) UILabel *redLabel;

@property (weak, nonatomic) IBOutlet CYBaseTableView *contentView;

@property (nonatomic ,strong) MineTableHeadView *tableHeadView;
/// 记录tableView的偏移量
@property (nonatomic ,assign) CGFloat offsetY;

@end

@implementation MineViewController

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.fd_prefersNavigationBarHidden = NO;
    
    self.offsetY = 0.0;
    [self.dataSource addObjectsFromArray:@[@"已购方案",@"推送设置",@"服务中心"]];
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogin:) name:kESDidLoginNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogout:) name:kESDidLogoutNotification object:nil];
    
    [self setupView];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleImageContent;
    
    [self showNavi];
    //埋点
    [ESNetworkService customPostionCode:@"005"];

    // 数据获取
    [self loadData:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

- (void)appDidLogin:(NSNotification *)notification {
    [self loadData:nil];
}

- (void)appDidLogout:(NSNotification *)notification {
    [self.contentView reloadData];
}

- (void)setupView {

    self.contentView.backgroundColor = ColorDefaultGrayBackground;
    
    self.contentView.delegate = self;
    self.contentView.dataSource = self;
    self.contentView.estimatedSectionFooterHeight = CGFLOAT_MIN;
    self.contentView.estimatedSectionHeaderHeight = self.tableHeadView.height;
    if (@available(iOS 11.0, *)) {
        self.contentView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    
    [self.contentView registerCell:[MineInviteTableCell class]];
    [self.contentView registerNibCell:[MineTableViewCell class]];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.messageB];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.settingB];
    
    [self.contentView addRefreshHeaderWithTarget:self textColor:UIColor.whiteColor action:@selector(loadData:)];
    
    /// 背景图
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectOffset(self.view.bounds, 0, -self.view.bounds.size.height)];
        bgView.contentMode = UIViewContentModeScaleAspectFill;
        bgView.image =  GetImage(@"head_bg_single");
        
        [self.contentView insertSubview:bgView atIndex:0];
    });
}

-(void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    //获取反馈未读数
    [ES_LPUnitily.feedbackKit getUnreadCountWithCompletionBlock:^(NSInteger unreadCount, NSError *error) {
        App_Utility.currentUser.feedbackMessageCount = @(unreadCount);
    }];
    //获取用户信息
    __weak MineViewController *weakSelf = self;
    [ESNetworkService getSelfMessageResponse:^(id dict, ESError *error) {
        [weakSelf endAllFreshing:weakSelf.contentView];
        
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSDictionary*data = dict[@"data"];
            App_Utility.currentUser.userName = data[@"userName"];
            App_Utility.currentUser.level = data[@"level"];
            if (!data[@"level"]) {
                App_Utility.currentUser.level = @(1);
            }
            App_Utility.currentUser.avatar  = data[@"avatar"];
            App_Utility.currentUser.gallopAccountAmount = data[@"gallopAccountAmount"];
            App_Utility.currentUser.couponAmount = data[@"couponAmount"];
            App_Utility.currentUser.pushMessageCount = data[@"pushMessageCount"];
            App_Utility.currentUser.interactMessageCount = data[@"interactMessageCount"];
            App_Utility.currentUser.messageCount = data[@"messageCount"];
            App_Utility.currentUser.gallopIndex = data[@"gallopIndex"];
            App_Utility.currentUser.allRedIndex = data[@"allRedIndex"];
            App_Utility.currentUser.hasUnreadMessage = data[@"hasUnreadMessage"];
            App_Utility.currentUser.notPayedOrderCount = data[@"notPayedOrderCount"];
            App_Utility.currentUser.notConsignedOrderCount = data[@"notConsignedOrderCount"];
            App_Utility.currentUser.consignedOrderCount = data[@"consignedOrderCount"];
            App_Utility.currentUser.signature = data[@"signature"];
            App_Utility.currentUser.cartSkuCount = data[@"cartSkuCount"];
            [App_Utility saveCurrentUser];
            dispatch_main_async_safe((^{
//                weakSelf.nameL.text = App_Utility.currentUser.userName;
//                weakSelf.levelLabel.text = [@"LV" stringByAppendingFormat:@"%@",App_Utility.currentUser.level];
//                NSArray *colorArr = @[RGBCOLOR(148, 176, 125),RGBCOLOR(0, 145, 255),RGBCOLOR(144, 19, 254),RGBCOLOR(255, 125, 0),RGBCOLOR(253, 2, 48)];
//                weakSelf.levelLabel.backgroundColor = colorArr[((App_Utility.currentUser.level.integerValue - 1) / 4)];
//                weakSelf.detailL.text = App_Utility.currentUser.signature;
//                NSString*avatar_url =  App_Utility.currentUser.avatar;
//                if (!QM_IS_STR_NIL(avatar_url)) {
//                    [weakSelf.headImageV sd_setImageWithURL:[NSURL URLWithString:avatar_url] placeholderImage:[UIImage imageNamed:@"avatar"]];
//                }
                [weakSelf.tableHeadView reloadData];
                if (App_Utility.currentUser.pushMessageCount.intValue > 0) {
                    self.redLabel.hidden=NO;
                    self.redLabel.text = ( App_Utility.currentUser.pushMessageCount.intValue > 99 ? @"99+" : App_Utility.currentUser.pushMessageCount.stringValue);
                }else{
                    self.redLabel.hidden = YES;
                }
                
//                weakSelf.coinL.text  = [NSString stringWithFormat:@"%ld",App_Utility.currentUser.gallopAccountAmount.integerValue] ;
//                weakSelf.quanL.text = [NSString stringWithFormat:@"%d",App_Utility.currentUser.couponAmount.intValue];
                
                [weakSelf.dataSource removeAllObjects];
                if (App_Utility.currentUser.role.integerValue !=3 && App_Utility.currentUser.role.integerValue !=7) {
                    [weakSelf.dataSource addObjectsFromArray:@[@"已购方案",@"推送设置",@"服务中心", @"专家申请"]];
                }else{
                    [weakSelf.dataSource addObjectsFromArray:@[@"已购方案",@"推送设置",@"服务中心"]];
                }
                [weakSelf.contentView reloadData];
            }));
        }
    }];
}

- (void)showNavi {
    CGFloat alpha = self.offsetY / NavBarHeight;
    
    self.navigationController.navigationBar.translucent = (alpha >= 1.0f) ? NO : YES;
    UIImage *image = [UIImage imageNamed:@"head_bg_single"];
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *barApp = self.navigationController.navigationBar.standardAppearance;
        barApp.backgroundImage = [UIImage changeAlphaOfImageWith:alpha withImage:image];
        
        self.navigationController.navigationBar.standardAppearance = barApp;
//        self.navigationController.navigationBar.scrollEdgeAppearance = barApp;
    }else {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage changeAlphaOfImageWith:alpha withImage:image] forBarMetrics:UIBarMetricsDefault];
    }
}

#pragma mark - collectionView delegate
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return  CGSizeMake((SCREEN_WIDTH - 60) / 4.0, 33);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    return  UIEdgeInsetsMake(0, 10, 0, 27);
}

#pragma mark - action
- (void)goGradeCenter {
    //等级中心
    MyGradeCenterViewController *vc = [[MyGradeCenterViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)goHomePage {
    //个人资料
    CommunityHomePageViewController*vc= [CommunityHomePageViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)goQuan:(id)tap{
    CaiJinQuanViewController*vc = [CaiJinQuanViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)pay:(id)tap
{
    PayViewController*vc = [PayViewController new];
    
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)goSetting{
    SettingViewController *vc = [SettingViewController new];
    
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)goMessageCenter {
    //埋点
    [ESNetworkService customPostionCode:@"005004"];
    
    PushMessageViewController *vc = [PushMessageViewController new];
    
    [self.navigationController pushViewController:vc animated:YES];
//    MessageCenterViewController*vc = [MessageCenterViewController new];
//    [vc setHidesBottomBarWhenPushed:YES];
//    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - 微信分享
- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

#pragma mark - 服务中心
- (void)openFeedBackPage {
    NSString *userId = App_Utility.currentUser.userId.stringValue;
    ES_LPUnitily.feedbackKit.extInfo = @{@"loginTime":[[NSDate date] description],
                                         @"visitPath":@"登陆->关于->反馈",
                                         @"userid":QM_STR_NOT_NIL(userId)};
    __weak typeof(self) weakSelf = self;
    [ES_LPUnitily.feedbackKit makeFeedbackViewControllerWithCompletionBlock:^(YWFeedbackViewController *viewController, NSError *error) {
        if (viewController != nil) {
            [weakSelf.navigationController pushViewController:viewController animated:YES];
            [viewController setCloseBlock:^(UIViewController *aParentController){
                [aParentController.navigationController popViewControllerAnimated:YES];
            }];
        }
    }];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (App_Utility.currentUser.role.integerValue !=3 && App_Utility.currentUser.role.integerValue !=7) {
        return 3;
    }
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 1: {
            MineTableViewCell *cell = [tableView dequeueReusableCell:[MineTableViewCell class]];
            cell.style = 0;
            [cell configCellWithArr:self.dataSource];
            cell.delegate = self;
            return cell;
        }
            break;
        case 2:{
//            if ([CommonUtils canShowWXAbout]) {
                MineInviteTableCell *cell = [tableView dequeueReusableCell:[MineInviteTableCell class]];
                return cell;
//            }else {
//                //显示专家服务
//                MineTableViewCell *cell = [tableView dequeueReusableCell:[MineTableViewCell class]];
//                cell.style = 1;
//                cell.delegate = self;
//                [cell configCellWithArr:@[@"发布方案",@"发单记录",@"专家主页",@"专家设置" ,@"专家指南"]];
//                return cell;
//            }
        }
            break;
        case 3: {
            //显示专家服务
            MineTableViewCell *cell = [tableView dequeueReusableCell:[MineTableViewCell class]];
            cell.style = 1;
            cell.delegate = self;
            [cell configCellWithArr:@[@"发布方案",@"发单记录",@"专家主页",@"专家设置" ,@"专家指南"]];
            return cell;
        }
            break;
        default:
            break;
    }
    return [UITableViewCell new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) return CGFLOAT_MIN;
    if (indexPath.section == 2) return 50.0;
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) return self.tableHeadView.height;
    if (section == 1 || section == 3) return 40.0;
    
    return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) return self.tableHeadView;
    if (section == 1 || section == 3) {
        CYCommonListHeaderView *textHeader = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([CYCommonListHeaderView class]) owner:nil options:nil].lastObject;
        textHeader.frame = CGRectMake(0, 0, tableView.width, 40);
        textHeader.titleLabel.text = (section == 1)?@"用户服务":@"专家服务";
        return textHeader;
    }
    return [UIView new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0 || section == (tableView.numberOfSections - 1)) return CGFLOAT_MIN;
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 2) {
        //邀请好友
        [ESNetworkService getShareUrl:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    [self shareWithModel:dict[@"data"]];
                });
            }
        }];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    self.offsetY = scrollView.contentOffset.y;
    
    [self showNavi];
}

#pragma mark - MineTableCellDelegate
- (void)shopServItemSeleted:(NSUInteger)index {
    if (index == 0) {
        ShopViewController *vc = [ShopViewController new];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (index == 1) {
        //跳转购物车
        ShopCartViewController *vc = [[ShopCartViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (index == 2) {
        //我的订单
        MyShopOrderViewController *vc = [[MyShopOrderViewController alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    } else if (index == 3) {
        //地址管理
        AdressManagerViewController *vc = [[AdressManagerViewController alloc] init];
        vc.enterType = EnterTypeManager;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)userServItemSeleted:(NSUInteger)index {
    switch (index) {
        case 0:
        {
            //已购方案
            HistoryBuyViewController*vc = [HistoryBuyViewController new];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1:
        {
            //推送设置
            [self.navigationController pushViewController:[[PushCenterViewController alloc] init] animated:YES];
            //埋点
            [ESNetworkService customPostionCode:@"005004"];
        }
            break;
        case 2:
        {
            //服务中心
            [self openFeedBackPage];
        }
            break;
//        case 3:
//        {
//            //埋点
//            [MobClick event:@"expert2"];
//            [ESNetworkService customPostionCode:@"005001"];
//
//            //关注专家
//            if (![App_Utility checkCurrentUser]) {
//                [App_Utility showLoginViewController];
//            }else{
//                MyExpertsViewController*vc = [MyExpertsViewController new];
//                vc.hidesBottomBarWhenPushed = YES;
//                [self.navigationController pushViewController:vc animated:YES];
//            }
//        }
//            break;
//        case 4:
//        {
//            //关注比赛
//            APP_DELEGATE.window.rootViewController = APP_DELEGATE.matchTabBarVC;
//            WTCTabBarViewController*tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
//            tabBarVC.selectedIndex = 0;
//            MatchHomeViewController *vc = ((UINavigationController *)tabBarVC.childViewControllers[0]).viewControllers[0];
////            [vc.segment.segmentToolView setDefaultIndex:4];
////            [vc.segment.bgScrollView setContentOffset:CGPointMake(SCREEN_WIDTH * 3, 0)];
//            [vc segementSeletedChange:3];
//        }
//            break;
        case 3 : {
            [ESNetworkService getExpertInfoResponse:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    NSDictionary*data = dict[@"data"];
                    NSInteger applyStatus = [data[@"applyStatus"] integerValue];
                    NSInteger userRole = [data[@"userRole"] integerValue];
                    App_Utility.currentUser.role = data[@"userRole"];
                    if (userRole!=3&&userRole!=7) {
                        switch (applyStatus) {
                            case 2://申请失败
                            {
                                dispatch_main_async_safe(^{
                                    ApplyingViewController*vc = [ApplyingViewController new];
                                    vc.text = data[@"applyResultDesc"];
                                    vc.isRefused = 1;
                                    [self.navigationController pushViewController:vc animated:YES];
                                });
                            }
                                break;
                            case -1://未申请
                            {
                                ApplyExpertViewController*vc = [ApplyExpertViewController new];
                                dispatch_main_async_safe(^{
                                    [self.navigationController pushViewController:vc animated:YES];
                                });
                            }
                                break;
                            case 0:{
                                //申请中
                                ApplyingViewController*vc = [ApplyingViewController new];
                                vc.text = data[@"applyResultDesc"];
                                vc.isRefused = 0;
                                dispatch_main_async_safe(^{
                                    [self.navigationController pushViewController:vc animated:YES];
                                });
                            }
                            default:
                                break;
                        }
                    }else{
                        dispatch_main_async_safe(^{
                            [CMMUtility showToastWithText:@"专家申请已通过"];
                            //刷新页面
                            [self loadData:nil];
                        });
                    }
                }
            }];
        }
            break;
        default:
            break;
    }
}

- (void)expertServItemSeleted:(NSUInteger)index {
    switch (index) {
        case 0: {
            //发布方案
            [MobClick event:@"expert8"];
            [ESNetworkService sendPreNewResponse:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        SelectPlanViewController*vc = [SelectPlanViewController new];
                        [self.navigationController pushViewController:vc animated:YES];
                    });
                    
                }
            }];
        }
            break;
        case 1: {
            //发单记录
            MyFaDanViewController*vc = [MyFaDanViewController new];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 2: {
            //专家主页
            ExpertDetailViewController*vc = [ExpertDetailViewController new];
            vc.expertId = [NSString stringWithFormat:@"%@",App_Utility.currentUser.userId];
            vc.sourcePage = @"我的";
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 3: {
            //专家资料
            [ESNetworkService getExpertInfoResponse:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        NSDictionary*data = dict[@"data"];
                        App_Utility.currentUser.role = data[@"userRole"];
                        ExpertViewController*vc = [ExpertViewController new];
                        vc.expertName = data[@"expertName"];
                        vc.avatarUrl = data[@"expertAvatar"];
                        vc.introduction = data[@"introduction"];
                        vc.detailT = data[@"applyResultDesc"];
                        [self.navigationController pushViewController:vc animated:YES];
                    });
                }
            }];
        }
            break;
        case 4: {
            /// 专家指南
            WTCContentViewController *vc = [WTCContentViewController new];
            vc.url = @"https://yy.feichitiyu.com/2021/05/%e4%b8%93%e5%ae%b6%e6%8c%87%e5%8d%97-2";
            vc.contentType = WTCContentTypeNav;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - MineTableHeadDelegate
// 充值
- (void)head:(MineTableHeadView *)head didClickToRecharge:(id)sender {
    [self pay:nil];
}

// 查看优惠券
- (void)head:(MineTableHeadView *)head didClickToSeeQuan:(id)sender {
    [self goQuan:nil];
}

// 查看用户详情
- (void)head:(MineTableHeadView *)head didClickToUserDetail:(id)sender {
    [self goHomePage];
}

#pragma mark - lazy init
//-(UIView*)headView
//{
//    if (!_headView) {
//        _headView = [[UIView alloc] init];
//    }
//    return _headView;
//}

- (MineTableHeadView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [MineTableHeadView shareInstance];
        _tableHeadView.delegate = self;
        _tableHeadView.frame = CGRectMake(0, 0, SCREEN_WIDTH, kMineTableHeadHeight + NavBarHeight);
    }return _tableHeadView;
}

//-(UIView*)headContentView {
//    if (!_headContentView) {
//        _headContentView = [UIView new];
//        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goHomePage)];
//        [_headContentView addGestureRecognizer:tap];
//        [self.headView addSubview:_headContentView];
//    }
//    return _headContentView;
//}

//-(UIView*)downView
//{
//    if (!_downView) {
//        _downView = [[UIView alloc] init];
//        [self.headView addSubview:_downView];
//    }
//    return _downView;
//}

//-(UIView*)gradeView
//{
//    if (!_gradeView) {
//        _gradeView = [[UIView alloc] init];
//        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goGradeCenter)];
//        [_gradeView addGestureRecognizer:tap];
//        [self.headView addSubview:_gradeView];
//        //
//        UIImageView *iconView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 15, 60, 60)];
//        iconView.image = GetImage(@"签到中心");
//        [_gradeView addSubview:iconView];
//        //
//        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(96, 33, 73, 24)];
//        titleLabel.text = @"签到中心";
//        titleLabel.textColor = ColorAppBlack;
//        titleLabel.font = fcFont(16);
//        [_gradeView addSubview:titleLabel];
//        //
//        UILabel *titleLabel2 = [[UILabel alloc] initWithFrame:CGRectMake(180, 33, 73, 24)];
//        titleLabel2.text = @"每日任务";
//        titleLabel2.textColor = ColorAppBlack;
//        titleLabel2.font = fcFont(16);
//        [_gradeView addSubview:titleLabel2];
//        //分割线
//        UIView *sepLine = [[UIView alloc] initWithFrame:CGRectMake(169, 35, 2, 20)];
//        sepLine.backgroundColor = ColorGrayBack;
//        [_gradeView addSubview:sepLine];
//
//        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, 90, SCREEN_WIDTH, 5)];
//        line.backgroundColor = ColorGrayBack;
//        [_gradeView addSubview:line];
//        //
//        UIImageView *detailArrow = [[UIImageView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 22, 38, 7, 14)];
//        detailArrow.image = GetImage(@"go_arrow");
//        [_gradeView addSubview:detailArrow];
//    }
//    return _gradeView;
//}

//-(UILabel*)nameL
//{
//    if (!_nameL) {
//        _nameL = [UILabel new];
//        _nameL.textColor = ColorAppBlack;
//        _nameL.font = fcBoldFont(18.0f);
//        [self.headContentView addSubview:_nameL];
//    }
//    return _nameL;
//}
//- (UILabel *)levelLabel {
//    if (!_levelLabel) {
//        _levelLabel = [UILabel new];
//        _levelLabel.font = fcBoldFont(12);
//
//        _levelLabel.textColor = [UIColor whiteColor];
//        _levelLabel.textAlignment = NSTextAlignmentCenter;
//        _levelLabel.layer.cornerRadius = 4;
//        _levelLabel.clipsToBounds = YES;
//        [self.headContentView addSubview:_levelLabel];
//    }
//    return _levelLabel;
//}
//-(UIImageView*)headImageV
//{
//    if (!_headImageV) {
//        _headImageV = [UIImageView new];
//        [self.headContentView addSubview:_headImageV];
//    }
//    return _headImageV;
//}
//-(UILabel*)detailL
//{
//    if (!_detailL) {
//        _detailL = [UILabel new];
//        _detailL.textColor = RGBCOLOR(168, 168, 168);
//        _detailL.font = fcFont(12.0f);
//        [self.headContentView addSubview:_detailL];
//    }
//    return _detailL;
//}
//
//- (UIImageView *)detailArrow {
//    if (!_detailArrow) {
//        _detailArrow = [UIImageView new];
//        _detailArrow.image = GetImage(@"go_arrow");
//        [self.headContentView addSubview:_detailArrow];
//    }
//    return _detailArrow;
//}
//
//-(UILabel*)feiL
//{
//    if (!_feiL) {
//        _feiL = [UILabel new];
//        _feiL.font = fcFont(8.0f);
//        [self.headView addSubview:_feiL];
//    }
//    return _feiL;
//}
-(CYButton*)settingB {
    if(!_settingB){
        _settingB = [CYButton buttonWithType:UIButtonTypeCustom];
        _settingB.frame = CGRectMake(0, 0, 44, 44);
        [_settingB setImage:[[UIImage imageNamed:@"设置"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _settingB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [_settingB addTarget:self action:@selector(goSetting) forControlEvents:UIControlEventTouchUpInside];
    }
    return _settingB;
}

-(CYButton*)messageB {
    if(!_messageB){
        _messageB = [CYButton buttonWithType:UIButtonTypeCustom];
        _messageB.frame = CGRectMake(0, 0, 44, 44);
        _messageB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_messageB setImage:[[UIImage imageNamed:@"消息中心"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        [_messageB addTarget:self action:@selector(goMessageCenter) forControlEvents:UIControlEventTouchUpInside];
        [_messageB addSubview:self.redLabel];
        [self.redLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(_messageB.imageView.mas_right);
            make.centerY.equalTo(_messageB.imageView.mas_top);
            make.size.mas_equalTo(CGSizeMake(12, 12));
        }];
//        [self.headView addSubview:_messageB];
    }
    return _messageB;
}

//-(UIImageView*)rechargeV
//{
//    if (!_rechargeV) {
//        _rechargeV = [UIImageView new];
//        [self.downView addSubview:_rechargeV];
//    }
//    return _rechargeV;
//}
//-(UILabel*)coinL
//{
//    if (!_coinL) {
//        _coinL = [UILabel new];
//        _coinL.textColor = ColorAppBlack;
//        _coinL.font = fcFont(14.0f);
//        [self.downView addSubview:_coinL];
//    }
//    return _coinL;
//}
//-(UILabel*)daijinquanL
//{
//    if (!_daijinquanL) {
//        _daijinquanL = [UILabel new];
//        _daijinquanL.textColor = ColorSubTitle;
//        _daijinquanL.font = fcFont(14.0f);
//        [self.downView addSubview:_daijinquanL];
//    }
//    return _daijinquanL;
//}
//-(UILabel*)feichiL
//{
//    if (!_feichiL) {
//        _feichiL = [UILabel new];
//        _feichiL.textColor = ColorSubTitle;
//        _feichiL.font = fcFont(14.0f);
//        [self.downView addSubview:_feichiL];
//    }
//    return _feichiL;
//}
//-(UILabel*)quanL
//{
//    if (!_quanL) {
//        _quanL = [UILabel new];
//        _quanL.textColor = ColorAppBlack;
//        _quanL.font = fcFont(14.0f);
//        [self.downView addSubview:_quanL];
//    }
//    return _quanL;
//}
-(UILabel*)redLabel
{
    if (!_redLabel) {
        _redLabel = [[UILabel alloc] init];
        _redLabel.textColor = ColorMainAppRed;
        _redLabel.font = [UIFont addPingFangSCBold:7];
        _redLabel.textAlignment = NSTextAlignmentCenter;
        _redLabel.backgroundColor = [UIColor whiteColor];
        _redLabel.layer.cornerRadius = 6;
        _redLabel.hidden = YES;
        _redLabel.adjustsFontSizeToFitWidth = YES;
        _redLabel.clipsToBounds = YES;
    }
    return _redLabel;
}

@end
