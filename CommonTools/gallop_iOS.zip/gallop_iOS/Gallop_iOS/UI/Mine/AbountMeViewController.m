//
//  AbountMeViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/9/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "AbountMeViewController.h"
#import "WTCContentViewController.h"



@interface AbountMeViewController ()
@property (nonatomic,strong) UIImageView *titleIconView;
@property (nonatomic,strong) UILabel *titleL;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UIView*headV;
@end

@implementation AbountMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"关于我们";

    [self.dataSource addObjectsFromArray:@[@"飞驰体育用户服务协议",@"隐私政策"]];

    [self setUpView];
}

- (void)setUpView {
    [self.headV setFrame:CGRectMake(0, 0, kScreen_Width,200)];
    [self.titleIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headV).offset(30 + NavBarHeight);
        make.size.mas_equalTo(CGSizeMake(80, 80));
        make.centerX.equalTo(self.headV);
    }];
    [self.titleL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleIconView.mas_bottom).offset(20);
        make.centerX.equalTo(self.headV);
    }];
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleL.mas_bottom).offset(10);
        make.centerX.equalTo(self.headV);
        make.width.mas_equalTo(SCREEN_WIDTH - 40);
    }];
    CGFloat height = [LPUnitily getHeightFromString:self.contentLabel.text font:self.contentLabel.font width:self.contentLabel.bounds.size.width];
    [self.headV setFrame:CGRectMake(0, 0, kScreen_Width, height*2+200)];
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(0);
        make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
        make.centerX.equalTo(self.view);
        make.width.mas_equalTo(SCREEN_WIDTH);
    }];
    self.tableView.tableHeaderView = self.headV;
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    
    cell.layoutMargins = UIEdgeInsetsZero;
    
    NSString *content = [self.dataSource objectAtIndex:indexPath.row];
    cell.textLabel.text = content;
    cell.textLabel.font = GetFont(12.0f);
    cell.textLabel.textColor = ColorSubTitle;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([btn isKindOfClass:[UIButton class]]) {
            [btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([imgView isKindOfClass:[UIImageView class]]) {
                    UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                    imgView.image = image;
                    imgView.tintColor = ColorAppRed;
                }
            }];
        }
    }];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 45.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO];
    switch (indexPath.row) {
        case 0:
        {
            //url
            WTCContentViewController*vc = [WTCContentViewController new];
            vc.url = @"http://common.feichitiyu.com/pages/agreements/userService.html";
            vc.hidesBottomBarWhenPushed = YES;
            vc.contentType = WTCContentTypeNav;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1:
        {
            //url
            WTCContentViewController*vc = [WTCContentViewController new];
            vc.url = @"http://common.feichitiyu.com/pages/agreements/privacy.html";
            vc.hidesBottomBarWhenPushed = YES;
            vc.contentType = WTCContentTypeNav;
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 2:
        {
        }
            break;
        default:
            break;
    }
}

#pragma mark - lazy init
- (UIImageView *)titleIconView {
    if (!_titleIconView) {
        _titleIconView = [UIImageView new];
        _titleIconView.image = GetImage(@"app_icon");
        [self.headV addSubview:_titleIconView];
    }
    return _titleIconView;
}
-(UIView*)headV
{
    if (!_headV) {
        _headV = [[UIView alloc] init];
        
    }
    return _headV;
}
- (UILabel *)titleL {
    if (!_titleL) {
        _titleL = [UILabel new];
        _titleL.text = @"飞驰体育";
        _titleL.textColor = RGBCOLOR(168, 168, 168);
        _titleL.font = GetFont(14);
        _titleL.textAlignment = NSTextAlignmentCenter;
        [self.headV addSubview:_titleL];
    }
    return _titleL;
}

- (UILabel *)contentLabel {
    if (!_contentLabel) {
        _contentLabel = [UILabel new];
        _contentLabel.text = @"飞驰体育是一款体育赛事数据咨询服务app,为广大体育爱好者提供赛程是即时比分、动画直播、聊天互动、赛事资料库、赛事分析,专家解读等服务。\n\n【即时比分】\n极速的赛事动画直播,比赛信息即时同步\n【赛事资料库】\n全面的历史数据,数据库覆盖全球1000多联赛。详细数据分析,包括赛前情报动向、历史比对分析等\n【全球指数】\n各公司最新指数,实时动态,独家走势分析\n【独家情报】\n伤停、转会、必发,国外情报一手掌握\n【专家解读】\n国内外专业资深人士,对比赛各个细节进行更全面,更细致的分析解读,只为你更好理解比赛情况";
        _contentLabel.textColor = RGBCOLOR(58, 58, 58);
        _contentLabel.font = GetFont(12);
        _contentLabel.numberOfLines = 0;
        [_contentLabel setLabelSpace:4 withFont:GetFont(12)];
        [self.headV addSubview:_contentLabel];
    }
    return _contentLabel;
}

@end
