//
//  SettingViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/16.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface SettingViewController : ESViewController

@end

NS_ASSUME_NONNULL_END
