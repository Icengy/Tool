//
//  SettingViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/16.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SettingViewController.h"
#import "WTCTabBarViewController.h"
#import "AbountMeViewController.h"
#import <SDWebImage/SDImageCache.h>

@interface SettingViewController ()

@end

@implementation SettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
    [self.dataSource addObjectsFromArray:@[@"清理缓存",@"关于我们"]];
    
    [self setupView];
}

-(void)setupView{
	self.navigationItem.title = @"设置";
    
    self.tableView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 67, 0);
    self.tableView.separatorInset = UIEdgeInsetsZero;
    self.tableView.layoutMargins = UIEdgeInsetsZero;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = ColorGrayBack;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"SettingTabelCell"];
    [self.view addSubview:self.tableView];
    [self addFooterView];
    
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentAutomatic;
    }
    
}
-(void)addFooterView{
    UIView*footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 55)];
    footerView.backgroundColor = [UIColor whiteColor];
    UIView*line1 = [UIView new];
    [footerView addSubview:line1];
    line1.backgroundColor = ColorGrayBack;
    UIView*line2 = [UIView new];
    [footerView addSubview:line2];
    line2.backgroundColor = ColorGrayBack;
    UIButton*cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [cancelButton setTitle:@"退出登录" forState:UIControlStateNormal];
    [cancelButton.titleLabel setFont:fcFont(16)];
    [cancelButton setTitleColor:ColorAppRed forState:UIControlStateNormal];
    [footerView addSubview:cancelButton];
    [line1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.mas_equalTo(footerView).offset(0);
        make.height.mas_equalTo(@(5));
    }];
    [cancelButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(footerView).offset(0);
        make.top.mas_equalTo(line1.mas_bottom).offset(0);
        make.height.mas_equalTo(@(50));
    }];
    [line2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.mas_equalTo(footerView).offset(0);
		make.height.mas_equalTo(@(0.5));
    }];
    [cancelButton addTarget:self action:@selector(logout:) forControlEvents:UIControlEventTouchUpInside];
    self.tableView.tableFooterView = footerView;
}
-(void)logout:(id)sender{
    [UIAlertView bk_showAlertViewWithTitle:@"确定退出？" message:nil cancelButtonTitle:@"取消" otherButtonTitles:@[@"确定"] handler:^(UIAlertView *alertView, NSInteger buttonIndex) {
        if (buttonIndex == 1) {
            [ESNetworkService logoutResponse:^(id dict, ESError *error) {
                if (dict && [dict[@"code"] integerValue] == 0) {
                    [App_Utility clearCurrentUser];
                    dispatch_main_async_safe(^{
                        [self.navigationController popToRootViewControllerAnimated:NO];
                        [[NSNotificationCenter defaultCenter] postNotificationName:kESDidLogoutNotification object:nil];
                        WTCTabBarViewController*tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
                        tabBarVC.selectedIndex = 0;
                    });
                    
                }
            }];
            
        }
    }];
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *string = @"SettingTabelCell";
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:string];
    //    cell.selectionStyle=NO;
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:string];
    }
    
    
    
    cell.layoutMargins = UIEdgeInsetsZero;
    
    cell.tag = indexPath.row+100;
    
    NSString *content = [self.dataSource objectAtIndex:indexPath.row];
    cell.textLabel.text = content;
    cell.textLabel.font = fcFont(14);
    cell.textLabel.textColor = Color66;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([btn isKindOfClass:[UIButton class]]) {
            [btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([imgView isKindOfClass:[UIImageView class]]) {
                    UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                    imgView.image = image;
                    imgView.tintColor = Color66;
                }
            }];
        }
    }];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 55.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.01f;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [[tableView cellForRowAtIndexPath:indexPath] setSelected:NO];
    switch (indexPath.row) {
        case 0:
        {
            [CMMUtility showWaitingAlertView];
            NSInteger tempSize=[[SDImageCache sharedImageCache] totalDiskSize];
            if (tempSize>1) {
                float size=tempSize/1024;
                NSLog(@"图片缓存大小%fK",size);
                float mSize=size/1024;
                NSLog(@"图片缓存大小为%fM",mSize);
                [[SDImageCache sharedImageCache] clearDiskOnCompletion:nil];
                [[SDImageCache sharedImageCache] clearMemory];
                [CMMUtility showSucessWith:[NSString stringWithFormat:@"已清理 %.2fM 缓存",mSize]];
            }else{
                [CMMUtility showSucessWith:@"缓存已清理完毕"];
            }
        }
            break;
        case 1:
        {
            //关于我们
            AbountMeViewController *vc = [[AbountMeViewController alloc] init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        default:
            break;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
