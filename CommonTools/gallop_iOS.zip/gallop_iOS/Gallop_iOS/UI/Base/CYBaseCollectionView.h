//
//  CYBaseCollectionView.h
//  Gallop_iOS
//
//  Created by lcy on 2021/7/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UICollectionView+SpaceHolder.h"

NS_ASSUME_NONNULL_BEGIN

@interface CYBaseCollectionView : UICollectionView

@property(nonatomic,copy) void(^clickToPlaceHolderViewBlock)(void);

@end

NS_ASSUME_NONNULL_END
