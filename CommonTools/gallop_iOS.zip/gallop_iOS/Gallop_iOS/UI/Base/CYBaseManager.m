//
//  CYBaseManager.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/3.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYBaseManager.h"

@interface CYBaseManager ()

@end

@implementation CYBaseManager

- (instancetype)init {
    if (self = [super init]) {
        [self setDefaultPre];
    }return self;
}

/// 初始化默认值
- (void)setDefaultPre {
    self.pageNum = 0;
    self.pageSize = 20;
    _dataSource = [[NSMutableArray alloc] init];
}

@end
