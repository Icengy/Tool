//
//  CYBaseItemParentViewController.h
//  ArtMedia2
//
//  Created by icnengy on 2020/6/13.
//  Copyright © 2020 翁磊. All rights reserved.
//

#import "ESViewController.h"

#import "TYTabButtonPagerController.h"
#import "CYBaseItemViewController.h"

@class CYTabChildModel;

NS_ASSUME_NONNULL_BEGIN

@interface CYBaseItemParentViewController : ESViewController <
                TYTabPagerControllerDelegate,
                TYPagerControllerDataSource,
                CYBaseItemViewControllerDelegate>
@property (nonatomic, strong) TYTabButtonPagerController *titleBarController;
@property (nonatomic, strong) NSArray <CYTabChildModel *>*childsArray;

@property (nonatomic ,assign) NSInteger currentIndex;
@property (nonatomic ,assign) BOOL canScroll;

@property (nonatomic ,assign) double offsetY;

- (void)tableViewDidScroll:(UIScrollView *)scrollView bottomCellOffset:(CGFloat)bottomCellOffset;
- (void)tableViewScrollToTopOffset;


@end

NS_ASSUME_NONNULL_END
