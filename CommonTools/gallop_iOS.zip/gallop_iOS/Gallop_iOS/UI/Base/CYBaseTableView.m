//
//  CYBaseTableView.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYBaseTableView.h"

@implementation CYBaseTableView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype) initWithCoder:(NSCoder *)coder {
    if (self = [super initWithCoder:coder]) {
        
        [self configuraDefaultSetting];
    }return self;
}

- (instancetype)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    if (self = [super initWithFrame:frame style:style]) {
        
        [self configuraDefaultSetting];
    }return self;
}

- (void)configuraDefaultSetting {
    self.backgroundColor = ColorDefaultGrayBackground;
    self.backgroundView = nil;
    
    self.estimatedRowHeight = 0.01;
    self.estimatedSectionHeaderHeight = 0.01;
    self.estimatedSectionFooterHeight = 0.01;
    
    if (@available(iOS 15.0, *)) {
        self.sectionHeaderTopPadding = 0.0;
    }
    
    self.showsHorizontalScrollIndicator = NO;
    self.showsVerticalScrollIndicator = NO;
    self.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    if ([self respondsToSelector:@selector(setSeparatorInset:)]) {
        [self setSeparatorInset:UIEdgeInsetsZero];
    }
    if ([self respondsToSelector:@selector(setLayoutMargins:)]) {
        [self setLayoutMargins:UIEdgeInsetsZero];
    }
    
    self.placeHolderView = [self placeHolderWithBounds:self.bounds];
    self.placeHolderLabel = [self placeHolderLabelWithBounds:self.bounds];
    [self addSubview:self.placeHolderView];
    [self addSubview:self.placeHolderLabel];
    
    self.placeHolderView.hidden = self.hidePlaceHolder;
    self.placeHolderLabel.hidden = self.hidePlaceHolder;
}

- (void)setHidePlaceHolder:(BOOL)hidePlaceHolder {
    _hidePlaceHolder = hidePlaceHolder;

//    self.placeHolderView.hidden = _hidePlaceHolder;
//    self.placeHolderLabel.hidden = _hidePlaceHolder;
    
//    [self setNeedsLayout];
}


- (UIImageView *)placeHolderWithBounds:(CGRect)bounds
{
    UIImageView*imageView = [[UIImageView alloc] init];
    imageView.hidden = YES;
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickToPlaceHolder:)];
    [imageView addGestureRecognizer:tap];
    
    return imageView;
}

- (UILabel *)placeHolderLabelWithBounds:(CGRect)bounds {
    UILabel *label = [UILabel new];
    label.hidden = YES;
    label.textColor = RGBCOLORV(0x8F8F8F);
    label.font = fcFont(12);
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    return label;
}

//- (UIStackView *)placeHolderView {
//    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[[self placeHolderWithBounds:self.bounds], [self placeHolderLabel]]];
//    stack.axis = UILayoutConstraintAxisVertical;
//    stack.alignment = UIStackViewAlignmentCenter;
//    stack.distribution = UIStackViewDistributionFill;
//    return stack;
//}

#pragma mark -
- (void)clickToPlaceHolder:(UIGestureRecognizer *)ges {
    if (self.clickToPlaceHolderViewBlock)
        self.clickToPlaceHolderViewBlock();
}

#pragma mark -
/**
 同时识别多个手势
 */
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return self.multipleGestureEnable;
}

@end
