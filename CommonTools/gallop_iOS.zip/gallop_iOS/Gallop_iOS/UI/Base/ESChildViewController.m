//
//  ESChildViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/6/15.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESChildViewController.h"

@interface ESChildViewController ()

@end

@implementation ESChildViewController

- (instancetype)init {
    self = [super init];
    if (self) {
        self.hideBarSetting = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
