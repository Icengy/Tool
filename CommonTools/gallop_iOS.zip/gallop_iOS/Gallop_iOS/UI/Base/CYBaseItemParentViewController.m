//
//  CYBaseItemParentViewController.m
//  ArtMedia2
//
//  Created by icnengy on 2020/6/13.
//  Copyright © 2020 翁磊. All rights reserved.
//

#import "CYBaseItemParentViewController.h"

#import "CYTabChildModel.h"

@interface CYBaseItemParentViewController ()

@end

@implementation CYBaseItemParentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.currentIndex = 0;
    self.canScroll = YES;
    self.offsetY = 0.0;
}

- (TYTabButtonPagerController *)titleBarController {
    if (!_titleBarController) {
        _titleBarController = [[TYTabButtonPagerController alloc] init];
        _titleBarController.contentTopEdging = 0.0f;
    }return _titleBarController;
}

#pragma mark - TYPagerControllerDataSource
- (NSInteger)numberOfControllersInPagerController {
    return self.childsArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return self.childsArray[index].childTitle;
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return self.childsArray[index].childViewController;
}

#pragma mark - public
- (void)tableViewDidScroll:(UIScrollView *)scrollView bottomCellOffset:(double)bottomCellOffset {
    NSDecimalNumber *offsetYNum = [NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%.2f", self.offsetY]];
    NSDecimalNumber *bottomCellOffsetNum = [NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%.2f", bottomCellOffset]];
    
//    WTCLog(@"self.offsetY = %f-offsetYNum = %f",self.offsetY, offsetYNum.doubleValue);
//    WTCLog(@"bottomCellOffset = %f - bottomCellOffsetNum = %f",bottomCellOffset, bottomCellOffsetNum.doubleValue);
    
    /// offsetY >= bottomCellOffset
    if ([offsetYNum compare:bottomCellOffsetNum] == NSOrderedDescending ||
        [offsetYNum compare:bottomCellOffsetNum] == NSOrderedSame) {
        
        [scrollView setContentOffset:CGPointMake(0, bottomCellOffsetNum.doubleValue) animated:NO];
        
        if (self.canScroll) {
            self.canScroll = NO;
            [self changeScrollStatus:!self.canScroll];
        }
    }else{
        if (!self.canScroll) {//子视图没到顶部;
            [scrollView setContentOffset:CGPointMake(0, bottomCellOffsetNum.doubleValue) animated:NO];
        }
    }
}

- (void)tableViewScrollToTopOffset {
    self.canScroll = YES;
    [self changeScrollStatus:!self.canScroll];
}

#pragma mark -
- (void)itemViewController:(CYBaseItemViewController *)itemVC scrollToTopOffset:(BOOL)scrollTop {
    [self tableViewScrollToTopOffset];
}

#pragma mark - prvite
- (void)changeScrollStatus:(BOOL)scrollEnabled {
    [self.childsArray enumerateObjectsUsingBlock:^(CYTabChildModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        obj.childViewController.vcCanScroll = scrollEnabled;
        if (!scrollEnabled) {
            obj.childViewController.scrollView.contentOffset = CGPointZero;
        }
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
