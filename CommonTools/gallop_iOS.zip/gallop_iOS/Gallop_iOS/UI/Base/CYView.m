//
//  CYView.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/6.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYView.h"

@implementation CYView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (CYView * _Nonnull (^)(UIColor * _Nullable))backgroundPrams {
    return ^CYView *(UIColor *_Nullable backgroundColor) {
        if (backgroundColor) self.backgroundColor = backgroundColor;
        return self;
    };
}

- (CYView * _Nonnull (^)(CGRect))framePrams {
    return ^CYView *(CGRect frame) {
        self.frame = frame;
        return self;
    };
}

- (void)setFrame:(CGRect)frame {
    
    frame.origin.x += _insets.left;
    frame.size.width -= (_insets.left+_insets.right);
    frame.origin.y += _insets.top;
    frame.size.height -= (_insets.top+_insets.bottom);
    
    [super setFrame:frame];
}


@end



@implementation CYXibView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self setup];
    }return self;
}

- (void)setup {
    [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    [self addSubview:self.view];
    self.view.frame = self.bounds;
}

@end

@implementation CYCodeView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

+ (instancetype)shareInstance {
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:nil options:nil].lastObject;
}

@end
