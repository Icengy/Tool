//
//  ESViewController.h
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/23.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ESNavigationViewController.h"
#import "CYBaseTableView.h"

#import "MatchDetailViewControllerDelegate.h"

@interface ESViewController : UIViewController<UITableViewDelegate,UITableViewDataSource, UIScrollViewDelegate>

@property (nonatomic ,assign) UIStatusBarStyle barStyle;
@property (nonatomic ,assign) CYNavigationBarStyle navigationBarStyle;

@property (nonatomic, assign) BOOL iconImageUp;

/** UITableViewStyleGroup 类型的tableview*/
@property (nonatomic, strong) CYBaseTableView *tableView;
/** UITableViewStylePlain 类型的tableview*/
@property (nonatomic, strong) CYBaseTableView *plainTableView;

@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) NSString *navTitleText;
@property (nonatomic, strong) UIColor * titleColor;

@property (nonatomic, assign) BOOL hideSperator;
/// 屏蔽导航栏设置（避免背景图设置影响子类）
@property (nonatomic, assign) BOOL hideBarSetting;

//@property (nonatomic, assign) CGFloat topEdgeInset;

- (void)dismissBack:(id)sender;
- (void)back:(id)sender;

- (void)reloadData;
- (void)endAllFreshing:(UIScrollView *)scrollView;
- (void)clearBackgroundColor:(UIScrollView *)scrollView;

@end

@interface MatchDetailItemViewController : ESViewController

@property (nonatomic,weak) id <MatchDetailViewControllerDelegate> delegate;

@end

