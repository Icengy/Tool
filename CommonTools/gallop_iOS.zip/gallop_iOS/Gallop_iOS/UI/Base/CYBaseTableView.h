//
//  CYBaseTableView.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIScrollView+Setting.h"
#import "UITableView+SpaceHolder.h"

#import "ESTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface CYBaseTableView : UITableView <UIGestureRecognizerDelegate>

@property(nonatomic,copy) void(^clickToPlaceHolderViewBlock)(void);
/// 是否允许多个手势 默认NO
@property (nonatomic ,assign) BOOL multipleGestureEnable;
/// 隐藏占位图 默认NO
@property (nonatomic ,assign) BOOL hidePlaceHolder;

@end

NS_ASSUME_NONNULL_END
