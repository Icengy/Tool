//
//  ESNavigationViewController.m
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/23.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import "ESNavigationViewController.h"

@interface ESNavigationViewController ()<UIGestureRecognizerDelegate, UINavigationControllerDelegate>
@property (nonatomic,assign) BOOL barHidden;
@end

@implementation ESNavigationViewController

//+ (void)initialize {
//    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(NSIntegerMin, 0) forBarMetrics:UIBarMetricsDefault];//隐藏back文字
////    [UINavigationBar appearance].tintColor = ColorMainNormalBlack;
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.interactivePopGestureRecognizer.enabled = NO;
    // Do any additional setup after loading the view.
    self.delegate = self;
    
    GallopNavigationBar *bar = [[GallopNavigationBar alloc] init];
    [self setValue:bar forKeyPath:@"navigationBar"];
}

#pragma mark -
- (void)setNavigationBarStyle:(CYNavigationBarStyle)navigationBarStyle {
    _navigationBarStyle = navigationBarStyle;
    
    [self updateDefaultSetting];
}

- (void)updateDefaultSetting {
    UIColor *barTintColor = UIColor.clearColor,  *tintColor = RGBCOLORV(0x8F8F8F), *textColor = RGBCOLORV(0x282828);
    UIImage *shadowImage = [UIImage new];
    UIImage *backgroundImage = [UIImage imageWithColor:barTintColor];
//    NSString *backImageStr = @"nav_return_black";
    
    switch (_navigationBarStyle) {
        case CYNavigationBarStyleRedContent: {
            /// 红底白字
            barTintColor = ColorMainAppRed;
            backgroundImage = [UIImage imageWithColor:barTintColor];
            
            tintColor = UIColor.whiteColor;
            textColor = UIColor.whiteColor;
            
            self.navigationBar.translucent = NO;
            break;
        }
        case CYNavigationBarStyleImageContent: {
            /// 使用图片做背景
            backgroundImage = nil;
//            barTintColor = UIColor.clearColor;
            
            self.navigationBar.translucent = NO;
            break;
        }
            
        default:
            /// 白底黑字
            
            barTintColor = UIColor.whiteColor;
            backgroundImage = [UIImage imageWithColor:barTintColor];
            
            shadowImage = [UIImage imageWithColor:ColorDefaultLightGrayBackground];
            
            self.navigationBar.translucent = YES;
            break;
    }
    
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *barApp = self.navigationBar.standardAppearance;
        barApp.backgroundColor = barTintColor;
        barApp.backgroundImage = backgroundImage;
        barApp.shadowColor = barTintColor;
        barApp.shadowImage = shadowImage;
        barApp.backgroundEffect = nil;
        
        barApp.titleTextAttributes = @{NSFontAttributeName:[UIFont addPingFangSCRegular:16.0f],
                                       NSForegroundColorAttributeName:textColor};
        
        self.navigationBar.standardAppearance = barApp;

        
        UINavigationBarAppearance *barApp1 = self.navigationBar.scrollEdgeAppearance;
        barApp1.backgroundColor = barTintColor;
        barApp1.backgroundImage = backgroundImage;
        barApp1.shadowColor = barTintColor;
        barApp1.shadowImage = shadowImage;
        barApp1.backgroundEffect = nil;
        barApp1.titleTextAttributes = @{NSFontAttributeName:[UIFont addPingFangSCRegular:16.0f],
                                       NSForegroundColorAttributeName:textColor};

        self.navigationBar.scrollEdgeAppearance = barApp1;
        
    }else {
        [self.navigationBar setBarTintColor:barTintColor];
        [self.navigationBar setTintColor:tintColor];
        // 导航栏文字颜色+字号
        [self.navigationBar setTitleTextAttributes:@{NSFontAttributeName:[UIFont addPingFangSCRegular:16.0f],
                                                     NSForegroundColorAttributeName:textColor}];
        if (backgroundImage) [self.navigationBar setBackgroundImage:backgroundImage forBarMetrics:UIBarMetricsDefault];
        if (shadowImage) [self.navigationBar setShadowImage:shadowImage];
    }
}


#pragma mark -
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    return NO;
}

#pragma mark -
/// 针对iOS14 隐藏tabbar的bug
//- (NSArray<__kindof UIViewController *> *)popToRootViewControllerAnimated:(BOOL)animated {
//    if (self.viewControllers.count > 0 ) {
//        UIViewController *popController = self.viewControllers.lastObject;
//        if ([popController isKindOfClass:[MinePageViewController class]] ||
//            [popController isKindOfClass:[HomeBaseViewController class]]) {
//            popController.hidesBottomBarWhenPushed = NO;
//        }
//    }
//    return [super popToRootViewControllerAnimated:animated];
//}


//- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
//
//    if ([viewController isKindOfClass:[ESViewController class]]) {
//        ESViewController * vc = (ESViewController *)viewController;
//        BOOL isHidenNaviBar = navigationController.navigationBarHidden;
//
//        if (isHidenNaviBar) {
//            vc.view.y = 0;
//            [vc.navigationController setNavigationBarHidden:YES animated:animated];
//        }else{
//            vc.view.y = NavBarHeight;
//            [vc.navigationController setNavigationBarHidden:NO animated:animated];
//        }
//    }
//}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count > 0) {
        // 当前导航栏, 只有第一个viewController push的时候设置隐藏
        if (self.viewControllers.count == 1) {
            viewController.hidesBottomBarWhenPushed = YES;
        }
    } else {
        viewController.hidesBottomBarWhenPushed = NO;
    }
    if (@available(iOS 13.0, *)) {
        [viewController setOverrideUserInterfaceStyle:(UIUserInterfaceStyleLight)];
    }
    self.navigationBarHidden = YES;
    [super pushViewController:viewController animated:animated];
}

/// 解决push之后状态栏不修改的bug
- (UIViewController *)childViewControllerForStatusBarStyle {
    return self.topViewController;
}

- (UIViewController *)childViewControllerForStatusBarHidden {
    return self.topViewController;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
