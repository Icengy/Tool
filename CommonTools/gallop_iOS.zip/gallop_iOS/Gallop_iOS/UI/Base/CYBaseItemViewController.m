//
//  CYBaseItemViewController.m
//  ArtMedia2
//
//  Created by icnengy on 2020/6/12.
//  Copyright © 2020 翁磊. All rights reserved.
//

#import "CYBaseItemViewController.h"

@interface CYBaseItemViewController () <UIScrollViewDelegate>

@end

@implementation CYBaseItemViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.scrollView.delegate = self;
    
    self.firstLoad = YES;
    
    self.scrollView.contentInset = kTableViewDetailtContentInset;
}

- (void)loadData:(id)sedner {
    
}

#pragma mark -
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (!self.isLiving) {
        if (!self.vcCanScroll) {
            scrollView.contentOffset = CGPointZero;
        }
        if (scrollView.contentOffset.y <= 0) {
            self.vcCanScroll = NO;
            scrollView.contentOffset = CGPointZero;
            if (self.delegate && [self.delegate respondsToSelector:@selector(itemViewController:scrollToTopOffset:)])
                [self.delegate itemViewController:self scrollToTopOffset:YES];
        }
        scrollView.showsVerticalScrollIndicator = self.vcCanScroll;
    }
}

#pragma mark -
- (void)didEndLoadData:(id)sender {
    self.firstLoad = NO;
    if (sender) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kDidEndRefreshForChildViewControllerNotification object:nil];
    }
}

#pragma mark - ESChildTableViewCellDelegate
- (void)childTableCell:(ESChildTableViewCell *)cell didScrollToHostPageBlock:(NSInteger)index {
    dispatch_main_async_safe(^{
        if (![self.scrollView isKindOfClass:[UITableView class]]) return;

        [(UITableView *)self.scrollView beginUpdates];
        [(UITableView *)self.scrollView endUpdates];
    });
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
