//
//  ESNavigationViewController.h
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/23.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GallopNavigationBar.h"

typedef NS_ENUM(NSInteger, CYNavigationBarStyle) {
    /// 白底黑字 默认
    CYNavigationBarStyleDefault                                  = 0,
    /// 红底白字
    CYNavigationBarStyleRedContent,
    /// 使用图片做背景
    CYNavigationBarStyleImageContent
};

@interface ESNavigationViewController : UINavigationController

@property (nonatomic ,assign) CYNavigationBarStyle navigationBarStyle;

- (void)updateDefaultSetting;

@end
