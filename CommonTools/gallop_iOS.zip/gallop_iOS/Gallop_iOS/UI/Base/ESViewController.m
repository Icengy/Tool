//
//  ESViewController.m
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/23.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import "ESViewController.h"

#import "WTCTitleView.h"

@interface ESViewController ()

@property (nonatomic, strong) WTCTitleView *titleView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UIImageView *titleImageView;
@property (nonatomic, strong) UIButton *titleButton;
@property (nonatomic, assign) BOOL showTitleButton;


@end

@implementation ESViewController

- (void)dealloc
{
    NSLog(@"%@ is dealloc",object_getClass(self));
    @try{
        [[NSNotificationCenter defaultCenter]removeObserver:self];//移除通知
    } @catch(id anException) {
        //do nothing, obviously it wasn't attached because an exception was thrown
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:[NSString stringWithFormat:@"进入 %@",self.title]];
    

}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:[NSString stringWithFormat:@"离开 %@",self.title]];
    
//    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    /**
     *  解决进入融云单聊页面后，POP返回后布局偏移的Bug
     */
    self.edgesForExtendedLayout = UIRectEdgeTop;
    self.extendedLayoutIncludesOpaqueBars = YES;
   
    self.view.backgroundColor = ColorDefaultGrayBackground;
    if (self.navigationController) {
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        self.navigationItem.backBarButtonItem = backItem;
    }
    
    if (!self.hideBarSetting) {
        self.barStyle = UIStatusBarStyleDefault;
        self.navigationBarStyle = CYNavigationBarStyleDefault;
    }
    
	//反馈悬浮窗
	[LPUnitily.keyWindow bringSubviewToFront:[LPUnitily.keyWindow viewWithTag:12345]];
}

#pragma mark -
- (void)setBarStyle:(UIStatusBarStyle)barStyle {
    _barStyle = barStyle;
    
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)setNavigationBarStyle:(CYNavigationBarStyle)navigationBarStyle {
    _navigationBarStyle = navigationBarStyle;
    if ([self.navigationController isKindOfClass:[ESNavigationViewController class]]) {
        [(ESNavigationViewController *)self.navigationController setNavigationBarStyle:_navigationBarStyle];
    }
}

- (UIStatusBarStyle)preferredStatusBarStyle {
    return _barStyle;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - scrollView delegate
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
	[UIView animateWithDuration:0.3f delay:0.f options:UIViewAnimationOptionLayoutSubviews animations:^{
		[[LPUnitily.keyWindow viewWithTag:12345] setX:SCREEN_WIDTH - 20];
		[LPUnitily.keyWindow viewWithTag:12345].alpha = 0.5;
	} completion:nil];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
	if (decelerate) {
		return;
	}
	[UIView animateWithDuration:0.3f delay:1.0f options:UIViewAnimationOptionLayoutSubviews animations:^{
		[[LPUnitily.keyWindow viewWithTag:12345] setX:SCREEN_WIDTH - 55];
		[LPUnitily.keyWindow viewWithTag:12345].alpha = 1;
	} completion:nil];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
	[UIView animateWithDuration:0.3f delay:1.0f options:UIViewAnimationOptionLayoutSubviews animations:^{
		[[LPUnitily.keyWindow viewWithTag:12345] setX:SCREEN_WIDTH - 55];
		[LPUnitily.keyWindow viewWithTag:12345].alpha = 1;
	} completion:nil];
}

#pragma mark - UITableViewDatasource Methods  子类有tableview的实现 =============

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 0;
}

#pragma mark 此方法加上是为了适配iOS 11出现的问题

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [CYView new];
}

//有时候tableview的底部视图也会出现此现象对应的修改就好了

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [CYView new];
}


#pragma mark -
- (void)setTitle:(NSString *)title {
//    [super setTitle:title];
    
//    [self.navigationItem setTitleView:self.titleView];
    self.titleLabel.text = title;
}

- (void)setNavTitleText:(NSString *)navTitleText
{
    _navTitleText = navTitleText;
    self.titleLabel.text = navTitleText;
}

- (void)toChoosetype:(UIButton *)button
{
    button.selected = !button.selected;
    if (button.selected) {
        _titleImageView.image = [UIImage imageNamed:@"up"];
    }else{
        _titleImageView.image = [UIImage imageNamed:@"down"];
    }
    [self chickTitleViewButton];
}
/** 子类需重写此方法 实现点击*/
- (void)chickTitleViewButton
{
    
}
- (void)setIconImageUp:(BOOL)iconImageUp
{
    _iconImageUp = iconImageUp;
    if (_iconImageUp) {
        _titleImageView.image = [UIImage imageNamed:@"up"];
    }else{
        _titleImageView.image = [UIImage imageNamed:@"down"];
    }
}
-(void)setTitleColor:(UIColor *)titleColor
{
    _titleColor = titleColor;
    _titleLabel.textColor = titleColor;
}
- (WTCTitleView *)titleView
{
    if (!_titleView) {
        _titleView = [[WTCTitleView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 200, 30)];
        self.titleLabel = [[UILabel alloc] init];
        [_titleView addSubview:self.titleLabel];
        _titleLabel.textColor = ColorAppBlack;
		_titleLabel.font = fcFont(18);
        self.titleImageView = [[UIImageView alloc] init];
        [_titleView addSubview:self.titleImageView];
        _titleImageView.image = [UIImage imageNamed:@"down"];
        [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self->_titleView);
            make.width.lessThanOrEqualTo(@(SCREEN_WIDTH - 80));
        }];
        [_titleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self->_titleLabel.mas_right).offset(5);
            make.centerY.equalTo(self->_titleView);
            make.size.mas_equalTo(CGSizeMake(13, 8));
        }];
        _titleImageView.hidden = YES;
        
        self.titleButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_titleView addSubview:self.titleButton];
        _titleButton.backgroundColor = [UIColor clearColor];
        [_titleButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_titleLabel.mas_left);
            make.right.mas_equalTo(self->_titleImageView.mas_right);
            make.centerY.equalTo(self->_titleView);
            make.height.equalTo(@(30));
        }];
        _titleView.intrinsicContentSize = CGSizeMake(SCREEN_WIDTH - 200, 40);
        
    }
    return _titleView;
}

//- (CYBaseTableView *)myTableView {
//    if (!_myTableView) {
//        _myTableView = [[CYBaseTableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
//        _myTableView.delegate = self;
//        _myTableView.dataSource = self;
//    }
//    return _myTableView;
//}

- (CYBaseTableView *)plainTableView {
    if (!_plainTableView) {
        _plainTableView = [[CYBaseTableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _plainTableView.delegate = self;
        _plainTableView.dataSource = self;
        _plainTableView.hidePlaceHolder = NO;
        _tableView.scrollsToTop = NO;
        
        if (@available(iOS 11.0, *)){
            _plainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
    }
    return _plainTableView;
}

- (CYBaseTableView *)tableView {
    if (!_tableView) {
        _tableView = [[CYBaseTableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
        
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.hidePlaceHolder = NO;
//        _tableView.scrollsToTop = NO;
        
        if (@available(iOS 11.0, *)){
            _tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
        }
    }
    return _tableView;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        _dataSource = [NSMutableArray array];
    }
    
    return _dataSource;
}


#pragma mark -
- (void)back:(id)sender {
    [ES_HttpService cancelAll];
    [ES_LPUnitily removeHUDToCurrentView];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)dismissBack:(id)sender {
    [ES_HttpService cancelAll];
    [ES_LPUnitily removeHUDToCurrentView];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)reloadData {
    
}

- (void)endAllFreshing:(UIScrollView *)scrollView {
    dispatch_async(dispatch_get_main_queue(), ^{
        [scrollView endAllFreshing];
        [ES_HttpService removeLoading];
    });
}

- (void)clearBackgroundColor:(UIScrollView *)scrollView {
    self.view.backgroundColor = scrollView.backgroundColor;
    scrollView.backgroundColor = UIColor.clearColor;
}

//#pragma mark - setter
//- (void)setTopEdgeInset:(CGFloat)topEdgeInset {
//    _topEdgeInset = topEdgeInset;
//}

@end


@implementation MatchDetailItemViewController

@end
