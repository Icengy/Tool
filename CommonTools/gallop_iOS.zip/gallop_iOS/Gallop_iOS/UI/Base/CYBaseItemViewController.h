//
//  CYBaseItemViewController.h
//  ArtMedia2
//
//  Created by icnengy on 2020/6/12.
//  Copyright © 2020 翁磊. All rights reserved.
//
// 分页子视图控制器
//

#import "ESViewController.h"

#define kDidEndRefreshForChildViewControllerNotification @"childDidEndRefresh"

NS_ASSUME_NONNULL_BEGIN

@class CYBaseItemViewController;
@protocol CYBaseItemViewControllerDelegate <NSObject>

/**
list是否滑动到顶部
 
@param itemVC itemVC
@param scrollTop scrollTop
*/
- (void)itemViewController:(CYBaseItemViewController *)itemVC scrollToTopOffset:(BOOL)scrollTop;

@end

@interface CYBaseItemViewController : ESChildViewController <ESChildTableViewCellDelegate>

@property (weak ,nonatomic) id <CYBaseItemViewControllerDelegate> delegate;
@property (nonatomic, assign) BOOL vcCanScroll;
/// 是否在播放
@property (nonatomic, assign) BOOL isLiving;
@property (nonatomic ,strong) UIScrollView *scrollView;

/// 首次加载
@property(nonatomic, assign) BOOL firstLoad;

/// 刷新操作结束，通知外层结束下拉动画
- (void)didEndLoadData:(nullable id)sender;

@end

NS_ASSUME_NONNULL_END
