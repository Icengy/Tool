//
//  CYBaseItemViewControllerDelegate.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/3.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CYBaseItemViewController;

NS_ASSUME_NONNULL_BEGIN

@protocol CYBaseItemViewControllerDelegate <NSObject>

/**
list是否滑动到顶部
 
@param itemVC itemVC
@param scrollTop scrollTop
*/
- (void)itemViewController:(CYBaseItemViewController *)itemVC scrollToTopOffset:(BOOL)scrollTop;

@end

NS_ASSUME_NONNULL_END
