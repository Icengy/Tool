//
//  CYBaseManager.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/3.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class CYBaseManager;
@protocol CYBaseManagerDelegate <NSObject>

- (void)manager:(CYBaseManager *)manager didEndLoadDataWithSender:(nullable id)sender isRefresh:(BOOL)needFooter noDataFooter:(BOOL)needNoDataFooter;

@end

@interface CYBaseManager : NSObject

@property (nonatomic, weak) id <CYBaseManagerDelegate> delegate;
/// 分页-页码
@property (nonatomic, assign) int pageNum;
/// 分页-每页数量
@property (nonatomic, assign) int pageSize;
/// 数据源
@property (nonatomic, strong, readonly) NSMutableArray *dataSource;

- (instancetype)init NS_DESIGNATED_INITIALIZER;
+ (instancetype)new NS_UNAVAILABLE;

- (void)loadData:(nullable id)sender;

@end

NS_ASSUME_NONNULL_END
