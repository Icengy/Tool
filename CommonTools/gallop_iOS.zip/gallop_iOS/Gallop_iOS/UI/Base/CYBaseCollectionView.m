//
//  CYBaseCollectionView.m
//  Gallop_iOS
//
//  Created by lcy on 2021/7/2.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYBaseCollectionView.h"

@implementation CYBaseCollectionView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self commonInit];
    }return self;
}

- (instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout {
    if (self = [super initWithFrame:frame collectionViewLayout:layout]) {
        [self commonInit];
    }return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    if (self = [super initWithCoder:coder]) {
        [self commonInit];
    }return self;
}

- (void)commonInit {
    self.backgroundColor = UIColor.clearColor;
    
    self.placeHolderView = [self placeHolderWithBounds:self.bounds];
    self.placeHolderLabel = [self placeHolderLabelWithBounds:self.bounds];
    [self addSubview:self.placeHolderView];
    [self addSubview:self.placeHolderLabel];
}

- (UIImageView *)placeHolderWithBounds:(CGRect)bounds {
    UIImageView*imageView = [[UIImageView alloc] init];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    imageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickToPlaceHolder:)];
    [imageView addGestureRecognizer:tap];
    
    return imageView;
}

- (UILabel *)placeHolderLabelWithBounds:(CGRect)bounds {
    UILabel *label = [UILabel new];
    label.textColor = RGBCOLORV(0x8F8F8F);
    label.font = fcFont(12);
    label.textAlignment = NSTextAlignmentCenter;
    label.numberOfLines = 0;
    return label;
}

- (void)clickToPlaceHolder:(UIGestureRecognizer *)ges {
    if (self.clickToPlaceHolderViewBlock)
        self.clickToPlaceHolderViewBlock();
}

@end

