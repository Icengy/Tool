//
//  CYView.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/6.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CYView : UIView

// @property(nonatomic,strong)void(^showGoodsSwitchBlock)(BOOL show);

/// 设置背景色
@property(nonatomic,copy) CYView*(^backgroundPrams)(UIColor *_Nullable backgroundColor);
/// 设置frame
@property(nonatomic,copy) CYView*(^framePrams)(CGRect frame);


@property (nonatomic) UIEdgeInsets insets;

@end

#pragma mark - xib使用
@interface CYXibView : CYView

@property (nonatomic ,weak) IBOutlet UIView *view;

@end

#pragma mark - 代码使用
@interface CYCodeView : CYView

+ (instancetype)shareInstance;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
