//
//  ESChildViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/6/15.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ESChildViewController : ESViewController

+ (instancetype)new NS_UNAVAILABLE;

- (void)loadData:(nullable id)sedner;

@end

NS_ASSUME_NONNULL_END
