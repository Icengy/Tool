//
//  PaperContentViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/3.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"
#import "ESBanner.h"

//文章浏览页(通用附带评论功能)

@interface PaperContentViewController : ESViewController
@property (nonatomic, assign)BOOL needShowCommentWhenPush;
@property (nonatomic, strong)ESBanner*banerModel;
@property (nonatomic, copy)NSString *textID;
@end
