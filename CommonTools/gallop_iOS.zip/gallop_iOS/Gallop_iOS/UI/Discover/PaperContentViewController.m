//
//  PaperContentViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/3.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperContentViewController.h"
#import "PaperCommentViewController.h"
#import "PaperReplyDetailController.h"
#import "PaperCommentCell.h"
#import "PaperBottomView.h"
#import "PaperCommentView.h"
#import "MLMOptionSelectView.h"
#import <WebKit/WebKit.h>
#import "PaperShareCommentViewController.h"
#import "dsbridge.h"
#import "OfficialRecommendViewController.h"
#import "CommunityHomePageViewController.h"
//分享
#import "ESShareViewController.h"

#define kPageSize 20

@interface PaperContentViewController ()<WKNavigationDelegate,PaperCommentCellDelegate,PaperBottomViewDelegate,PaperCommentViewDelegate>
@property (nonatomic, strong) DWKWebView *kwebView;
@property (nonatomic, strong) UIView *commentHeaderView;
@property (nonatomic, strong) MLMOptionSelectView *sortSelectView;
@property (nonatomic, strong) PaperBottomView *bottomView;  //底部tab框
@property (nonatomic, strong) PaperCommentView *commentView; //评论输入框

@property (nonatomic, strong) ESPaperModel *paperModel;
@property (nonatomic, strong) NSMutableArray<ESCommentItem *> *commentList;
@property (nonatomic, assign) NSUInteger currentPage;
@property (nonatomic, assign) NSUInteger selectedSort;
@end

@implementation PaperContentViewController
#pragma mark - lify cycel & layout
- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replyCommitSuccess) name:kReplyCommitSuccess object:nil];
	[self.kwebView.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(windowDidBecomeHidden:) name:UIWindowDidBecomeHiddenNotification object:nil];
	[self.kwebView addJavascriptObject:self namespace:@"gallop"];
}

- (void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
	
	if (self.kwebView.loading) {
		[self.kwebView stopLoading];
		[ES_LPUnitily removeHUDToCurrentView];
	}
	
	[self.kwebView.scrollView removeObserver:self forKeyPath:@"contentSize"];
	[self.kwebView removeJavascriptObject:@"gallop"];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	self.navigationItem.title = @"飞驰体育";
	self.commentList = [NSMutableArray array];
	self.selectedSort = 1;
	[self initWithSubView];
	[self loadPaperData];
	
}

- (void)initWithSubView{
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.view).offset(NavBarHeight);
		make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
		make.left.right.equalTo(self.view);
	}];
	self.tableView.allowsSelection = NO;
	self.tableView.backgroundColor = RGBCOLOR(244, 244, 244);
	self.tableView.placeHolderView = nil;
	self.tableView.tableHeaderView = self.kwebView;
	self.tableView.estimatedRowHeight = 0;
	self.tableView.estimatedSectionFooterHeight = 0;
	self.tableView.estimatedSectionHeaderHeight = 0;

	[self.tableView registerClass:[PaperCommentCell class] forCellReuseIdentifier:@"PaperCommentCellIdentifier"];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
}

#pragma mark - fetch Data
- (void)loadPaperData {
	if (self.banerModel.textFormat.integerValue == 0) {
		//老格式文章直接跳转url
		[self loadRequstWithURLString:self.banerModel.link];
		return;
	}
	//数据请求
	@weakify(self)
	[ESNetworkService viewPaperWithTextId:self.banerModel.textId.integerValue Response:^(id dict, ESError *error) {
	}];
	
	[ESNetworkService getNewsDetailWithTextId:self.banerModel.textId Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.paperModel = [ESPaperModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				[self loadRequstWithURLString:self.paperModel.link];
			});
		} else {
			
		}
	}];
}

- (void)loadCommentList {
	self.currentPage = 1;
	//获取评论列表
	@weakify(self)
	[ESNetworkService getCommentListWithTextId:self.banerModel.textId sortType:self.selectedSort page:self.currentPage pageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			ESCommentList *model = [ESCommentList mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				self.paperModel.commentCount = model.totalCount;
				[self.bottomView configViewWithModel:self.paperModel isComunity:NO];
				[self.commentList removeAllObjects];
				[self.commentList addObjectsFromArray:model.commentList];
				if (self.currentPage >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				} else {
					[self.tableView.mj_footer endRefreshing];
				}
				[self.tableView reloadData];
				
				if (self.needShowCommentWhenPush == YES) {
					self.needShowCommentWhenPush = NO;
					[self.commentView showPaperCommentView];
				}
			});
		} else {
			
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	//获取评论列表
	@weakify(self)
	[ESNetworkService getCommentListWithTextId:self.banerModel.textId sortType:self.selectedSort page:self.currentPage pageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.tableView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			ESCommentList *model = [ESCommentList mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				[self.commentList addObjectsFromArray:model.commentList];
				if (self.currentPage >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.tableView reloadData];
			});
		} else {
			
		}
	}];
}

#pragma mark - action
- (void)defaultCell:(NSArray*)listArray CellView:(MLMOptionSelectView*)cellView{
	WEAK(weakCellView, cellView);
	cellView.canEdit = NO;
	cellView.showsVerticalScrollIndicator = YES;
	if (listArray.count > 5) {
		//暂时显示滚动条
		[cellView flashScrollIndicators];
	}
	[cellView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
	
	cellView.cell = ^(NSIndexPath *indexPath){
		
		UITableViewCell *cell = [weakCellView dequeueReusableCellWithIdentifier:@"DefaultCell"];
		
		cell.backgroundColor =[UIColor whiteColor];
		cell.textLabel.textColor = ColorSubTitle;
		cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@",listArray[indexPath.row]]];
		cell.textLabel.textAlignment = NSTextAlignmentCenter;
		
		
		cell.textLabel.font = GetFont(13.0f);
		return cell;
	};
	cellView.optionCellHeight = ^{
		
		return 40.f;
	};
	cellView.rowNumber = ^(){
		
		return (NSInteger)listArray.count;
	};
}

- (void)hotBtnClick:(UIButton *)btn {
	UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
	CGRect nowRect = [btn convertRect:btn.bounds toView:window];
	
	self.sortSelectView = [[MLMOptionSelectView alloc] initOptionView];
	
	NSMutableArray*arr1 = [NSMutableArray array];
	[arr1 addObjectsFromArray:@[@"最高热度",@"最多赞数",@"最晚评论",@"最早评论"]];
	
	[self defaultCell:arr1 CellView:self.sortSelectView];
	
	self.sortSelectView.vhShow = YES;
	self.sortSelectView.optionType = MLMOptionSelectViewTypeCustom;
	self.sortSelectView.edgeInsets = UIEdgeInsetsZero;
	[self.sortSelectView showTapPoint:CGPointMake(nowRect.origin.x + 50, nowRect.origin.y+30) viewWidth:nowRect.size.width + 10 direction:MLMOptionSelectViewBottom];
	
	@weakify(self)
	self.sortSelectView.selectedOption = ^(NSIndexPath *index) {
		@strongify(self)
		self.selectedSort = index.row + 1;
		[btn setTitle:arr1[index.row] forState:UIControlStateNormal];
		[self loadCommentList];
	};
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	if (self.commentList.count <= 0) {
		return 0.01;
	} else {
		return 48;
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	if (self.commentList.count <= 0) {
		return 10;
	}
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	if (self.commentList.count <= 0) {
		return [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 10)];
	}
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	if (self.commentList.count <= 0) {
		return nil;
	}
	UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 48)];
	//分割区域
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 8)];
	view.backgroundColor = RGBCOLOR(244, 244, 244);
	[headView addSubview:view];
	//sectionHeader
	[headView addSubview:self.commentHeaderView];
	[self.commentHeaderView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.left.right.equalTo(headView);
		make.height.mas_equalTo(40);
	}];
	
	return headView;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.commentList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	PaperCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PaperCommentCellIdentifier"];
	cell.cellDelegate = self;
	[cell configCellWithModel:self.commentList[indexPath.row] indexPath:indexPath.row];
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	tableView.rowHeight = UITableViewAutomaticDimension;
	tableView.estimatedRowHeight = 75;
	return tableView.rowHeight;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - PaperCellDelegate
- (void)likeClick:(NSUInteger)index {
	//调用评论点赞接口
	@weakify(self)
	[ESNetworkService commentLikeStatusChangeWithCommentId:self.commentList[index].commentId likeStatus:!self.commentList[index].liked Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe(^{
				//点赞状态更新
				self.commentList[index].liked = !self.commentList[index].liked;
				self.commentList[index].likeCount = [data[@"likeCount"] integerValue];
				[UIView performWithoutAnimation:^{
					[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
				}];
			});
		} else {
			
		}
	}];
}

- (void)replyClick:(NSUInteger)index {
	//查看回复列表
	PaperReplyDetailController *vc = [[PaperReplyDetailController alloc] init];
	vc.commentModel = self.commentList[index];
	vc.pageType = PageTypeReply;
	vc.paperModel = self.paperModel;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)shareClick:(NSUInteger)index {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//分享评论
	if (self.commentList[index].hideShow == 0) {
		[CMMUtility showToastWithText:@"违规评论不可分享"];
		return;
	}
	PaperShareCommentViewController *vc = [[PaperShareCommentViewController alloc] init];
	vc.paperModel = self.paperModel;
	vc.commentItem = self.commentList[index];
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)goHomePage:(NSUInteger)index {
	CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
	vc.authorUid = self.commentList[index].userId;
	
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - PaperBottomViewDelegate
- (void)commentClick {
	//弹出评论框
	[self.commentView showPaperCommentView];
}

- (void)tabReplyClick:(UIButton *)btn {
	if (self.commentList.count > 0) {
		NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
		[self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
	}
}

- (void)tabLikeClick:(UIButton *)btn {
	
	//调用文章点赞接口
	@weakify(self)
	[ESNetworkService paperLikeStatusChangeWithTextId:self.paperModel.textId likeStatus:!btn.selected Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe(^{
				self.paperModel.liked = !btn.selected;
				self.paperModel.likeCount = [data[@"likeCount"] integerValue];
				[self.bottomView configViewWithModel:self.paperModel isComunity:NO];
			});
		} else {
			
		}
	}];
}

- (void)tabShareClick:(UIButton *)btn {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//分享文章
	@weakify(self)
	[ESNetworkService getPaperFowardInfoWithTextId:self.banerModel.textId.intValue Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe(^{
				[self shareWithModel:data];
			});
		} else {
			
		}
	}];
}

- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

#pragma mark - PaperCommentViewDelegate
- (void)sendBtnClick:(NSString *)content {
	//调用文章评论接口
	@weakify(self)
	[ESNetworkService paperCommentWithTextId:self.paperModel.textId content:content Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe((^{
				self.commentView.textView.text = @"";
				[self.commentView hidePaperCommentView];
				self.paperModel.commentCount = [data[@"commentCount"] integerValue];
				[self.bottomView configViewWithModel:self.paperModel isComunity:NO];
				//生成本地消息插入列表最上方
				ESCommentItem *item = [ESCommentItem mj_objectWithKeyValues:data];
				item.content = content;
				item.hideShow = 1;
				NSDate *datenow = [NSDate date];
				item.createTime = [NSString stringWithFormat:@"%ld", (long)([datenow timeIntervalSince1970]*1000)];
				[self.commentList insertObject:item atIndex:0];
				[self.tableView reloadData];
				NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
				[self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
			}));
		} else {
			
		}
	}];
}

- (void)fullScreenBtnClick:(NSString *)content {
	//全屏输入
	PaperCommentViewController *vc = [[PaperCommentViewController alloc] init];
	vc.delegate = self;
	vc.commentType = CommentTypePaper;
	vc.placeHolder = @"说说你的看法";
	vc.content = content;
	vc.backBlock = ^(NSString *content) {
		self.commentView.textView.text = content;
		if (QM_IS_STR_NIL(content)) {
			self.commentView.placeHolderLabel.hidden = NO;
		} else {
			self.commentView.placeHolderLabel.hidden = YES;
		}
	};
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - notify
-(void)windowDidBecomeHidden:(NSNotification *)noti{
	[[UIApplication sharedApplication] setStatusBarHidden:false animated:false];
}

- (void)replyCommitSuccess {
	[self loadCommentList];
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(nullable void *)context{
	if ([keyPath isEqualToString:@"contentSize"]) {
		CGSize oldSize = [change[NSKeyValueChangeOldKey] CGSizeValue];
		CGSize newSize = [change[NSKeyValueChangeNewKey] CGSizeValue];
		if (oldSize.height == newSize.height) {
			return;
		}
		//自动适应网页高度
		[self.kwebView.scrollView removeObserver:self forKeyPath:@"contentSize"];
		self.kwebView.size = newSize;
		[self.tableView setTableHeaderView:self.kwebView];
		//添加监听
		[self.kwebView.scrollView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
	}
}

#pragma mark - webViewDelegate
-(void)loadRequstWithURLString:(NSString *)url
{
	[self.kwebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url] cachePolicy:0 timeoutInterval:15.0]];
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
	// 页面开始加载时调用
	[ES_LPUnitily removeHUDToCurrentView];
	WTCLog(@"%@",[webView.URL absoluteString]);
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation{
	
	// 当内容开始返回时调用
	[ES_LPUnitily removeHUDToCurrentView];
	WTCLog(@"%@",[webView.URL absoluteString]);
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation{
	// 接收到服务器跳转请求之后调用
	WTCLog(@"%@",[webView.URL absoluteString]);
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation{
	// 页面加载完成之后调用
	[ES_LPUnitily removeHUDToCurrentView];
	
	WTCLog(@"%@",[webView.URL absoluteString]);
	
	//禁止长按弹出框
	[webView evaluateJavaScript:@"document.documentElement.style.webkitUserSelect='none';" completionHandler:nil];
	
	//禁止捏合
	NSString *injectionJSString = @"var script = document.createElement('meta');"
	"script.name = 'viewport';"
	"script.content=\"width=device-width, user-scalable=no\";"
	"document.getElementsByTagName('head')[0].appendChild(script);";
	[webView evaluateJavaScript:injectionJSString completionHandler:nil];
	
	//页面加载完成后再请求评论列表
	if (self.paperModel.commentStatus == 0) {
		//无评论模块
		self.tableView.mj_footer.hidden = YES;
		self.tableView.mj_header.hidden = YES;
		self.bottomView.hidden = YES;
	} else {
		[self loadCommentList];
		if (self.paperModel.commentStatus == 1) {
			self.tableView.mj_footer.hidden = NO;
			self.tableView.mj_header.hidden = NO;
			[self.bottomView configViewWithModel:self.paperModel isComunity:NO];
			self.bottomView.hidden = NO;
		} else {
			self.bottomView.hidden = YES;
		}
	}
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
	[ES_LPUnitily removeHUDToCurrentView];
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
	WTCLog(@"%@",webView.URL.absoluteString);
	decisionHandler(WKNavigationActionPolicyAllow);
}
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
	WTCLog(@"%@",webView.URL.absoluteString);
	// 在收到响应后，决定是否跳转和发送请求之前那个允许配套使用
	decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *__nullable credential))completionHandler{
	WTCLog(@"%@",webView.URL.absoluteString);
	completionHandler(NSURLSessionAuthChallengePerformDefaultHandling ,nil);
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
	[webView reload];    //刷新就好了
}

#pragma mark - 开放接口
- (NSString *)goNative:(NSNumber *)type
{
	OfficialRecommendViewController *vc = [OfficialRecommendViewController new];
	if (type.intValue == 1) {
		vc.type = 0;
	} else {
		vc.type = 2;
	}
	
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
	return @"iOS";
}

- (void)getPlatform:(NSString *)msg :(JSCallback)completionHandler {
	completionHandler(@"iOS",YES);
}

- (NSString *)goUserHomePage:(NSString *)userId {
	CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
	vc.authorUid = userId;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
	return @"iOS";
}

#pragma mark - lazy init
-(DWKWebView *)kwebView
{
	if (!_kwebView) {
		_kwebView=[[DWKWebView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width,0.01)];
		
		_kwebView.navigationDelegate=self;
		_kwebView.backgroundColor = [UIColor whiteColor];
		_kwebView.allowsBackForwardNavigationGestures = YES;
		_kwebView.scrollView.scrollEnabled = NO;
		if (@available(iOS 11.0, *)){
			_kwebView.scrollView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
		}
	}
	return _kwebView;
}

- (UIView *)commentHeaderView {
	if (!_commentHeaderView) {
		_commentHeaderView = [UIView new];
		_commentHeaderView.backgroundColor = [UIColor whiteColor];
		//
		UILabel *titleLabel = [UILabel new];
		titleLabel.textColor = ColorAppBlack;
		titleLabel.text = @"全部评论";
		titleLabel.font = fcFont(16);
		[_commentHeaderView addSubview:titleLabel];
		[titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(_commentHeaderView).offset(14);
			make.centerY.equalTo(_commentHeaderView);
		}];
		//
		UIButton *hotBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[hotBtn setTitle:@"最高热度" forState:UIControlStateNormal];
		[hotBtn setImage:GetImage(@"paper_filter_icon") forState:UIControlStateNormal];
		hotBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		hotBtn.titleLabel.font = fcFont(14);
		[hotBtn setTitleColor:RGBCOLOR(6, 120, 125) forState:UIControlStateNormal];
		[hotBtn addTarget:self action:@selector(hotBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		[_commentHeaderView addSubview:hotBtn];
		[hotBtn mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(_commentHeaderView).offset(-14);
			make.centerY.equalTo(_commentHeaderView);
			make.height.mas_equalTo(20);
		}];
		//
		UIView *seperatorLine = [UIView new];
		seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[_commentHeaderView addSubview:seperatorLine];
		[seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.bottom.equalTo(_commentHeaderView);
			make.height.mas_equalTo(1);
		}];
	}
	return _commentHeaderView;
}

- (PaperBottomView *)bottomView {
	if (!_bottomView) {
		_bottomView = [[PaperBottomView alloc] init];
		[self.view addSubview:_bottomView];
		[_bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.equalTo(self.view);
			make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
			make.height.mas_equalTo(50);
		}];
		_bottomView.viewDelegate = self;
	}
	return _bottomView;
}

- (PaperCommentView *)commentView {
	if (!_commentView) {
		_commentView = [[PaperCommentView alloc] init];
		_commentView.hidden = YES;
		_commentView.delegate = self;
		_commentView.placeHolderLabel.text = @"说说你的看法";
		[self.view addSubview:_commentView];
		[_commentView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.bottom.left.right.top.equalTo(self.tableView);
		}];
	}
	return _commentView;
}

@end
