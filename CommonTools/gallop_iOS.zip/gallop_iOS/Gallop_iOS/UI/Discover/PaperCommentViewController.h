//
//  PaperCommentViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"
#import "PaperCommentView.h"

typedef enum : NSUInteger {
	CommentTypePaper,//写评论
	CommentTypeReply,//回复评论
} CommentType;

typedef void(^BackBlock)(NSString*content);

@interface PaperCommentViewController : ESViewController
@property (nonatomic,assign) CommentType commentType;
@property (nonatomic,strong) NSString *placeHolder;
@property (nonatomic,strong) NSString *content;
@property (nonatomic,copy) BackBlock backBlock;
@property (nonatomic,weak)id<PaperCommentViewDelegate> delegate;
@end
