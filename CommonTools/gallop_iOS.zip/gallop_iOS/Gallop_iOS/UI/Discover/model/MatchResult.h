//
//  MatchResult.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface MatchResult : NSObject
@property (nonatomic,strong) NSString *matchId;
@property (nonatomic,strong) NSString *leagueName;
@property (nonatomic,strong) NSString *leagueColor;
@property (nonatomic,strong) NSString *startTime;
@property (nonatomic,strong) NSString *hostName;
@property (nonatomic,strong) NSString *guestName;
@property (nonatomic,strong) NSString *hostFlag;
@property (nonatomic,strong) NSString *guestFlag;
@property (nonatomic,strong) NSString *hostScore;
@property (nonatomic,strong) NSString *guestScore;
@end


