//
//  NewModel.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "NewModel.h"

@implementation NewModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"m_id" : @"id"};
}
@end
