//
//  NewModel.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface NewModel : NSObject
@property (nonatomic,strong) NSString*m_id;
@property (nonatomic,strong) NSString *title;
@property (nonatomic,strong) NSString *picture;
@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) NSString *publisher;
@property (nonatomic,strong) NSString *times;
@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,strong) NSString *textId; //文章id
@property (nonatomic,strong) NSString *textType; //文章类型，0：后台人员添加的文章，目前只有0，
@property (nonatomic,strong) NSString *textFormat; //文章格式，0：原来的老格式直接跳转链接,1：新格式
@end


