//
//  PaperShareCommentViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/11.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperShareCommentViewController.h"
#import "WXApi.h"
@interface PaperShareCommentViewController ()
@property (nonatomic,strong) UIScrollView 		*contentScrollView;
@property (nonatomic,strong) UIImageView *appImageView;
@property (nonatomic,strong) UILabel *shareTitleLabel;
@property (nonatomic,strong) UIButton *originTextBtn;
@property (nonatomic,strong) UILabel *textContentLabel;
@property (nonatomic,strong) UIView	*seperatorLine;
@property (nonatomic,strong) UIView *replyContentView;
@property (nonatomic,strong) UILabel *replyContentLabel;
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *authLabel;
@property (nonatomic,strong) UILabel *contentLabel;

//二维码区域
@property (nonatomic,strong) UIView *qrContentView;
@property (nonatomic,strong) UILabel *qrTipLabel;
@property (nonatomic,strong) UIImageView *qrImageView;
//分享按钮区域
@property (nonatomic,strong) UIView *shareContentView;
@property (nonatomic,strong) NSMutableArray<UIButton *> *shareBtnArr;
@property (nonatomic,strong) UIButton *cancelBtn;

@end

@implementation PaperShareCommentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.fd_prefersNavigationBarHidden = YES;
	self.view.backgroundColor = RGBCOLOR(244, 244, 244);
	[self setupView];
	[self configQrCode];
	[self configView];
}

- (void)setupView {
	[self.view addSubview:self.contentScrollView];
	[self.appImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentScrollView).offset(44);
		make.left.equalTo(self.contentScrollView).offset(58);
		make.size.mas_equalTo(CGSizeMake(36, 36));
	}];
	[self.shareTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.appImageView);
		make.left.equalTo(self.appImageView.mas_right).offset(10);
	}];
	[self.originTextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.appImageView.mas_bottom).offset(37.5);
		make.left.equalTo(self.contentScrollView).offset(15);
		make.size.mas_equalTo(CGSizeMake(34, 18));
	}];
	[self.textContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.originTextBtn.mas_right).offset(10);
		make.top.equalTo(self.appImageView.mas_bottom).offset(37);
		make.right.equalTo(self.view).offset(-15);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.textContentLabel.mas_bottom).offset(23);
		make.left.equalTo(self.contentScrollView);
		make.width.mas_equalTo(SCREEN_WIDTH);
		make.height.mas_equalTo(1);
	}];
	
	[self.replyContentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.seperatorLine.mas_bottom).offset(19);
		make.left.equalTo(self.contentScrollView).offset(15);
		make.width.mas_equalTo(SCREEN_WIDTH - 30);
	}];
	[self.replyContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.replyContentView).offset(10);
		make.right.equalTo(self.replyContentView).offset(-10);
		make.top.equalTo(self.replyContentView).offset(8);
		make.bottom.equalTo(self.replyContentView).offset(-10);
	}];
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyContentView.mas_bottom).offset(20);
		make.left.equalTo(self.contentScrollView).offset(15);
		make.size.mas_equalTo(CGSizeMake(40, 40));
	}];
	[self.authLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.headImageView.mas_right).offset(8);
		make.centerY.equalTo(self.headImageView);
	}];
	[self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headImageView.mas_bottom).offset(12);
		make.left.equalTo(self.contentScrollView).offset(15);
		make.width.mas_equalTo(SCREEN_WIDTH - 30);
	}];
	
	//
	[self.qrContentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentLabel.mas_bottom).offset(40);
		make.left.equalTo(self.contentScrollView);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 80));
		make.bottom.equalTo(self.contentScrollView).offset(-37);
	}];
	[self.qrImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.qrContentView).offset(-15);
		make.centerY.equalTo(self.qrContentView);
		make.size.mas_equalTo(CGSizeMake(50, 50));
	}];
	[self.qrTipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.qrImageView.mas_left).offset(-20);
		make.centerY.equalTo(self.qrContentView);
	}];
	
	//
	[self.shareContentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.bottom.equalTo(self.view).offset(- 50 - kBottomSafeArea);
		make.height.mas_equalTo(104);
	}];
	[self.shareBtnArr mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:44 leadSpacing:48 tailSpacing:48];
	[self.shareBtnArr mas_makeConstraints:^(MASConstraintMaker *make) {
		make.size.mas_equalTo(CGSizeMake(44, 44));
		make.centerY.equalTo(self.shareContentView);
	}];
	[self.cancelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.bottom.equalTo(self.view).offset(- kBottomSafeArea);
		make.height.mas_equalTo(50);
	}];
}

- (void)configQrCode {
	NSUInteger textId;
	if (self.paperModel){
		textId  = self.paperModel.textId;
	} else {
		textId = self.messageListItem.sourceId;
	}
	@weakify(self)
	[ESNetworkService getPaperFowardInfoWithTextId:textId Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe(^{
				//生成二维码
				UIImage *qrImage = [self getQrCodeWithUrl:[data objectForKey:@"link"]];
				self.qrImageView.image = qrImage;
			});
		} else {
			
		}
	}];
}

- (void)configView {
	if (self.paperModel) {
		self.textContentLabel.text = self.paperModel.textTitle;
	} else {
		self.textContentLabel.text = self.messageListItem.title;
	}
	if (self.replyListItem) {
		if (self.replyListItem.otherCommentId == 0) {
			self.replyContentLabel.text = @"";
			self.replyContentView.hidden = YES;
			[self.headImageView sd_setImageWithURL:[NSURL URLWithString:self.replyListItem.avatar] placeholderImage:GetImage(@"avatar")];
			self.authLabel.text = self.replyListItem.userName;
			self.contentLabel.text = self.replyListItem.content;
			[self.headImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.seperatorLine.mas_bottom).offset(27);
				make.left.equalTo(self.contentScrollView).offset(15);
				make.size.mas_equalTo(CGSizeMake(40, 40));
			}];
		} else {
			self.replyContentLabel.text = [NSString stringWithFormat:@"引用@%@说:\"%@\"",self.replyListItem.otherCommentUserName, self.replyListItem.otherCommentContent];
			self.replyContentView.hidden = NO;
			[self.headImageView sd_setImageWithURL:[NSURL URLWithString:self.replyListItem.avatar] placeholderImage:GetImage(@"avatar")];
			self.authLabel.text = self.replyListItem.userName;
			self.contentLabel.text = self.replyListItem.content;
		}
	} else {
		self.replyContentLabel.text = @"";
		self.replyContentView.hidden = YES;
		[self.headImageView sd_setImageWithURL:[NSURL URLWithString:self.commentItem.avatar] placeholderImage:GetImage(@"avatar")];
		self.authLabel.text = self.commentItem.userName;
		self.contentLabel.text = self.commentItem.content;
		[self.headImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.seperatorLine.mas_bottom).offset(27);
			make.left.equalTo(self.contentScrollView).offset(15);
			make.size.mas_equalTo(CGSizeMake(40, 40));
		}];
	}
}

#pragma mark - qrCode && 截屏 &&分享
- (UIImage *)getQrCodeWithUrl:(NSString *)url {
	// 创建过滤器
	CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
	// 过滤器恢复默认
	[filter setDefaults];
	// 给过滤器添加数据
	NSData *data = [url dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
	[filter setValue:data forKeyPath:@"inputMessage"];
	// 获取二维码过滤器生成的二维码
	CIImage *image = [filter outputImage];
	return [self createNonInterpolatedUIImageFormCIImage:image withSize:300];// withSize 大于等于视图显示的尺寸
}

//--生成高清二维码
- (UIImage *)createNonInterpolatedUIImageFormCIImage:(CIImage *)image withSize:(CGFloat) size {
	CGRect extent = CGRectIntegral(image.extent);
	CGFloat scale = MIN(size/CGRectGetWidth(extent), size/CGRectGetHeight(extent));
	// 创建 bitmap
	size_t width = CGRectGetWidth(extent) * scale;
	size_t height = CGRectGetHeight(extent) * scale;
	CGColorSpaceRef cs = CGColorSpaceCreateDeviceGray();
	CGContextRef bitmapRef = CGBitmapContextCreate(nil, width, height, 8, 0, cs, (CGBitmapInfo)kCGImageAlphaNone);
	CIContext *context = [CIContext contextWithOptions:nil];
	CGImageRef bitmapImage = [context createCGImage:image fromRect:extent];
	CGContextSetInterpolationQuality(bitmapRef, kCGInterpolationNone);
	CGContextScaleCTM(bitmapRef, scale, scale);
	CGContextDrawImage(bitmapRef, extent, bitmapImage);
	
	// 保存 bitmap 到图片
	CGImageRef scaledImage = CGBitmapContextCreateImage(bitmapRef);
	CGContextRelease(bitmapRef);
	CGImageRelease(bitmapImage);
	return [UIImage imageWithCGImage:scaledImage];
}

//截屏
- (UIImage *)getShareImage {
	UIImage* image = nil;
	CGPoint savedContentOffset = self.contentScrollView.contentOffset;
	CGRect savedFrame = self.contentScrollView.frame;
	self.contentScrollView.contentOffset = CGPointZero;
	self.contentScrollView.height = self.contentScrollView.contentSize.height;
	
	//把View绘制成UIImage
	UIGraphicsBeginImageContextWithOptions(self.contentScrollView.size, NO, [UIScreen mainScreen].scale);
	CGContextRef ctx = UIGraphicsGetCurrentContext();
	[self.contentScrollView.layer renderInContext:ctx];
	image = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	self.contentScrollView.contentOffset = savedContentOffset;
	self.contentScrollView.frame = savedFrame;

	return image;
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
	NSString *msg = nil ;
	if(error != NULL){
		msg = @"图片保存失败" ;
	}else{
		msg = @"图片保存成功，可到相册查看" ;
	}
	[CMMUtility showToastWithText:msg];
}

- (void)systemShareWith:(UIImage *)image {
	// 1、设置分享的内容，并将内容添加到数组中
	NSArray *activityItemsArray = @[image];
	NSArray *activityArray = @[];
	
	// 2、初始化控制器，添加分享内容至控制器
	UIActivityViewController *activityVC = [[UIActivityViewController alloc]initWithActivityItems:activityItemsArray applicationActivities:activityArray];
	activityVC.modalInPopover = YES;
	// 3、设置回调
	UIActivityViewControllerCompletionWithItemsHandler itemsBlock = ^(UIActivityType __nullable activityType, BOOL completed, NSArray * __nullable returnedItems, NSError * __nullable activityError){
		NSLog(@"activityType == %@",activityType);
		if (completed == YES) {
			NSLog(@"completed");
		}else{
			NSLog(@"cancel");
		}
	};
	activityVC.completionWithItemsHandler = itemsBlock;
	[self presentViewController:activityVC animated:YES completion:nil];
}

//type : 0 - 聊天 1 - 朋友圈
- (void)weChatShareWithImage:(UIImage *)image type:(int)type{
	[ESNetworkService completeShareTaskWithResponse:^(id dict, ESError *error) {
	}];
	if([WXApi isWXAppInstalled]){//判断当前设备是否安装微信客户端
		NSData *imageData = UIImageJPEGRepresentation(image, 0.7);
		
		WXImageObject *imageObject = [WXImageObject object];
		imageObject.imageData = imageData;
		
		WXMediaMessage *message = [WXMediaMessage message];
		message.thumbData = nil;
		message.mediaObject = imageObject;
		
		SendMessageToWXReq *req = [[SendMessageToWXReq alloc] init];
		req.bText = NO;
		req.message = message;
		req.scene = type;
		[WXApi sendReq:req completion:nil];
	}else{
		//未安装微信应用或版本过低
		[self systemShareWith:image];
	}
}

#pragma mark - aciton
- (void)cancelBtnClick {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)shareBtnClick:(UIButton *)btn {
	//获取分享截图
	UIImage *shareImage = [self getShareImage];
	if (!shareImage) {
		[CMMUtility showToastWithText:@"获取分享截图失败,请重试"];
		return;
	}
	switch (btn.tag) {
		case 0: {
			//微信
			[self weChatShareWithImage:shareImage type:0];
		}
			break;
		case 1: {
			//朋友圈
			[self weChatShareWithImage:shareImage type:1];
		}
			break;
		case 2: {
			//本地保存
			UIImageWriteToSavedPhotosAlbum(shareImage, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
		}
			break;
		case 3: {
			//系统分享
			[self systemShareWith:shareImage];
		}
			break;
		default:
			break;
	}
}

#pragma mark - lazy init
- (UIScrollView *)contentScrollView {
	if (!_contentScrollView) {
		_contentScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 154 - kBottomSafeArea)];
		_contentScrollView.showsVerticalScrollIndicator = NO;
		_contentScrollView.backgroundColor = [UIColor whiteColor];
	}
	return _contentScrollView;
}

- (UIImageView *)appImageView {
	if (!_appImageView) {
		_appImageView = [UIImageView new];
		_appImageView.image = GetImage(@"app_icon");
		_appImageView.layer.cornerRadius = 4;
		_appImageView.clipsToBounds = YES;
		[self.contentScrollView addSubview:_appImageView];
	}
	return _appImageView;
}

- (UILabel *)shareTitleLabel {
	if (!_shareTitleLabel) {
		_shareTitleLabel = [UILabel new];
		_shareTitleLabel.text = @"飞驰体育｜精彩评论";
		_shareTitleLabel.textColor = ColorAppBlack;
		_shareTitleLabel.font = fcBoldFont(18);
		[self.contentScrollView addSubview:_shareTitleLabel];
	}
	return _shareTitleLabel;
}

- (UIButton *)originTextBtn {
	if (!_originTextBtn) {
		_originTextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_originTextBtn setTitle:@"原文" forState:UIControlStateNormal];
		[_originTextBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_originTextBtn.titleLabel.font = fcFont(12);
		_originTextBtn.enabled = NO;
		_originTextBtn.backgroundColor = RGBCOLOR(168, 168, 168);
		_originTextBtn.layer.cornerRadius = 2;
		[self.contentScrollView addSubview:_originTextBtn];
	}
	return _originTextBtn;
}

- (UILabel *)textContentLabel {
	if (!_textContentLabel) {
		_textContentLabel = [UILabel new];
		_textContentLabel.textColor = RGBCOLOR(136, 136, 136);
		_textContentLabel.font = fcFont(14);
		_textContentLabel.numberOfLines = 2;
		[self.contentScrollView addSubview:_textContentLabel];
	}
	return _textContentLabel;
}

- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [[UIImageView alloc] init];
		_headImageView.contentMode = UIViewContentModeScaleAspectFill;
		_headImageView.clipsToBounds = YES;
		_headImageView.layer.cornerRadius = 20;
		[self.contentScrollView addSubview:_headImageView];
	}
	return _headImageView;
}

- (UIView *)replyContentView {
	if (!_replyContentView) {
		_replyContentView = [UIView new];
		_replyContentView.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentScrollView addSubview:_replyContentView];
	}
	return _replyContentView;
}

- (UILabel *)replyContentLabel {
	if (!_replyContentLabel) {
		_replyContentLabel = [UILabel new];
		_replyContentLabel.textColor = ColorAppBlack;
		_replyContentLabel.font = fcFont(12);
		_replyContentLabel.numberOfLines = 3;
		[self.contentScrollView addSubview:_replyContentLabel];
	}
	return _replyContentLabel;
}

- (UILabel *)contentLabel {
	if (!_contentLabel) {
		_contentLabel = [UILabel new];
		_contentLabel.textColor = ColorAppBlack;
		_contentLabel.font = fcFont(14);
		_contentLabel.numberOfLines = 0;
		[self.contentScrollView addSubview:_contentLabel];
	}
	return _contentLabel;
}

- (UILabel *)authLabel {
	if (!_authLabel) {
		_authLabel = [UILabel new];
		_authLabel.textColor = ColorAppBlack;
		_authLabel.font = fcFont(14);
		[self.contentScrollView addSubview:_authLabel];
	}
	return _authLabel;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentScrollView addSubview:_seperatorLine];
	}
	return _seperatorLine;
}

//二维码区域
- (UIView *)qrContentView {
	if (!_qrContentView) {
		_qrContentView = [UIView new];
		_qrContentView.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentScrollView addSubview:_qrContentView];
	}
	return _qrContentView;
}

- (UILabel *)qrTipLabel {
	if (!_qrTipLabel) {
		_qrTipLabel = [UILabel new];
		_qrTipLabel.text = @"长按识别二维码\n查看原文及更多精彩评论";
		_qrTipLabel.textColor = ColorAppBlack;
		_qrTipLabel.font = fcFont(12);
		_qrTipLabel.numberOfLines = 2;
		[self.qrContentView addSubview:_qrTipLabel];
	}
	return _qrTipLabel;
}

- (UIImageView *)qrImageView {
	if (!_qrImageView) {
		_qrImageView = [[UIImageView alloc] init];
		[self.qrContentView addSubview:_qrImageView];
	}
	return _qrImageView;
}

//分享区域
- (UIView *)shareContentView {
	if (!_shareContentView) {
		_shareContentView = [UIView new];
		_shareContentView.backgroundColor = [UIColor whiteColor];
		[self.view addSubview:_shareContentView];
	}
	return _shareContentView;
}

- (NSMutableArray<UIButton *> *)shareBtnArr {
	if (!_shareBtnArr) {
		_shareBtnArr = [NSMutableArray array];
		NSArray *imageArr = @[@"微信",@"朋友圈",@"本地相册",@"系统分享"];
		for (NSUInteger i = 0; i < 4; i++) {
			UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
			[btn setImage:GetImage(imageArr[i]) forState:UIControlStateNormal];
			btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
			btn.tag = i;
			[btn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
			[self.shareContentView addSubview:btn];
			[_shareBtnArr addObject:btn];
		}
	}
	return _shareBtnArr;
}

- (UIButton *)cancelBtn {
	if (!_cancelBtn) {
		_cancelBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_cancelBtn setTitle:@"取消" forState:UIControlStateNormal];
		_cancelBtn.titleLabel.font = fcFont(16);
		[_cancelBtn setTitleColor:ColorAppBlack forState:UIControlStateNormal];
		[_cancelBtn addTarget:self action:@selector(cancelBtnClick) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_cancelBtn];
	}
	return _cancelBtn;
}

@end
