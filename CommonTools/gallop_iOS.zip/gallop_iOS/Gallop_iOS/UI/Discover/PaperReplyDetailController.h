//
//  PaperReplyDetailController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"
#import "ESBanner.h"
#import "MessageCenterListModel.h"

//查看回复 || 互动消息详情页
typedef enum : NSUInteger {
	PageTypeReply,//查看回复
	PageTypeDetail,//互动消息详情
} PageType;

@interface PaperReplyDetailController : ESViewController
@property (nonatomic,assign)PageType pageType;
@property (nonatomic,strong)ESCommentItem *commentModel;
@property (nonatomic,strong)ESPaperModel *paperModel;
@property (nonatomic,strong)MessageListItem *messageListModel;
@end
