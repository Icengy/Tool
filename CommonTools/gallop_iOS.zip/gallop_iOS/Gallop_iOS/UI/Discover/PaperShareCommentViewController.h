//
//  PaperShareCommentViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/11.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"
#import "ESBanner.h"

//分享评论页面
@interface PaperShareCommentViewController : ESViewController
@property (nonatomic,strong) ESPaperModel *paperModel;
@property (nonatomic,strong) ReplyListItem *replyListItem;
@property (nonatomic,strong) ESCommentItem *commentItem;
@property (nonatomic,strong) MessageListItem *messageListItem;
@end

