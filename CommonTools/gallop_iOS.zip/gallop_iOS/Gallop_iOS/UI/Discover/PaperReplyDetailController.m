//
//  PaperReplyDetailController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperReplyDetailController.h"
#import "ESBanner.h"
#import "PaperReplyListCell.h"
#import "PaperBottomView.h"
#import "PaperCommentView.h"
#import "PaperContentViewController.h"
#import "MLMOptionSelectView.h"
#import "PaperShareCommentViewController.h"
#import "PaperCommentViewController.h"
#import "CommunityHomePageViewController.h"
//分享
#import "ESShareViewController.h"

@interface PaperReplyDetailController ()<PaperCommentCellDelegate,PaperBottomViewDelegate,PaperCommentViewDelegate>
@property (nonatomic, strong) UIView *commentHeaderView;
@property (nonatomic, strong) UILabel *totalLabel;
@property (nonatomic, strong) MLMOptionSelectView *sortSelectView;
@property (nonatomic, strong) PaperBottomView *bottomView;  //底部tab框
@property (nonatomic, strong) PaperCommentView *commentView; //评论输入框

@property (nonatomic, strong) PaperCommentReplyList *model;
@property (nonatomic, strong) ReplyListItem *floorItem;
@property (nonatomic, strong) ReplyListItem *replyModel;
@property (nonatomic, strong) NSMutableArray<ReplyListItem *> *commentList;
@property (nonatomic, assign) NSInteger  otherCommentId;	//当前评论的层主id
@property (nonatomic, strong) NSString *otherCommentContent;//回复别人时记录用于生成本地消息
@property (nonatomic, strong) NSString *otherCommentUserName; //回复别人时记录用于生成本地消息
@property (nonatomic, assign) NSUInteger currentPage;
@property (nonatomic, assign) NSUInteger currentLastPage;//用于下拉加载之前页面记录
@property (nonatomic, assign) NSUInteger pageSize;
@property (nonatomic, assign) NSUInteger selectedSort;
@property (nonatomic, assign) NSUInteger commentId;
@end

@implementation PaperReplyDetailController
- (void)viewDidLoad {
	[super viewDidLoad];
	self.navigationItem.title = @"查看回复";
	self.commentList = [NSMutableArray array];
	self.selectedSort = 2;
	self.floorItem = [[ReplyListItem alloc] init];
	[self initWithSubView];
	if (self.pageType == PageTypeDetail) {
		[self getReplyModel];
	}
	[self loadCommentList];
}

- (void)initWithSubView{
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.view).offset(NavBarHeight);
	}];
	self.tableView.allowsSelection = NO;
	self.tableView.backgroundColor = RGBCOLOR(244, 244, 244);
	self.tableView.estimatedRowHeight = 0;
	self.tableView.estimatedSectionFooterHeight = 0;
	self.tableView.estimatedSectionHeaderHeight = 0;
	
	[self.tableView registerClass:[PaperReplyListCell class] forCellReuseIdentifier:@"PaperReplyListCellIdentifier"];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
}

#pragma mark - fetch Data
- (void)getReplyModel {
	@weakify(self)
	[ESNetworkService getCommunityReplyMessageWithCommentId:self.messageListModel.otherCommentId messageType:1 Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				self.replyModel = [ReplyListItem mj_objectWithKeyValues:dict[@"data"]];
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadCommentList {
	if (self.pageType == PageTypeDetail) {
		//消息中心跳转过来
		self.commentId = self.messageListModel.hostCommentId;
	} else {
		self.commentId = self.commentModel.commentId;
	}
	self.currentPage = 1;
	self.pageSize = 20;
	
	//获取评论列表
	@weakify(self)
	[ESNetworkService paperCommentReplyListWithHostCommentId:self.commentId sortType:self.selectedSort page:self.currentPage pageSize:self.pageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			PaperCommentReplyList *model = [PaperCommentReplyList mj_objectWithKeyValues:dict[@"data"]];
			self.model = model;
			dispatch_main_async_safe(^{
				if (self.currentPage >= self.model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				} else {
					[self.tableView.mj_footer resetNoMoreData];
				}
				[self.commentList removeAllObjects];
				[self.commentList addObjectsFromArray:model.replyList];
				[self.tableView reloadData];
			
				if (self.model.commentStatus == 1) {
					[self.bottomView configViewWithModel:nil isComunity:NO];
					self.bottomView.hidden = NO;
				} else {
					self.bottomView.hidden = YES;
				}
				//模型转换方便填充
				if (self.commentModel) {
					self.floorItem.commentId = self.commentModel.commentId;
				} else {
					self.floorItem.commentId = self.messageListModel.hostCommentId;
				}
				self.floorItem.userName = self.model.userName;
				self.floorItem.avatar = self.model.avatar;
				self.floorItem.content = self.model.content;
				self.floorItem.liked = self.model.liked;
				self.floorItem.likeCount = self.model.likeCount;
				self.floorItem.createTime = self.model.createTime;
				self.floorItem.userId = self.model.userId;
			});
		} else {
			
		}
	}];
}

//拉取当前下一页
- (void)loadMoreData {
	self.currentPage ++;
	//获取评论列表
	@weakify(self)
	[ESNetworkService paperCommentReplyListWithHostCommentId:self.commentId sortType:self.selectedSort page:self.currentPage pageSize:self.pageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.tableView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			PaperCommentReplyList *model = [PaperCommentReplyList mj_objectWithKeyValues:dict[@"data"]];
			self.model = model;
			dispatch_main_async_safe(^{
				if (self.currentPage >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.commentList addObjectsFromArray:model.replyList];
				[self.tableView reloadData];
			});
		} else {
			
		}
	}];
}

#pragma mark - action
- (void)defaultCell:(NSArray*)listArray CellView:(MLMOptionSelectView*)cellView{
	WEAK(weakCellView, cellView);
	cellView.canEdit = NO;
	cellView.showsVerticalScrollIndicator = YES;
	if (listArray.count > 5) {
		//暂时显示滚动条
		[cellView flashScrollIndicators];
	}
	[cellView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
	
	cellView.cell = ^(NSIndexPath *indexPath){
		
		UITableViewCell *cell = [weakCellView dequeueReusableCellWithIdentifier:@"DefaultCell"];
		
		cell.backgroundColor =[UIColor whiteColor];
		cell.textLabel.textColor = ColorSubTitle;
		cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@",listArray[indexPath.row]]];
		cell.textLabel.textAlignment = NSTextAlignmentCenter;
		
		
		cell.textLabel.font = GetFont(13.0f);
		return cell;
	};
	cellView.optionCellHeight = ^{
		
		return 40.f;
	};
	cellView.rowNumber = ^(){
		
		return (NSInteger)listArray.count;
	};
}

- (void)hotBtnClick:(UIButton *)btn {
	UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
	CGRect nowRect = [btn convertRect:btn.bounds toView:window];
	
	self.sortSelectView = [[MLMOptionSelectView alloc] initOptionView];
	
	NSMutableArray*arr1 = [NSMutableArray array];
	[arr1 addObjectsFromArray:@[@"最多赞数",@"最晚回复",@"最早回复"]];
	
	[self defaultCell:arr1 CellView:self.sortSelectView];
	
	self.sortSelectView.vhShow = YES;
	self.sortSelectView.optionType = MLMOptionSelectViewTypeCustom;
	self.sortSelectView.edgeInsets = UIEdgeInsetsZero;
	[self.sortSelectView showTapPoint:CGPointMake(nowRect.origin.x + 50, nowRect.origin.y+30) viewWidth:nowRect.size.width + 10 direction:MLMOptionSelectViewBottom];
	
	@weakify(self)
	self.sortSelectView.selectedOption = ^(NSIndexPath *index) {
		@strongify(self)
		self.selectedSort = index.row + 2;
		[btn setTitle:arr1[index.row] forState:UIControlStateNormal];
		[self loadCommentList];
	};
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	if (section == 0) {
		return 0.01;
	}
	if (self.commentList.count <= 0) {
		return 0.01;
	} else {
		return 48;
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	if (section == 0) {
		return nil;
	}
	if (self.commentList.count <= 0) {
		return nil;
	}
	UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 48)];
	//分割区域
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 8)];
	view.backgroundColor = RGBCOLOR(244, 244, 244);
	[headView addSubview:view];
	//sectionHeader
	[headView addSubview:self.commentHeaderView];
	[self.commentHeaderView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.left.right.equalTo(headView);
		make.height.mas_equalTo(40);
	}];
	
	return headView;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	if (section == 0) {
		if (self.pageType == PageTypeDetail && self.replyModel) {
			return 2;
		} else {
			return 1;
		}
	}
	return self.commentList.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section == 0) {
		if (indexPath.row == 0) {
			//楼主
			PaperReplyListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PaperReplyListCellIdentifier"];
			cell.cellDelegate = self;
			if (self.pageType == PageTypeDetail) {
				self.floorItem.messageListItem = self.messageListModel;
				[cell configCellWithModel:self.floorItem indexPath:9999];
			} else {
				self.floorItem.messageListItem = nil;
				[cell configCellWithModel:self.floorItem indexPath:999];
			}
			return cell;
		} else {
			PaperReplyListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PaperReplyListCellIdentifier"];
			cell.cellDelegate = self;
			[cell configCellWithModel:self.replyModel indexPath:10000];
			return cell;
		}
	}
	//回复
	PaperReplyListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PaperReplyListCellIdentifier"];
	cell.cellDelegate = self;
	[cell configCellWithModel:self.commentList[indexPath.row] indexPath:indexPath.row];
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	tableView.rowHeight = UITableViewAutomaticDimension;
	tableView.estimatedRowHeight = 75;
	return tableView.rowHeight;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 2;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
}

#pragma mark - PaperCellDelegate
- (void)likeClick:(NSUInteger)index {
	if (index == 999 || index == 9999) {
		//对楼主点赞
		@weakify(self)
		[ESNetworkService commentLikeStatusChangeWithCommentId:self.floorItem.commentId likeStatus:!self.floorItem.liked Response:^(id dict, ESError *error) {
			@strongify(self)
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				dispatch_main_async_safe(^{
					self.floorItem.liked = !self.floorItem.liked;
					self.floorItem.likeCount = [data[@"likeCount"] integerValue];
					[UIView performWithoutAnimation:^{
						[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
					}];
				});
			} else {
				
			}
		}];
	} else if (index == 10000) {
		//对回复点赞
		@weakify(self)
		[ESNetworkService communityPostCommentLikeWithCommentId:self.replyModel.commentId likeStatus:!self.replyModel.liked Response:^(id dict, ESError *error) {
			@strongify(self)
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				dispatch_main_async_safe(^{
					self.replyModel.liked = !self.replyModel.liked;
					self.replyModel.likeCount = [data[@"likeCount"] integerValue];
					[UIView performWithoutAnimation:^{
						[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:1 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
					}];
				});
			} else {
				
			}
		}];
	} else {
		//对回复点赞
		@weakify(self)
		[ESNetworkService commentLikeStatusChangeWithCommentId:self.commentList[index].commentId likeStatus:!self.commentList[index].liked Response:^(id dict, ESError *error) {
			@strongify(self)
			if (dict&&[dict[@"code"] integerValue] == 0) {
				NSDictionary *data = dict[@"data"];
				dispatch_main_async_safe(^{
					self.commentList[index].liked = !self.commentList[index].liked;
					self.commentList[index].likeCount = [data[@"likeCount"] integerValue];
					[UIView performWithoutAnimation:^{
						[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:1]] withRowAnimation:UITableViewRowAnimationNone];
					}];
				});
			} else {
				
			}
		}];
	}
}

- (void)replyClick:(NSUInteger)index {
	if (self.model.commentStatus == 1) {
		
	} else {
		return;
	}
	if (index == 10000) {
		self.otherCommentId = self.replyModel.commentId;
		self.otherCommentContent = self.replyModel.content;
		self.otherCommentUserName = self.replyModel.userName;
	} else {
		self.otherCommentId = self.commentList[index].commentId;
		self.otherCommentContent = self.commentList[index].content;
		self.otherCommentUserName = self.commentList[index].userName;
	}
	//弹出评论框
	self.commentView.placeHolderLabel.text = [NSString stringWithFormat:@"回复[%@]:%@",self.otherCommentUserName,self.otherCommentContent];
	[self.commentView showPaperCommentView];
}

- (void)shareClick:(NSUInteger)index {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//分享评论
	PaperShareCommentViewController *vc = [[PaperShareCommentViewController alloc] init];
	vc.paperModel = self.paperModel;
	if (index == 10000) {
		if (self.replyModel.hideShow == 0) {
			[CMMUtility showToastWithText:@"违规评论不可分享"];
			return;
		}
		vc.replyListItem = self.replyModel;
	} else {
		if (self.commentList[index].hideShow == 0) {
			[CMMUtility showToastWithText:@"违规评论不可分享"];
			return;
		}
		vc.replyListItem = self.commentList[index];
	}
	vc.messageListItem = self.messageListModel;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)extenClick:(NSUInteger)index isExtend:(BOOL)isExtend{
	if (index == 10000) {
		self.replyModel.isExtend = !isExtend;
		[UIView performWithoutAnimation:^{
			[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:1 inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
		}];
	} else {
		self.commentList[index].isExtend = !isExtend;
		[UIView performWithoutAnimation:^{
			[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:index inSection:1]] withRowAnimation:UITableViewRowAnimationNone];
		}];
	}
}

- (void)textTitleClick:(NSUInteger)textId {
	ESBanner *bannerModel = [ESBanner new];
	bannerModel.textId = @(textId).stringValue;
	bannerModel.textType = 0;
	bannerModel.textFormat = @"1";
	bannerModel.link = @"";
	//文章
	PaperContentViewController*vc = [PaperContentViewController new];
	vc.banerModel = bannerModel;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)goHomePage:(NSUInteger)index {
	CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
	
	if (index == 10000) {
		vc.authorUid = self.replyModel.userId;
	} else if (index == 999 || index == 9999){
		vc.authorUid = self.floorItem.userId;
	} else {
		vc.authorUid = self.commentList[index].userId;
	}
	
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - PaperBottomViewDelegate
- (void)commentClick {
	self.otherCommentId = 0;
	self.otherCommentContent = @"";
	self.otherCommentUserName = @"";
	//弹出评论框
	self.commentView.placeHolderLabel.text = @"说说你的看法";
	[self.commentView showPaperCommentView];
}

- (void)tabShareClick:(UIButton *)btn {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	NSUInteger textId;
	if (self.pageType == PageTypeReply) {
		textId = self.paperModel.textId;
	} else {
		textId = self.messageListModel.textId;
	}
	//分享文章
	@weakify(self)
	[ESNetworkService getPaperFowardInfoWithTextId:textId Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSDictionary *data = dict[@"data"];
			dispatch_main_async_safe(^{
				[self shareWithModel:data];
			});
		} else {
			
		}
	}];
}

- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

#pragma mark - PaperCommentViewDelegate
- (void)sendBtnClick:(NSString *)content {
	//发送评论
	if (QM_IS_STR_NIL(content)) {
		[CMMUtility showToastWithText:@"评论内容不能为空"];
		return;
	}
	if (content.length > 1500) {
		[CMMUtility showToastWithText:@"评论字数不能超过1500个字符"];
		return;
	}
	//调用回复接口
	@weakify(self)
	[ESNetworkService paperCommentWithHostCommentId:self.floorItem.commentId otherCommentId:self.otherCommentId content:content Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe((^{
				self.commentView.textView.text = @"";
				[self.commentView hidePaperCommentView];
				//生成本地消息插入列表最上方
				ReplyListItem *item = [ReplyListItem mj_objectWithKeyValues:dict[@"data"]];
				item.content = content;
				item.otherCommentId = self.otherCommentId;
				item.otherCommentContent = self.otherCommentContent;
				item.otherCommentUserName = self.otherCommentUserName;
				item.hideShow = 1;
				NSDate *datenow = [NSDate date];
				item.createTime = [NSString stringWithFormat:@"%ld", (long)([datenow timeIntervalSince1970]*1000)];
				
				[self.commentList insertObject:item atIndex:0];
				self.totalLabel.text = [NSString stringWithFormat:@"全部回复  %@条", dict[@"data"][@"commentCount"]];
				[self.tableView reloadData];
				NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
				[self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
				[[NSNotificationCenter defaultCenter] postNotificationName:kReplyCommitSuccess object:nil];
			}));
		} else {
			
		}
	}];
}

- (void)fullScreenBtnClick:(NSString *)content {
	//全屏输入
	PaperCommentViewController *vc = [[PaperCommentViewController alloc] init];
	vc.delegate = self;
	vc.commentType = CommentTypePaper;
	//弹出评论框
	if (QM_IS_STR_NIL(self.otherCommentContent)) {
		vc.placeHolder = @"说说你的看法";
	} else {
		vc.placeHolder = [NSString stringWithFormat:@"回复[%@]:%@",self.otherCommentUserName,self.otherCommentContent];
	}
	vc.content = content;
	vc.backBlock = ^(NSString *content) {
		self.commentView.textView.text = content;
		if (QM_IS_STR_NIL(content)) {
			self.commentView.placeHolderLabel.hidden = NO;
		} else {
			self.commentView.placeHolderLabel.hidden = YES;
		}
	};
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - lazy init
- (UIView *)commentHeaderView {
	if (!_commentHeaderView) {
		_commentHeaderView = [UIView new];
		_commentHeaderView.backgroundColor = [UIColor whiteColor];
		//
		self.totalLabel = [UILabel new];
		self.totalLabel.textColor = ColorAppBlack;
		self.totalLabel.text = [NSString stringWithFormat:@"全部回复  %@条",@(self.model.totalCount)];
		self.totalLabel.font = fcFont(16);
		[_commentHeaderView addSubview:self.totalLabel];
		[self.totalLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(_commentHeaderView).offset(14);
			make.centerY.equalTo(_commentHeaderView);
		}];
		//
		UIButton *hotBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[hotBtn setTitle:@"最多赞数" forState:UIControlStateNormal];
		[hotBtn setImage:GetImage(@"paper_filter_icon") forState:UIControlStateNormal];
		hotBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		hotBtn.titleLabel.font = fcFont(14);
		[hotBtn setTitleColor:RGBCOLOR(6, 120, 125) forState:UIControlStateNormal];
		[hotBtn addTarget:self action:@selector(hotBtnClick:) forControlEvents:UIControlEventTouchUpInside];

		[_commentHeaderView addSubview:hotBtn];
		[hotBtn mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(_commentHeaderView).offset(-14);
			make.centerY.equalTo(_commentHeaderView);
			make.height.mas_equalTo(20);
		}];
		//
		UIView *seperatorLine = [UIView new];
		seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[_commentHeaderView addSubview:seperatorLine];
		[seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.bottom.equalTo(_commentHeaderView);
			make.height.mas_equalTo(1);
		}];
	}
	return _commentHeaderView;
}

- (PaperBottomView *)bottomView {
	if (!_bottomView) {
		_bottomView = [[PaperBottomView alloc] init];
		[self.view addSubview:_bottomView];
		[_bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.equalTo(self.view);
			make.bottom.equalTo(self.tableView);
			make.height.mas_equalTo(50);
		}];
		_bottomView.viewDelegate = self;
	}
	return _bottomView;
}

- (PaperCommentView *)commentView {
	if (!_commentView) {
		_commentView = [[PaperCommentView alloc] init];
		_commentView.hidden = YES;
		_commentView.delegate = self;
		_commentView.placeHolderLabel.text = @"说说你的看法";
		[self.view addSubview:_commentView];
		[_commentView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.bottom.left.right.top.equalTo(self.tableView);
		}];
	}
	return _commentView;
}

@end
