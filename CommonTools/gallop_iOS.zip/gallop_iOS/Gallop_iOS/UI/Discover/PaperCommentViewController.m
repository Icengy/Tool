//
//  PaperCommentViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperCommentViewController.h"
#import <IQKeyboardManager.h>

@interface PaperCommentViewController()<UITextViewDelegate>
@property (nonatomic,strong) UITextView *textView;
@property (nonatomic,strong) UILabel *placeHolderLabel;
@property (nonatomic,strong) UIButton *sendBtn;
@end

@implementation PaperCommentViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[self.textView resignFirstResponder];
	if (self.backBlock) {
		self.backBlock(self.textView.text);
	}
}

- (void)setupView {
	self.navigationItem.title = self.commentType == CommentTypePaper ? @"写评论" : @"回复评论";
	self.view.backgroundColor = [UIColor whiteColor];
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.sendBtn];
	[self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.view).offset(NavBarHeight + 10);
		make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
		make.left.equalTo(self.view).offset(15);
		make.right.equalTo(self.view).offset(-15);
	}];
	
	[self.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.textView).offset(10);
		make.top.equalTo(self.textView).offset(10);
		make.width.mas_equalTo(SCREEN_WIDTH - 50);
	}];

	self.placeHolderLabel.text = self.placeHolder;
	self.textView.text = self.content;
	
	[self.textView becomeFirstResponder];
}

#pragma mark - action
- (void)sendBtnClick {
	NSString *content = self.textView.text;
	if (QM_IS_STR_NIL(content)) {
		[CMMUtility showToastWithText:@"评论内容不能为空"];
		return;
	}
	if (content.length > 1500) {
		[CMMUtility showToastWithText:@"评论字数不能超过1500个字符"];
		return;
	}
	if ([self.delegate respondsToSelector:@selector(sendBtnClick:)]) {
		[self.delegate sendBtnClick:content];
		[self.navigationController popViewControllerAnimated:YES];
	}
}

#pragma mark - textView delegate
-(void)textViewDidBeginEditing:(UITextView*)textView{
	self.placeHolderLabel.hidden = YES;
}

-(BOOL)textView:(UITextView*)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString*)text{
	return YES;
}

-(void)textViewDidEndEditing:(UITextView*)textView{
	if (QM_IS_STR_NIL(textView.text)) {
		self.placeHolderLabel.hidden = NO;
	} else {
		self.placeHolderLabel.hidden = YES;
	}
}

#pragma mark - lazy init
- (UITextView *)textView {
	if (!_textView) {
		_textView = [[UITextView alloc] init];
		_textView.delegate = self;
		[self.view addSubview:_textView];
	}
	return _textView;
}

- (UILabel *)placeHolderLabel {
	if (!_placeHolderLabel) {
		_placeHolderLabel = [UILabel new];
		_placeHolderLabel.textColor = RGBCOLOR(168, 168, 168);
		_placeHolderLabel.font = fcFont(14);
		_placeHolderLabel.hidden = YES;
		[self.textView addSubview:_placeHolderLabel];
	}
	return _placeHolderLabel;
}


- (UIButton *)sendBtn {
	if (!_sendBtn) {
		_sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_sendBtn setTitle:@"发送" forState:UIControlStateNormal];
		[_sendBtn setTitleColor:ColorAppBlack forState:UIControlStateNormal];
		_sendBtn.titleLabel.font = fcFont(16);
		[_sendBtn addTarget:self action:@selector(sendBtnClick) forControlEvents:UIControlEventTouchUpInside];
	}
	return _sendBtn;
}
@end

