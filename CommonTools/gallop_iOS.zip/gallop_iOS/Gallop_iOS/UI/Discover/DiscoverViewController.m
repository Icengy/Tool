//
//  DiscoverViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/11.
//  Copyright © 2019 homosum. All rights reserved.
//
#define kheadViewHight 400*[UIScreen mainScreen].bounds.size.width/750
//#define kmiddleViewHight 70
#import "DiscoverViewController.h"
//子View
#import "ESNewMainScrollView.h"//轮播图
#import "DiscoverHeadLineView.h"//飞驰头条
#import "TuijianTableViewCell.h"//赛事推荐
#import "MatchResultTableViewCell.h"
#import "DiscoverInformationCell.h"
//模型
#import "ESBanner.h"
#import "MatchInstantListModel.h"
#import "MatchResult.h"
#import "GallopBannerItemModel.h"
#import "NewModel.h"
//Manager
#import "NewsListManager.h"
//跳转的Controller
#import "WTCContentViewController.h"
#import "PaperContentViewController.h"
#import "PayViewController.h"
#import "WTCTabBarViewController.h"
#import "MatchDetailViewController.h"
#import "CYPlanDetailViewController.h"
#import "ExpertDetailViewController.h"
#import "MatchHomeViewController.h"

@interface DiscoverViewController ()<ESNewMainScrollViewDelegate,HeadLineDelegate,NewsListManagerDelegate>
{
    UIView*headView;
}
//view
@property (nonatomic, strong) ESNewMainScrollView*mainScrollView;
@property (nonatomic, strong) DiscoverHeadLineView *headLineView;
//data
@property (nonatomic, copy) NSMutableArray *banners;
@property (nonatomic, copy) NSMutableArray *recommendList;
@property (nonatomic, copy) NSMutableArray *resultList;
//manager
@property (nonatomic, strong) NewsListManager*manager;
@end

@implementation DiscoverViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupViews];
}

-(void)setupViews{
    self.view.backgroundColor = [UIColor colorWithHexString:@"#E7E7E7"];
    self.tableView.frame = CGRectMake(10, 0, SCREEN_WIDTH-20, SCREEN_HEIGHT - TabBarHeight);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.placeHolderView = nil;
    self.tableView.backgroundColor = [UIColor colorWithHexString:@"#E7E7E7"];
    self.tableView.clipsToBounds = NO;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
    
    headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width-20, kheadViewHight+kmiddleViewHight+5)];
    headView.clipsToBounds = NO;
    //	self.mainScrollView = [[ESNewMainScrollView alloc] initWithDelegate:self andHeight:kheadViewHight andWidth:SCREEN_WIDTH andX:-10];
    self.mainScrollView = [[ESNewMainScrollView alloc] initWithFrame:CGRectMake(-10, 0, SCREEN_WIDTH, kheadViewHight) withDelegate:self];
    
    [headView addSubview:self.mainScrollView];
    
    [headView addSubview:self.headLineView];
    self.tableView.tableHeaderView = headView;
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
    
    [self loadData];
}
#pragma mark 网络请求
-(void)loadBanner
{
    [ESNetworkService getBannersDiscoverWithResponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* bannerList = data[@"bannerList"];
            dispatch_main_async_safe(^{
                [self.banners removeAllObjects];
                for (NSDictionary *dic in bannerList) {
                    ESBanner *banner = [ESBanner mj_objectWithKeyValues:dic];
                    [self.banners addObject:banner];
                }
                [self.mainScrollView reloadData];
            });
            
        }
    }];
}

- (void)loadHeadlines {
    @weakify(self);
    [ESNetworkService getHeadlinesDiscoverWithResponse:^(id dict, ESError *error) {
        @strongify(self)
        GallopBannerModel *model = [GallopBannerModel mj_objectWithKeyValues:dict[@"data"]];
        
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                if (QM_IS_ARRAY_NIL(model.data)) {
                    [headView setFrame:CGRectMake(0, 0, kScreen_Width-20, kheadViewHight+5)];
                    self.tableView.tableHeaderView = headView;
                    self.headLineView.hidden = YES;
                    [self.headLineView configViewWithModel:model];
                }else{
                    [headView setFrame:CGRectMake(0, 0, kScreen_Width-20, kheadViewHight+kmiddleViewHight+5)];
                    self.headLineView.hidden = NO;
                    [self.headLineView configViewWithModel:model];
                }
                
            });
        }
    }];
}

-(void)loadTuiJianMatch {
    [ESNetworkService recomandMatchWithresponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* list = data[@"matchList"];
            dispatch_main_async_safe(^{
                [self.recommendList removeAllObjects];
                for (NSDictionary *dic in list) {
                    if (!QM_IS_DICT_NIL(dic)) {
                        InstantMatcth *model = [InstantMatcth mj_objectWithKeyValues:dic];
                        [self.recommendList addObject:model];
                    }
                }
                [self.tableView reloadData];
            });
        }
    }];
}

-(void)loadRecentResult{
    [ESNetworkService recentMatchResultWithresponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* list = data[@"matchList"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.resultList removeAllObjects];
                if (!QM_IS_ARRAY_NIL(list)) {
                    for (NSDictionary *dic in list) {
                        if (!QM_IS_DICT_NIL(dic)) {
                            MatchResult *model = [MatchResult mj_objectWithKeyValues:dic];
                            [self.resultList addObject:model];
                        }
                    }
                }
                [self.tableView reloadData];
            });
        }
    }];
}

-(void)loadData{
    [self.manager refreshData];
    [self loadBanner];
    [self loadHeadlines];
    [self loadTuiJianMatch];
    [self loadRecentResult];
}

-(void)loadMoreData{
    [self.manager loadData];
}

#pragma mark manager代理
-(void)newsListManager:(NewsListManager *)newsListManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
    dispatch_main_async_safe(^{
        [self.tableView.mj_header endRefreshing];
        [self.tableView.mj_footer endRefreshing];
        if (self.manager.dataSource.count == 0) {
        }
        if (!isRefresh && self.manager.dataSource.count >= 20) {
            self.tableView.mj_footer.hidden = NO;
        }else{
            self.tableView.mj_footer.hidden = YES;
        }
        [self.tableView reloadData];
    });
}
#pragma mark tableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
        {
            if (!QM_IS_ARRAY_NIL(self.recommendList)) {
                return 1;
            }
        }
            break;
        case 1:
        {
            if (!QM_IS_ARRAY_NIL(self.resultList)) {
                return 1;
            }
        }
            break;
        case 2:
        {
            if (!QM_IS_ARRAY_NIL(self.manager.dataSource)) {
                return self.manager.dataSource.count;
            }
        }
            break;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
        {
            if (QM_IS_ARRAY_NIL(self.recommendList)) {
                return 0;
            }
            return 125;
        }
            break;
        case 1:
        {
            if (QM_IS_ARRAY_NIL(self.resultList)) {
                return 0;
            }
            return 200;
        }
            break;
        case 2:
        {
            if (QM_IS_ARRAY_NIL(self.manager.dataSource)) {
                return 0;
            }
            return 100;
        }
            break;
            
        default:
            break;
    }
    return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:
        {
            if (QM_IS_ARRAY_NIL(self.recommendList)) {
                return 0.01;
            }
            return 40;
        }
            break;
        case 1:
        {
            if (QM_IS_ARRAY_NIL(self.resultList)) {
                return 0.01;
            }
            return 40;
        }
            break;
        case 2:
        {
            if (QM_IS_ARRAY_NIL(self.manager.dataSource)) {
                return 0.01;
            }
            return 40;
        }
            break;
            
        default:
            break;
    }
    return 0.01;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (indexPath.section) {
        case 0:
        {
            NSString*identifier = @"TuijianTableViewCell";
            TuijianTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            if (!cell) {
                cell = [[TuijianTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.dataSource = [self.recommendList copy];
            cell.clickItems = ^(InstantMatcth * _Nonnull model) {
                //*推出比赛页***//
                dispatch_main_async_safe(^{
                    InstantMatcth *matchModel = model;
                    
                    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
                    //                    liveVC.field = matchModel.;
                    
                    liveVC.matchId = matchModel.matchId;
                    liveVC.sourcePage = @"比赛即时页";
                    
                    [self.navigationController pushViewController:liveVC animated:YES];
                });
            };
            return cell;
        }
            break;
        case 1:
        {
            NSString*identifier = @"MatchResultTableViewCell";
            MatchResultTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            if (!cell) {
                cell = [[MatchResultTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.dataSource = [self.resultList copy];
            cell.clickBlock = ^(MatchResult *model) {
                dispatch_main_async_safe(^{
                    MatchResult *matchModel = model;
                    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
                    //                    liveVC.field = self.field;
                    
                    liveVC.matchId = matchModel.matchId.integerValue;
                    liveVC.sourcePage = @"比赛即时页";
                    
                    [self.navigationController pushViewController:liveVC animated:YES];
                    
                });
            };
            return cell;
        }
            break;
        case 2:
        {
            NSString*identifier = @"DiscoverInformationCell";
            DiscoverInformationCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            if (!cell) {
                cell = [[DiscoverInformationCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            }
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if (self.manager.dataSource.count>=indexPath.row+1) {
                NewModel*model = self.manager.dataSource[indexPath.row];
                [cell configCellWithModel:model];
            }
            return cell;
        }
            break;
        default:
            break;
    }
    return [UITableViewCell new];
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case 0:
        {
            if (!QM_IS_ARRAY_NIL(self.recommendList)) {
                UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width-20, 40)];
                view.backgroundColor = [UIColor colorWithHexString:@"#f4f4f4"];
                UIImageView*icon = [UIImageView new];
                UILabel*nameL = [UILabel new];
                UIButton*allB = [UIButton buttonWithType:UIButtonTypeCustom];
                [view addSubview:icon];
                
                [view addSubview:nameL];
                [view addSubview:allB];
                [icon mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(view);
                    make.left.mas_equalTo(view).offset(10);
                    make.size.mas_equalTo(CGSizeMake(15, 15));
                }];
                [nameL mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(icon.mas_right).offset(5);
                    make.centerY.mas_equalTo(view);
                }];
                nameL.font = GetBoldFont(16.0f);
                nameL.textColor = ColorTitle;
                [allB mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(view);
                    make.right.mas_equalTo(view);
                    make.size.mas_equalTo(CGSizeMake(80, 40));
                }];
                [allB setTitleColor:ColorAppRed forState:UIControlStateNormal];
                allB.titleLabel.font = GetFont(14.0f);
                [allB setTitle:@"全部赛事" forState:UIControlStateNormal];
                [allB addTarget:self action:@selector(allRecommandMatch) forControlEvents:UIControlEventTouchUpInside];
                icon.image = [UIImage imageNamed:@"hotFire"];
                nameL.text = @"推荐赛事";
                return view;
            }
            
            
        }
            break;
        case 1:
        {
            if (!QM_IS_ARRAY_NIL(self.resultList)) {
                UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width-20, 40)];
                view.backgroundColor = [UIColor colorWithHexString:@"#f4f4f4"];
                UILabel*typeL = [UILabel new];
                UILabel*nameL = [UILabel new];
                UIButton*allB = [UIButton buttonWithType:UIButtonTypeCustom];
                [view addSubview:typeL];
                
                [view addSubview:nameL];
                [view addSubview:allB];
                [typeL mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(view);
                    make.left.mas_equalTo(view).offset(5);
                }];
                typeL.font = GetBoldFont(16.0f);
                typeL.textColor = [UIColor colorWithHexString:@"#F04844"];
                [nameL mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.mas_equalTo(typeL.mas_right).offset(0);
                    make.centerY.mas_equalTo(view);
                }];
                nameL.font = GetBoldFont(16.0f);
                nameL.textColor = ColorTitle;
                [allB mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(view);
                    make.right.mas_equalTo(view);
                    make.size.mas_equalTo(CGSizeMake(80, 40));
                }];
                [allB setTitleColor:ColorAppRed forState:UIControlStateNormal];
                allB.titleLabel.font = GetFont(14.0f);
                typeL.text = @"【竞彩】";
                [allB setTitle:@"更多赛果" forState:UIControlStateNormal];
                [allB addTarget:self action:@selector(allResultMatch) forControlEvents:UIControlEventTouchUpInside];
                nameL.text = @"最新战报";
                return view;
            }
            
            
        }
            break;
        case 2:
        {
            if (!QM_IS_ARRAY_NIL(self.manager.dataSource)) {
                UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width-20, 40)];
                view.backgroundColor = [UIColor colorWithHexString:@"#f4f4f4"];
                UILabel*nameL = [UILabel new];
                
                [view addSubview:nameL];
                [nameL mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.centerY.mas_equalTo(view);
                    make.left.mas_equalTo(view).offset(5);
                }];
                nameL.font = GetBoldFont(16.0f);
                nameL.textColor = ColorTitle;
                nameL.text = @"资讯快报";
                return view;
            }
            
            
        }
            break;
            
        default:
            break;
    }
    return [UIView new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5.f;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    return [UIView new];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 2) {
        //模型转换
        NewModel*model  = self.manager.dataSource[indexPath.row];
        ESBanner *bannerModel = [ESBanner new];
        bannerModel.textId = model.textId;
        bannerModel.textType = model.textType;
        bannerModel.textFormat = model.textFormat;
        bannerModel.link = model.url;
        //文章
        PaperContentViewController*vc = [PaperContentViewController new];
        vc.banerModel = bannerModel;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

#pragma mark 按钮点击事件
-(void)allResultMatch{
    //跳转比赛赛果
    dispatch_main_async_safe(^{
        WTCTabBarViewController*tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
        tabBarVC.selectedIndex = 2;
        MatchHomeViewController *vc = ((UINavigationController *)tabBarVC.childViewControllers[0]).viewControllers[0];
        //		[vc.segment.segmentToolView setDefaultIndex:3];
        //		[vc.segment.bgScrollView setContentOffset:CGPointMake(SCREEN_WIDTH * 2, 0)];
        [vc switchViewControllerWithField:0];
    });
    
}

-(void)allRecommandMatch{
    //跳转比赛
    dispatch_main_async_safe(^{
        WTCTabBarViewController*tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
        tabBarVC.selectedIndex = 0;
    });
    
}

#pragma mark HeadLineDelegate
- (void)parseClick:(NSString *)planId {
    if (QM_IS_STR_NIL(planId)) {
        return;
    }
    CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
    vc.planId = [planId integerValue];
    vc.sourcePage = @"飞驰头条";
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)hotClick:(NSString *)expertId {
    //	if (QM_IS_STR_NIL(expertId)) {
    //		return;
    //	}
    //	ExpertDetailViewController*vc = [ExpertDetailViewController new];
    //	vc.expertId = @(expertId.integerValue);
    //	vc.sourcePage = @"飞驰头条";
    //	vc.hidesBottomBarWhenPushed = YES;
    //	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark 轮播图代理
- (NSArray *)imagesInMainScrollView:(ESNewMainScrollView *)mainScrollView{
    return self.banners;
}

- (void)mainScrollView:(ESNewMainScrollView *)mainScrollView atIndex:(NSInteger)index {
    ESBanner *banner = [self.banners objectAtIndex:index];
    if (banner.skipType.integerValue == 1) {
        //充值
        if (![App_Utility checkCurrentUser]) {
            [App_Utility showLoginViewController];
        }else{
            PayViewController*vc = [[PayViewController alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }
        
    }
    if (banner.skipType.integerValue == 6) {
        //url
        WTCContentViewController*vc = [WTCContentViewController new];
        vc.url = banner.link;
        vc.hidesBottomBarWhenPushed = YES;
        vc.contentType = WTCContentTypeNav;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    if (banner.skipType.integerValue == 2) {
        //文章
        PaperContentViewController*vc = [PaperContentViewController new];
        banner.textFormat = @"1";
        vc.banerModel = banner;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
    [MobClick event:@"discover1" attributes:@{@"imageUrl":QM_STR_NOT_NIL(banner.imgUrl),@"link":QM_STR_NOT_NIL(banner.link)}];
    [ESNetworkService updateBannersVisit:banner.bannerId.integerValue InfoType:1 Response:nil];
}

#pragma mark 初始化
- (NSMutableArray *)banners{
    if (!_banners) {
        _banners = [NSMutableArray array];
    }
    
    return _banners;
}
- (NSMutableArray *)recommendList{
    if (!_recommendList) {
        _recommendList = [NSMutableArray array];
    }
    
    return _recommendList;
}

- (NSMutableArray *)resultList{
    if (!_resultList) {
        _resultList = [NSMutableArray array];
    }
    
    return _resultList;
}

- (DiscoverHeadLineView *)headLineView {
    if (!_headLineView) {
        _headLineView = [[DiscoverHeadLineView alloc] initWithFrame:CGRectMake(-10, kheadViewHight, kScreen_Width, kmiddleViewHight)];
        _headLineView.backgroundColor = [UIColor whiteColor];
        _headLineView.delegateVC = self;
    }
    return _headLineView;
}
-(NewsListManager*)manager
{
    if (!_manager) {
        _manager = [NewsListManager new];
        _manager.delegate = self;
    }
    return _manager;
}

#pragma mark - life cycle
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [ESNetworkService customPostionCode:@"003"];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

@end
