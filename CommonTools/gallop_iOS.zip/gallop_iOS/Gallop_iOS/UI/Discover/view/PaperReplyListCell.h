//
//  PaperReplyListCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PaperCommentCell.h"

@interface PaperReplyListCell : UITableViewCell
@property (nonatomic,weak)id<PaperCommentCellDelegate> cellDelegate;
- (void)configCellWithModel:(id)model indexPath:(NSInteger)index;
@end

