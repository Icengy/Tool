//
//  MatchResultCollectionViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchResultCollectionViewCell.h"
@interface MatchResultCollectionViewCell()
@property (nonatomic,strong) UILabel*typeL;
@property (nonatomic,strong) UILabel*timeL;
@property (nonatomic,strong) UILabel*hostL;
@property (nonatomic,strong) UILabel*guestL;
@property (nonatomic,strong) UILabel*hostScoreL;
@property (nonatomic,strong) UILabel*guestScoreL;
@property (nonatomic,strong) UIImageView*hostV;
@property (nonatomic,strong) UIImageView*guestV;
@end
@implementation MatchResultCollectionViewCell
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.backgroundColor = [UIColor colorWithHexString:@"#f6f6f6"];
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self addRoundedCorners:(UIRectCornerAllCorners) withRadii:2];
    [self.typeL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView).offset(10);
        make.top.mas_equalTo(self.contentView).offset(10);
    }];
    [self.timeL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.typeL);
        make.left.mas_equalTo(self.typeL.mas_right).offset(10);
    }];
    [self.hostV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView).offset(10);
        make.top.mas_equalTo(self.typeL.mas_bottom).offset(8);
        make.size.mas_equalTo(CGSizeMake(22, 22));
    }];
    
    [self.hostScoreL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.hostV);
        make.right.mas_equalTo(self.contentView).offset(-8);
    }];
    [self.hostL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.hostV.mas_right).offset(10);
        make.centerY.mas_equalTo(self.hostV);
        make.width.mas_equalTo(100);
    }];
    [self.guestV mas_makeConstraints:^(MASConstraintMaker *make) {
           make.left.mas_equalTo(self.contentView).offset(10);
           make.bottom.mas_equalTo(self.contentView).offset(-10);
           make.size.mas_equalTo(CGSizeMake(22, 22));
    }];
    [self.guestL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.guestV.mas_right).offset(10);
        make.centerY.mas_equalTo(self.guestV);
        make.width.mas_equalTo(100);
    }];
    [self.guestScoreL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.guestV);
        make.right.mas_equalTo(self.contentView).offset(-8);
    }];
}



-(void)setModel:(MatchResult *)model {
    _model = model;
    if (model) {
        dispatch_main_async_safe(^{
            self.typeL.text = model.leagueName;
            self.typeL.textColor = [UIColor colorWithHexString:model.leagueColor];
            [self.hostV sd_setImageWithURL:[NSURL URLWithString:model.hostFlag] placeholderImage:GetImage(@"host")];
            [self.guestV sd_setImageWithURL:[NSURL URLWithString:model.guestFlag] placeholderImage:GetImage(@"guest")];
            self.hostL.text = model.hostName;
            self.guestL.text = model.guestName;
            self.hostScoreL.text = model.hostScore;
            self.guestScoreL.text = model.guestScore;
            self.timeL.text = [CMMUtility timeConvertWithTimeStamp:model.startTime andTimeFormat:@"HH:mm"];
        });
    }
}
-(UILabel*)typeL
{
    if (!_typeL) {
        _typeL = [UILabel new];
        _typeL.textColor = ColorAppRed;
        _typeL.font = fcFont(10.0f);
        _typeL.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_typeL];
    }
    return _typeL;
}
-(UILabel*)timeL
{
    if (!_timeL) {
        _timeL = [UILabel new];
        _timeL.textColor = ColorSubTitle;
        _timeL.font = fcFont(10.0f);
        _timeL.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_timeL];
    }
    return _timeL;
}
-(UIImageView*)hostV
{
    if (!_hostV) {
        _hostV = [UIImageView new];
        [self.contentView addSubview:_hostV];
    }
    return _hostV;
}
-(UILabel*)hostL
{
    if (!_hostL) {
        _hostL = [UILabel new];
        _hostL.textColor = ColorSubTitle;
        _hostL.font = fcFont(12.0f);
        _hostL.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_hostL];
    }
    return _hostL;
}
-(UIImageView*)guestV
{
    if (!_guestV) {
        _guestV = [UIImageView new];
        [self.contentView addSubview:_guestV];
    }
    return _guestV;
}
-(UILabel*)guestL
{
    if (!_guestL) {
        _guestL = [UILabel new];
        _guestL.textColor = ColorSubTitle;
        _guestL.font = fcFont(12.0f);
        _guestL
        .textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_guestL];
    }
    return _guestL;
}
-(UILabel*)hostScoreL
{
    if (!_hostScoreL) {
        _hostScoreL = [UILabel new];
        _hostScoreL.textColor = ColorTitle;
        _hostScoreL.font = GetBoldFont(16.0f);
        _hostScoreL.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_hostScoreL];
    }
    return _hostScoreL;
}
-(UILabel*)guestScoreL
{
    if (!_guestScoreL) {
        _guestScoreL = [UILabel new];
        _guestScoreL.textColor = ColorTitle;
        _guestScoreL.font = GetBoldFont(16.0f);
        _guestScoreL.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_guestScoreL];
    }
    return _guestScoreL;
}
@end
