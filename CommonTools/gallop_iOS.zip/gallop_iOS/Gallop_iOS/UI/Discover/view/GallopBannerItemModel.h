//
//  GallopBannerModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GallopBannerItemModel :NSObject

@property (nonatomic , copy) NSString              * content;
@property (nonatomic , copy) NSString              * contentId;

@property (nonatomic , copy) NSString              * advertiseType;
///
@property (nonatomic , copy) NSString              * businessType;
/// "{\"field\":2,\"matchId\":3503609}";
@property (nonatomic , copy) NSString              * linkTo;
/// 跳转类型，NOT_LINKED:纯图（不跳转）、URL:链接、ARTICLE:文章、APP_PAGE:APP页面
@property (nonatomic , copy) NSString              * type;

#pragma mark - 社区主页独有
@property (nonatomic , copy) NSString              * img;
@property (nonatomic , copy) NSString              * title;

@end

@interface GallopBannerModel : NSObject

@property (nonatomic , strong) NSArray <GallopBannerItemModel *>              * data;

@end

