//
//  MatchResultTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchResultTableViewCell.h"
#import "MatchResultCollectionViewCell.h"
#import "MatchResult.h"
@interface MatchResultTableViewCell()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong)UICollectionView*allCollectionView;
@end
@implementation MatchResultTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}
-(void)setupView{
    self.dataSource = [NSMutableArray arrayWithCapacity:0];
    UICollectionViewFlowLayout*layout=[[UICollectionViewFlowLayout alloc]init];
    self.allCollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0,0,kScreen_Width-20,200) collectionViewLayout:layout];
       self.allCollectionView.backgroundColor=[UIColor colorWithHexString:@"#F4F4F4"];
       self.allCollectionView.showsHorizontalScrollIndicator=NO;
       layout.scrollDirection=UICollectionViewScrollDirectionVertical;
    self.allCollectionView.scrollEnabled = NO;
       layout.minimumInteritemSpacing=3;
       layout.minimumLineSpacing = 3;
       layout.itemSize=CGSizeMake((kScreen_Width-20-3)/2,98.5);
       self.allCollectionView.delegate=self;
       self.allCollectionView.dataSource=self;
       [self.allCollectionView registerClass:[MatchResultCollectionViewCell class] forCellWithReuseIdentifier:@"MatchResultCollectionViewCell"];
       [self.contentView addSubview:self.allCollectionView];
    
}
-(void)setDataSource:(NSMutableArray *)dataSource
{
    
    dispatch_main_async_safe(^{
       _dataSource = dataSource;
        [self.allCollectionView reloadData];
    });
}
#pragma mark collection代理
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section

{
   
         return UIEdgeInsetsMake(0, 0,0,0);//分别为上、左、下、右
    

}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSource.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
        static NSString *cellID = @"MatchResultCollectionViewCell";
        MatchResultCollectionViewCell*cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
        if (!cell) {
            cell= [[MatchResultCollectionViewCell alloc] init];
        }
        dispatch_main_async_safe(^{
            MatchResult*modle = self.dataSource[indexPath.row];
            cell.model = modle;
        });
         return cell;
    
    
   
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
        MatchResult*modle = self.dataSource[indexPath.row];
    if (self.clickBlock) {
        self.clickBlock(modle);
    }
        
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
