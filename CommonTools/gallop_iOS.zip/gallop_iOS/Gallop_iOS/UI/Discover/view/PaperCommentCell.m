//
//  PaperCommentCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/4.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperCommentCell.h"
#import "ESBanner.h"

@interface PaperCommentCell()
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UIImageView *hotImageView;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *authLabel;
@property (nonatomic,strong) UILabel *levelLabel;
@property (nonatomic,strong) UIButton *replyBtn;
@property (nonatomic,strong) UIButton *likeBtn;
@property (nonatomic,strong) UIButton *shareBtn;
@property (nonatomic,strong) UIView	*seperatorLine;
@property (nonatomic,strong) UIImageView*officalImageV;
//data
@property (nonatomic,assign) NSUInteger row;
@end

@implementation PaperCommentCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(13);
		make.left.equalTo(self.contentView).offset(15);
		make.size.mas_equalTo(CGSizeMake(44, 44));
	}];
	[self.authLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(18);
		make.left.equalTo(self.contentView).offset(67);
	}];
    [self.officalImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.authLabel.mas_right).offset(10);
        make.centerY.equalTo(self.authLabel);
        make.size.mas_equalTo(CGSizeMake(18, 18));
    }];
	[self.levelLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.authLabel);
		make.width.mas_greaterThanOrEqualTo(34);
		make.height.mas_equalTo(18);
		make.left.equalTo(self.officalImageV.mas_right).offset(10);
	}];

    self.officalImageV.hidden = YES;
    self.officalImageV.image = GetImage(@"topic_official_icon");//官方图片
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.authLabel.mas_bottom).offset(3);
		make.left.equalTo(self.contentView).offset(67);
	}];
	[self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.timeLabel.mas_bottom).offset(10);
		make.left.equalTo(self.contentView).offset(67);
		make.right.equalTo(self.contentView).offset(-7.5);
	}];
	[self.hotImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentLabel);
		make.top.equalTo(self.timeLabel);
		make.size.mas_equalTo(CGSizeMake(36, 36));
	}];
	[self.replyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentLabel.mas_bottom).offset(14);
		make.left.equalTo(self.contentView).offset(67);
		make.height.mas_equalTo(20);
	}];
	[self.likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.replyBtn.mas_right).offset(20);
		make.centerY.equalTo(self.replyBtn);
		make.height.mas_equalTo(20);
	}];
	[self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentView).offset(-15);
		make.centerY.equalTo(self.replyBtn);
		make.height.mas_equalTo(20);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyBtn.mas_bottom).offset(16);
		make.left.equalTo(self.contentView).offset(67);
		make.height.mas_equalTo(2);
		make.right.bottom.equalTo(self.contentView);
	}];
}

- (NSString *)calculateCreateTime:(NSString *)time {
	//毫秒转换为秒
	NSTimeInterval timerInterval = [time doubleValue] / 1000;
	
	NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
	[formatter setDateStyle:NSDateFormatterMediumStyle];
	[formatter setTimeStyle:NSDateFormatterShortStyle];
	[formatter setDateFormat:@"MM-dd HH:mm"];
	
	NSDate* date = [NSDate date];
	
	NSDate *date2 = [NSDate dateWithTimeIntervalSince1970:timerInterval];
	NSString *dateString2 = [formatter stringFromDate:date2];
	
	NSCalendar *calendar = [NSCalendar currentCalendar];
	NSCalendarUnit unit =NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
	NSDateComponents *cmps = [calendar components:unit fromDate:date2 toDate:date options:0];
	
	if (cmps.day >= 1) {
		//大于24小时
		return dateString2;
	} else if (cmps.hour >= 1) {
		//1 < h < 24
		return [NSString stringWithFormat:@"%@小时前",@(cmps.hour)];
	} else if (cmps.minute > 1) {
		//1 < minute <60
		return [NSString stringWithFormat:@"%@分钟前",@(cmps.minute)];
	} else {
		return @"刚刚";
	}
}

- (void)configCellWithModel:(ESCommentItem *)model indexPath:(NSUInteger)index {
	self.row = index;
	[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:GetImage(@"avatar")];
	self.hotImageView.hidden = !model.commentSign;
	self.authLabel.text = model.userName;
//	if (model.level) {
//		self.levelLabel.text = [@"LV" stringByAppendingFormat:@"%@",model.level];
//		NSArray *colorArr = @[RGBCOLOR(148, 176, 125),RGBCOLOR(0, 145, 255),RGBCOLOR(144, 19, 254),RGBCOLOR(255, 125, 0),RGBCOLOR(253, 2, 48)];
//		self.levelLabel.backgroundColor = colorArr[((model.level.integerValue  - 1) / 4)];
//		self.levelLabel.hidden = NO;
//	} else {
//		self.levelLabel.hidden = YES;
//	}

	self.timeLabel.text = [self calculateCreateTime:model.createTime];
	self.contentLabel.text = model.content;
	if (model.hideShow == 0) {
		//屏蔽
		self.contentLabel.textColor = RGBCOLOR(168, 168, 168);
	} else {
		//未屏蔽
		self.contentLabel.textColor = ColorAppBlack;
	}
	[self.replyBtn setTitle:model.replyCount > 0 ? [NSString stringWithFormat:@"回复(%@)",@(model.replyCount)] : @"回复" forState:UIControlStateNormal];
	[self.likeBtn setTitle:model.likeCount > 0 ? [NSString stringWithFormat:@"赞(%@)",@(model.likeCount)] : @"赞" forState:UIControlStateNormal];
	self.likeBtn.selected = model.liked;
    if (model.isOfficial.intValue == 1) {
        self.officalImageV.hidden = NO;
		[self.officalImageV mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(self.authLabel.mas_right).offset(10);
			make.centerY.equalTo(self.authLabel);
			make.size.mas_equalTo(CGSizeMake(18, 18));
		}];
    }else{
        self.officalImageV.hidden = YES;
		[self.officalImageV mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(self.authLabel.mas_right).offset(-18);
			make.centerY.equalTo(self.authLabel);
			make.size.mas_equalTo(CGSizeMake(18, 18));
		}];
    }
}

#pragma mark - action
- (void)replyBtnClick:(UIButton *)btn {
	if ([self.cellDelegate respondsToSelector:@selector(replyClick:)]) {
		[self.cellDelegate replyClick:self.row];
	};
}

- (void)likeBtnClick:(UIButton *)btn {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	if ([self.cellDelegate respondsToSelector:@selector(likeClick:)]) {
		[self.cellDelegate likeClick:self.row];
	};
}

- (void)shareBtnClick:(UIButton *)btn {
	if ([self.cellDelegate respondsToSelector:@selector(shareClick:)]) {
		[self.cellDelegate shareClick:self.row];
	};
}

- (void)goHomePage {
	if ([self.cellDelegate respondsToSelector:@selector(goHomePage:)]) {
		[self.cellDelegate goHomePage:self.row];
	};
}

#pragma mark - lazy init
- (UIImageView *)hotImageView {
	if (!_hotImageView) {
		_hotImageView = [[UIImageView alloc] init];
		_hotImageView.contentMode = UIViewContentModeScaleAspectFill;
		_hotImageView.image = GetImage(@"paper_hotComment_icon");
		_hotImageView.clipsToBounds = YES;
		[self.contentView addSubview:_hotImageView];
	}
	return _hotImageView;
}

- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [[UIImageView alloc] init];
		_headImageView.contentMode = UIViewContentModeScaleAspectFill;
		_headImageView.clipsToBounds = YES;
		_headImageView.layer.cornerRadius = 22;
		_headImageView.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goHomePage)];
		[_headImageView addGestureRecognizer:tap];
		[self.contentView addSubview:_headImageView];
	}
	return _headImageView;
}

- (UILabel *)contentLabel {
	if (!_contentLabel) {
		_contentLabel = [UILabel new];
		_contentLabel.textColor = ColorAppBlack;
		_contentLabel.font = fcFont(14);
		_contentLabel.numberOfLines = 0;
		[self.contentView addSubview:_contentLabel];
	}
	return _contentLabel;
}

- (UILabel *)timeLabel {
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.font = fcFont(12);
		_timeLabel.textColor = RGBCOLOR(168, 168, 168);
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}

- (UILabel *)authLabel {
	if (!_authLabel) {
		_authLabel = [UILabel new];
		_authLabel.textColor = ColorAppBlack;
		_authLabel.font = fcFont(14);
		[self.contentView addSubview:_authLabel];
	}
	return _authLabel;
}

- (UILabel *)levelLabel {
	if (!_levelLabel) {
		_levelLabel = [UILabel new];
		_levelLabel.font = fcBoldFont(12);
		_levelLabel.textColor = [UIColor whiteColor];
		_levelLabel.textAlignment = NSTextAlignmentCenter;
		_levelLabel.layer.cornerRadius = 4;
		_levelLabel.clipsToBounds = YES;
        _levelLabel.hidden = YES;
		[self.contentView addSubview:_levelLabel];
	}
	return _levelLabel;
}

- (UIButton *)replyBtn {
	if (!_replyBtn) {
		_replyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_replyBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_replyBtn setTitle:@"回复" forState:UIControlStateNormal];
		_replyBtn.titleLabel.font = fcFont(12);
		[_replyBtn setImage:GetImage(@"paper_reply_icon") forState:UIControlStateNormal];
		[_replyBtn addTarget:self action:@selector(replyBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_replyBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_replyBtn];
	}
	return _replyBtn;
}

- (UIButton *)likeBtn {
	if (!_likeBtn) {
		_likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_likeBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_likeBtn setTitle:@"赞" forState:UIControlStateNormal];
		_likeBtn.titleLabel.font = fcFont(12);
		[_likeBtn setImage:GetImage(@"paper_like_icon") forState:UIControlStateNormal];
		[_likeBtn setImage:GetImage(@"paper_liked_icon") forState:UIControlStateSelected];
		[_likeBtn addTarget:self action:@selector(likeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_likeBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_likeBtn];
	}
	return _likeBtn;
}

- (UIButton *)shareBtn {
	if (!_shareBtn) {
		_shareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_shareBtn setImage:GetImage(@"paper_share_icon") forState:UIControlStateNormal];
		[_shareBtn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_shareBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_shareBtn];
	}
	return _shareBtn;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentView addSubview:_seperatorLine];
	}
	return _seperatorLine;
}
-(UIImageView*)officalImageV
{
    if (!_officalImageV) {
        _officalImageV = [UIImageView new];
        [self.contentView addSubview:_officalImageV];
    }
    return _officalImageV;
}
@end
