//
//  DiscoverHeadLineView.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "DiscoverHeadLineView.h"

#import "GallopBannerItemModel.h"

@interface DiscoverHeadLineView()
//@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *headTitleLabel;
@property (nonatomic,strong) UILabel *firstTitleLabel;
@property (nonatomic,strong) UILabel *firstContentLabel;
@property (nonatomic,strong) UILabel *secondTitleLabel;
@property (nonatomic,strong) UILabel *secondContentLabel;
//data
@property (nonatomic,strong) NSMutableArray<GallopBannerItemModel *> *currentArr;
@property (nonatomic,strong) GallopBannerModel *model;
@end

@implementation DiscoverHeadLineView
{
	NSTimer * _timeCountTimer;
	NSInteger _timeCount;
}

- (instancetype)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		self.currentArr = [NSMutableArray array];
		[self setupView];
	}
	return self;
}

- (void)setupView {

    self.backgroundColor = UIColor.clearColor;
    
    [self addSubview:self.headTitleLabel];
    [self addSubview:self.firstContentLabel];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.headTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(10);
        make.top.equalTo(self);
        make.height.offset(kmiddleViewHight);
    }];

    [self.firstContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.headTitleLabel.mas_right).offset(8);
        make.centerY.equalTo(self.headTitleLabel);
        make.right.lessThanOrEqualTo(self).offset(-10);
    }];
}

#pragma mark - 定时器
- (void)initTimer {
	dispatch_main_async_safe(^{
		[self destoryTimer];
		_timeCountTimer = [NSTimer timerWithTimeInterval:2.0  target:self selector:@selector(loadNewData) userInfo:nil repeats:YES];
		_timeCount = 0;
		[[NSRunLoop currentRunLoop] addTimer:_timeCountTimer forMode:NSRunLoopCommonModes];
	})
}

- (void)destoryTimer {
	dispatch_main_async_safe(^{
		if (_timeCountTimer) {
			if ([_timeCountTimer respondsToSelector:@selector(isValid)]){
				if ([_timeCountTimer isValid]){
					[_timeCountTimer invalidate];
					_timeCountTimer = nil;
				}
			}
		}
	})
}

- (void)loadNewData {
	_timeCount += 1;
	NSUInteger index = _timeCount % self.model.data.count;
	[self.currentArr removeAllObjects];
	[self.currentArr addObject:self.model.data[index]];
	[self layoutViewWithData];
}

- (void)layoutViewWithData {
    if (self.currentArr.count) {
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.4];
        [self.currentArr enumerateObjectsUsingBlock:^(GallopBannerItemModel *item, NSUInteger idx, BOOL * _Nonnull stop) {
            if (idx == 0) {
                // 第一条
                self.firstContentLabel.text = item.content;
            }
        }];
    }else {
        self.backgroundColor = UIColor.clearColor;
    }
}

- (void)configViewWithModel:(GallopBannerModel *)model {
	if (QM_IS_ARRAY_NIL(model.data)) {
		return;
	}
    if (model.data.count == 1) {
        model.data = @[model.data[0],model.data[0]];
    }
	self.model = model;
	[self.currentArr removeAllObjects];
	[self.currentArr addObject:model.data[0]];
	[self layoutViewWithData];
	[self initTimer];
}

#pragma mark - action
- (void)firstClick {
    if (self.delegateVC && [self.delegateVC respondsToSelector:@selector(parseClick:)]) {
        [self.delegateVC parseClick:self.currentArr[0]];
    }
}

- (void)secondClick {
//	if (self.currentArr[1].type == 1) {
//		if (self.delegateVC && [self.delegateVC respondsToSelector:@selector(hotClick:)]) {
//			[self.delegateVC hotClick:self.currentArr[1].contentId];
//		}
//	} else {
//		if (self.delegateVC && [self.delegateVC respondsToSelector:@selector(parseClick:)]) {
//			[self.delegateVC parseClick:self.currentArr[1].contentId];
//		}
//	}
}

- (void)headLineClick:(UITapGestureRecognizer *)tap {
	if (tap.view.tag > 10002) {
		//点击第二条
//		[self secondClick];
	} else {
		//点击第一条
		[self firstClick];
	}
}

#pragma mark - lazy init
//- (UIImageView *)headImageView {
//	if (!_headImageView) {
//		_headImageView = [[UIImageView alloc] initWithImage:GetImage(@"discover_headline_icon")];
//		[self addSubview:_headImageView];
//	}
//	return _headImageView;
//}

- (UILabel *)headTitleLabel {
    if (!_headTitleLabel) {
        _headTitleLabel = [UILabel new];
        _headTitleLabel.font = [UIFont addPingFangSCBold:16];
        _headTitleLabel.text = @"每日头条";
        _headTitleLabel.textColor = RGBCOLORV(0xFFC700);
        
        [_headTitleLabel sizeToFit];
        _headTitleLabel.transform = CGAffineTransformIdentity;
        CGAffineTransform matrix = CGAffineTransformMake(1, 0, tanf(-15 * (CGFloat)M_PI / 180), 1, 0, 0);
        _headTitleLabel.transform = matrix;
        
    }return _headTitleLabel;
}


- (UILabel *)firstTitleLabel {
	if (!_firstTitleLabel) {
		_firstTitleLabel = [UILabel new];
		_firstTitleLabel.font = [UIFont addPingFangSCRegular:13];
		_firstTitleLabel.textColor = [UIColor whiteColor];
		_firstTitleLabel.tag = 10001;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headLineClick:)];
		[_firstTitleLabel addGestureRecognizer:tap];
		_firstTitleLabel.userInteractionEnabled = YES;
		[self addSubview:_firstTitleLabel];
	}
	return _firstTitleLabel;
}

- (UILabel *)firstContentLabel {
	if (!_firstContentLabel) {
		_firstContentLabel = [UILabel new];
		_firstContentLabel.textColor = [UIColor whiteColor];
        _firstContentLabel.font = [UIFont addPingFangSCRegular:13];
		_firstContentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
		_firstTitleLabel.tag = 10002;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headLineClick:)];
		[_firstContentLabel addGestureRecognizer:tap];
		_firstContentLabel.userInteractionEnabled = YES;
	}
	return _firstContentLabel;
}

- (UILabel *)secondTitleLabel {
	if (!_secondTitleLabel) {
		_secondTitleLabel = [UILabel new];
        _secondTitleLabel.font = [UIFont addPingFangSCRegular:13];
		_secondTitleLabel.textColor = RGBCOLOR(249, 129, 49);
		_secondTitleLabel.tag = 10003;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headLineClick:)];
		[_secondTitleLabel addGestureRecognizer:tap];
		_secondTitleLabel.userInteractionEnabled = YES;
		[self addSubview:_secondTitleLabel];
	}
	return _secondTitleLabel;
}

- (UILabel *)secondContentLabel {
	if (!_secondContentLabel) {
		_secondContentLabel = [UILabel new];
		_secondContentLabel.textColor = RGBCOLOR(42, 42, 42);
        _secondContentLabel.font = [UIFont addPingFangSCRegular:13];
		_secondContentLabel.lineBreakMode = NSLineBreakByTruncatingTail;
		_secondContentLabel.tag = 10004;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headLineClick:)];
		[_secondContentLabel addGestureRecognizer:tap];
		_secondContentLabel.userInteractionEnabled = YES;
		[self addSubview:_secondContentLabel];
	}
	return _secondContentLabel;
}
@end
