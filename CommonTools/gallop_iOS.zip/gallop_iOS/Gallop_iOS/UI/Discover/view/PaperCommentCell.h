//
//  PaperCommentCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/4.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol PaperCommentCellDelegate<NSObject>
@optional
- (void)replyClick:(NSUInteger)index;
- (void)likeClick:(NSUInteger)index;
- (void)shareClick:(NSUInteger)index;
- (void)extenClick:(NSUInteger)index isExtend:(BOOL)isExtend;
- (void)textTitleClick:(NSUInteger)textId;
- (void)goHomePage:(NSUInteger)index;
@end

@interface PaperCommentCell : UITableViewCell
@property (nonatomic,weak)id<PaperCommentCellDelegate> cellDelegate;
- (void)configCellWithModel:(id)model indexPath:(NSUInteger)index;
@end

