//
//  PaperCommentView.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/5.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PointExtenButton.h"

@protocol PaperCommentViewDelegate<NSObject>

@optional
- (void)sendBtnClick:(NSString *)content;
- (void)fullScreenBtnClick:(NSString *)content;
- (void)sendBtnClick:(id)sender content:(NSString *)content;

@end

@interface PaperCommentView : UIView
- (void)showPaperCommentView;
- (void)hidePaperCommentView;
@property (nonatomic,strong) UITextView *textView;
@property (nonatomic,strong) UILabel *placeHolderLabel;
@property (nonatomic,strong) PointExtenButton *fullScreenBtn;
@property (nonatomic,weak)id<PaperCommentViewDelegate> delegate;
@end

