//
//  DiscoverMatchCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
//固定高度114

@interface DiscoverMatchCell : UICollectionViewCell
- (void)configCellWithModel:(id)model;
@property (nonatomic,weak) id delegate;
@end
