//
//  PaperReplyListCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/6.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperReplyListCell.h"
#import "ESBanner.h"
#import "PointExtenButton.h"
#import <CoreText/CoreText.h>

@interface PaperReplyListCell()
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UIImageView*officalImageV;
@property (nonatomic,strong) UIButton *floorLogoBtn;
@property (nonatomic,strong) UILabel *levelLabel;
@property (nonatomic,strong) UIButton *originTextBtn;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UIView *replyContentView;
@property (nonatomic,strong) UILabel *replyContentLabel;
@property (nonatomic,strong) PointExtenButton *extentLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *authLabel;
@property (nonatomic,strong) UIButton *replyBtn;
@property (nonatomic,strong) UIButton *likeBtn;
@property (nonatomic,strong) UIButton *shareBtn;
@property (nonatomic,strong) UIView	*seperatorLine;
//data
@property (nonatomic,assign) NSUInteger row;
@property (nonatomic,strong) ReplyListItem *model;
@end

@implementation PaperReplyListCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(13);
		make.left.equalTo(self.contentView).offset(15);
		make.size.mas_equalTo(CGSizeMake(44, 44));
	}];
	[self.authLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(18);
		make.left.equalTo(self.contentView).offset(67);
	}];
	[self.officalImageV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.authLabel.mas_right).offset(10);
		make.centerY.equalTo(self.authLabel);
		make.size.mas_equalTo(CGSizeMake(18, 18));
	}];
	[self.floorLogoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.authLabel);
		make.left.equalTo(self.authLabel.mas_right).offset(12);
		make.size.mas_equalTo(CGSizeMake(32, 18));
	}];
	
	[self.levelLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.authLabel);
		make.width.mas_greaterThanOrEqualTo(34);
		make.height.mas_equalTo(18);
		make.left.equalTo(self.officalImageV.mas_right).offset(10);
	}];

	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.authLabel.mas_bottom).offset(3);
		make.left.equalTo(self.contentView).offset(67);
	}];
	[self.replyContentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.timeLabel);
		make.top.equalTo(self.timeLabel.mas_bottom).offset(10);
		make.right.equalTo(self.contentView).offset(-15);
	}];
	[self.replyContentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyContentView).offset(8);
		make.left.equalTo(self.replyContentView).offset(12);
		make.right.equalTo(self.replyContentView).offset(-2);
	}];
	[self.originTextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyContentView).offset(7);
		make.left.equalTo(self.replyContentLabel);
		make.size.mas_equalTo(CGSizeMake(28, 16));
	}];
	[self.extentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.replyContentView).offset(-10);
		make.top.equalTo(self.replyContentLabel.mas_bottom).offset(2);
		make.bottom.equalTo(self.replyContentView).offset(-10);
		make.height.mas_equalTo(15);
	}];
	[self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyContentView.mas_bottom).offset(10);
		make.left.equalTo(self.contentView).offset(67);
		make.right.equalTo(self.contentView).offset(-7.5);
	}];
	[self.replyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentLabel.mas_bottom).offset(14);
		make.left.equalTo(self.contentView).offset(67);
		make.height.mas_equalTo(20);
	}];
	[self.likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.replyBtn.mas_right).offset(20);
		make.centerY.equalTo(self.replyBtn);
		make.height.mas_equalTo(20);
	}];
	[self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentView).offset(-15);
		make.centerY.equalTo(self.replyBtn);
		make.height.mas_equalTo(20);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.replyBtn.mas_bottom).offset(16);
		make.left.equalTo(self.contentView).offset(67);
		make.height.mas_equalTo(2);
		make.right.bottom.equalTo(self.contentView);
	}];
}

- (NSString *)calculateCreateTime:(NSString *)time {
	//毫秒转换为秒
	NSTimeInterval timerInterval = [time doubleValue] / 1000;
	
	NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
	[formatter setDateStyle:NSDateFormatterMediumStyle];
	[formatter setTimeStyle:NSDateFormatterShortStyle];
	[formatter setDateFormat:@"MM-dd HH:mm"];
	
	NSDate* date = [NSDate date];
	
	NSDate *date2 = [NSDate dateWithTimeIntervalSince1970:timerInterval];
	NSString *dateString2 = [formatter stringFromDate:date2];
	
	NSCalendar *calendar = [NSCalendar currentCalendar];
	NSCalendarUnit unit =NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
	NSDateComponents *cmps = [calendar components:unit fromDate:date2 toDate:date options:0];
	
	if (cmps.day >= 1) {
		//大于24小时
		return dateString2;
	} else if (cmps.hour >= 1) {
		//1 < h < 24
		return [NSString stringWithFormat:@"%@小时前",@(cmps.hour)];
	} else if (cmps.minute > 1) {
		//1 < minute <60
		return [NSString stringWithFormat:@"%@分钟前",@(cmps.minute)];
	} else {
		return @"刚刚";
	}
}

//获取文本行数
- (NSUInteger)getNumberOfLinesWithText:(NSMutableAttributedString *)text andLabelWidth:(CGFloat)width {
	CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString((CFAttributedStringRef)text);
	CGMutablePathRef Path = CGPathCreateMutable();
	CGPathAddRect(Path, NULL ,CGRectMake(0 , 0 , width, INT_MAX));
	CTFrameRef frame = CTFramesetterCreateFrame(framesetter, CFRangeMake(0, 0), Path, NULL);
	// 得到字串在frame中被自动分成了多少个行。
	CFArrayRef rows = CTFrameGetLines(frame);
	// 实际行数
	NSUInteger numberOfLines = CFArrayGetCount(rows);
	CFRelease(frame);
	CGPathRelease(Path);
	CFRelease(framesetter);
	return numberOfLines;
}

- (void)configCellWithModel:(ReplyListItem *)model indexPath:(NSInteger)index {
	self.model = model;
	self.row = index;
	if (index == 9999) {
		//楼主 && 互动消息详情跳转
		[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:GetImage(@"avatar")];
		self.authLabel.text = model.userName;
		self.timeLabel.text = [self calculateCreateTime:model.createTime];
		self.contentLabel.text = model.content;
		if (model.hideShow == 0) {
			//屏蔽
			self.contentLabel.textColor = RGBCOLOR(168, 168, 168);
		} else {
			//未屏蔽
			self.contentLabel.textColor = ColorAppBlack;
		}
		[self.likeBtn setTitle:model.likeCount > 0 ? [NSString stringWithFormat:@"赞(%@)",@(model.likeCount)] : @"赞" forState:UIControlStateNormal];
		CGFloat imageWidth = self.likeBtn.imageView.bounds.size.width;
		CGFloat labelWidth = self.likeBtn.titleLabel.bounds.size.width;
		self.likeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth, 0, -labelWidth);
		self.likeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
		self.likeBtn.selected = model.liked;
		self.replyContentLabel.text = [NSString stringWithFormat:@"\t  %@",self.model.messageListItem.title];
		self.originTextBtn.hidden = NO;
		//
		self.replyBtn.hidden = YES;
		self.shareBtn.hidden = YES;
		self.seperatorLine.hidden = NO;
		self.floorLogoBtn.hidden = NO;
		self.levelLabel.hidden = YES;
		self.authLabel.textColor = ColorAppBlack;
		self.replyContentLabel.numberOfLines = 2;
		self.extentLabel.hidden = YES;
		self.replyContentView.hidden = NO;
		[self.replyBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.contentLabel.mas_bottom);
			make.left.equalTo(self.contentView).offset(67);
			make.height.mas_equalTo(0);
		}];
		[self.likeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(self.contentView).offset(-30);
			make.centerY.equalTo(self.authLabel);
			make.height.mas_equalTo(20);
		}];
		[self.replyContentView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(self.timeLabel);
			make.top.equalTo(self.timeLabel.mas_bottom).offset(10);
			make.right.equalTo(self.contentView).offset(-15);
		}];
		[self.extentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(self.replyContentView).offset(-10);
			make.top.equalTo(self.replyContentLabel.mas_bottom).offset(-16);
			make.bottom.equalTo(self.replyContentView).offset(-10);
			make.height.mas_equalTo(15);
		}];
	} else if (index == 999) {
		//楼主
		[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:GetImage(@"avatar")];
		self.authLabel.text = model.userName;
		self.timeLabel.text = [self calculateCreateTime:model.createTime];
		self.contentLabel.text = model.content;
		if (model.hideShow == 0) {
			//屏蔽
			self.contentLabel.textColor = RGBCOLOR(168, 168, 168);
		} else {
			//未屏蔽
			self.contentLabel.textColor = ColorAppBlack;
		}
		[self.likeBtn setTitle:model.likeCount > 0 ? [NSString stringWithFormat:@"赞(%@)",@(model.likeCount)] : @"赞" forState:UIControlStateNormal];
		CGFloat imageWidth = self.likeBtn.imageView.bounds.size.width;
		CGFloat labelWidth = self.likeBtn.titleLabel.bounds.size.width;
		self.likeBtn.imageEdgeInsets = UIEdgeInsetsMake(0, labelWidth, 0, -labelWidth);
		self.likeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
		self.likeBtn.selected = model.liked;
		//
		self.replyBtn.hidden = YES;
		self.levelLabel.hidden = YES;
		self.shareBtn.hidden = YES;
		self.seperatorLine.hidden = YES;
		self.replyContentView.hidden = YES;
		self.floorLogoBtn.hidden = NO;
		self.originTextBtn.hidden = YES;
		self.authLabel.textColor = ColorAppBlack;
		[self.replyBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.contentLabel.mas_bottom);
			make.left.equalTo(self.contentView).offset(67);
			make.height.mas_equalTo(0);
		}];
		[self.likeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(self.contentView).offset(-30);
			make.centerY.equalTo(self.authLabel);
			make.height.mas_equalTo(20);
		}];
		[self.replyContentView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(self.timeLabel);
			make.top.equalTo(self.timeLabel.mas_bottom);
			make.right.equalTo(self.contentView).offset(-15);
			make.height.mas_equalTo(0);
		}];
	} else {
		//回复
		[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:GetImage(@"avatar")];
		self.authLabel.text = model.userName;
//		if (!model.level) {
//			self.levelLabel.hidden = YES;
//		} else {
//			self.levelLabel.text = [@"LV" stringByAppendingFormat:@"%@",model.level];
//			NSArray *colorArr = @[RGBCOLOR(148, 176, 125),RGBCOLOR(0, 145, 255),RGBCOLOR(144, 19, 254),RGBCOLOR(255, 125, 0),RGBCOLOR(253, 2, 48)];
//			self.levelLabel.backgroundColor = colorArr[((model.level.integerValue  - 1) / 4)];
//			self.levelLabel.hidden = NO;
//		}
		self.timeLabel.text = [self calculateCreateTime:model.createTime];
		self.contentLabel.text = model.content;
		if (model.hideShow == 0) {
			//屏蔽
			self.contentLabel.textColor = RGBCOLOR(168, 168, 168);
		} else {
			//未屏蔽
			self.contentLabel.textColor = ColorAppBlack;
		}
		[self.likeBtn setTitle:model.likeCount > 0 ? [NSString stringWithFormat:@"赞(%@)",@(model.likeCount)] : @"赞" forState:UIControlStateNormal];
		self.likeBtn.imageEdgeInsets = UIEdgeInsetsZero;
		self.likeBtn.titleEdgeInsets = UIEdgeInsetsZero;
		self.likeBtn.selected = model.liked;
		//
		self.replyBtn.hidden = NO;
		self.shareBtn.hidden = NO;
		self.seperatorLine.hidden = NO;
		self.floorLogoBtn.hidden = YES;
		self.originTextBtn.hidden = YES;
		self.authLabel.textColor = ColorAppBlack;
		self.replyContentLabel.text = [NSString stringWithFormat:@"%@ : %@  ",  model.otherCommentUserName ,model.otherCommentContent];
		self.replyContentLabel.numberOfLines = 0;
		[self.replyContentLabel layoutIfNeeded];
		[self.replyBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.contentLabel.mas_bottom).offset(14);
			make.left.equalTo(self.contentView).offset(67);
			make.height.mas_equalTo(20);
		}];
		[self.likeBtn mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(self.replyBtn.mas_right).offset(20);
			make.centerY.equalTo(self.replyBtn);
			make.height.mas_equalTo(20);
		}];
		if (model.otherCommentId == 0) {
			//对楼主的评论
			self.replyContentView.hidden = YES;
			[self.replyContentView mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.left.equalTo(self.timeLabel);
				make.top.equalTo(self.timeLabel.mas_bottom);
				make.right.equalTo(self.contentView).offset(-15);
				make.height.mas_equalTo(0);
			}];
		} else {
			self.replyContentView.hidden = NO;
			[self.replyContentView mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.left.equalTo(self.timeLabel);
				make.top.equalTo(self.timeLabel.mas_bottom).offset(10);
				make.right.equalTo(self.contentView).offset(-15);
			}];
			//计算理论上显示所有文字需要的尺寸
			NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:self.replyContentLabel.text];
			NSUInteger row = [self getNumberOfLinesWithText:string andLabelWidth:self.replyContentLabel.width];
			if (row <= 3) {
				self.replyContentLabel.numberOfLines = row;
				self.extentLabel.hidden = YES;
				[self.extentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
					make.right.equalTo(self.replyContentView).offset(-10);
					make.top.equalTo(self.replyContentLabel.mas_bottom).offset(-16);
					make.bottom.equalTo(self.replyContentView).offset(-10);
					make.height.mas_equalTo(15);
				}];
			} else {
				self.extentLabel.hidden = NO;
				[self.extentLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
					make.right.equalTo(self.replyContentView).offset(-10);
					make.top.equalTo(self.replyContentLabel.mas_bottom).offset(2);
					make.bottom.equalTo(self.replyContentView).offset(-10);
					make.height.mas_equalTo(15);
				}];
				if (self.model.isExtend == NO) {
					[self.extentLabel setTitle:@"展开" forState:UIControlStateNormal];
					self.replyContentLabel.numberOfLines = 3;
				} else {
					[self.extentLabel setTitle:@"收起" forState:UIControlStateNormal];
					self.replyContentLabel.numberOfLines = 0;
				}
				[self.replyContentLabel layoutIfNeeded];
			}
		}
	}
	
	if (model.isOfficial == 1) {
		self.officalImageV.hidden = NO;
		[self.officalImageV mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(self.authLabel.mas_right).offset(10);
			make.centerY.equalTo(self.authLabel);
			make.size.mas_equalTo(CGSizeMake(18, 18));
		}];
	}else{
		self.officalImageV.hidden = YES;
		[self.officalImageV mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(self.authLabel.mas_right).offset(-18);
			make.centerY.equalTo(self.authLabel);
			make.size.mas_equalTo(CGSizeMake(18, 18));
		}];
	}
}

#pragma mark - action
- (void)replyBtnClick:(UIButton *)btn {
	if ([self.cellDelegate respondsToSelector:@selector(replyClick:)]) {
		[self.cellDelegate replyClick:self.row];
	};
}

- (void)likeBtnClick:(UIButton *)btn {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	if ([self.cellDelegate respondsToSelector:@selector(likeClick:)]) {
		[self.cellDelegate likeClick:self.row];
	};
}

- (void)shareBtnClick:(UIButton *)btn {
	if ([self.cellDelegate respondsToSelector:@selector(shareClick:)]) {
		[self.cellDelegate shareClick:self.row];
	};
}

- (void)extenClick {
	//展开
	if ([self.cellDelegate respondsToSelector:@selector(extenClick:isExtend:)]) {
		[self.cellDelegate extenClick:self.row isExtend:self.model.isExtend];
	};
}

- (void)textTitleClick {
	if (self.row != 9999) {
		return;
	}
	if ([self.cellDelegate respondsToSelector:@selector(textTitleClick:)]) {
		[self.cellDelegate textTitleClick:self.model.messageListItem.sourceId];
	};
}

- (void)goHomePage {
	if ([self.cellDelegate respondsToSelector:@selector(goHomePage:)]) {
		[self.cellDelegate goHomePage:self.row];
	};
}

#pragma mark - lazy init
- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [[UIImageView alloc] init];
		_headImageView.contentMode = UIViewContentModeScaleAspectFill;
		_headImageView.clipsToBounds = YES;
		_headImageView.layer.cornerRadius = 22;
		_headImageView.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goHomePage)];
		[_headImageView addGestureRecognizer:tap];
		[self.contentView addSubview:_headImageView];
	}
	return _headImageView;
}

-(UIImageView*)officalImageV
{
	if (!_officalImageV) {
		_officalImageV = [UIImageView new];
		_officalImageV.image = GetImage(@"topic_official_icon");
		_officalImageV.hidden = YES;
		[self.contentView addSubview:_officalImageV];
	}
	return _officalImageV;
}

- (UIView *)replyContentView {
	if (!_replyContentView) {
		_replyContentView = [UIView new];
		_replyContentView.backgroundColor = RGBCOLOR(244, 244, 244);
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(textTitleClick)];
		[_replyContentView addGestureRecognizer:tap];
		[self.contentView addSubview:_replyContentView];
	}
	return _replyContentView;
}

- (UILabel *)replyContentLabel {
	if (!_replyContentLabel) {
		_replyContentLabel = [UILabel new];
		_replyContentLabel.textColor = ColorAppBlack;
		_replyContentLabel.font = fcFont(12);
		_replyContentLabel.numberOfLines = 0;
		[self.contentView addSubview:_replyContentLabel];
	}
	return _replyContentLabel;
}

- (PointExtenButton *)extentLabel {
	if (!_extentLabel) {
		_extentLabel = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_extentLabel setTitle:@"展开" forState:UIControlStateNormal];
		_extentLabel.titleLabel.font = fcFont(12);
		[_extentLabel setTitleColor:RGBCOLOR(249, 129, 49) forState:UIControlStateNormal];
		[_extentLabel addTarget:self action:@selector(extenClick) forControlEvents:UIControlEventTouchUpInside];
		[self.replyContentView addSubview:_extentLabel];
	}
	return _extentLabel;
}

- (UILabel *)contentLabel {
	if (!_contentLabel) {
		_contentLabel = [UILabel new];
		_contentLabel.textColor = ColorAppBlack;
		_contentLabel.font = fcBoldFont(14);
		_contentLabel.numberOfLines = 0;
		[self.contentView addSubview:_contentLabel];
	}
	return _contentLabel;
}

- (UILabel *)timeLabel {
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.font = fcFont(12);
		_timeLabel.textColor = RGBCOLOR(168, 168, 168);
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}

- (UILabel *)authLabel {
	if (!_authLabel) {
		_authLabel = [UILabel new];
		_authLabel.textColor = ColorAppBlack;
		_authLabel.font = fcBoldFont(14);
		[self.contentView addSubview:_authLabel];
	}
	return _authLabel;
}

- (UILabel *)levelLabel {
	if (!_levelLabel) {
		_levelLabel = [UILabel new];
		_levelLabel.font = fcBoldFont(12);
		_levelLabel.textColor = [UIColor whiteColor];
		_levelLabel.textAlignment = NSTextAlignmentCenter;
		_levelLabel.layer.cornerRadius = 4;
		_levelLabel.clipsToBounds = YES;
        _levelLabel.hidden = YES;
		[self.contentView addSubview:_levelLabel];
	}
	return _levelLabel;
}

- (UIButton *)floorLogoBtn {
	if (!_floorLogoBtn) {
		_floorLogoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_floorLogoBtn setTitle:@"楼主" forState:UIControlStateNormal];
		[_floorLogoBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_floorLogoBtn.titleLabel.font = fcFont(11);
		_floorLogoBtn.enabled = NO;
		_floorLogoBtn.backgroundColor = RGBCOLOR(6, 120, 125);
		_floorLogoBtn.layer.cornerRadius = 4;
		[self.contentView addSubview:_floorLogoBtn];
	}
	return _floorLogoBtn;
}

- (UIButton *)originTextBtn {
	if (!_originTextBtn) {
		_originTextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_originTextBtn setTitle:@"原文" forState:UIControlStateNormal];
		[_originTextBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_originTextBtn.titleLabel.font = fcFont(11);
		_originTextBtn.enabled = NO;
		_originTextBtn.backgroundColor = RGBCOLOR(168, 168, 168);
		_originTextBtn.layer.cornerRadius = 2;
		[self.replyContentLabel addSubview:_originTextBtn];
	}
	return _originTextBtn;
}

- (UIButton *)replyBtn {
	if (!_replyBtn) {
		_replyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_replyBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_replyBtn setTitle:@"回复" forState:UIControlStateNormal];
		_replyBtn.titleLabel.font = fcFont(12);
		[_replyBtn setImage:GetImage(@"paper_reply_icon") forState:UIControlStateNormal];
		[_replyBtn addTarget:self action:@selector(replyBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_replyBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_replyBtn];
	}
	return _replyBtn;
}

- (UIButton *)likeBtn {
	if (!_likeBtn) {
		_likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_likeBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_likeBtn setTitle:@"赞" forState:UIControlStateNormal];
		_likeBtn.titleLabel.font = fcFont(12);
		[_likeBtn setImage:GetImage(@"paper_like_icon") forState:UIControlStateNormal];
		[_likeBtn setImage:GetImage(@"paper_liked_icon") forState:UIControlStateSelected];
		[_likeBtn addTarget:self action:@selector(likeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_likeBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_likeBtn];
	}
	return _likeBtn;
}

- (UIButton *)shareBtn {
	if (!_shareBtn) {
		_shareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_shareBtn setImage:GetImage(@"paper_share_icon") forState:UIControlStateNormal];
		[_shareBtn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_shareBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self.contentView addSubview:_shareBtn];
	}
	return _shareBtn;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentView addSubview:_seperatorLine];
	}
	return _seperatorLine;
}
@end
