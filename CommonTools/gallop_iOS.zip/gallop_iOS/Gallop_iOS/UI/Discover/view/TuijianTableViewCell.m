//
//  TuijianTableViewCell.m
//  ESTicket
//
//  Created by Homosum on 2019/3/13.
//  Copyright © 2019 九辰_王添诚. All rights reserved.
//

#import "TuijianTableViewCell.h"
#import "MatchInstantListModel.h"
@interface TuijianTableViewCell()<TuiJianScrollViewDelegate>
@end
@implementation TuijianTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setupView];
    }
    return self;
}
- (void)setupView
{
    TuijianTableViewCell *weakSelf = self;
    
    [self.contentView addSubview:self.tuijianView];
    [self.tuijianView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.bottom.mas_equalTo(weakSelf.contentView);
    }];
    
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(TuiJianScrollView*)tuijianView
{
    if (!_tuijianView) {
        _tuijianView = [[TuiJianScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 115)];
        _tuijianView.delegate = self;
        _tuijianView.autoScrollTimeInterval = 4.0;
        _tuijianView.pageControlStyle = SD1CycleScrollViewPageContolStyleAnimated;
        _tuijianView.pageControlAliment = SD1CycleScrollViewPageContolAlimentCenter;
        _tuijianView.currentPageDotImage = [UIImage imageNamed:@"dotball"];
        _tuijianView.pageDotImage = [UIImage imageNamed:@"dotgray"];
        _tuijianView.autoScroll = NO;
//        _tuijianView.currentPageDotColor = ColorPink;
    }
    return _tuijianView;
}
-(void)tcScrollView:(TuiJianScrollView *)tcScrollView didSelectItemAtIndex:(NSInteger)index
{
    InstantMatcth*model  = self.dataSource[index];
    if (self.clickItems) {
        self.clickItems(model);
    }
    //push
}
- (void)setDataSource:(NSArray *)dataSource
{
    _dataSource = dataSource;
    dispatch_main_async_safe(^{
//        [self setupView];
        self.tuijianView.modelArrs = dataSource;
    });
    
}

@end
