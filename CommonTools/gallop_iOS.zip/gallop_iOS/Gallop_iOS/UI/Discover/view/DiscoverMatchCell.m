//
//  DiscoverMatchCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "DiscoverMatchCell.h"
#import "MatchInstantListModel.h"

@interface DiscoverMatchCell()
@property(nonatomic, strong)UIView                      *containerView;
@property(nonatomic, strong)UIView                  *headView;
@property(nonatomic, strong)UILabel          *typeLabel;
@property(nonatomic, strong)UILabel          *startTimeLabel;
@property(nonatomic, strong)UILabel          *secondsLabel;
@property(nonatomic, strong)UILabel          *currentTimeLabel;
@property(nonatomic, strong)UILabel          *dishLabel;
@property(nonatomic, strong)UILabel          *raceIdentLabel;

@property(nonatomic, strong)UIView                  *matchView;
@property(nonatomic, strong)UIImageView     *hostImageView;
@property(nonatomic, strong)UILabel         *hostTeamLabel;
@property(nonatomic, strong)UILabel         *instantHostRankLabel;
@property(nonatomic, strong)UIImageView     *awayImageView;
@property(nonatomic, strong)UILabel         *awayTeamLabel;
@property(nonatomic, strong)UILabel         *awayRankLabel;
@property(nonatomic, strong)UILabel         *scoreLabel;
@property(nonatomic, strong)UILabel         *redCardLabel;
@property(nonatomic, strong)UILabel         *yellowCardLabel;
@property(nonatomic, strong)UILabel         *awayRedCardLabel;
@property(nonatomic, strong)UILabel         *awayYellowCardLabel;
@property(nonatomic, strong)UIImageView     *liveImageView;
@property(nonatomic, strong)UILabel         *halfInfoLabel;
@property(nonatomic, strong)UILabel         *expertsLabel;
@property(nonatomic, strong)UILabel         *intelligenceLabel;

//data
@property(nonatomic, strong)InstantMatcth *matchModel;

@end

@implementation DiscoverMatchCell
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setupView];
    }
    return self;
}

- (void)configCellWithModel:(id)model{
    _matchModel = model;
    //比赛信息
    self.typeLabel.text = _matchModel.league;
    self.typeLabel.textColor = [UIColor colorWithHexString:_matchModel.leagueColor];
    self.startTimeLabel.text = [CMMUtility timeConvertWithTimeStamp:@(_matchModel.startTime).stringValue andTimeFormat:@"HH:mm"];
    self.currentTimeLabel.text = [NSString stringWithFormat:@"%@'",@(_matchModel.elapsedTime)];
    
    self.currentTimeLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.elapsedTime)];
    
    self.currentTimeLabel.textColor = ColorAppBlack;
    if (_matchModel.status == 0) {
        self.currentTimeLabel.text = @"未";
        self.currentTimeLabel.textColor = RGBCOLOR(58, 58, 58);
    } else if (_matchModel.status == 1 && _matchModel.elapsedTime > 45) {
        //上半场
        self.currentTimeLabel.text = @"45+";
    } else if (_matchModel.status == 2) {
        self.currentTimeLabel.text = @"中";
    } else if (_matchModel.status == 3 && _matchModel.elapsedTime > 90) {
        //下半场
        self.currentTimeLabel.text = @"90+";
    } else if (_matchModel.status == 4 && _matchModel.elapsedTime > 120) {
        self.currentTimeLabel.text = @"120+";
    } else if (_matchModel.status == 5) {
        self.currentTimeLabel.text = @"点球";
    } else if (_matchModel.status == 6) {
        self.currentTimeLabel.text = @"完";
        self.currentTimeLabel.textColor = RGBCOLOR(240, 72, 68);
    }
    
    //仅即时列表秒点闪烁
    BOOL needShowSecond = (([self.currentTimeLabel.text isEqualToString:@(_matchModel.elapsedTime).stringValue] || [self.currentTimeLabel.text containsString:@"+"]));
    if (needShowSecond) {
        self.secondsLabel.hidden = NO;
        [self.secondsLabel.layer addAnimation:[self opacityForever_Animation:0.5] forKey:@"opacityForever"];
    } else {
        self.secondsLabel.hidden = YES;
    }
    
    //竞彩标识
    self.raceIdentLabel.text = QM_IS_STR_NIL(_matchModel.lotteryNo) ? @"" : _matchModel.lotteryNo;
    
    //盘口
    if (QM_IS_STR_NIL(_matchModel.handicap)) {
        self.dishLabel.hidden = YES;
    } else {
        self.dishLabel.hidden = NO;
        self.dishLabel.text = _matchModel.handicap;
        if (QM_IS_STR_NIL(_matchModel.lotteryNo)) {
            [self.dishLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self.headView).offset(-10);
                make.centerY.equalTo(self.headView);
                make.height.mas_equalTo(17);
            }];
        } else {
            [self.dishLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(self.raceIdentLabel.mas_left).offset(-10);
                make.centerY.equalTo(self.headView);
                make.height.mas_equalTo(17);
            }];
        }
    }
    
    //主客队
    [self.hostImageView sd_setImageWithURL:[NSURL URLWithString:_matchModel.hostIcon] placeholderImage:GetImage(@"host")];
    [self.awayImageView sd_setImageWithURL:[NSURL URLWithString:_matchModel.guestIcon] placeholderImage:GetImage(@"guest")];
    self.hostTeamLabel.text = _matchModel.hostName.length > 4 ? [_matchModel.hostName substringToIndex:4] : _matchModel.hostName;
    self.awayTeamLabel.text = _matchModel.guestName.length > 4 ? [_matchModel.guestName substringToIndex:4] : _matchModel.guestName;
    self.instantHostRankLabel.text = QM_STR_NOT_NIL(_matchModel.instantHostRank);
    self.awayRankLabel.text = QM_STR_NOT_NIL(_matchModel.instantGuestRank);
    
    //红黄牌
    if (_matchModel.hostRedCard > 0) {
        self.redCardLabel.hidden = NO;
        self.redCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.hostRedCard)];
        [self.yellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.redCardLabel.mas_right).offset(6.5);
            make.centerY.equalTo(self.hostImageView);
            make.size.mas_equalTo(CGSizeMake(9, 14));
        }];
    } else {
        self.redCardLabel.hidden = YES;
        [self.yellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.redCardLabel);
            make.centerY.equalTo(self.hostImageView);
            make.size.mas_equalTo(CGSizeMake(9, 14));
        }];
    }
    
    if (_matchModel.hostYellowCard > 0) {
        self.yellowCardLabel.hidden = NO;
        self.yellowCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.hostYellowCard)];
    } else {
        self.yellowCardLabel.hidden = YES;
    }
    
    if (_matchModel.guestRedCard > 0) {
        self.awayRedCardLabel.hidden = NO;
        self.awayRedCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.guestRedCard)];
        [self.awayYellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.awayRedCardLabel.mas_left).offset(-6.5);
            make.centerY.equalTo(self.awayImageView);
            make.size.mas_equalTo(CGSizeMake(9, 14));
        }];
    } else {
        self.awayRedCardLabel.hidden = YES;
        [self.awayYellowCardLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.awayTeamLabel.mas_left).offset(-10);
            make.centerY.equalTo(self.awayImageView);
            make.size.mas_equalTo(CGSizeMake(9, 14));
        }];
    }
    
    if (_matchModel.guestYellowCard > 0) {
        self.awayYellowCardLabel.hidden = NO;
        self.awayYellowCardLabel.text = [NSString stringWithFormat:@"%@",@(_matchModel.guestYellowCard)];
    } else {
        self.awayYellowCardLabel.hidden = YES;
    }
    
    //比分
    if (_matchModel.status == 0) {
        self.scoreLabel.text = @"VS";
        self.scoreLabel.textColor = ColorAppBlack;
    } else {
        self.scoreLabel.textColor = RGBCOLOR(240, 72, 68);
        self.scoreLabel.text = [NSString stringWithFormat:@"%@ : %@",@(_matchModel.hostScore),@(_matchModel.guestScore)];
    }
    
    //直播标识
    if (_matchModel.liveType == 0) {
        self.liveImageView.hidden = YES;
    } else if (_matchModel.liveType == 2) {
        self.liveImageView.hidden = NO;
        self.liveImageView.image = [UIImage imageNamed:@"match_live_video"];
    } else {
        self.liveImageView.hidden = NO;
        self.liveImageView.image = [UIImage imageNamed:@"match_live_animation"];
    }
    
    //情报专家标识
    self.expertsLabel.hidden = _matchModel.hasExpert == 1 ? NO:YES;
    if (_matchModel.hasInformation == 0) {
        self.intelligenceLabel.hidden = YES;
        [self.expertsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.intelligenceLabel.mas_left).offset(15);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.equalTo(self.liveImageView);
        }];
    } else {
        self.intelligenceLabel.hidden = NO;
        [self.expertsLabel mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.intelligenceLabel.mas_left).offset(-8);
            make.size.mas_equalTo(CGSizeMake(15, 15));
            make.centerY.equalTo(self.liveImageView);
        }];
    }
    
    //半场信息
    self.halfInfoLabel.text = @"";
    NSMutableString *halfStr = [NSMutableString string];
    if (_matchModel.halfHostScore >= 0 && _matchModel.status >= 3 && _matchModel.status <= 6) {
        [halfStr appendFormat:@"半(%@:%@)  ",@(_matchModel.halfHostScore),@(_matchModel.halfGuestScore)];
    }
    if (_matchModel.hostCorner >= 0 && _matchModel.status != 0) {
        [halfStr appendFormat:@"角(%@:%@)",@(_matchModel.hostCorner),@(_matchModel.guestCorner)];
    }
    self.halfInfoLabel.text = halfStr.length > 0 ? halfStr : @"";
    self.halfInfoLabel.hidden  = halfStr.length > 0 ? NO : YES;
}

- (void)setupView {
    self.backgroundColor = [UIColor clearColor];
    self.contentView.backgroundColor = [UIColor clearColor];
    
    [self.containerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.contentView);
    }];
    
    //headView
    [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.containerView);
        make.height.mas_equalTo(28);
    }];
    [self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.headView).offset(10);
        make.centerY.equalTo(self.headView);
    }];
    [self.startTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.typeLabel.mas_right).offset(18);
        make.width.mas_lessThanOrEqualTo(60);
        make.centerY.equalTo(self.headView);
    }];
    [self.currentTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.headView);
    }];
    [self.secondsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.currentTimeLabel.mas_right);
        make.centerY.equalTo(self.currentTimeLabel);
    }];
    [self.raceIdentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.headView).offset(-9.5);
        make.centerY.equalTo(self.headView);
        make.height.mas_equalTo(17);
    }];
    [self.dishLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.raceIdentLabel.mas_left).offset(-10);
        make.centerY.equalTo(self.headView);
        make.height.mas_equalTo(17);
    }];
    
    //matchView
    [self.matchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headView.mas_bottom);
        make.left.right.equalTo(self.containerView);
        make.bottom.equalTo(self.liveImageView).offset(28);
    }];
    [self.hostImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.matchView).offset(10);
        make.top.equalTo(self.matchView).offset(22);
        make.size.mas_equalTo(CGSizeMake(22, 22));
    }];
    [self.instantHostRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.hostImageView);
        make.left.equalTo(self.hostImageView.mas_right).offset(10);
    }];
    [self.hostTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.hostImageView);
        make.left.equalTo(self.instantHostRankLabel.mas_right);
    }];
    [self.redCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.hostImageView);
        make.left.equalTo(self.hostTeamLabel.mas_right).offset(10);
        make.size.mas_equalTo(CGSizeMake(9, 14));
    }];
    [self.yellowCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.hostImageView);
        make.left.equalTo(self.redCardLabel.mas_right).offset(6.5);
        make.size.mas_equalTo(CGSizeMake(9, 14));
    }];
    
    [self.scoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.matchView);
        make.centerY.equalTo(self.hostImageView);
    }];
    
    [self.awayImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.matchView).offset(-10);
        make.centerY.equalTo(self.hostImageView);
        make.size.mas_equalTo(CGSizeMake(22, 22));
    }];
    [self.awayRankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.awayImageView);
        make.right.equalTo(self.awayImageView.mas_left).offset(-10);
    }];
    [self.awayTeamLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.awayImageView);
        make.right.equalTo(self.awayRankLabel.mas_left);
    }];
    [self.awayRedCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.awayImageView);
        make.right.equalTo(self.awayTeamLabel.mas_left).offset(-10);
        make.size.mas_equalTo(CGSizeMake(9, 14));
    }];
    [self.awayYellowCardLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.awayImageView);
        make.right.equalTo(self.awayRedCardLabel.mas_left).offset(-6.5);
        make.size.mas_equalTo(CGSizeMake(9, 14));
    }];
    
    [self.liveImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.hostImageView.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(15, 15));
        make.left.equalTo(self.matchView).offset(10);
    }];
    [self.halfInfoLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.matchView);
        make.centerY.equalTo(self.liveImageView);
    }];
    [self.intelligenceLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.matchView).offset(-10);
        make.size.mas_equalTo(CGSizeMake(15, 15));
        make.centerY.equalTo(self.liveImageView);
    }];
    [self.expertsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.intelligenceLabel.mas_left).offset(-8);
        make.size.mas_equalTo(CGSizeMake(15, 15));
        make.centerY.equalTo(self.liveImageView);
    }];
}

#pragma mark 秒点闪烁动画
- (CABasicAnimation *)opacityForever_Animation:(float)time
{
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation.fromValue = [NSNumber numberWithFloat:1.0f];
    animation.toValue = [NSNumber numberWithFloat:0.0f];
    animation.autoreverses = YES;
    animation.duration = time;
    animation.repeatCount = MAXFLOAT;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn];
    return animation;
}

#pragma mark - lazy init
- (UIView *)containerView {
    if (!_containerView) {
        _containerView = [UIView new];
        _containerView.backgroundColor = [UIColor whiteColor];
        _containerView.layer.cornerRadius = 5;
        _containerView.clipsToBounds = YES;
        [self.contentView addSubview:_containerView];
    }
    return _containerView;
}
//headView
- (UIView *)headView {
    if (!_headView) {
        _headView = [UIView new];
//        _headView.backgroundColor = RGBCOLOR(244, 244, 244);
        _headView.backgroundColor  = [UIColor whiteColor];
        [self.contentView addSubview:_headView];
    }
    return _headView;
}

- (UILabel *)typeLabel {
    if (!_typeLabel) {
        _typeLabel = [UILabel new];
        _typeLabel.textColor = RGBCOLOR(58, 58, 58);
        _typeLabel.font = fcFont(12);
        [self.headView addSubview:_typeLabel];
    }
    return _typeLabel;
}

- (UILabel *)startTimeLabel {
    if (!_startTimeLabel) {
        _startTimeLabel = [UILabel new];
        _startTimeLabel.textColor = RGBCOLOR(58, 58, 58);
        _startTimeLabel.font = fcFont(12);
        [self.headView addSubview:_startTimeLabel];
    }
    return _startTimeLabel;
}

- (UILabel *)secondsLabel {
    if (!_secondsLabel) {
        _secondsLabel = [UILabel new];
        _secondsLabel.textColor = ColorAppBlack;
        _secondsLabel.font = fcFont(12);
        _secondsLabel.text = @"'";
        _secondsLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_secondsLabel];
    }
    return _secondsLabel;
}

- (UILabel *)currentTimeLabel {
    if (!_currentTimeLabel) {
        _currentTimeLabel = [UILabel new];
        _currentTimeLabel.font = fcFont(12);
        _currentTimeLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_currentTimeLabel];
    }
    return _currentTimeLabel;
}

- (UILabel *)dishLabel {
    if (!_dishLabel) {
        _dishLabel = [UILabel new];
        _dishLabel.textColor = RGBCOLOR(58, 58, 58);
        _dishLabel.font = fcFont(12);
        _dishLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_dishLabel];
    }
    return _dishLabel;
}

- (UILabel *)raceIdentLabel {
    if (!_raceIdentLabel) {
        _raceIdentLabel = [UILabel new];
        _raceIdentLabel.textColor = RGBCOLOR(58, 58, 58);
        _raceIdentLabel.font = fcFont(12);
        _raceIdentLabel.textAlignment = NSTextAlignmentCenter;
        [self.headView addSubview:_raceIdentLabel];
    }
    return _raceIdentLabel;
}

//mathView
- (UIView *)matchView {
    if (!_matchView) {
        _matchView = [UIView new];
        _matchView.backgroundColor = [UIColor whiteColor];
        [self.containerView addSubview:_matchView];
    }
    return _matchView;
}

- (UILabel *)redCardLabel {
    if (!_redCardLabel) {
        _redCardLabel = [UILabel new];
        _redCardLabel.textColor = [UIColor whiteColor];
        _redCardLabel.textAlignment = NSTextAlignmentCenter;
        _redCardLabel.font = fcFont(10);
        _redCardLabel.backgroundColor = RGBCOLOR(240, 72, 68);
        [self.matchView addSubview:_redCardLabel];
    }
    return _redCardLabel;
}

- (UILabel *)yellowCardLabel {
    if (!_yellowCardLabel) {
        _yellowCardLabel = [UILabel new];
        _yellowCardLabel.textColor = [UIColor whiteColor];
        _yellowCardLabel.textAlignment = NSTextAlignmentCenter;
        _yellowCardLabel.backgroundColor = RGBCOLOR(255, 205, 46);
        _yellowCardLabel.font = fcFont(10);
        [self.matchView addSubview:_yellowCardLabel];
    }
    return _yellowCardLabel;
}

- (UILabel *)awayRedCardLabel {
    if (!_awayRedCardLabel) {
        _awayRedCardLabel = [UILabel new];
        _awayRedCardLabel.textColor = [UIColor whiteColor];
        _awayRedCardLabel.textAlignment = NSTextAlignmentCenter;
        _awayRedCardLabel.font = fcFont(10);
        _awayRedCardLabel.backgroundColor = RGBCOLOR(240, 72, 68);
        [self.matchView addSubview:_awayRedCardLabel];
    }
    return _awayRedCardLabel;
}

- (UILabel *)awayYellowCardLabel {
    if (!_awayYellowCardLabel) {
        _awayYellowCardLabel = [UILabel new];
        _awayYellowCardLabel.textColor = [UIColor whiteColor];
        _awayYellowCardLabel.textAlignment = NSTextAlignmentCenter;
        _awayYellowCardLabel.backgroundColor = RGBCOLOR(255, 205, 46);
        _awayYellowCardLabel.font = fcFont(10);
        [self.matchView addSubview:_awayYellowCardLabel];
    }
    return _awayYellowCardLabel;
}

- (UIImageView *)hostImageView {
    if (!_hostImageView) {
        _hostImageView = [[UIImageView alloc] init];
        _hostImageView.layer.cornerRadius = 11;
        _hostImageView.clipsToBounds = YES;
        [self.matchView addSubview:_hostImageView];
    }
    return _hostImageView;
}

- (UILabel *)hostTeamLabel {
    if (!_hostTeamLabel) {
        _hostTeamLabel = [UILabel new];
        _hostTeamLabel.textColor = ColorAppBlack;
        _hostTeamLabel.font = GetBoldFont(14);
        _hostTeamLabel.textAlignment = NSTextAlignmentRight;
        [self.matchView addSubview:_hostTeamLabel];
    }
    return _hostTeamLabel;
}

- (UILabel *)instantHostRankLabel {
    if (!_instantHostRankLabel) {
        _instantHostRankLabel = [UILabel new];
        _instantHostRankLabel.textColor = RGBCOLOR(58, 58, 58);
        _instantHostRankLabel.font = fcFont(12);
        [self.matchView addSubview:_instantHostRankLabel];
    }
    return _instantHostRankLabel;
}

- (UIImageView *)awayImageView {
    if (!_awayImageView) {
        _awayImageView = [[UIImageView alloc] init];
        _awayImageView.layer.cornerRadius = 11;
        _awayImageView.clipsToBounds = YES;
        [self.matchView addSubview:_awayImageView];
    }
    return _awayImageView;
}

- (UILabel *)awayTeamLabel {
    if (!_awayTeamLabel) {
        _awayTeamLabel = [UILabel new];
        _awayTeamLabel.textColor = ColorAppBlack;
        _awayTeamLabel.font = GetBoldFont(14);
        _awayTeamLabel.textAlignment = NSTextAlignmentLeft;
        [self.matchView addSubview:_awayTeamLabel];
    }
    return _awayTeamLabel;
}

- (UILabel *)awayRankLabel {
    if (!_awayRankLabel) {
        _awayRankLabel = [UILabel new];
        _awayRankLabel.textColor = RGBCOLOR(58, 58, 58);
        _awayRankLabel.font = fcFont(12);
        [self.matchView addSubview:_awayRankLabel];
    }
    return _awayRankLabel;
}

- (UILabel *)scoreLabel {
    if (!_scoreLabel) {
        _scoreLabel = [UILabel new];
        _scoreLabel.textColor = ColorAppBlack;
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
        _scoreLabel.font = GetBoldFont(16);
        [self.matchView addSubview:_scoreLabel];
    }
    return _scoreLabel;
}

- (UIImageView *)liveImageView {
    if (!_liveImageView) {
        _liveImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"match_live_animation"]];
        [self.matchView addSubview:_liveImageView];
    }
    return _liveImageView;
}

- (UILabel *)halfInfoLabel {
    if (!_halfInfoLabel) {
        _halfInfoLabel = [UILabel new];
        _halfInfoLabel.textColor = RGBCOLOR(58, 58, 58);
        _halfInfoLabel.font = fcFont(12);
        _halfInfoLabel.textAlignment = NSTextAlignmentCenter;
        [self.matchView addSubview:_halfInfoLabel];
    }
    return _halfInfoLabel;
}

- (UILabel *)expertsLabel {
    if (!_expertsLabel) {
        _expertsLabel = [UILabel new];
        _expertsLabel.textColor = ColorAppGreen;
        _expertsLabel.font = fcFont(9);
        _expertsLabel.backgroundColor = [UIColor whiteColor];
        _expertsLabel.text = @"专";
        _expertsLabel.textAlignment = NSTextAlignmentCenter;
        _expertsLabel.layer.cornerRadius = 7.5;
        _expertsLabel.layer.borderColor = ColorAppGreen.CGColor;
        _expertsLabel.layer.borderWidth = 1.0f;
        _expertsLabel.clipsToBounds = YES;
        [self.matchView addSubview:_expertsLabel];
    }
    return _expertsLabel;
}

- (UILabel *)intelligenceLabel {
    if (!_intelligenceLabel) {
        _intelligenceLabel = [UILabel new];
        _intelligenceLabel.textColor = RGBCOLOR(240, 72, 68);
        _intelligenceLabel.font = fcFont(9);
        _intelligenceLabel.backgroundColor = [UIColor whiteColor];
        _intelligenceLabel.text = @"报";
        _intelligenceLabel.textAlignment = NSTextAlignmentCenter;
        _intelligenceLabel.layer.cornerRadius = 7.5;
        _intelligenceLabel.layer.borderColor = RGBCOLOR(240, 72, 68).CGColor;
        _intelligenceLabel.layer.borderWidth = 1.0f;
        _intelligenceLabel.clipsToBounds = YES;
        [self.matchView addSubview:_intelligenceLabel];
    }
    return _intelligenceLabel;
}

@end
