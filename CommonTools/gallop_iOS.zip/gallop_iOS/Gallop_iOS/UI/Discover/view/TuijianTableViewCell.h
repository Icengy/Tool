//
//  TuijianTableViewCell.h
//  ESTicket
//
//  Created by Homosum on 2019/3/13.
//  Copyright © 2019 九辰_王添诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TuiJianScrollView.h"
NS_ASSUME_NONNULL_BEGIN

@interface TuijianTableViewCell : UITableViewCell
@property (nonatomic, strong) TuiJianScrollView *tuijianView;
@property (nonatomic, copy)NSArray *dataSource;
@property (nonatomic, copy) void (^clickItems)(InstantMatcth*model);
@end

NS_ASSUME_NONNULL_END
