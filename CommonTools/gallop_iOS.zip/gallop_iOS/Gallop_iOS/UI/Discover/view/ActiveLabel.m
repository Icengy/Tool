//
//  ActiveLabel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/9.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ActiveLabel.h"

@implementation ActiveLabel

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
