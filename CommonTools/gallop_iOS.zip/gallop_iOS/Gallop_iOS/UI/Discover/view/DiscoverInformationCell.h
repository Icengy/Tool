//
//  DiscoverInformationCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscoverInformationCell : UITableViewCell
- (void)configCellWithModel:(id)model;
@end
