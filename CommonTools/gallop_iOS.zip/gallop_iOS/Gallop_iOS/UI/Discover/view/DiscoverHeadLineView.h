//
//  DiscoverHeadLineView.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kmiddleViewHight 25.0

@class GallopBannerItemModel;

@protocol HeadLineDelegate <NSObject>

- (void)parseClick:(GallopBannerItemModel *)model;

@optional
- (void)hotClick:(NSString *)planId;

@end

@interface DiscoverHeadLineView : UIView
- (void)configViewWithModel:(id)model;
@property (nonatomic,weak) id<HeadLineDelegate> delegateVC;
@end
