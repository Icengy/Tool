//
//  PaperBottomView.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/5.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperBottomView.h"
#import "ESBanner.h"

@interface PaperBottomView()
@property (nonatomic,strong) UIView *commentBgView;
@property (nonatomic,strong) UILabel *commentTipLabel;
@property (nonatomic,strong) UIButton *replyBtn;
@property (nonatomic,strong) UIButton *likeBtn;
@property (nonatomic,strong) UIButton *shareBtn;
@property (nonatomic,strong) UIButton*collectBtn;
@property (nonatomic,strong) UIView *seperatorLine;
//
@property (nonatomic,strong) ESPaperModel *model;
@end

@implementation PaperBottomView
- (instancetype)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = [UIColor whiteColor];
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self).offset(-15);
		make.centerY.equalTo(self);
		make.height.mas_equalTo(20);
	}];
	[self.likeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.shareBtn.mas_left).offset(-15);
		make.centerY.equalTo(self.replyBtn);
		make.height.mas_equalTo(20);
	}];
	[self.replyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self);
		make.right.equalTo(self.likeBtn.mas_left).offset(-15);
		make.height.mas_equalTo(20);
	}];
    [self.collectBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.height.mas_equalTo(20);
        make.right.mas_equalTo(self.replyBtn.mas_left).offset(-15);
    }];
	[self.commentBgView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self).offset(15);
		make.right.equalTo(self.collectBtn.mas_left).offset(-23);
		make.centerY.equalTo(self);
		make.height.mas_equalTo(32);
	}];
	[self.commentTipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.commentBgView).offset(8.5);
		make.centerY.equalTo(self.commentBgView);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.top.right.equalTo(self);
		make.height.mas_equalTo(1);
	}];
}

- (void)configViewWithModel:(ESPaperModel *)model isComunity:(BOOL)isComunity{
	if (model == nil) {
		self.replyBtn.hidden = YES;
		self.likeBtn.hidden = YES;
		self.collectBtn.hidden = YES;
		[self.commentBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(self).offset(15);
			make.right.equalTo(self).offset(-50);
			make.centerY.equalTo(self);
			make.height.mas_equalTo(32);
		}];
	} else {
		self.replyBtn.hidden = NO;
		self.likeBtn.hidden = NO;
		self.model = model;
		[self.replyBtn setTitle:[NSString stringWithFormat:@" %@ ",@(model.commentCount)] forState:UIControlStateNormal];
		[self.likeBtn setTitle:[NSString stringWithFormat:@" %@ ",@(model.likeCount)] forState:UIControlStateNormal];
		if (isComunity) {
			self.collectBtn.hidden = NO;
			[self.commentBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.left.equalTo(self).offset(15);
				make.right.equalTo(self.collectBtn.mas_left).offset(-25);
				make.centerY.equalTo(self);
				make.height.mas_equalTo(32);
			}];
			self.likeBtn.selected = model.isLiked;
			self.collectBtn.selected = model.isFavourite;
		} else {
			self.collectBtn.hidden = YES;
			[self.commentBgView mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.left.equalTo(self).offset(15);
				make.right.equalTo(self.replyBtn.mas_left).offset(-25);
				make.centerY.equalTo(self);
				make.height.mas_equalTo(32);
			}];
			self.likeBtn.selected = model.isLiked;
		}
		
	}
}

#pragma mark - action
- (void)commentClick {
	if ([self.viewDelegate respondsToSelector:@selector(commentClick)]) {
		[self.viewDelegate commentClick];
	};
}

- (void)replyBtnClick:(UIButton *)btn {
	if ([self.viewDelegate respondsToSelector:@selector(tabReplyClick:)]) {
		[self.viewDelegate tabReplyClick:btn];
	};
}

- (void)likeBtnClick:(UIButton *)btn {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	if ([self.viewDelegate respondsToSelector:@selector(tabLikeClick:)]) {
		[self.viewDelegate tabLikeClick:btn];
	};
}
-(void)collectBtnClick:(UIButton*)btn{
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    if ([self.viewDelegate respondsToSelector:@selector(tabCollectClick:)]) {
        [self.viewDelegate tabCollectClick:btn];
    };
}
- (void)shareBtnClick:(UIButton *)btn {
	if ([self.viewDelegate respondsToSelector:@selector(tabShareClick:)]) {
		[self.viewDelegate tabShareClick:btn];
	};
}

#pragma mark - lazy init
- (UIView *)commentBgView {
	if (!_commentBgView) {
		_commentBgView = [UIView new];
		_commentBgView.backgroundColor = RGBCOLOR(244, 244, 244);
		_commentBgView.userInteractionEnabled = YES;
		_commentBgView.clipsToBounds = YES;
		_commentBgView.layer.cornerRadius = 2;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(commentClick)];
		[_commentBgView addGestureRecognizer:tap];
		[self addSubview:_commentBgView];
	}
	return _commentBgView;
}

- (UILabel *)commentTipLabel {
	if (!_commentTipLabel) {
		_commentTipLabel = [UILabel new];
		_commentTipLabel.text = @"我也来评论";
		_commentTipLabel.textColor = RGBCOLOR(168, 168, 168);
		_commentTipLabel.font = fcFont(12);
		[self.commentBgView addSubview:_commentTipLabel];
	}
	return _commentTipLabel;
}

- (UIButton *)replyBtn {
	if (!_replyBtn) {
		_replyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_replyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_replyBtn.titleLabel.font = fcFont(9);
		_replyBtn.titleLabel.backgroundColor = ColorAppBlack;
		_replyBtn.titleLabel.layer.cornerRadius = 4;
		_replyBtn.titleLabel.clipsToBounds = YES;
		_replyBtn.titleEdgeInsets  = UIEdgeInsetsMake(- 10, -10, 10, 10);
		[_replyBtn setImage:GetImage(@"paper_tab_comment") forState:UIControlStateNormal];
		[_replyBtn addTarget:self action:@selector(replyBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_replyBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self addSubview:_replyBtn];
	}
	return _replyBtn;
}


- (UIButton *)likeBtn {
	if (!_likeBtn) {
		_likeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_likeBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_likeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_likeBtn.titleLabel.font = fcFont(9);
		_likeBtn.titleLabel.backgroundColor = ColorAppBlack;
		_likeBtn.titleLabel.layer.cornerRadius = 4;
		_likeBtn.titleLabel.clipsToBounds = YES;
		_likeBtn.titleEdgeInsets  = UIEdgeInsetsMake(- 10, -10, 10, 10);
		[_likeBtn setImage:GetImage(@"paper_tab_like") forState:UIControlStateNormal];
		[_likeBtn setImage:GetImage(@"paper_tab_liked") forState:UIControlStateSelected];
		[_likeBtn addTarget:self action:@selector(likeBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_likeBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self addSubview:_likeBtn];
	}
	return _likeBtn;
}

- (UIButton *)shareBtn {
	if (!_shareBtn) {
		_shareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_shareBtn setImage:GetImage(@"paper_tab_share") forState:UIControlStateNormal];
		[_shareBtn addTarget:self action:@selector(shareBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_shareBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[self addSubview:_shareBtn];
	}
	return _shareBtn;
}
- (UIButton *)collectBtn {
    if (!_collectBtn) {
        _collectBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_collectBtn setImage:GetImage(@"topic_tab_like_btn") forState:UIControlStateNormal];
        [_collectBtn setImage:GetImage(@"topic_tab_like_btn_pre") forState:UIControlStateSelected];
        [_collectBtn addTarget:self action:@selector(collectBtnClick:) forControlEvents:UIControlEventTouchUpInside];
        _collectBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:_collectBtn];
    }
    return _collectBtn;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self addSubview:_seperatorLine];
	}
	return _seperatorLine;
}

@end
