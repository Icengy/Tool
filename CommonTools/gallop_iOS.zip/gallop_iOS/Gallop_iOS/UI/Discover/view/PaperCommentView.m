//
//  PaperCommentView.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/5.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PaperCommentView.h"

@interface PaperCommentView()<UITextViewDelegate>
@property (nonatomic,strong) UIView *contentView;
@property (nonatomic,strong) UIView *topAreaView;
@property (nonatomic,strong) PointExtenButton *sendBtn;
@end

@implementation PaperCommentView
- (instancetype)initWithFrame:(CGRect)frame
{
	self = [super initWithFrame:frame];
	if (self) {
		self.backgroundColor = RGBACOLOR(0, 0, 0, 0.3);
		self.hidden = YES;
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.topAreaView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.top.equalTo(self);
		make.bottom.equalTo(self).offset(-160);
	}];
	[self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.bottom.equalTo(self);
		make.height.mas_equalTo(160);
	}];
	[self.textView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.contentView).offset(15);
		make.top.equalTo(self.contentView).offset(20);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH - 79, 120));
	}];
	[self.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.textView).offset(10);
		make.top.equalTo(self.textView).offset(10);
		make.width.mas_equalTo(SCREEN_WIDTH - 100);
	}];
	[self.fullScreenBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentView).offset(-15);
		make.top.equalTo(self.textView);
		make.size.mas_equalTo(CGSizeMake(25, 25));
	}];
	[self.sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.fullScreenBtn);
		make.bottom.equalTo(self.textView);
	}];
}

- (void)showPaperCommentView {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	self.hidden = NO;
	[self.textView becomeFirstResponder];
}

- (void)hidePaperCommentView {
	self.hidden = YES;
	[self.textView resignFirstResponder];
}

#pragma mark - action
- (void)sendBtnClick:(id)sender {
	NSString *content = self.textView.text;
	if (QM_IS_STR_NIL(content)) {
		[CMMUtility showToastWithText:@"评论内容不能为空"];
		return;
	}
	if (content.length > 1500) {
		[CMMUtility showToastWithText:@"评论字数不能超过1500个字符"];
		return;
	}
	if ([self.delegate respondsToSelector:@selector(sendBtnClick:)]) {
		[self.delegate sendBtnClick:content];
	}
    if ([self.delegate respondsToSelector:@selector(sendBtnClick:content:)]) {
        [self.delegate sendBtnClick:sender content:content];
    }
}

- (void)fullScreenBtnClick {
	if ([self.delegate respondsToSelector:@selector(fullScreenBtnClick:)]) {
		NSString *content = self.textView.text;
		[self.delegate fullScreenBtnClick:content];
	}
}

#pragma mark - textView delegate
-(void)textViewDidBeginEditing:(UITextView*)textView{
	self.placeHolderLabel.hidden = YES;
}

-(BOOL)textView:(UITextView*)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString*)text{
	return YES;
}

-(void)textViewDidEndEditing:(UITextView*)textView{
	if (QM_IS_STR_NIL(textView.text)) {
		self.placeHolderLabel.hidden = NO;
	} else {
		self.placeHolderLabel.hidden = YES;
	}
}

#pragma mark - lazy init
- (UIView *)topAreaView {
	if (!_topAreaView) {
		_topAreaView = [UIView new];
		_topAreaView.backgroundColor = [UIColor clearColor];
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidePaperCommentView)];
		[_topAreaView addGestureRecognizer:tap];
		[self addSubview:_topAreaView];
	}
	return _topAreaView;
}

- (UIView *)contentView {
	if (!_contentView) {
		_contentView = [UIView new];
		_contentView.backgroundColor = [UIColor whiteColor];
		[self addSubview:_contentView];
	}
	return _contentView;
}

- (UITextView *)textView {
	if (!_textView) {
		_textView = [[UITextView alloc] init];
		_textView.backgroundColor = RGBCOLOR(244, 244, 244);
		_textView.delegate = self;
		[self.contentView addSubview:_textView];
	}
	return _textView;
}

- (UILabel *)placeHolderLabel {
	if (!_placeHolderLabel) {
		_placeHolderLabel = [UILabel new];
		_placeHolderLabel.textColor = RGBCOLOR(168, 168, 168);
		_placeHolderLabel.font = fcFont(14);
		_placeHolderLabel.hidden = YES;
		[self.textView addSubview:_placeHolderLabel];
	}
	return _placeHolderLabel;
}

- (PointExtenButton *)sendBtn {
	if (!_sendBtn) {
		_sendBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_sendBtn setTitle:@"发送" forState:UIControlStateNormal];
		[_sendBtn setTitleColor:ColorAppBlack forState:UIControlStateNormal];
		_sendBtn.titleLabel.font = fcFont(16);
        [_sendBtn addTarget:self action:@selector(sendBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:_sendBtn];
	}
	return _sendBtn;
}

- (PointExtenButton *)fullScreenBtn {
	if (!_fullScreenBtn) {
		_fullScreenBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_fullScreenBtn setImage:GetImage(@"paper_fullsreen_btn") forState:UIControlStateNormal];
		_fullScreenBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_fullScreenBtn addTarget:self action:@selector(fullScreenBtnClick) forControlEvents:UIControlEventTouchUpInside];
		[self.contentView addSubview:_fullScreenBtn];
	}
	return _fullScreenBtn;
}
@end
