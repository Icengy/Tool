//
//  MatchResultTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchResult.h"


@interface MatchResultTableViewCell : UITableViewCell
@property (nonatomic,copy) NSMutableArray*dataSource;
@property (nonatomic,copy) void (^ clickBlock)(MatchResult*model);
@end


