//
//  MatchResultCollectionViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchResult.h"


@interface MatchResultCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) MatchResult*model;
@end
