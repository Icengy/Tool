//
//  TuiJianScrollView.m
//  ESTicket
//
//  Created by Homosum on 2018/5/7.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#import "TuiJianScrollView.h"

#import "UIView+SDExtension.h"
#import "TAPageControl.h"
#import "DiscoverMatchCell.h"

NSString * const tcID = @"tcCycleCell";
@interface TuiJianScrollView () <UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, weak) UICollectionView *mainView; // 显示图片的collectionView
@property (nonatomic, weak) UICollectionViewFlowLayout *flowLayout;
@property (nonatomic, weak) NSTimer *timer;
@property (nonatomic, assign) NSInteger totalItemsCount;
@property (nonatomic, weak) UIControl *pageControl;
@property (nonatomic, assign) NSInteger networkFailedRetryCount;
@end
@implementation TuiJianScrollView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self initialization];
        [self setupMainView];
    }
    return self;
}
- (void)awakeFromNib
{
    [super awakeFromNib];
    [self initialization];
    [self setupMainView];
}
- (void)initialization
{
    _pageControlAliment = SD1CycleScrollViewPageContolAlimentCenter;
    _autoScrollTimeInterval = 2.0;

    _titleLabelTextColor = ColorDefaultBackground;

    _titleLabelTextFont= [UIFont systemFontOfSize:14];
    _titleLabelBackgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5];
    _titleLabelHeight = 30;
    _autoScroll = YES;
    _infiniteLoop = YES;
    _showPageControl = YES;
    _pageControlDotSize = CGSizeMake(10, 10);
    
    
    _pageControlStyle = SD1CycleScrollViewPageContolStyleAnimated;
    _hidesForSinglePage = YES;
//    _currentPageDotColor = [UIColor whiteColor];
//    _pageDotColor = [UIColor lightGrayColor];

    self.backgroundColor = [UIColor whiteColor];

    
}
+(instancetype)tcScrollViewWithFrame:(CGRect)frame modelArrs:(NSArray *)modelArrs
{
    TuiJianScrollView *tcSrollView = [[self alloc] initWithFrame:frame];
    tcSrollView.modelArrs = modelArrs;
    return tcSrollView;
    
}
-(void)setupMainView
{
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    _flowLayout = flowLayout;
    
    UICollectionView *mainView = [[UICollectionView alloc] initWithFrame:self.bounds collectionViewLayout:flowLayout];
    mainView.backgroundColor = [UIColor clearColor];
    mainView.pagingEnabled = YES;
    mainView.showsHorizontalScrollIndicator = NO;
    mainView.showsVerticalScrollIndicator = NO;

    [mainView registerClass:[DiscoverMatchCell class] forCellWithReuseIdentifier:tcID];

    mainView.dataSource = self;
    mainView.delegate = self;
    [self addSubview:mainView];
    _mainView = mainView;
}
- (void)setPageControlDotSize:(CGSize)pageControlDotSize
{
    _pageControlDotSize = pageControlDotSize;
    [self setupPageControl];
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageContol = (TAPageControl *)_pageControl;
        pageContol.dotSize = pageControlDotSize;
    }
}
- (void)setShowPageControl:(BOOL)showPageControl
{
    _showPageControl = showPageControl;
    
    _pageControl.hidden = !showPageControl;
}
- (void)setCurrentPageDotColor:(UIColor *)currentPageDotColor
{
    _currentPageDotColor = currentPageDotColor;
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageControl = (TAPageControl *)_pageControl;
        pageControl.dotColor = currentPageDotColor;
    } else {
        UIPageControl *pageControl = (UIPageControl *)_pageControl;
        pageControl.currentPageIndicatorTintColor = currentPageDotColor;
    }
    
}
- (void)setPageDotColor:(UIColor *)pageDotColor
{
    _pageDotColor = pageDotColor;
    if ([self.pageControl isKindOfClass:[UIPageControl class]]) {
        UIPageControl *pageControl = (UIPageControl *)_pageControl;
        pageControl.pageIndicatorTintColor = pageDotColor;
    }
}
- (void)setCurrentPageDotImage:(UIImage *)currentPageDotImage
{
    _currentPageDotImage = currentPageDotImage;
    if (self.pageControlStyle != SD1CycleScrollViewPageContolStyleAnimated) {
        self.pageControlStyle = SD1CycleScrollViewPageContolStyleAnimated;
    }
    [self setCustomPageControlDotImage:currentPageDotImage isCurrentPageDot:YES];
}
- (void)setPageDotImage:(UIImage *)pageDotImage
{
    _pageDotImage = pageDotImage;
    if (self.pageControlStyle != SD1CycleScrollViewPageContolStyleAnimated) {
        self.pageControlStyle = SD1CycleScrollViewPageContolStyleAnimated;
    }
    [self setCustomPageControlDotImage:pageDotImage isCurrentPageDot:NO];
}

- (void)setCustomPageControlDotImage:(UIImage *)image isCurrentPageDot:(BOOL)isCurrentPageDot
{
    if (!image || !self.pageControl) return;
    
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageControl = (TAPageControl *)_pageControl;
        if (isCurrentPageDot) {
            pageControl.currentDotImage = image;
        } else {
            pageControl.dotImage = image;
        }
    } else {
        UIPageControl *pageControl = (UIPageControl *)_pageControl;
        if (isCurrentPageDot) {
            [pageControl setValue:image forKey:@"_currentPageImage"];
        } else {
            [pageControl setValue:image forKey:@"_pageImage"];
        }
    }
}
- (void)setInfiniteLoop:(BOOL)infiniteLoop
{
    _infiniteLoop = infiniteLoop;
    
    if (self.modelArrs.count) {
        self.modelArrs = self.modelArrs;
    }
}
-(void)setAutoScroll:(BOOL)autoScroll{
    _autoScroll = autoScroll;
    [_timer invalidate];
    _timer = nil;
    
    if (_autoScroll) {
        [self setupTimer];
    }
}
- (void)setAutoScrollTimeInterval:(CGFloat)autoScrollTimeInterval
{
    _autoScrollTimeInterval = autoScrollTimeInterval;
    
    [self setAutoScroll:self.autoScroll];
}
- (void)setPageControlStyle:(SD1CycleScrollViewPageContolStyle)pageControlStyle
{
    _pageControlStyle = pageControlStyle;
    
    [self setupPageControl];
}
- (int)pageControlIndexWithCurrentCellIndex:(NSInteger)index
{
    return (int)index % self.modelArrs.count;
}
- (int)currentIndex
{
    if (_mainView.sd_width == 0 || _mainView.sd_height == 0) {
        return 0;
    }
    
    int index = 0;
    if (_flowLayout.scrollDirection == UICollectionViewScrollDirectionHorizontal) {
        index = (_mainView.contentOffset.x + _flowLayout.itemSize.width * 0.5) / _flowLayout.itemSize.width;
    } else {
        index = (_mainView.contentOffset.y + _flowLayout.itemSize.height * 0.5) / _flowLayout.itemSize.height;
    }
    
    return MAX(0, index);
}

- (void)setupPageControl
{
     dispatch_main_async_safe(^{
    if (_pageControl) [_pageControl removeFromSuperview];
     });// 重新加载数据时调整
    
    if ((self.modelArrs.count <= 1) && self.hidesForSinglePage) {
        return;
    }
int indexOnPageControl = [self pageControlIndexWithCurrentCellIndex:[self currentIndex]];
    dispatch_main_async_safe(^{
        switch (self.pageControlStyle) {
            case SD1CycleScrollViewPageContolStyleAnimated:
            {
                TAPageControl *pageControl = [[TAPageControl alloc] init];
                pageControl.numberOfPages = self.modelArrs.count;
//                pageControl.dotColor = self.currentPageDotColor;
                pageControl.dotImage = [UIImage imageNamed:@"dotgray"];
                pageControl.currentDotImage  = [UIImage imageNamed:@"dotball"];
                pageControl.userInteractionEnabled = NO;
                pageControl.currentPage = indexOnPageControl;
                [self addSubview:pageControl];
                _pageControl = pageControl;
            }
                break;
                
            case SD1CycleScrollViewPageContolStyleClassic:
            {
                UIPageControl *pageControl = [[UIPageControl alloc] init];
                pageControl.numberOfPages = self.modelArrs.count;
                pageControl.currentPageIndicatorTintColor = self.currentPageDotColor;
                pageControl.pageIndicatorTintColor = self.pageDotColor;
                pageControl.userInteractionEnabled = NO;
                [self addSubview:pageControl];
                _pageControl = pageControl;
            }
                break;
                
            default:
                break;
        }
    });
    

    // 重设pagecontroldot图片
   if (self.currentPageDotImage) {
          self.currentPageDotImage = self.currentPageDotImage;
      }
      if (self.pageDotImage) {
          self.pageDotImage = self.pageDotImage;
      }

}

- (void)automaticScroll
{

    if (0 == _totalItemsCount || self.modelArrs.count <= 1) return;

    int currentIndex = _mainView.contentOffset.x / _flowLayout.itemSize.width;
    int targetIndex = currentIndex + 1;
    if (targetIndex == _totalItemsCount) {
        if (self.infiniteLoop) {
            targetIndex = _totalItemsCount * 0.5;
        }else{
            return;
        }

         if (self.modelArrs.count > 0) {
             @try{
                 [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
             }@catch(id anException) {
                 //do nothing, obviously it wasn't attached because an exception was thrown
             }
         }
        return;
    }
     if (self.modelArrs.count > 0) {
    [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:YES];
     }

}

- (void)setupTimer
{
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:self.autoScrollTimeInterval target:self selector:@selector(automaticScroll) userInfo:nil repeats:YES];
    _timer = timer;
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    _flowLayout.itemSize = self.frame.size;
    
    _mainView.frame = self.bounds;
    if (_mainView.contentOffset.x == 0 &&  _totalItemsCount) {
        int targetIndex = 0;
        if (self.infiniteLoop) {
            targetIndex = _totalItemsCount * 0.5;
        }else{
            targetIndex = 0;
        }

         if (self.modelArrs.count > 0) {
         @try{
        [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
         }@catch(id anException) {
             //do nothing, obviously it wasn't attached because an exception was thrown
         }
         }

    }
    
    CGSize size = CGSizeZero;
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageControl = (TAPageControl *)_pageControl;
        size = [pageControl sizeForNumberOfPages:self.modelArrs.count];
    } else {
        size = CGSizeMake(self.modelArrs.count * self.pageControlDotSize.width * 1.2, self.pageControlDotSize.height);
    }
    CGFloat x = (self.sd_width - size.width) * 0.5;
    if (self.pageControlAliment == SD1CycleScrollViewPageContolAlimentRight) {
        x = self.mainView.sd_width - size.width - 10;
    }
    CGFloat y = self.mainView.sd_height - size.height - 10;
    
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageControl = (TAPageControl *)_pageControl;
        [pageControl sizeToFit];
    }
    
    self.pageControl.frame = CGRectMake(x, y, size.width, size.height);
    self.pageControl.hidden = !_showPageControl;
    
//    if (self.backgroundImageView) {
//        self.backgroundImageView.frame = self.bounds;
//    }
    
}

//解决当父View释放时，当前视图因为被Timer强引用而不能释放的问题
- (void)willMoveToSuperview:(UIView *)newSuperview
{
    if (!newSuperview) {
        [_timer invalidate];
        _timer = nil;
    }
}
//解决当timer释放后 回调scrollViewDidScroll时访问野指针导致崩溃
- (void)dealloc {
    _mainView.delegate = nil;
    _mainView.dataSource = nil;
}

-(void)setModelArrs:(NSArray *)modelArrs
{
    _modelArrs = modelArrs;
    _totalItemsCount = self.infiniteLoop ? self.modelArrs.count * 100 : self.modelArrs.count;
    if (modelArrs.count != 1) {
        dispatch_main_async_safe(^{
            self.mainView.scrollEnabled = YES;
            [self setAutoScroll:self.autoScroll];
        });
       
    } else {
        dispatch_main_async_safe(^{
             self.mainView.scrollEnabled = NO;
        });
        
       
    }
    
  [self setupPageControl];
    dispatch_main_async_safe(^{
        
        [self.mainView reloadData];
        if (self.modelArrs.count > 0) { //数据刷新时
            @try{
                [_mainView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:0 inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
            }@catch(id anException) {
                //do nothing, obviously it wasn't attached because an exception was thrown
            }
        }
    });
    
   
}

- (void)setTimerSwitch:(BOOL)timerSwitch
{
    _timerSwitch = timerSwitch;
    if (_timerSwitch) {
        if (!_timer) {
            [self setupTimer];
        }
    }else{
        if (_timer) {
            [_timer invalidate];
            _timer = nil;
        }
    }
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return _totalItemsCount;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    DiscoverMatchCell*cell = [collectionView dequeueReusableCellWithReuseIdentifier:tcID forIndexPath:indexPath];
    cell.delegate = self;
    long itemIndex = indexPath.item % self.modelArrs.count;
    InstantMatcth *modle = self.modelArrs[itemIndex];
    [cell configCellWithModel:modle];
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(tcScrollView:didSelectItemAtIndex:)]) {
           [self.delegate tcScrollView:self didSelectItemAtIndex:indexPath.item % self.modelArrs.count];
       }
       if (self.clickItemOperationBlock) {
           self.clickItemOperationBlock(indexPath.item % self.modelArrs.count);
       }
    /*点击效果无效
   
     */
}
#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    int itemIndex = (scrollView.contentOffset.x + self.mainView.sd_width * 0.5) / self.mainView.sd_width;
    if (!self.modelArrs.count) return; // 解决清除timer时偶尔会出现的问题
    int indexOnPageControl = itemIndex % self.modelArrs.count;
    
    if ([self.pageControl isKindOfClass:[TAPageControl class]]) {
        TAPageControl *pageControl = (TAPageControl *)_pageControl;
        pageControl.currentPage = indexOnPageControl;
    } else {
        UIPageControl *pageControl = (UIPageControl *)_pageControl;
        pageControl.currentPage = indexOnPageControl;
    }
}
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    if (self.autoScroll) {
        [_timer invalidate];
        _timer = nil;
    }
}
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (self.autoScroll) {
        [self setupTimer];
    }
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    int itemIndex = (scrollView.contentOffset.x + self.mainView.sd_width * 0.5) / self.mainView.sd_width;
    if (!self.modelArrs.count) return; // 解决清除timer时偶尔会出现的问题
    int indexOnPageControl = itemIndex % self.modelArrs.count;
    
    if ([self.delegate respondsToSelector:@selector(tcScrollView:didScrollToIndex:)]) {
        [self.delegate tcScrollView:self didScrollToIndex:indexOnPageControl];
    }
}






/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
