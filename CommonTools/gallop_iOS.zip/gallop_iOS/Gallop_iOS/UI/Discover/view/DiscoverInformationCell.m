//
//  DiscoverInformationCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "DiscoverInformationCell.h"
#import "NewModel.h"
@interface DiscoverInformationCell()
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *authLabel;
@property (nonatomic,strong) UIView	*seperatorLine;
@end

@implementation DiscoverInformationCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(10);
		make.left.equalTo(self.contentView);
		make.size.mas_equalTo(CGSizeMake(110, 77));
	}];
	[self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(10);
		make.left.equalTo(self.headImageView.mas_right).offset(10);
		make.right.equalTo(self.contentView).offset(-5.5);
		make.height.mas_equalTo(63);
	}];
	[self.authLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.contentView).offset(-9.5);
		make.right.equalTo(self.contentView).offset(-8.5);
	}];
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.contentView).offset(-9.5);
		make.right.equalTo(self.authLabel.mas_left).offset(-10);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.bottom.equalTo(self.contentView);
		make.height.mas_equalTo(2);
	}];
}

- (void)configCellWithModel:(NewModel*)model {
   
        dispatch_main_async_safe(^{
             if (model) {
            [self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.picture] placeholderImage:[UIImage imageNamed:@"discover_news_placeholder"]];
            self.contentLabel.text = model.title;
            [self.contentLabel setLabelSpace:6 withFont:fcBoldFont(15)];
            self.timeLabel.text = [CMMUtility timeConvertWithTimeStamp:model.createTime andTimeFormat:@"MM-dd HH:mm"];
            self.authLabel.text = model.publisher;
                  }
        });
   
    
}

#pragma mark - lazy init
- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [[UIImageView alloc] init];
		_headImageView.contentMode = UIViewContentModeScaleAspectFill;
		_headImageView.clipsToBounds = YES;
		[self.contentView addSubview:_headImageView];
	}
	return _headImageView;
}

- (UILabel *)contentLabel {
	if (!_contentLabel) {
		_contentLabel = [UILabel new];
		_contentLabel.textColor = ColorTitle;
		_contentLabel.font = fcBoldFont(15);
		_contentLabel.numberOfLines = 0;
		[self.contentView addSubview:_contentLabel];
	}
	return _contentLabel;
}

- (UILabel *)timeLabel {
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.font = fcFont(11);
		_timeLabel.textColor = RGBCOLOR(168, 168, 168);
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}

- (UILabel *)authLabel {
	if (!_authLabel) {
		_authLabel = [UILabel new];
		_authLabel.textColor = ColorAppBlack;
		_authLabel.font = fcFont(11);
		[self.contentView addSubview:_authLabel];
	}
	return _authLabel;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentView addSubview:_seperatorLine];
	}
	return _seperatorLine;
}
@end
