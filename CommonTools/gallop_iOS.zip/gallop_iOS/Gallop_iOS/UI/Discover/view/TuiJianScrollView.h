//
//  TuiJianScrollView.h
//  ESTicket
//
//  Created by Homosum on 2018/5/7.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//



#import <UIKit/UIKit.h>

#import "MatchInstantListModel.h"



typedef enum {
    SD1CycleScrollViewPageContolAlimentRight,
    SD1CycleScrollViewPageContolAlimentCenter
} SD1CycleScrollViewPageContolAliment;

typedef enum {
    SD1CycleScrollViewPageContolStyleClassic,        // 系统自带经典样式
    SD1CycleScrollViewPageContolStyleAnimated,       // 动画效果pagecontrol
    SD1CycleScrollViewPageContolStyleNone            // 不显示pagecontrol
} SD1CycleScrollViewPageContolStyle;


@class TuiJianScrollView;
@protocol TuiJianScrollViewDelegate <NSObject>

@optional

-(void)tcScrollView:(TuiJianScrollView*)tcScrollView didSelectItemAtIndex:(NSInteger)index;

-(void)tcScrollView:(TuiJianScrollView*)tcScrollView didScrollToIndex:(NSInteger)index;


@end
@interface TuiJianScrollView : UIView
@property (nonatomic, copy) NSArray *modelArrs;

/** timer开关 YES为开  NO为关 */
@property (nonatomic, assign) BOOL timerSwitch;

/** 自动滚动间隔时间,默认2s */
@property (nonatomic, assign) CGFloat autoScrollTimeInterval;

/** 是否无限循环,默认Yes */
@property(nonatomic,assign) BOOL infiniteLoop;

/** 是否自动滚动,默认Yes */
@property(nonatomic,assign) BOOL autoScroll;

@property (nonatomic, weak) id<TuiJianScrollViewDelegate> delegate;

/** block监听点击方式 */
@property (nonatomic, copy) void (^clickItemOperationBlock)(NSInteger currentIndex);

/** 是否显示分页控件 */
@property (nonatomic, assign) BOOL showPageControl;

/** 是否在只有一张图时隐藏pagecontrol，默认为YES */
@property(nonatomic) BOOL hidesForSinglePage;

/** pagecontrol 样式，默认为动画样式 */
@property (nonatomic, assign) SD1CycleScrollViewPageContolStyle pageControlStyle;

/** 分页控件位置 */
@property (nonatomic, assign) SD1CycleScrollViewPageContolAliment pageControlAliment;

/** 分页控件小圆标大小 */
@property (nonatomic, assign) CGSize pageControlDotSize;

/** 当前分页控件小圆标颜色 */
@property (nonatomic, strong) UIColor *currentPageDotColor;

/** 其他分页控件小圆标颜色 */
@property (nonatomic, strong) UIColor *pageDotColor;

/** 当前分页控件小圆标图片 */
@property (nonatomic, strong) UIImage *currentPageDotImage;

/** 其他分页控件小圆标图片 */
@property (nonatomic, strong) UIImage *pageDotImage;

/** 轮播文字label字体大小 */
@property (nonatomic, strong) UIFont  *titleLabelTextFont;

/** 轮播文字label字体颜色 */
@property (nonatomic, strong) UIColor *titleLabelTextColor;

/** 轮播文字label背景颜色 */
@property (nonatomic, strong) UIColor *titleLabelBackgroundColor;

/** 轮播文字label高度 */
@property (nonatomic, assign) CGFloat titleLabelHeight;

+ (instancetype)tcScrollViewWithFrame:(CGRect)frame modelArrs:(NSArray *)modelArrs;

@end
