//
//  PaperBottomView.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/5.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PaperBottomViewDelegate<NSObject>
- (void)commentClick;
- (void)tabShareClick:(UIButton *)btn;
@optional
- (void)tabReplyClick:(UIButton *)btn;
- (void)tabLikeClick:(UIButton *)btn;
- (void)tabCollectClick:(UIButton *)btn;
@end

@interface PaperBottomView : UIView
@property (nonatomic,weak) id<PaperBottomViewDelegate> viewDelegate;
- (void)configViewWithModel:(id)model isComunity:(BOOL)isComunity;
@end
