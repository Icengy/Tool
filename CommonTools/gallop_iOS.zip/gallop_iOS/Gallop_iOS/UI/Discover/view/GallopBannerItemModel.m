//
//  GallopBannerModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "GallopBannerItemModel.h"

@implementation GallopBannerItemModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName{
	return @{@"contentId" : @"id",
             @"type" : @"linkType"
    };
}
@end

@implementation GallopBannerModel

+ (NSDictionary *)mj_objectClassInArray{
	return @{@"data" : @"GallopBannerItemModel"};
}

@end
