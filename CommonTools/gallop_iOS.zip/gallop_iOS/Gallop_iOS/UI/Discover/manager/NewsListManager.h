//
//  NewsListManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class NewsListManager;
@protocol NewsListManagerDelegate <NSObject>

- (void)newsListManager:(NewsListManager*)newsListManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload;

@end

@interface NewsListManager : NSObject
@property (nonatomic, weak) id<NewsListManagerDelegate> delegate;
@property (atomic, strong, readonly) NSMutableArray *dataSource;
-(void)loadData;
-(void)refreshData;
@end

NS_ASSUME_NONNULL_END
