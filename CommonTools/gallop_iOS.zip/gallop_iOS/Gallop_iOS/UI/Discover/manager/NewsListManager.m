//
//  NewsListManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/11/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "NewsListManager.h"
#import "NewModel.h"
@interface NewsListManager()
{
    int pageNum;
    int pageSize;
}
@end
@implementation NewsListManager
- (id)init{
    if (self = [super init]){
        pageNum = 0;
        pageSize = 20;
        _dataSource = [[NSMutableArray alloc] init];
    }
    return self;
}
-(void)refreshData
{
    pageNum = 0;
    [self loadData];
}
-(void)loadData{
    pageNum++;

    [ESNetworkService newsListPage:pageNum PageSize:pageSize Withresponse:^(id dict, ESError *error) {
        NSArray*array = nil;
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id da = dict[@"data"];
            id data = da[@"newsList"];
            if ([data isKindOfClass:[NSString class]]) {
                array = [data objectFromJSONString];
            }
            if ([data isKindOfClass:[NSArray class]]) {
                array = data;
            }
            if (array.count == 0&&self->pageNum != 1) {
                [CMMUtility showToastWithText:@"没有更多数据"];
            }else {
                if (self->pageNum == 1) {
                            [self.dataSource removeAllObjects];
                    }
                for (NSDictionary *dic in array) {
                    NewModel*model = [NewModel mj_objectWithKeyValues:dic];
                    [self.dataSource addObject:model];
                }
            }
            
        }
        if (self.delegate&&[self.delegate respondsToSelector:@selector(newsListManager:didEndLoadDataIsRefresh:shouldReload:)]) {
            [self.delegate newsListManager:self didEndLoadDataIsRefresh:(array.count == 0) shouldReload:(error)];
        }
    }];
}
@end
