//
//  DiscoverViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/11/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface DiscoverViewController : ESViewController

@end

NS_ASSUME_NONNULL_END
