//
//  ExpertBallCategoryViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertBallCategoryViewController.h"
#import "TYTabButtonPagerController.h"
#import "ExpertBallListViewController.h"

@interface ExpertBallCategoryViewController () <TYPagerControllerDataSource>

@property (nonatomic, strong) TYTabButtonPagerController *contentView;

@property (nonatomic, strong) NSMutableArray *contentChildArray;
@property (nonatomic, strong) NSMutableArray *contentTitleArray;

@end

@implementation ExpertBallCategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.contentTitleArray = [self getContentTitleArray];
    self.contentChildArray = [self getContentChildArray];
    
    [self addChildViewController:self.contentView];
    [self.view addSubview:self.contentView.view];
    [self.contentView.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.bottom.width.centerX.equalTo(self.view);
    }];
}

#pragma mark - TYPagerControllerDataSource
- (NSInteger)numberOfControllersInPagerController {
    return _contentChildArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return _contentTitleArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return _contentChildArray[index];
}

#pragma mark -
- (NSMutableArray *)getContentChildArray {
    NSInteger count = self.contentTitleArray.count;
    NSMutableArray *childs = [[NSMutableArray alloc] initWithCapacity:count];
    for (NSInteger i = 0; i < count; i ++) {
        ExpertBallListViewController *ballList = [[ExpertBallListViewController alloc] init];
        ballList.style = i;
        ballList.field = self.field;
        ballList.hideBarSetting = YES;
        [childs addObject:ballList];
    }
    return childs;
}

- (NSMutableArray *)getContentTitleArray {
    return @[@"7日返奖",
             @"连红",
             @"命中"].mutableCopy;
}

#pragma mark - lazy init
- (TYTabButtonPagerController *)contentView {
    if (!_contentView) {
        _contentView = [[TYTabButtonPagerController alloc] init];
        _contentView.dataSource = self;
        _contentView.barStyle = TYPagerBarStyleProgressView;
        _contentView.contentTopEdging = kNavBarHeight;
        _contentView.collectionLayoutEdging = 15.0;
        _contentView.cellWidth = (kScreen_Width - 15.0*(self.contentChildArray.count + 1))/self.contentChildArray.count;
        _contentView.cellSpacing = 15.0;
        _contentView.progressHeight = 3.0;
        _contentView.progressWidth = _contentView.cellWidth/2;
        _contentView.normalTextFont = [UIFont addPingFangSCRegular:16];
        _contentView.selectedTextFont = [UIFont addPingFangSCBold:16];
        _contentView.progressColor = ColorMainAppRed;
        _contentView.normalTextColor = ColorMainNormalBlack;
        _contentView.selectedTextColor = ColorMainAppRed;
        
    } return _contentView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
