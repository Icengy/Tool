//
//  ExpertFollowPlanListViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/21.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertFollowPlanListViewController.h"

#import "CYPlanDetailViewController.h"

#import "ExpertPlansListTableViewCell.h"
#import "PlanModel.h"

#import "ExpertDetailViewController.h"

@interface ExpertFollowPlanListViewController () <ExpertPlansListTableCellDelegate>

@property (nonatomic ,assign) NSInteger currentPage;
/// 0 访问正常
@property (nonatomic ,assign) NSInteger errorCode;

@end

@implementation ExpertFollowPlanListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.currentPage = 1;
    self.errorCode = 0;
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
    }];
    
    self.tableView.backgroundColor = ColorDefaultGrayBackground;
    self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    self.tableView.sectionFooterHeight = CGFLOAT_MIN;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = RGBCOLORV(0xEDEDED);
    
    self.tableView.placeHolderText = @"你还没有登录，点击进行登录";
    self.tableView.clickToPlaceHolderViewBlock = ^{
        if (self.errorCode == NeedLoginCode) {
            [App_Utility clearCurrentUser];
            dispatch_async(dispatch_get_main_queue(), ^{
                [App_Utility showLoginViewController];
            });
        }
    };
    
    [self.tableView registerNibCell:[ExpertPlansListTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (!self.dataSource.count) {
        [self loadData:nil];
    }
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ExpertPlansListTableViewCell *cell = [tableView dequeueReusableCell:[ExpertPlansListTableViewCell class]];
    
    cell.delegate = self;
    cell.cellType = 1;
    cell.model = [self.dataSource objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    PlanModel *model  = [self.dataSource objectAtIndex:indexPath.row];
    CYPlanDetailViewController *detailVC = [CYPlanDetailViewController new];
    detailVC.back = YES;
    detailVC.planId = [model.planId integerValue];
    detailVC.sourcePage = @"关注的专家方案列表";
//    detailVC.hidesBottomBarWhenPushed = YES;
//    detailVC.isBasket = (model.field.integerValue == 2);
    [self.navigationController pushViewController:detailVC animated:YES];
}

#pragma mark -
- (void)listCell:(ExpertPlansListTableViewCell *)listCell didClickToAvatar:(id _Nullable)sender {
    
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    ExpertDetailViewController *detailVC = [[ExpertDetailViewController alloc] init];
    detailVC.expertId = [NSString stringWithFormat:@"%@",listCell.model.userId];
    detailVC.sourcePage = @"关注的专家方案列表";
    [self.navigationController pushViewController:detailVC animated:YES];
}

#pragma mark -
- (void)setErrorCode:(NSInteger)errorCode {
    _errorCode = errorCode;
    if (_errorCode == NeedLoginCode) {
        self.tableView.placeHolderText = @"你还没有登录，点击进行登录";
    }else {
        self.tableView.placeHolderText = @"暂无内容";
    }
}

#pragma mark - load data
- (void)reloadData {
    [self loadData:nil];
}

-(void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
    @weakify(self)
    [ESNetworkService plansSubscribedListWithPage:self.currentPage pageSize:20 response:^(id dict, NSInteger code, ESError *error) {
        @strongify(self)
        [self endAllFreshing:self.tableView];
        
        self.errorCode = code;
        if (self.errorCode == NeedLoginCode) {
            if (self.dataSource.count) {
                [self.dataSource removeAllObjects];
            }
            self.tableView.placeHolderText = @"你还没有登录，点击进行登录";
            self.tableView.mj_footer.hidden = YES;
            [self.tableView reloadData];
            
            return;
        }
        if (dict && self.errorCode == 0) {
            if (!(sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]])) {
                if (self.dataSource.count) [self.dataSource removeAllObjects];
            }
            NSDictionary *data = [dict objectForKey:@"data"];
            NSArray *datas = [data objectForKey:@"data"];
            if (datas && datas.count) {
                [self.dataSource addObjectsFromArray:[PlanModel mj_objectArrayWithKeyValuesArray:datas]];
            }
//            dispatch_main_async_safe(^{
            [self.tableView updataFreshFooter:(self.dataSource.count && datas.count != 20)];
//            });
        }
        self.tableView.mj_footer.hidden = !self.dataSource.count;
        self.tableView.placeHolderText = @"暂无内容";
        [self.tableView reloadData];
    }];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
