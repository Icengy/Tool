//
//  ExpertBallCategoryViewController.h
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ExpertBallCategoryViewController : ESViewController

/// =1：足球 =2:篮球
@property (nonatomic ,assign) NSInteger field;

@end

NS_ASSUME_NONNULL_END
