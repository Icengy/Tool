//
//  ExpertBallListViewController.h
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

#import "ExpertBallListTableViewCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface ExpertBallListViewController : ESViewController

/// =1：足球 =2:篮球
@property (nonatomic ,assign) NSInteger field;
/// 列表类型(7日返奖、连红、命中)
@property (nonatomic ,assign) ExpertBallListStyle style;

@end

NS_ASSUME_NONNULL_END
