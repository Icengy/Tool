//
//  ExpertBallListViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertBallListViewController.h"
#import "ExpertDetailViewController.h"

#import "ExpertBallListFooterView.h"

#import "GallopExpertModel.h"

#import "BoardManager.h"

@interface ExpertBallListViewController ()

@property (nonatomic, assign) NSInteger currentPage;

@end

@implementation ExpertBallListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
    }];
    
    self.tableView.backgroundColor = ColorDefaultGrayBackground;
    self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.separatorColor = RGBCOLORV(0xEDEDED);
    
    [self.tableView registerNibCell:[ExpertBallListTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (!self.dataSource.count) {
        [self loadData:nil];
    }
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
//    return self.dataSource.count;
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ExpertBallListTableViewCell *cell = [tableView dequeueReusableCell:[ExpertBallListTableViewCell class]];
    cell.style = self.style;
    cell.index = indexPath.section;
    cell.model = [self.dataSource objectAtIndex:indexPath.section];
    @weakify(self)
    cell.clickToFollowBlock = ^(GallopExpertModel * _Nonnull model, NSInteger state, NSArray<UIButton *> * _Nonnull btns) {
        @strongify(self)
        [self clickToFollowWithModel:model withState:state withBtns:btns];
    };
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    GallopExpertModel *model = [self.dataSource objectAtIndex:section];
    if (model.forSalePlanCount) {
        return 30.0;
    }
    return CGFLOAT_MIN;
}


- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    GallopExpertModel *model = [self.dataSource objectAtIndex:section];
    if (!model.forSalePlanCount) return [UIView new];
    
    ExpertBallListFooterView *footerView = [ExpertBallListFooterView shareInstance];
    footerView.frame = CGRectMake(0, 0, tableView.width, 30.0);
    
    footerView.model = model;
    
    @weakify(self)
    footerView.clickToDetailBlock = ^(GallopExpertModel * _Nonnull model) {
        @strongify(self)
        [self clickToExpertDetail:model];
    };
    
    return footerView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    GallopExpertModel *model = [self.dataSource objectAtIndex:indexPath.section];
    [self clickToExpertDetail:model];
}

#pragma mark -
- (void)clickToExpertDetail:(GallopExpertModel *)model {
    ///  13 * self.field + self.style (13、14、15、26、27、28)
    [MobClick event:[NSString stringWithFormat:@"expert%@",@(13 * self.field + self.style)]];
    
    ExpertDetailViewController *detailVC = [[ExpertDetailViewController alloc] init];
    detailVC.expertId = [NSString stringWithFormat:@"%@",@(model.expertId)];
    detailVC.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detailVC animated:YES];
}

- (void)clickToFollowWithModel:(GallopExpertModel *)model withState:(NSInteger)state withBtns:(NSArray <UIButton *>*)btns {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    if (model.expertId) {
        if (state) {
            /// 取关
            [ESNetworkService unfollowExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = NO;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }else{
            /// 关注
            [ESNetworkService followExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = YES;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }
    }
}

#pragma mark - load data
-(void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
    @weakify(self)
    [ESNetworkService expertBoardWithPage:self.currentPage PageSize:20 Rank:[NSString stringWithFormat:@"%@",@(self.style + 1)] Field:self.field Response:^(id dict, ESError *error) {
        @strongify(self)
        [self endAllFreshing:self.tableView];
        
        if (dict && [[dict objectForKey:@"code"] integerValue] == 0) {
            
            if (!(sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]])) {
                if (self.dataSource.count) [self.dataSource removeAllObjects];
            }
            NSDictionary *data = [dict objectForKey:@"data"];
            NSArray *datas = [data objectForKey:@"expertList"];
            if (datas && datas.count) {
                [self.dataSource addObjectsFromArray:[GallopExpertModel mj_objectArrayWithKeyValuesArray:datas]];
            }
            dispatch_main_async_safe(^{
                [self.tableView updataFreshFooter:(self.dataSource.count && datas.count < 20)];
                self.tableView.mj_footer.hidden = !self.dataSource.count;
                [self.tableView reloadData];
            });
        }
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
