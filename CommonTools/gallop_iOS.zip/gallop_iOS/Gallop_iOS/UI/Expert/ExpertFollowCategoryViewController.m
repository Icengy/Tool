//
//  ExpertFollowListViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertFollowCategoryViewController.h"

#import "TYTabButtonPagerController.h"
#import "ExpertFollowListViewController.h"
#import "ExpertFollowPlanListViewController.h"

@interface ExpertFollowCategoryViewController () <TYPagerControllerDataSource>

@property (nonatomic, strong) TYTabButtonPagerController *contentView;

@property (nonatomic, strong) NSMutableArray *contentChildArray;
@property (nonatomic, strong) NSMutableArray *contentTitleArray;

@end

@implementation ExpertFollowCategoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.contentTitleArray = [self getContentTitleArray];
    self.contentChildArray = [self getContentChildArray];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogin:) name:kESDidLoginNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogout:) name:kESDidLogoutNotification object:nil];
    
    [self addChildViewController:self.contentView];
    [self.view addSubview:self.contentView.view];
    [self.contentView.view mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.view.mas_top).offset(NavBarHeight);
        make.top.bottom.width.centerX.equalTo(self.view);
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.fd_prefersNavigationBarHidden = YES;
}

- (void)appDidLogin:(NSNotification *)notification {
    [self.contentChildArray enumerateObjectsUsingBlock:^(ESViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj reloadData];
    }];
}

- (void)appDidLogout:(NSNotification *)notification {
    [self.contentChildArray enumerateObjectsUsingBlock:^(ESViewController *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj reloadData];
    }];
}

#pragma mark - TYPagerControllerDataSource
- (NSInteger)numberOfControllersInPagerController {
    return _contentChildArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return _contentTitleArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return _contentChildArray[index];
}

#pragma mark -
- (NSMutableArray *)getContentChildArray {
    ExpertFollowListViewController *followlist = [[ExpertFollowListViewController alloc] init];
    followlist.hideBarSetting = YES;
    
    ExpertFollowPlanListViewController *planlist = [[ExpertFollowPlanListViewController alloc] init];
    planlist.hideBarSetting = YES;
    
    return @[followlist,planlist].mutableCopy;
}

- (NSMutableArray *)getContentTitleArray {
    return @[@"关注的专家", @"关注的专家方案"].mutableCopy;
}

#pragma mark - lazy init
- (TYTabButtonPagerController *)contentView {
    if (!_contentView) {
        _contentView = [[TYTabButtonPagerController alloc] init];
        _contentView.dataSource = self;
        _contentView.barStyle = TYPagerBarStyleProgressView;
        _contentView.contentTopEdging = kNavBarHeight;
        _contentView.collectionLayoutEdging = 15.0;
        _contentView.cellWidth = (kScreen_Width - 15.0*(self.contentChildArray.count + 1))/self.contentChildArray.count;
        _contentView.cellSpacing = 15.0;
        _contentView.progressHeight = 3.0;
        _contentView.progressWidth = _contentView.cellWidth/2;
        _contentView.normalTextFont = [UIFont addPingFangSCRegular:16];
        _contentView.selectedTextFont = [UIFont addPingFangSCBold:16];
        _contentView.progressColor = ColorMainAppRed;
        _contentView.normalTextColor = ColorMainNormalBlack;
        _contentView.selectedTextColor = ColorMainAppRed;
        
    } return _contentView;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
