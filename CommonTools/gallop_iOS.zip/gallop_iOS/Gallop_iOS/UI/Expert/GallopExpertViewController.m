//
//  ExpertViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "GallopExpertViewController.h"

#import "TYTabButtonPagerController.h"

#import "ExpertFollowCategoryViewController.h"
#import "ExpertBallCategoryViewController.h"

#import "SearchViewController.h"

static const NSInteger ExpertSwitchDefaultTag = 300000;

@interface GallopExpertViewController () <TYTabPagerControllerDelegate, TYPagerControllerDataSource> {
    NSInteger _currentIndex;
}

@property (nonatomic, strong) UIView *switchView;
@property (nonatomic, strong) CYButton *searchBtn;

@property (nonatomic, strong) TYTabButtonPagerController *contentView;

@property (nonatomic, strong) NSMutableArray *contentChildArray;
@property (nonatomic, strong) NSMutableArray *contentTitleArray;

@property (nonatomic, copy) NSArray *switchChildArray;

@end

@implementation GallopExpertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _currentIndex = 0;
    self.contentTitleArray = [self getContentTitleArray];
    self.contentChildArray = [self getContentChildArray];
    
    [self setupViews];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleRedContent;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

#pragma mark - 子视图初始化
- (void)setupViews {
    
    self.navigationItem.titleView = self.switchView;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.searchBtn];
    
    [self addChildViewController:self.contentView];
    [self.view addSubview:self.contentView.view];
    [self.contentView.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).offset(NavBarHeight);
        make.bottom.width.centerX.equalTo(self.view);
    }];
    
}

#pragma mark - click
- (void)swithBtnClick:(UIButton *)sender {
    NSInteger tag = sender.tag - ExpertSwitchDefaultTag - 1;
    if (tag == _currentIndex) return;
    _currentIndex = tag;
    [self.contentView moveToControllerAtIndex:_currentIndex animated:YES];
    [self changeSwithState];
}

- (void)searchBtnClick:(id)sender {
    [MobClick event:@"expert6"];
    [ESNetworkService customPostionCode:@"002003"];
    
    SearchViewController*vc = [SearchViewController new];
//    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)changeSwithState {
    if (_currentIndex < 0 || _currentIndex >= self.switchChildArray.count) return;
    
    [self.switchChildArray enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj setSelected:(idx == _currentIndex)?YES:NO];
    }];
}

#pragma mark - TYPagerControllerDataSource
- (NSInteger)numberOfControllersInPagerController {
    return _contentChildArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return _contentTitleArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return _contentChildArray[index];
}

- (void)pagerController:(TYTabPagerController *)pagerController didScrollToTabPageIndex:(NSInteger)index {
    NSLog(@"didScrollToTabPageIndex - %@",@(index));
    _currentIndex = index;
    [self changeSwithState];
}

#pragma mark -
- (NSMutableArray *)getContentChildArray {
    NSMutableArray *childArray = [NSMutableArray arrayWithCapacity:self.contentTitleArray.count];
    
    /// 专家-关注
    ExpertFollowCategoryViewController *followList = [[ExpertFollowCategoryViewController alloc] init];
    followList.hideBarSetting = YES;
    [childArray addObject:followList];
    
    /// 专家-足球
    ExpertBallCategoryViewController *footballList = [[ExpertBallCategoryViewController alloc] init];
    footballList.field = 1;
    footballList.hideBarSetting = YES;
    [childArray addObject:footballList];
    
    /// 专家-篮球
    ExpertBallCategoryViewController *basketballList = [[ExpertBallCategoryViewController alloc] init];
    basketballList.field = 2;
    basketballList.hideBarSetting = YES;
    [childArray addObject:basketballList];
    
    return childArray;
}

- (NSMutableArray *)getContentTitleArray {
    return @[@"关注", @"足球", @"篮球"].mutableCopy;
}


- (void)setDefaultIndex:(NSInteger)defaultIndex {
    _defaultIndex = defaultIndex;
    if (self.contentView && _defaultIndex < [self getContentTitleArray].count) {
        [self.contentView moveToControllerAtIndex:_defaultIndex animated:YES];
    }
}

#pragma mark - lazy init
- (UIView *)switchView {
    if (!_switchView) {
        CGFloat tagWidth = 70.0, margin = 10.0, tagHeight = 30.0;
        
        _switchView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, (tagWidth *self.contentTitleArray.count + margin *(self.contentTitleArray.count - 1)), tagHeight)];
        NSMutableArray *childArray = @[].mutableCopy;
        
        for (int i = 0; i < self.contentTitleArray.count; i ++) {
            UIButton *tagBtn = [UIButton buttonWithType:UIButtonTypeCustom];
            tagBtn.frame = CGRectMake(i * (tagWidth + margin), 0.0, tagWidth, tagHeight);
            [_switchView addSubview:tagBtn];
            [tagBtn setTitle:self.contentTitleArray[i] forState:UIControlStateNormal];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:ColorMainAppDarkRed] forState:UIControlStateSelected];
            tagBtn.titleLabel.font = [UIFont addPingFangSCMedium:16];;
            tagBtn.tag = ExpertSwitchDefaultTag + 1 + i;
            tagBtn.layer.cornerRadius = tagBtn.height / 2;
            tagBtn.clipsToBounds = YES;
            
            tagBtn.selected = (i == _currentIndex) ? YES:NO;
            
            [tagBtn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            
            [childArray addObject:tagBtn];
        }
        self.switchChildArray = childArray.copy;
    }
    return _switchView;
}

- (CYButton *)searchBtn {
    if (!_searchBtn) {
        
        _searchBtn = [CYButton buttonWithType:UIButtonTypeCustom];
        _searchBtn.frame = CGRectMake(0, 0, 44.0, 44.0);
        
        [_searchBtn setImage:[[UIImage imageNamed:@"search_white"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _searchBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [_searchBtn addTarget:self action:@selector(searchBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    } return _searchBtn;
}

- (TYTabButtonPagerController *)contentView {
    if (!_contentView) {
        _contentView = [[TYTabButtonPagerController alloc] init];
        _contentView.delegate = self;
        _contentView.dataSource = self;
        _contentView.contentTopEdging = 0.0;
        
        _contentView.defaultIndex = self.defaultIndex;
        
    } return _contentView;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
