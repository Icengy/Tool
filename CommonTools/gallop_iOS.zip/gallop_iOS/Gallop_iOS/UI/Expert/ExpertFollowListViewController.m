//
//  ExpertFollowListViewController.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertFollowListViewController.h"
#import "ExpertDetailViewController.h"

#import "ExpertFollowListTableViewCell.h"
#import "ExpertFollowEmptyTableViewCell.h"
#import "CYCommonListHeaderView.h"

#import "GallopExpertModel.h"

@interface ExpertFollowListViewController () <ExpertFollowListTableCellDelegate> {
    /// 0 访问正常
    NSInteger _errorCode;
}

@property (nonatomic ,strong) CYCommonListHeaderView *headerView;

/// 推荐专家数据
@property (nonatomic ,strong) NSMutableArray *dataArray;

@property (nonatomic ,assign) NSUInteger currentPage;

@end

@implementation ExpertFollowListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.dataArray = [NSMutableArray new];
    self.currentPage = 1;
    _errorCode = 0;
    
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
    }];
    
    self.tableView.backgroundColor = ColorDefaultGrayBackground;
    self.tableView.sectionFooterHeight = CGFLOAT_MIN;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = ColorDefaultGrayBackground;
    
    [self.tableView registerNibCell:[ExpertFollowListTableViewCell class]];
    [self.tableView registerNibCell:[ExpertFollowEmptyTableViewCell class]];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    if (!self.dataSource.count) {
        [self loadData:nil];
    }
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (!self.dataSource.count && !self.dataArray.count) {
        return 0;
    }
    NSInteger count = 1;
    if (!self.dataSource.count) count += 1;
    return count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {/// 关注专家列表(为空有占位图)
        return (self.dataSource.count != 0)? self.dataSource.count:1;
    }else if (section == 1) {
    /// 关注的专家方案
        return self.dataArray.count;
    }else
        return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!self.dataSource.count && indexPath.section == 0) {
        ExpertFollowEmptyTableViewCell *cell = [tableView dequeueReusableCell:[ExpertFollowEmptyTableViewCell class]];
        cell.errorCode = _errorCode;
        
        return cell;
    }
    ExpertFollowListTableViewCell *cell = [tableView dequeueReusableCell:[ExpertFollowListTableViewCell class]];
    cell.delegate = self;
    cell.expertFollowCellStyle = indexPath.section;
    
    if (indexPath.section) {
        cell.model = (GallopExpertModel *)[self.dataArray objectAtIndex:indexPath.row];
    }else {
        cell.model = (GallopExpertModel *)[self.dataSource objectAtIndex:indexPath.row];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if ([[tableView cellForRowAtIndexPath:indexPath] isKindOfClass:[ExpertFollowEmptyTableViewCell class]]) {
        if (_errorCode == 0) {
            return;
        }
        if (_errorCode == NeedLoginCode) {
            // 跳转登陆
            [App_Utility showLoginViewController];
            return;
        }
    }
    /// 关注的专家：expert11 推荐专家：expert12
    [MobClick event:[NSString stringWithFormat:@"expert%@",indexPath.section?@(12):@(11)]];
    
    ExpertFollowListTableViewCell *cell = (ExpertFollowListTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    ExpertDetailViewController *detailVC = [[ExpertDetailViewController alloc] init];
    detailVC.expertId = [NSString stringWithFormat:@"%@",@(cell.model.expertId)];
    [self.navigationController pushViewController:detailVC animated:YES];
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return (section && self.dataArray.count) ? 40.0:0.0;
}

- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section && self.dataArray.count) {
        self.headerView.frame = CGRectMake(0, 0, tableView.width, 40.0);
        return self.headerView;
    }
    return [UIView new];
}

#pragma mark - ExpertFollowListTableCellDelegate
- (void)listCell:(ExpertFollowListTableViewCell *)cell didClickToWarning:(GallopExpertModel *)model withState:(NSInteger)state withBtns:(NSArray<UIButton *> *)btns {

    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    [ESNetworkService ocWithExpertId:model.expertId andOpenClose:!model.pushOpened Response:^(id dict, ESError *error) {
        if (dict && [dict[@"code"] integerValue] == 0) {
            model.pushOpened = !model.pushOpened;
            dispatch_main_async_safe(^{
                [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    obj.hidden = !obj.hidden;
                }];
            });
        }
    }];
}

- (void)listCell:(ExpertFollowListTableViewCell *)cell didClickToFollow:(GallopExpertModel *)model withState:(NSInteger)state withBtns:(NSArray<UIButton *> *)btns {
    
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    if (model.expertId) {
        if (state) {
            /// 取关
            [ESNetworkService unfollowExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = NO;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }else{
            /// 关注
            [ESNetworkService followExpert:model.expertId  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    model.followed = YES;
                    dispatch_main_async_safe(^{
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }
    }
}

#pragma mark - lazy init
- (CYCommonListHeaderView *)headerView {
    if (!_headerView) {
        _headerView = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([CYCommonListHeaderView class]) owner:nil options:nil].lastObject;
    }return _headerView;
}

- (NSMutableArray *)dataArray {
    if (!_dataArray) {
        _dataArray = [NSMutableArray new];
    } return _dataArray;
}

#pragma mark - load data
- (void)reloadData {
    [self loadData:nil];
}

-(void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
    @weakify(self)

    [ESNetworkService expertSubscribedListWithPage:self.currentPage pageSize:20 response:^(id dict, NSInteger code, ESError *error) {
        _errorCode = code;
        if (_errorCode == NeedLoginCode) {
            [self loadRecommendData];
        }else {
            @strongify(self)
            [self endAllFreshing:self.tableView];
            
            if (dict && [[dict objectForKey:@"code"] integerValue] == 0) {
                
                if (!(sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]])) {
                    if (self.dataSource.count) [self.dataSource removeAllObjects];
                }
                NSDictionary *dic = [dict objectForKey:@"data"];
                NSArray *datas = [dic objectForKey:@"data"];
                if (datas && datas.count) {
                    [self.dataSource addObjectsFromArray:[GallopExpertModel mj_objectArrayWithKeyValuesArray:datas]];
                }
                if (_errorCode == 0 && !datas.count) {
                    [self loadRecommendData];
                }else {
                    if (self.dataArray.count) [self.dataArray removeAllObjects];
                    [self.tableView updataFreshFooter:(self.dataSource.count && datas.count != 20)];
                }
            }
            
            self.tableView.mj_footer.hidden = !self.dataSource.count;
            [self.tableView reloadData];
        }
    }];
}

- (void)loadRecommendData {
    self.tableView.mj_footer.hidden = YES;
    if (self.dataSource.count) [self.dataSource removeAllObjects];
    
    @weakify(self)
    [ESNetworkService expertRecommendListWithResponse:^(id dict, NSInteger code, ESError *error) {
        @strongify(self)
        
        [self endAllFreshing:self.tableView];
        
        if (dict && [[dict objectForKey:@"code"] integerValue] == 0) {
            NSArray *datas = [dict objectForKey:@"data"];
            if (datas && datas.count) {
                if (self.dataArray.count) [self.dataArray removeAllObjects];
                [self.dataArray addObjectsFromArray:[GallopExpertModel mj_objectArrayWithKeyValuesArray:datas]];
            }
            [self.tableView reloadData];
        }
    }];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
