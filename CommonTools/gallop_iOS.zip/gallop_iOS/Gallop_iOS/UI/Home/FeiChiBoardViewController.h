//
//  FeiChiBoardViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface FeiChiBoardViewController : ESViewController
@property (nonatomic,strong) NSString *field;
@end

NS_ASSUME_NONNULL_END
