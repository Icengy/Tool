//
//  ProfitRankViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ProfitRankViewController.h"
#import "BoardManager.h"
#import "YinLi.h"
#import "YinLiTableViewCell.h"
#import "ExpertDetailViewController.h"

@interface ProfitRankViewController ()<BoardManagerDelegate>
@property (nonatomic, strong) BoardManager *manager;
@end

@implementation ProfitRankViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self initWithSubViews];
	// Do any additional setup after loading the view.
}
-(void)BoardManager:(BoardManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
	dispatch_main_async_safe(^{
		[self.tableView.mj_header endRefreshing];
		[self.tableView.mj_footer endRefreshing];
		
		if (self.manager.dataSource.count == 0) {
		}
		
		if (!isRefresh && self.manager.dataSource.count >= 20) {
			self.tableView.mj_footer.hidden = NO;
		}else{
			self.tableView.mj_footer.hidden = YES;
		}
		
		[self.tableView reloadData];
	});
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.manager.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	YinLi*model = self.manager.dataSource[indexPath.row];
	YinLiTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:@"YinLiTableViewCell"];
	cell.selectionStyle = UITableViewCellSelectionStyleDefault;
	if (cell==nil) {
		cell= [[[NSBundle mainBundle]loadNibNamed:@"YinLiTableViewCell" owner:nil options:nil] firstObject];
		
	}
	[cell configCell:model index:indexPath.row];
	
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	YinLi*model = self.manager.dataSource[indexPath.row];
	ExpertDetailViewController*vc = [ExpertDetailViewController new];
	vc.sourcePage = @"飞驰榜-7天返奖";
    vc.expertId = [NSString stringWithFormat:@"%@",model.userId];
	[self.navigationController pushViewController:vc animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 55.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 0.01f;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 0.01f;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	return nil;
}

-(void)initWithSubViews
{
	self.navigationItem.title = @"3日返奖";
	self.tableView.frame = CGRectMake(0, 0, kScreen_Width, kScreen_Height-NavBarHeight-40);
	self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
	self.tableView.separatorColor = ColorGrayBack;
	if (@available(iOS 11.0, *)){
		self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
	}
	[self.tableView registerNib:[UINib nibWithNibName:@"YinLiTableViewCell" bundle:nil] forCellReuseIdentifier:@"YinLiTableViewCell"];
	[self.view addSubview:self.tableView];
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self loadData];
}
- (void)loadData{
	self.manager.field = self.field;
	[self.manager refreshData];
}
- (void)loadMoreData{
	[self.manager loadData];
}
- (BoardManager *)manager{
	if (!_manager) {
		_manager = [[BoardManager alloc]init];
		_manager.rank = @"minDays";
		_manager.delegate = self;
	}
	
	return _manager;
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

@end

