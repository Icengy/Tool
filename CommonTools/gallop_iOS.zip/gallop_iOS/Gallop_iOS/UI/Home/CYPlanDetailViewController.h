//
//  CYPlanDetailViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/6.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CYPlanDetailViewController : ESViewController
@property (nonatomic, assign) NSInteger planId;
@property (nonatomic,assign) BOOL back;
//@property (nonatomic,assign) BOOL isBasket;//YES-篮球 NO-足球
@property (nonatomic, strong) NSString *sourcePage; //埋点用字段
@end

NS_ASSUME_NONNULL_END
