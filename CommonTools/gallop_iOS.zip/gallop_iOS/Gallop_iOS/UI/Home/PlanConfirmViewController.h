//
//  PlanConfirmViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@class PlanModel;
NS_ASSUME_NONNULL_BEGIN

@interface PlanConfirmViewController : ESViewController

@property (nonatomic ,strong) PlanModel *model;

//@property (nonatomic,copy) NSString*pTitle;
//@property (nonatomic,copy) NSString *avatar;
//@property (nonatomic,copy) NSString *expertName;
//@property (nonatomic,copy) NSString *price;
//@property (nonatomic,copy) NSString *accountM;
//@property (nonatomic,strong) NSNumber *planId;

//-(void)refreshViews;

@end

NS_ASSUME_NONNULL_END
