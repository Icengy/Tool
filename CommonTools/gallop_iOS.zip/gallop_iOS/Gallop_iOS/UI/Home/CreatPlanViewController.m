//
//  CreatPlanViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "CreatPlanViewController.h"
#import "SelectPlanViewController.h"
#import "MatchModel.h"
#import "SelectedMatchModel.h"
#import "MatchTableViewCell.h"
#import "WTCWriterTextView.h"
#import "UNSelectTableViewCell.h"
#import "MLMOptionSelectView.h"
#import "UIView+Category.h"
#import "ConfirmMoneyView.h"
#import "ExpertDetailViewController.h"
#import "CYPlanDetailViewController.h"
#import "ImageDeliverManager.h"
#import "PhotoCollectionViewCell.h"
#import "WBPopOverView.h"
#import <IQKeyboardManager.h>
#import "MatchBasketBallTableViewCell.h"

#define itemsHigh ((kScreen_Width-2*15)*0.25 - 0.1)

@interface CreatPlanViewController ()<UITextViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource,PhotoCollectionViewCellDelegate,AppUtilityDelegate>

@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, strong) NSArray*modelArr;
@property (nonatomic, strong) NSArray*footerArr;
@property (nonatomic, strong) WTCWriterTextView *textV_Title;
@property (nonatomic, strong) WTCWriterTextView *textV_Content;
@property (nonatomic, strong) WTCWriterTextView*textV_Declaration;
@property (nonatomic, strong) UILabel *titleCountLabel;
@property (nonatomic, strong) UILabel *declarationCountLabel;
@property (nonatomic, strong) UILabel *contentCountLabel;
@property (nonatomic, strong) UIImageView *addPhtoImageView;
@property (nonatomic, strong) UIImageView *declarationImageView;
@property (nonatomic, strong) UIButton *deleteB;
@property (nonatomic, strong) UIView*footerView;
@property (nonatomic, strong) UIButton *postBtn;
@property (nonatomic, strong) MLMOptionSelectView *cellView;
@property (nonatomic, assign) NSInteger type;
@property (nonatomic, assign) NSInteger commmentState;
@property (nonatomic, strong) NSMutableArray *listArray;
@property (nonatomic, strong) NSMutableArray *commentStateArray;
@property (nonatomic, strong) NSString*money;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) NSMutableArray*contentImageNameArr;
@property (nonatomic, strong) NSMutableArray*contentImageArr;
@property (nonatomic, assign) NSInteger field;
@property (nonatomic, strong) NSString *declarationImageUrl;
@property (nonatomic, assign) BOOL selectForDeclaration;
@property (nonatomic, assign) BOOL onSaving;
@end

@implementation CreatPlanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
	self.listArray = [NSMutableArray arrayWithArray:@[@"方案类型",@"付费推荐",@"免费推荐",@"仅粉丝免费"]];
	self.commentStateArray = [NSMutableArray arrayWithArray:@[@"评论区权限",@"关闭评论",@"购买可评论",@"所有人可评论"]];
    _cellView = [[MLMOptionSelectView alloc] initOptionView];
    self.contentImageArr = [NSMutableArray arrayWithCapacity:0];
    self.contentImageNameArr = [NSMutableArray arrayWithCapacity:0];
    self.money = @"";
    self.type = 1;
    
	[self initWithSubViews];
}

- (void)back {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)initWithSubViews {
    self.navigationItem.title = @"方案编辑";
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 42, 22)];
	[view addSubview:self.postBtn];
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:view];
	
    self.tableView.frame = CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight);
    self.tableView.backgroundColor = ColorGrayBack;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
	self.footerArr = @[@"方案类型",@"价格",@"评论区权限",@"分析"];
    [self.contentImageNameArr addObject:@"添加图片"];
    [self.contentImageArr addObject:[UIImage imageNamed:@"添加图片"]];
    [self addFooterView];
    [self reloadColletionView];
    
}
-(BOOL)checkUrls{
   
    if (QM_IS_ARRAY_NIL(self.modelArr)) {
        [CMMUtility showToastWithText:@"请选择赛事及玩法"];
        return NO;
    }
    return YES;
}
-(void)saveIt:(UIButton*)button{
	if (self.onSaving) {
		return;
	}
	[self.view endEditing:YES];
	if ([self checkUrls]) {
		NSString*title = self.textV_Title.text;
		NSString*content = self.textV_Content.text;
		NSString*declaration = self.textV_Declaration.text;
		
		NSMutableArray*dicArr = [NSMutableArray arrayWithCapacity:0];
		for (MatchModel*model in self.modelArr) {
			NSMutableDictionary*dic = [NSMutableDictionary dictionaryWithCapacity:0];
			NSMutableArray*selectedItemArr = [NSMutableArray arrayWithCapacity:0];
			[dic setObject:model.matchDateNum forKey:@"matchDateNum"];
			NSArray*arr1 = [model.sfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
			
			NSArray*arr2 = [model.rqsfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
			
			[selectedItemArr addObjectsFromArray:arr1];
			[selectedItemArr addObjectsFromArray:arr2];
			if (self.field) {
				NSArray*arr3 = [model.dxfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
				[selectedItemArr addObjectsFromArray:arr3];
			}
			NSMutableArray*itmA = [NSMutableArray arrayWithCapacity:0];
			for (SelectedMatchModel*smodel in selectedItemArr) {
				NSDictionary*di = @{@"type":smodel.selectType,@"result":smodel.selectOdds};
				[itmA addObject:di];
			}
			
			if (!QM_IS_ARRAY_NIL(itmA)) {
				[dic setObject:itmA forKey:@"selects"];
				[dicArr addObject:dic];
			}
		}
		if (QM_IS_ARRAY_NIL(dicArr)) {
			[CMMUtility showToastWithText:@"请选择具体玩法"];
			return;
		}
		if (self.modelArr.count == 2&&dicArr.count!=2) {
			[CMMUtility showToastWithText:@"请选择具体玩法"];
			return;
		}
		if (dicArr.count == 1) {
			NSDictionary*dic = dicArr[0];
			NSMutableArray*itmA = dic[@"selects"];
			if (itmA.count == 2) {
				for (MatchModel*model in self.modelArr) {
					NSMutableDictionary*dic = [NSMutableDictionary dictionaryWithCapacity:0];
					NSMutableArray*selectedItemArr = [NSMutableArray arrayWithCapacity:0];
					[dic setObject:model.matchDateNum forKey:@"matchDateNum"];
					NSArray*arr1 = [model.sfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
					
					NSArray*arr2 = [model.rqsfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
					
					[selectedItemArr addObjectsFromArray:arr1];
					[selectedItemArr addObjectsFromArray:arr2];
					
					for (SelectedMatchModel*smodel in selectedItemArr) {
						if (smodel.odds.floatValue<2) {
							[CMMUtility showToastWithText:@"单关双选的选项赔率必须都＞2"];
							return;
						}
					}
				}
			}
		}
		
		int price;
		
		if (self.type < 3) {
			if (QM_IS_STR_NIL(self.money)) {
				[CMMUtility showToastWithText:@"请编辑价格"];
				return;
			}
			price = [self.money intValue];
			if (price < self.minPrice) {
				[CMMUtility showToastWithText:[NSString stringWithFormat:@"价格不可低于%@飞驰币", @(self.minPrice)]];
				return;
			}
			if (price > self.maxPrice) {
				[CMMUtility showToastWithText:[NSString stringWithFormat:@"价格不可超过%@飞驰币", @(self.maxPrice)]];
				return;
			}
		}else{
			price = 0;
		}
		
		if (title.length>50||title.length<10) {
			[CMMUtility showToastWithText:@"请保持标题字符在10-50字之间"];
			return;
		}
		if (declaration.length>100) {
			[CMMUtility showToastWithText:@"请保持专家宣言在100字以内"];
			return;
		}
		if (content.length>2000||content.length<100) {
			[CMMUtility showToastWithText:@"请保持方案内容字符在100-2000字之间"];
			return;
		}
		
		self.onSaving = YES;
		
		[self.contentImageNameArr removeAllObjects];
		[self.contentImageNameArr addObject:@"添加图片"];
		[ES_LPUnitily addHUDToSystemWindowWithString:@"提交中..."];
		NSInteger count=self.contentImageArr.count-1;
		
		if (count == 0 && !self.declarationImageView.image) {
			[ESNetworkService createPlanWithMatchInfo:[dicArr copy] price:price content:content title:title type:[NSString stringWithFormat:@"%@",@(self.type)] pic:@"" field:(self.field+1) declaration:declaration declarationPic:self.declarationImageUrl commentAreaType:self.commmentState Response:^(id dict, ESError *error) {
				if (dict&&[dict[@"code"] integerValue] == 0) {
					dispatch_main_async_safe(^{
						[CMMUtility showToastWithText:@"创建方案成功"];
						//98765
						NSDictionary*data = dict[@"data"];
						NSString*planId = [data[@"planId"] stringValue];
						
                        CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
						vc.planId = planId.integerValue;
						vc.sourcePage = self.title;
						NSMutableArray*mArr = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
						[mArr removeLastObject];
						[mArr removeLastObject];
						[mArr addObject:vc];
						vc.hidesBottomBarWhenPushed = YES;
						[self.navigationController setViewControllers:mArr.copy animated:YES];
					});
					
				}
				self.onSaving = NO;
			}];
			[ES_LPUnitily removeHUDToSystemWindow];
			
		}else{
			dispatch_group_t gcdGroup = dispatch_group_create();

			if (self.declarationImageView.image) {
				dispatch_group_enter(gcdGroup);
				UIImage*image = self.declarationImageView.image;
				NSString*keyName = [NSString stringWithFormat:@"%ld_%ld_%d.jpg",App_Utility.currentUser.userId.integerValue,[LPUnitily getTimeSp],rand()];
				[[ImageDeliverManager sharedInstance] deliverImageWithKeyName:[NSString stringWithFormat:@"plan/declaration/%@",keyName] fileData:UIImageJPEGRepresentation(image, 0.5) mimeType:@"" imgType:5 result:^(NSString * _Nonnull url, ESError * _Nonnull error) {
					self.declarationImageUrl = url;
					dispatch_group_leave(gcdGroup);
				}];
			}
			for (NSUInteger i = 0; i < count; i++) {
				dispatch_group_enter(gcdGroup);
				UIImage*image = self.contentImageArr[i+1];
				NSString*keyName = [NSString stringWithFormat:@"%ld_%ld_%d.jpg",App_Utility.currentUser.userId.integerValue,[LPUnitily getTimeSp],rand()];
				[[ImageDeliverManager sharedInstance] deliverImageWithKeyName:[NSString stringWithFormat:@"plan/image/%@",keyName] fileData:UIImageJPEGRepresentation(image, 0.5) mimeType:@"" imgType:3 result:^(NSString * _Nonnull url, ESError * _Nonnull error) {
					[self.contentImageNameArr addObject:keyName];
					dispatch_group_leave(gcdGroup);
				}];
			}
			
			dispatch_group_notify(gcdGroup, dispatch_get_main_queue(), ^{
				NSMutableArray*nameArr = [NSMutableArray arrayWithArray:[self.contentImageNameArr copy]] ;
				[nameArr removeObjectAtIndex:0];
				NSString* currentDescImg = [nameArr componentsJoinedByString:@","];
				[ESNetworkService createPlanWithMatchInfo:[dicArr copy] price:price content:content title:title type:[NSString stringWithFormat:@"%@",@(self.type)] pic:currentDescImg field:(self.field+1) declaration:declaration declarationPic:self.declarationImageUrl commentAreaType:self.commmentState Response:^(id dict, ESError *error) {
					if (dict&&[dict[@"code"] integerValue] == 0) {
						dispatch_main_async_safe(^{
							[CMMUtility showToastWithText:@"创建方案成功"];
							//98765
							NSDictionary*data = dict[@"data"];
							NSString*planId = [data[@"planId"] stringValue];
                            CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
							vc.planId = planId.integerValue;
							vc.sourcePage = self.title;
							vc.hidesBottomBarWhenPushed = YES;
							NSMutableArray*mArr = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
							[mArr removeLastObject];
							[mArr removeLastObject];
							[mArr addObject:vc];
							vc.hidesBottomBarWhenPushed = YES;
							[self.navigationController setViewControllers:mArr.copy animated:YES];
						});
						
					}
					self.onSaving = NO;
					[ES_LPUnitily removeHUDToSystemWindow];
				}];
			});
		}
	}
}
- (void)defaultCell {
	WEAK(weaklistArray, self.listArray);
    WEAK(weakSelf, self);
    _cellView.canEdit = NO;
    [_cellView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
    _cellView.cell = ^(NSIndexPath *indexPath){
         UITableViewCell *cell = [weakSelf.cellView dequeueReusableCellWithIdentifier:@"DefaultCell"];
        if (indexPath.row == 0) {
            cell.textLabel.textColor = ColorAppRed;
            cell.backgroundColor = ColorGrayBack;
        }else{
            cell.backgroundColor =[UIColor whiteColor];
            cell.textLabel.textColor = ColorSubTitle;
        }
       
        cell.textLabel.text = [NSString stringWithFormat:@"%@",weaklistArray[indexPath.row]];
        
        return cell;
    };
    _cellView.optionCellHeight = ^{
        return 40.f;
    };
    _cellView.rowNumber = ^(){
        return (NSInteger)weaklistArray.count;
    };
}

- (void)configCommentCell {
	if (self.type >=3) {
		self.commentStateArray = [NSMutableArray arrayWithArray:@[@"评论区权限",@"关闭评论",@"所有人可评论"]];
	} else {
		self.commentStateArray = [NSMutableArray arrayWithArray:@[@"评论区权限",@"关闭评论",@"购买可评论",@"所有人可评论"]];
	}
	WEAK(weaklistArray, self.commentStateArray);
	WEAK(weakSelf, self);
	_cellView.canEdit = NO;
	[_cellView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
	_cellView.cell = ^(NSIndexPath *indexPath){
		UITableViewCell *cell = [weakSelf.cellView dequeueReusableCellWithIdentifier:@"DefaultCell"];
		if (indexPath.row == 0) {
			cell.textLabel.textColor = ColorAppRed;
			cell.backgroundColor = ColorGrayBack;
		}else{
			cell.backgroundColor =[UIColor whiteColor];
			cell.textLabel.textColor = ColorSubTitle;
		}
		
		cell.textLabel.text = [NSString stringWithFormat:@"%@",weaklistArray[indexPath.row]];
		
		return cell;
	};
	_cellView.optionCellHeight = ^{
		return 40.f;
	};
	_cellView.rowNumber = ^(){
		return (NSInteger)weaklistArray.count;
	};
}

-(void)didSelectModelArr:(NSArray *)modelArr andfield:(NSInteger)field
{
    self.modelArr = modelArr;
    self.field = field;
    if (modelArr.count == 1) {
//         [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:0];
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:0];
    }
    if (modelArr.count == 2) {
//        [self.tableView beginUpdates];
//         [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:YES];
        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:0];
//        [self.tableView endUpdates];
        
//
    }
   
}
-(void)addFooterView{
	[self.footerView setFrame:CGRectMake(0, 0, kScreen_Width, 314.0 + itemsHigh)];
	self.footerView.backgroundColor = [UIColor whiteColor];
	[self.textV_Title mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(15);
		make.right.mas_equalTo(self.footerView).offset(-15);
		make.height.mas_equalTo(@(51));
		make.top.mas_equalTo(self.footerView);
	}];
	
	[self.titleCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.textV_Title.mas_bottom);
		make.height.equalTo(@(17));
		make.right.equalTo(self.footerView).offset(-14);
	}];

	UIView*line =[UIView new];
	[self.footerView addSubview:line];
	[line mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(0);
		make.right.mas_equalTo(self.footerView).offset(0);
		make.height.mas_equalTo(1);
		make.top.mas_equalTo(self.titleCountLabel.mas_bottom).offset(9);
	}];
	line.backgroundColor = ColorGrayBack;
	//宣言
	[self.textV_Declaration mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(15);
		make.right.mas_equalTo(self.footerView).offset(-15);
		make.height.mas_equalTo(@(90));
		make.top.mas_equalTo(line.mas_bottom);
	}];
	
//	[self.addPhtoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//		make.top.equalTo(self.textV_Declaration.mas_bottom).offset(41);
//		make.left.equalTo(self.footerView).offset(15);
//		make.size.mas_equalTo(CGSizeMake(itemsHigh - 30, itemsHigh - 30));
//	}];
//
//	[self.declarationImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//		make.top.equalTo(self.textV_Declaration.mas_bottom).offset(41);
//		make.left.equalTo(self.footerView).offset(15);
//		make.size.mas_equalTo(CGSizeMake(itemsHigh - 30, itemsHigh - 30));
//	}];
//
//	[self.deleteB mas_makeConstraints:^(MASConstraintMaker *make) {
//		make.centerY.mas_equalTo(self.declarationImageView.mas_top);
//		make.centerX.mas_equalTo(self.declarationImageView.mas_right);
//		make.size.mas_equalTo(CGSizeMake(30, 30));
//	}];
//
//	[self.declarationCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//		make.bottom.equalTo(self.addPhtoImageView.mas_top).offset(-9);
//		make.height.equalTo(@(17));
//		make.right.equalTo(self.footerView).offset(-14);
//	}];
	
	//内容
	UIView*line1 =[UIView new];
	[self.footerView addSubview:line1];
	[line1 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(0);
		make.right.mas_equalTo(self.footerView).offset(0);
		make.height.mas_equalTo(1);
		make.top.mas_equalTo(self.textV_Declaration.mas_bottom).offset(15);
	}];
	line1.backgroundColor = ColorGrayBack;
	[self.textV_Content mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(15);
		make.right.mas_equalTo(self.footerView).offset(-15);
		make.height.mas_equalTo(90);
		make.top.mas_equalTo(line1).offset(1);
	}];
	self.textV_Title.placeholder = @"标题(所有用户可见,10-50字符)";
	self.textV_Declaration.placeholder = @"专家宣言(选填,所有用户可见,100字以内)";
	self.textV_Content.placeholder = @"内容(请保证内容的原创性100字以上,图片选填最多三张)";
	self.tableView.tableFooterView = self.footerView;
	
	UICollectionViewFlowLayout*layout=[[UICollectionViewFlowLayout alloc]init];
	layout.minimumLineSpacing=5;
	layout.minimumInteritemSpacing=5;
	layout.itemSize=CGSizeMake(itemsHigh,itemsHigh);
	self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, 0.1, 0.1) collectionViewLayout:layout];
	self.collectionView.delegate=self;
	self.collectionView.dataSource=self;
	self.collectionView.backgroundColor=[UIColor whiteColor];
	self.collectionView.showsVerticalScrollIndicator=NO;
	[self.collectionView registerClass:[PhotoCollectionViewCell class] forCellWithReuseIdentifier:@"PhotoCollectionViewCell"];
	[self.footerView addSubview:self.collectionView];
	[self.collectionView mas_remakeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.footerView).offset(0);
		make.right.mas_equalTo(self.footerView).offset(0);
		make.height.mas_equalTo(@(itemsHigh + 30));//200个字如何保证高度
		make.top.mas_equalTo(self.textV_Content.mas_bottom).offset(26);
		make.bottom.equalTo(self.footerView).offset(-10);
	}];
	
	[self.contentCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.equalTo(self.collectionView.mas_top).offset(-9);
		make.height.equalTo(@(17));
		make.right.equalTo(self.footerView).offset(-14);
	}];
}
-(void)textViewDidChange:(UITextView *)textView
{
    dispatch_main_async_safe(^{
	NSInteger lenth = textView.text.length;
    if (textView.tag == 2019) {
        //标题
		self.titleCountLabel.text = [@(lenth).stringValue stringByAppendingString:@"/50"];
		if (lenth > 50 || lenth < 10) {
			NSRange range= NSMakeRange(0, @(lenth).stringValue.length);
			NSMutableAttributedString *textAttributed = [[NSMutableAttributedString alloc] initWithString:self.titleCountLabel.text];
			[textAttributed addAttribute:NSForegroundColorAttributeName value:ColorAppRed range:range];
			self.titleCountLabel.attributedText = textAttributed;
		}
    }
    if (textView.tag == 2021) {
		//宣言
		self.declarationCountLabel.text = [@(lenth).stringValue stringByAppendingString:@"/100"];
		if (lenth > 100) {
			NSRange range= NSMakeRange(0, @(lenth).stringValue.length);
			NSMutableAttributedString *textAttributed = [[NSMutableAttributedString alloc] initWithString:self.declarationCountLabel.text];
			[textAttributed addAttribute:NSForegroundColorAttributeName value:ColorAppRed range:range];
			self.declarationCountLabel.attributedText = textAttributed;
		}
    }
    if (textView.tag == 2020) {
		self.contentCountLabel.text = [@(lenth).stringValue stringByAppendingString:@"/2000"];
        //内容
		if (lenth > 2000 || lenth < 100) {
			NSRange range= NSMakeRange(0, @(lenth).stringValue.length);
			NSMutableAttributedString *textAttributed = [[NSMutableAttributedString alloc] initWithString:self.contentCountLabel.text];
			[textAttributed addAttribute:NSForegroundColorAttributeName value:ColorAppRed range:range];
			self.contentCountLabel.attributedText = textAttributed;
		}
    }
});
}
#pragma mark collectionView代理
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        if (self.contentImageArr.count<4) {
            App_Utility.delegate = self;
            App_Utility.completeImage = 1;
            [App_Utility usePhotoForGetImage];
            
        }
    }
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    PhotoCollectionViewCell*cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"PhotoCollectionViewCell" forIndexPath:indexPath];
    cell.delegate = self;
    cell.photoIV.image = [self.contentImageArr objectAtIndex:indexPath.row];
    if (indexPath.row!=0) {
        cell.deleteB.hidden = NO;
    }else{
        cell.deleteB.hidden = YES;
    }
    
    return cell;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.contentImageArr.count;
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
//    WTCWriterTextView*textView0 = textView;
//    IQKeyboardManager *manager = [IQKeyboardManager sharedManager];


//    dispatch_main_async_safe(^{
//        if (textView0.tag == 2019) {
//            NSInteger count = textView.text.length+1;
//            if (count == 0 || (count>=15&& count<=35)) {
//                textView0.placeholder = @"标题(所有用户可见,15-35字符)";
//                [manager.myTootBar setTitle:@"标题(所有用户可见,15-35字符)"];
//            }else if (count<15) {
//                textView0.placeholder = [NSString stringWithFormat:@"标题最少15字,还差%ld字",(15-count)];
//                [manager.myTootBar setTitle:[NSString stringWithFormat:@"标题最少15字,还差%ld字",(15-count)]];
//
//            } else if (count>35){
//                textView0.placeholder = [NSString stringWithFormat:@"标题最多35字,超出%ld字",(count-35)];
//                [manager.myTootBar setTitle:[NSString stringWithFormat:@"标题最多35字,超出%ld字",(count-35)]];
//            }
//        }
//        if (textView0.tag == 2020) {
//            NSInteger count = textView.text.length+1;
//            if (count == 0 ||(count>=100&& count<=2000)) {
//                textView0.placeholder = @"内容(请保证内容的原创性100字以上,图片选填最多三张)";
//                [manager.myTootBar setTitle:@"内容(请保证内容的原创性100字以上,图片选填最多三张)"];
//            }else if (count<100) {
//                textView0.placeholder = [NSString stringWithFormat:@"内容最少100字,还差%ld字",(100-count)];
//                [manager.myTootBar setTitle:[NSString stringWithFormat:@"内容最少100字,还差%ld字",(100-count)]];
//            } else if (count>2000){
//                textView0.placeholder = [NSString stringWithFormat:@"标题最多2000字,超出%ld字",(count-2000)];
//                [manager.myTootBar setTitle:[NSString stringWithFormat:@"标题最多2000字,超出%ld字",(count-2000)]];
//            }
//        }
//    });
   
    return YES;
}

#pragma mark PhotoCollectionViewCella代理
-(void)didClickDeleteWithPhotoCollectionViewCell:(id)cell
{
    NSIndexPath*path = [self.collectionView indexPathForCell:cell];
    [self.contentImageArr removeObjectAtIndex:path.row];
    [self reloadColletionView];
}

#pragma mark - action
- (void)addPhoto {
	if (!self.declarationImageView.image) {
		self.selectForDeclaration = YES;
		App_Utility.delegate = self;
		App_Utility.completeImage = 1;
		[App_Utility usePhotoForGetImage];
	}
}

- (void)delete {
	if (self.declarationImageView.image) {
		self.selectForDeclaration = NO;
		self.declarationImageView.image = nil;
		self.declarationImageView.hidden = YES;
		self.deleteB.hidden = YES;
	}
}

#pragma mark - AppUtilityDelegate
- (void)completePhotoImageSuccessWithImage:(UIImage *)image
{
	NSData *data = UIImageJPEGRepresentation(image, 1);
	if (data.length > 1024 * 1024 * 5) {
		[CMMUtility showToastWithText:@"上传图片不可超过5M" duration:3];
		return;
	}
	if (self.selectForDeclaration == YES) {
		self.declarationImageView.image = image;
		self.declarationImageView.hidden = NO;
		self.deleteB.hidden = NO;
		self.selectForDeclaration = NO;
	} else {
		[self.contentImageArr addObject:image];
		[self reloadColletionView];
	}
}
-(void)reloadColletionView{
    dispatch_main_async_safe(^{
        if (self.contentImageArr.count<=4) {
            [self.collectionView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.height.mas_equalTo(@(1*itemsHigh + 15));
            }];
        }else{
            [self.collectionView mas_updateConstraints:^(MASConstraintMaker *make) {
                make.height.mas_equalTo(@(2*itemsHigh + 15));
            }];
        }
        [self.collectionView reloadData];
    });
}

- (void)completePhotoImageFaild {
	self.selectForDeclaration = NO;
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        if (self.modelArr.count!=2) {
            return 1;
        }else{
            return 2;
        }
    }
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (!QM_IS_ARRAY_NIL(self.modelArr)) {
            if (self.field) {
                static NSString *identifier=@"MatchBasketBallTableViewCell";
                MatchBasketBallTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if (cell==nil) {
                    cell=[[MatchBasketBallTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
                }
                cell.forbidSelect = YES;
                cell.model = self.modelArr[indexPath.row];
                
                return cell;
            }else{
                static NSString *identifier=@"MatchTableViewCell";
                MatchTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
                if (cell==nil) {
                    cell=[[MatchTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
                }
                cell.forbidSelect = YES;
                cell.model = self.modelArr[indexPath.row];
                
                return cell;
            }
            
        }else{
            static NSString *identifier=@"UNSelectTableViewCell";
            UNSelectTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            if (cell==nil) {
                cell=[[UNSelectTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            }
            cell.text = [NSString stringWithFormat:@"%d/%d",self.avail,self.max];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            [cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
                if ([btn isKindOfClass:[UIButton class]]) {
                    [btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
                        if ([imgView isKindOfClass:[UIImageView class]]) {
                            UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                            imgView.image = image;
                            imgView.tintColor = ColorAppRed;
                        }
                    }];
                }
            }];
            return cell;
        }
    }else if(indexPath.section == 1){
        static NSString *string = @"tableViewCell1";
        UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:string];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:string];
        }
        cell.layoutMargins = UIEdgeInsetsZero;
		if (self.type == 1) {
			cell.textLabel.text = self.listArray[1];
		} else if (self.type == 3){
			cell.textLabel.text = self.listArray[2];
		} else if (self.type == 4){
			cell.textLabel.text = self.listArray[3];
		} else {
			cell.textLabel.text = self.listArray[1];
		}
        cell.textLabel.font = fcFont(14.0f);
        cell.textLabel.textColor = ColorAppBlack;
		[cell.textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(cell.contentView).offset(15);
			make.centerY.equalTo(cell.contentView);
			make.size.mas_equalTo(CGSizeMake(200, 20));
		}];
		[cell.contentView layoutSubviews];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([btn isKindOfClass:[UIButton class]]) {
                [btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([imgView isKindOfClass:[UIImageView class]]) {
                        UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                        imgView.image = image;
                        imgView.tintColor = ColorAppRed;
                    }
                }];
            }
        }];
        return cell;
    } else if (indexPath.section == 2){
		static NSString *string = @"tableViewCell2";
        UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:string];
        if (cell==nil) {
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:string];
        }
        cell.layoutMargins = UIEdgeInsetsZero;
		cell.textLabel.font = fcFont(14.0f);
		cell.textLabel.textColor = ColorAppBlack;
		[cell.textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(cell.contentView).offset(15);
			make.centerY.equalTo(cell.contentView);
			make.size.mas_equalTo(CGSizeMake(200, 20));
		}];
		[cell.contentView layoutSubviews];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        [cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([btn isKindOfClass:[UIButton class]]) {
                [btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([imgView isKindOfClass:[UIImageView class]]) {
                        UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
                        imgView.image = image;
                        imgView.tintColor = ColorAppRed;
                    }
                }];
            }
        }];
		if (self.type == 3 || self.type == 4) {
            cell.textLabel.text = @"免费";
        }else{
            if (QM_IS_STR_NIL(self.money)) {
                cell.textLabel.text = @"请编辑价格";
            }else{
                cell.textLabel.text = [NSString stringWithFormat:@"%ld飞驰币",(long)self.money.integerValue];
            }
        }
        return cell;
	} else {
		static NSString *string = @"tableViewCell3";
		UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:string];
		if (cell==nil) {
			cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:string];
		}
		cell.layoutMargins = UIEdgeInsetsZero;
		cell.textLabel.font = fcFont(14.0f);
		cell.textLabel.textColor = ColorAppBlack;
		[cell.textLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.equalTo(cell.contentView).offset(15);
			make.centerY.equalTo(cell.contentView);
			make.size.mas_equalTo(CGSizeMake(200, 20));
		}];
		[cell.contentView layoutSubviews];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		[cell.subviews enumerateObjectsUsingBlock:^(__kindof UIButton * _Nonnull btn, NSUInteger idx, BOOL * _Nonnull stop) {
			if ([btn isKindOfClass:[UIButton class]]) {
				[btn.subviews enumerateObjectsUsingBlock:^(__kindof UIImageView * _Nonnull imgView, NSUInteger idx, BOOL * _Nonnull stop) {
					if ([imgView isKindOfClass:[UIImageView class]]) {
						UIImage *image = [imgView.image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
						imgView.image = image;
						imgView.tintColor = ColorAppRed;
					}
				}];
			}
		}];
		if (self.commmentState == 0) {
			cell.textLabel.text = @"关闭评论";
		} else if (self.commmentState == 1) {
			cell.textLabel.text = @"购买可评论";
		} else {
			cell.textLabel.text = @"所有人可评论";
		}
		return cell;
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        if (!QM_IS_ARRAY_NIL(self.modelArr)) {
//             [self pushVC];
        }else{
            [self pushVC];
        }
    }else if(indexPath.section == 1){
        UITableViewCell*cell= [tableView cellForRowAtIndexPath:indexPath];
        UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
        CGRect rect=[cell convertRect:cell.bounds toView:window];
        [self defaultCell];
        _cellView.vhShow = YES;
        _cellView.optionType = MLMOptionSelectViewTypeCustom;
        _cellView.edgeInsets = UIEdgeInsetsZero;
        if (kScreen_Height-rect.origin.y-45<200) {
            [_cellView showTapPoint:CGPointMake((SCREEN_WIDTH)*0.5, rect.origin.y) viewWidth:120 direction:MLMOptionSelectViewTop];
        }else{
			[_cellView showTapPoint:CGPointMake((SCREEN_WIDTH)*0.5, rect.origin.y+45) viewWidth:120 direction:MLMOptionSelectViewBottom];
        }
		
        @weakify(self)
        _cellView.selectedOption = ^(NSIndexPath *index) {
            @strongify(self)
            if (index.row == 1) {
				cell.textLabel.text = self.listArray[1];
                UITableViewCell*priceCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
                priceCell.textLabel.text = @"请编辑价格";
				if (self.type == 1) {
					return;
				}
				self.type = 1;
            }else if (index.row == 2){
                cell.textLabel.text = self.listArray[2];
                UITableViewCell*priceCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
                priceCell.textLabel.text = @"免费";
				if (self.type == 3) {
					return;
				}
				self.type = 3;
            }else if (index.row == 3){
                cell.textLabel.text = self.listArray[3];
                UITableViewCell*priceCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
                priceCell.textLabel.text = @"仅粉丝免费";
				if (self.type == 4) {
					return;
				}
				self.type = 4;
            }
			//重置评论状态
			self.commmentState = 0;
			UITableViewCell*cell= [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:3]];
			cell.textLabel.text = @"关闭评论";
        };
    }else if(indexPath.section == 2) {
		if (self.type == 3 || self.type == 4) {
            
        }else{
            ConfirmMoneyView*view = [[ConfirmMoneyView alloc]initWithMoney:self.money descrip:self.priceRule moneyArr:@[@"28",@"38",@"58"]];
            view.myText = self.priceRule;
            view.delegate = self;
            @weakify(self)
            view.confirmBlock = ^(NSString *money) {
                @strongify(self)
                if (!QM_IS_STR_NIL(money)) {
                    UITableViewCell*priceCell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:2]];
                        priceCell.textLabel.text = [NSString stringWithFormat:@"%ld飞驰币",(long)money.integerValue];
                    self.money = money;
                }
                 
                    
            };
            [view show];
        }
	} else if(indexPath.section == 3) {
		UITableViewCell*cell= [tableView cellForRowAtIndexPath:indexPath];
		UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
		CGRect rect=[cell convertRect:cell.bounds toView:window];
		[self configCommentCell];
		_cellView.vhShow = YES;
		_cellView.optionType = MLMOptionSelectViewTypeCustom;
		_cellView.edgeInsets = UIEdgeInsetsZero;
		if (kScreen_Height-rect.origin.y-45<200) {
			[_cellView showTapPoint:CGPointMake((SCREEN_WIDTH)*0.5, rect.origin.y) viewWidth:135 direction:MLMOptionSelectViewTop];
		}else{
			[_cellView showTapPoint:CGPointMake((SCREEN_WIDTH)*0.5, rect.origin.y+45) viewWidth:135 direction:MLMOptionSelectViewBottom];
		}
		//        __weak CreatPlanViewController*weakSelf = self;
		@weakify(self)
		_cellView.selectedOption = ^(NSIndexPath *index) {
			@strongify(self)
			if (index.row != 0) {
				cell.textLabel.text = self.commentStateArray[index.row];
				NSArray *arr = @[@"关闭评论",@"购买可评论",@"所有人可评论"];
				self.commmentState = [arr indexOfObject:cell.textLabel.text];
			}
		};
	}
}

-(void)showPriceRules:(UIButton *)button andView:(UIView *)view
{
    CGPoint point=CGPointMake(button.frame.origin.x+button.frame.size.width/2+view.frame.origin.x, button.frame.origin.y+view.frame.origin.y);//箭头点的位置
    CGFloat height = [LPUnitily getHeightFromString:self.priceRule font:fcFont(12) width:170];
    WBPopOverView *viewP=[[WBPopOverView alloc]initWithOrigin:point Width:180 Height:(height+10) Direction:WBArrowDirectionDown2];//初始化弹出视图的箭头顶点位置point,展示视图的宽度Width,高度Height,Direction以及展示的方向
    UILabel *lable=[[UILabel alloc]initWithFrame:CGRectMake(5, 5, 170, height)];
    lable.textAlignment = NSTextAlignmentCenter;
    lable.font = fcFont(12.0f);
    lable.textColor = ColorAppRed;
    lable.text=self.priceRule;
    lable.numberOfLines = 0;
    lable.textColor=[UIColor whiteColor];
    [viewP.backView addSubview:lable];
    [viewP popView];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.section == 0){
        if (!QM_IS_ARRAY_NIL(self.modelArr)) {
            if (self.field) {
                return k6sVersusWidth*50+20+10+20+5+15+20+10 + (kSPForJCCellHeight *3 + 2.0);
            }else{
        return k6sVersusWidth*50+20+10+20+5+15+20+10 + (kSPForJCCellHeight *2 + 1.0);
            }
        }else{
            return 69;
        }
    }else if(indexPath.section == 1){
        return 45.0;
    }else{
        return 45.0;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        if (!QM_IS_ARRAY_NIL(self.modelArr)) {
            return 35;
        }else{
            return 0.01;
        }
    }
    return 0.01;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        if (!QM_IS_ARRAY_NIL(self.modelArr)) {
            UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
            UILabel*label = [UILabel new];
            label.textColor = ColorTitle;
            label.font = fcFont(12.0f);
            [view addSubview:label];
            [label mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.mas_equalTo(view).offset(15);
                make.right.mas_equalTo(view).offset(-15);
                make.top.bottom.mas_equalTo(view);
            }];
            if (self.modelArr.count == 2) {
                if (self.field) {
                    label.text = @"竞篮-二串一";
                }else{
                label.text = @"竞足-二串一";
                }
            }else{
                if (self.field) {
                    label.text = @"竞篮-单关";
                }else{
                label.text = @"竞足-单关";
                }
            }
            return view;
            
        }
    }
    return nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 35.0f;
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
    view.backgroundColor = ColorGrayBack;
    UILabel*label = [UILabel new];
    label.textColor = ColorAppBlack;
    label.font = fcFont(14.0f);
    [view addSubview:label];
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(view).offset(15);
        make.right.mas_equalTo(view).offset(-15);
        make.top.bottom.mas_equalTo(view);
    }];
    label.text = self.footerArr[section];
    return view;
}
-(void)pushVC{
//    SelectPlanViewController*vc = [SelectPlanViewController new];
//    if (!QM_IS_ARRAY_NIL(self.modelArr)) {
//        vc.haveSelectArr = [NSMutableArray arrayWithArray:self.modelArr];
//    }
//    vc.delegate = self;
//
//    [self.navigationController pushViewController:vc animated:YES];
    [self.navigationController popViewControllerAnimated:YES];
}
-(WTCWriterTextView*)textV_Title
{
    if (!_textV_Title) {
        _textV_Title = [WTCWriterTextView new];
        _textV_Title.font = fcFont(14.0f);
        _textV_Title.tag = 2019;
        _textV_Title.delegate = self;
        [self.footerView addSubview:_textV_Title];
    }
    return _textV_Title;
}
-(WTCWriterTextView*)textV_Content
{
    if (!_textV_Content) {
        _textV_Content = [WTCWriterTextView new];
        _textV_Content.font = fcFont(14.0f);
        _textV_Content.tag = 2020;
        _textV_Content.delegate = self;
        [self.footerView addSubview:_textV_Content];
    }
    return _textV_Content;
}
-(WTCWriterTextView*)textV_Declaration
{
    if (!_textV_Declaration) {
        _textV_Declaration = [WTCWriterTextView new];
        _textV_Declaration.font = fcFont(14.0f);
        _textV_Declaration.tag = 2021;
        _textV_Declaration.delegate = self;
        [self.footerView addSubview:_textV_Declaration];
    }
    return _textV_Declaration;
}

- (UILabel *)titleCountLabel {
	if (!_titleCountLabel) {
		_titleCountLabel = [UILabel new];
		_titleCountLabel.textColor = RGBCOLOR(102, 102, 102);
		_titleCountLabel.font = fcFont(12);
		_titleCountLabel.text = @"0/50";
		[self.footerView addSubview:_titleCountLabel];
	}
	return _titleCountLabel;
}

- (UILabel *)declarationCountLabel {
	if (!_declarationCountLabel) {
		_declarationCountLabel = [UILabel new];
		_declarationCountLabel.textColor = RGBCOLOR(102, 102, 102);
		_declarationCountLabel.font = fcFont(12);
		_declarationCountLabel.text = @"0/100";
		[self.footerView addSubview:_declarationCountLabel];
	}
	return _declarationCountLabel;
}

- (UILabel *)contentCountLabel {
	if (!_contentCountLabel) {
		_contentCountLabel = [UILabel new];
		_contentCountLabel.textColor = RGBCOLOR(102, 102, 102);
		_contentCountLabel.font = fcFont(12);
		_contentCountLabel.text = @"0/2000";
		[self.footerView addSubview:_contentCountLabel];
	}
	return _contentCountLabel;
}

- (UIImageView *)addPhtoImageView {
	if (!_addPhtoImageView) {
		_addPhtoImageView = [UIImageView new];
		_addPhtoImageView.image = GetImage(@"添加图片");
		_addPhtoImageView.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addPhoto)];
		[_addPhtoImageView addGestureRecognizer:tap];
		[self.footerView addSubview:_addPhtoImageView];
	}
	return _addPhtoImageView;
}

- (UIImageView *)declarationImageView {
	if (!_declarationImageView) {
		_declarationImageView = [UIImageView new];
		_declarationImageView.hidden = YES;
		[self.footerView addSubview:_declarationImageView];
	}
	return _declarationImageView;
}

- (UIButton *)deleteB {
	if (!_deleteB) {
		_deleteB = [UIButton buttonWithType:UIButtonTypeCustom];
		[_deleteB addTarget:self action:@selector(delete) forControlEvents:UIControlEventTouchUpInside];
		_deleteB.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_deleteB setImage:[UIImage imageNamed:@"community_delete_icon"] forState:UIControlStateNormal];
		_deleteB.hidden = YES;
		[self.footerView addSubview:_deleteB];
	}
	return _deleteB;
}

-(UIView*)footerView
{
    if (!_footerView) {
        _footerView = [[UIView alloc] init];
        
    }
    return _footerView;
}

- (UIButton *)postBtn {
	if (!_postBtn) {
		_postBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		_postBtn.frame = CGRectMake(0, 0, 42, 22);
		[_postBtn setTitle:@"发布" forState:UIControlStateNormal];
		_postBtn.backgroundColor = ColorAppRed;
		[_postBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_postBtn.titleLabel.font = fcFont(12);
		_postBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
		_postBtn.layer.cornerRadius = 2;
		_postBtn.clipsToBounds = YES;
		[_postBtn addTarget:self action:@selector(saveIt:) forControlEvents:UIControlEventTouchUpInside];
	}
	return _postBtn;
}

@end
