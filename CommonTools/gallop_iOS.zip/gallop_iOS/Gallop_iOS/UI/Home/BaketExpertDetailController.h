//
//  BaketExpertDetailController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"
@protocol BaketExpertDetailControllerDelegte<NSObject>

-(void)scrollViewOffsetChanged:(UIScrollView *)scrollView isDataEmpty:(BOOL)isDataEmpty;

@end

@interface BaketExpertDetailController : ESViewController
- (void)loadZhanjiWithModel:(id)model;
@property (nonatomic, strong) NSNumber*expertId;
@property (nonatomic,weak) id delegate;
@end
