//
//  ESContentNavigationView.h
//  ESTicket
//
//  Created by 王帅 on 16/3/11.
//  Copyright © 2016年 鹏 刘. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ESContentNavigationView;

@protocol ESContentNavigationViewDelegate <NSObject>

- (void)toBackLastView;

- (void)toCloseCurrentView;

@end

@interface ESContentNavigationView : UIView

@property (nonatomic, weak) id<ESContentNavigationViewDelegate> delegate;

@property (nonatomic, assign) BOOL hiddenCloseButton;

@property (nonatomic, strong) NSString *title;

@property (nonatomic, assign) BOOL showBackButton;

@end
