//
//  BoardExpert.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BoardExpert : NSObject
@property (nonatomic,strong) NSString *expertName;
@property (nonatomic,strong) NSString *expertAvatar;
@property (nonatomic,strong) NSNumber *cnt;
@property (nonatomic,strong) NSNumber *gotCnt;
@property (nonatomic,strong) NSNumber *userId;
@property (nonatomic,strong) NSNumber *profit;
@property (nonatomic,strong) NSNumber *continueRedCnt;
@end

NS_ASSUME_NONNULL_END
