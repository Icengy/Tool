//
//  YinLi.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/2.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "YinLi.h"
@implementation HitRank
@end

@implementation RedRank
@end

@implementation YinLi
@end
