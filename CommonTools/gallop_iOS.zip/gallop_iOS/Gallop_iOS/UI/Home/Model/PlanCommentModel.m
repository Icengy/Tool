//
//  PlanCommentModel.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/7/1.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PlanCommentModel.h"

@implementation PlanCommentItem

@end

@implementation PlanCommentModel
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"content":@"PlanCommentItem"};
}
@end
