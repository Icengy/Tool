//
//  MatchModel.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SelectResult : NSObject
@property (strong, nonatomic)NSString*type;
@property (strong, nonatomic)NSString*result;
@end

@interface MatchModel : NSObject

@property (assign, nonatomic) NSUInteger matchId;
@property (strong, nonatomic) NSString*bDate;
@property (strong, nonatomic) NSNumber*matchDateNum;
@property (strong, nonatomic) NSString*matchNum;
@property (strong, nonatomic) NSString*matchTime;
@property (strong, nonatomic) NSString*leagueShortName;
@property (strong, nonatomic) NSString*leagueId;
@property (strong, nonatomic) NSString*hostName;
@property (strong, nonatomic) NSString*hostShortName;
@property (strong, nonatomic) NSString*hostId;
@property (strong, nonatomic) NSString*hostOrder;
@property (strong, nonatomic) NSString*hostScore;
@property (strong, nonatomic) NSString*hostIcon;
@property (strong, nonatomic) NSString*awayName;
@property (strong, nonatomic) NSString*awayShortName;
@property (strong, nonatomic) NSString*awayId;
@property (strong, nonatomic) NSString*awayOrder;
@property (strong, nonatomic) NSString*awayScore;
@property (strong, nonatomic) NSString*awayIcon;
@property (strong, nonatomic) NSDictionary*winLose;
@property (strong, nonatomic) NSDictionary*concedeWinLose;
@property (nonatomic,strong) NSDictionary*dxfWinLose;
@property (strong, nonatomic) NSString*lastUpdated;
/// 开奖时间
@property (nonatomic,strong) NSString *lotteryTime;

@property (strong, nonatomic) NSMutableArray<SelectResult *> *selects;
@property (strong, nonatomic) NSDictionary *odds;

/** 胜负*/
@property (nonatomic, strong) NSMutableArray *sfArray;
@property (nonatomic, assign) BOOL sfAllow;
/** 亚指胜负*/
@property (nonatomic, strong) NSMutableArray *rqsfArray;
@property (nonatomic, assign) BOOL rqsfAllow;
@property (nonatomic, strong) NSString *rangNumStr;
/** 本次比赛是否选中*/
@property (nonatomic, assign) BOOL selected;


//***篮球额外属性***//
@property (nonatomic,strong) NSMutableArray*dxfArray;
@property (nonatomic, assign) BOOL dxfAllow;
@property (nonatomic,strong) NSString *dxfNumStr;

@property (nonatomic,strong) NSString *guessStatus;
@end


NS_ASSUME_NONNULL_END
