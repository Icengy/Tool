//
//  ExpertDetail.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface ExpertLeagueListItem :NSObject
@property (nonatomic , assign) NSInteger              rank;
@property (nonatomic , assign) NSInteger              userId;
@property (nonatomic , assign) NSInteger              field;
@property (nonatomic , assign) NSInteger              leagueId;
@property (nonatomic , copy) NSString              * leagueName;
@property (nonatomic , assign) NSInteger              totalCount;
@property (nonatomic , assign) NSInteger              redCount;
@property (nonatomic , assign) NSInteger              redRate;
@property (nonatomic , assign) NSInteger              createTime;
@property (nonatomic , assign) NSInteger              updateTime;

@end

@interface ExpertLeagueCountModel :NSObject
@property (nonatomic , strong) NSArray <ExpertLeagueListItem *>              * expertLeagueList;
@property (nonatomic , assign) NSInteger              page;
@property (nonatomic , assign) NSInteger              pageSize;
@property (nonatomic , assign) NSInteger              pageCount;

@end

@interface ExpertPrize : NSObject
@property (nonatomic , assign) NSInteger              lastContinueCnt;
@property (nonatomic , assign) NSInteger              historyContinueCnt;
@property (nonatomic , assign) NSInteger              redCnt;
@property (nonatomic , assign) NSInteger              planCnt;
@property (nonatomic , assign) CGFloat                sevenProfit;
@property (nonatomic , strong) NSArray <NSNumber *>              * sevenRedList;
@end

@interface ExpertDetail : NSObject
@property (nonatomic , assign) NSInteger              userId;
@property (nonatomic , copy) NSString              * expertName;
@property (nonatomic , copy) NSString              * expertAvatar;
@property (nonatomic , copy) NSString              * introduction;
@property (nonatomic , assign) NSInteger              followCount;
@property (nonatomic , assign) NSInteger              releasePlanCnt;
@property (nonatomic , assign) NSInteger              field;
@end
