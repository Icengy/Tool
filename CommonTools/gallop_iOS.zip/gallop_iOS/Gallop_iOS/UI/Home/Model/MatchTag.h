//
//  MatchTag.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MatchSeleted : NSObject
@property (nonatomic,strong) NSString *handicap;
@property (nonatomic,strong) NSString *type;
@end

@interface MatchTag : NSObject
@property (nonatomic , assign) NSInteger              matchDateNum;
@property (nonatomic,strong) NSString*hostName;
@property (nonatomic,strong) NSString *awayName;
@property (nonatomic,strong) NSString *hostScore;
@property (nonatomic,strong) NSString *awayScore;
@property (nonatomic,strong) NSString *leagueShortName;
@property (nonatomic,strong) NSNumber *matchTime;
@property (nonatomic,strong) MatchSeleted *selected;
@end

NS_ASSUME_NONNULL_END
