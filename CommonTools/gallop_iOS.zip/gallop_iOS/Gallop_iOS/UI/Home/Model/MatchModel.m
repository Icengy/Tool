//
//  MatchModel.m
//  Gallop_iOS
//
//  Created by Homosu-m on 2019/5/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchModel.h"

@implementation SelectResult

@end

@implementation MatchModel
-(id)init{
    if (self = [super init]) {
        self.sfArray = [NSMutableArray arrayWithCapacity:0];
        self.rqsfArray = [NSMutableArray arrayWithCapacity:0];
        self.dxfArray = [NSMutableArray arrayWithCapacity:0];
    }
    return self;
}

+ (NSDictionary *)mj_objectClassInArray {
    return @{
             @"selects" : @"SelectResult",
             };
}

+ (NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{
             @"matchId" : @"id"//前边的是你想用的key，后边的是返回的key
             };
}
@end
