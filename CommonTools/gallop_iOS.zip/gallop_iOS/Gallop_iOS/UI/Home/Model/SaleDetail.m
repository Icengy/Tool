//
//  SaleDetail.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SaleDetail.h"

@implementation SaleDetail

@end
