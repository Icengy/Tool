//
//  SelectedMatchModel.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SelectedMatchModel.h"

@implementation SelectedMatchModel

@end

