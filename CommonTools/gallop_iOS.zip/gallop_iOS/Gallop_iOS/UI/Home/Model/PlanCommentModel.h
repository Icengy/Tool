//
//  PlanCommentModel.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/7/1.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlanCommentItem : NSObject
@property (nonatomic , assign) NSInteger              planId;
@property (nonatomic , copy) NSString              * userId;
@property (nonatomic , copy) NSString              * userName;
@property (nonatomic , copy) NSString              * avatar;
@property (nonatomic , copy) NSString              * content;
@property (nonatomic , assign) NSInteger              status;
@property (nonatomic , copy) NSString              * createTime;
@end

@interface PlanCommentModel : NSObject
@property (nonatomic , assign) NSInteger              totalPages;
@property (nonatomic , assign) NSInteger              number;
@property (nonatomic , assign) NSInteger              size;
@property (nonatomic , assign) NSInteger              totalElements;
@property (nonatomic , strong) NSArray <PlanCommentItem *>              * content;
@end
