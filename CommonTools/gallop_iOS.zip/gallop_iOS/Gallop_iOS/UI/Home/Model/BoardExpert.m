//
//  BoardExpert.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "BoardExpert.h"

@implementation BoardExpert

@end
