//
//  SelectedMatchModel.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/29.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SelectedMatchModel : NSObject
@property (strong, nonatomic) NSNumber*matchDateNum;
@property (strong, nonatomic) NSString*selectType;
@property (strong, nonatomic) NSString*title;
@property (strong, nonatomic) NSString*selectOdds;
@property (strong, nonatomic) NSString*odds;
/** 是否选中*/
@property (nonatomic, assign) BOOL selected;
/** 是否为结果*/
@property (nonatomic, assign) BOOL winResult;

@end

NS_ASSUME_NONNULL_END
