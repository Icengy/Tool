//
//  SaleDetail.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SaleDetail : NSObject
@property (nonatomic,strong) NSString *userId;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *buyTime;
@property (nonatomic,strong) NSString *avatar;
@end

NS_ASSUME_NONNULL_END
