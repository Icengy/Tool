//
//  PayWay.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PayWay : NSObject
@property (nonatomic,strong) NSNumber *m_id;
@property (nonatomic,strong) NSString *payName;
@property (nonatomic,strong) NSString *paySuggest;
@property (nonatomic,strong) NSNumber *payType;
@property (nonatomic,strong) NSNumber *iosStatus;
@property (nonatomic,strong) NSString *createTime;
@property (nonatomic,strong) NSString *updateTime;




@end

NS_ASSUME_NONNULL_END
