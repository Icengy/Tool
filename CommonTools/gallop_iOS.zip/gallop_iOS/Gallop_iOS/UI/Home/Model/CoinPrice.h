//
//  CoinPrice.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CoinPrice : NSObject
@property (nonatomic,strong)NSNumber*m_id;
@property (nonatomic,strong)NSNumber*gallopAmount;
@property (nonatomic,strong)NSNumber*payMoney;
@end

NS_ASSUME_NONNULL_END
