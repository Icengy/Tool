//
//  PayWay.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PayWay.h"

@implementation PayWay
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"m_id": @"id"};
}
@end
