//
//  ExpertDetail.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/22.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertDetail.h"
@implementation ExpertLeagueListItem
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
	return @{@"rank":@"id"};
}
@end

@implementation ExpertLeagueCountModel
+ (NSDictionary *)mj_objectClassInArray {
	return @{@"expertLeagueList":@"ExpertLeagueListItem"};
}
@end

@implementation ExpertPrize

@end

@implementation ExpertDetail

@end
