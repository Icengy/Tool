//
//  YinLi.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/2.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HitRank : NSObject
@property (nonatomic,strong) NSString *expertName;
@property (nonatomic,strong) NSNumber *gotRate;
@property (nonatomic,strong) NSString *expertAvatar;
@property (nonatomic,strong) NSNumber *userId;
@property (nonatomic,strong) NSString *recentGot;
@end

@interface RedRank : NSObject
@property (nonatomic,strong) NSString *expertName;
@property (nonatomic,strong) NSNumber *continueRedCnt;
@property (nonatomic,strong) NSString *expertAvatar;
@property (nonatomic,strong) NSNumber *userId;
@end

@interface YinLi : NSObject
@property (nonatomic,strong) NSString*expertName;
@property (nonatomic,strong) NSNumber *cnt;
@property (nonatomic,strong) NSNumber *gotCnt;
@property (nonatomic,strong) NSNumber *userId;
@property (nonatomic,strong) NSNumber *profit;
@property (nonatomic,strong) NSString*expertAvatar;
@property (nonatomic,strong) NSNumber *forSalePlanCount;

@end
