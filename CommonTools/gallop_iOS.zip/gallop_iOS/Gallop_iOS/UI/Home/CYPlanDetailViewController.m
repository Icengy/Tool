//
//  CYPlanDetailViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/6.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "CYPlanDetailViewController.h"
#import "ExpertDetailViewController.h"
#import "PlanConfirmViewController.h"
#import "MatchDetailViewController.h"

#import "HZPhotoBrowser.h"
#import <SDWebImage/SDWebImage.h>

#import "PlanModel.h"
#import "PlanCommentModel.h"
/// 专家选择方案model
#import "SelectedMatchModel.h"

#import "PlanDetailHeadView.h"
#import "ESShareViewController.h"
#import "PlanDetailHeadDescTableCell.h"
#import "CYCommonListHeaderView.h"
#import "ExpertDetailHistoryPlanTableViewCell.h"
#import "PlanDetailTitleTableCell.h"
#import "PlanCommentCell.h"
#import "PaperCommentView.h"
#import "PlanEmptyCommentView.h"
#import "PlanGameInfoTableCell.h"

#import "PlanDetailAnalyseTableViewCell.h"
#import "PlanDetailAnalyseImageTableCell.h"
#import "PlanDetailAnalyseLockedTableCell.h"

#import "MyLabel.h"

#import "ImageDeliverManager.h"

#import "UIBarButtonItem+CreateExt.h"

#define kPageSize 20
#define kPlanTableHeadHeight (SCREEN_WIDTH *(48.0/375.0) + NavBarHeight + 16.0 + 12.0)

@interface CYPlanDetailViewController () <UITableViewDelegate,
UITableViewDataSource,
PaperCommentViewDelegate,
PlanDetailHeadDelegate,
PlanDetailAnalyseLockedTableCellDelegate>

@property (weak, nonatomic) IBOutlet CYBaseTableView *contentTableView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet UILabel *bottomTitleLabel;
@property (weak, nonatomic) IBOutlet CYButton *payBtn;
@property (weak, nonatomic) IBOutlet CYButton *unlockBtn;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentBottomConstraint;

@property (nonatomic, strong) UILabel *naviTitleLabel;
@property (nonatomic, strong) PlanDetailHeadView *tableHeadView;

@property (nonatomic ,strong) NSMutableArray <PlanDetailAnalyseImageModel *>*imageDatas;

/// 评论输入框
@property (nonatomic, strong) PaperCommentView *commentView;
@property (nonatomic ,strong) HZPhotoBrowser *browserVc;


@property (nonatomic ,assign) NSInteger currentPage;
@property (nonatomic ,assign) CGFloat offsetY;
/// 是否关注当前用户
@property (nonatomic ,assign) BOOL isSubscribed;
@property (nonatomic ,strong) NSMutableArray *commentData;
/// 专家方案选择结果
@property (nonatomic ,strong) NSArray <SelectResult *>*selectData;

@property (nonatomic, strong) PlanModel *planModel;
@property (nonatomic, strong) PlanDetailAnalyseImageModel *declarationPicModel;

@end

@implementation CYPlanDetailViewController {
    /// 需要购买-需要关注
    BOOL _needPay, _needFollow;
    
    /// 分析高度
    CGFloat _analyseHeight;
}

#pragma mark - life cycle
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.fd_prefersNavigationBarHidden = NO;
    
    self.currentPage = 1;
    self.offsetY = 0.0;
    self.commentData = [NSMutableArray new];
    self.imageDatas = [NSMutableArray new];
    
    _needPay = NO;
    _needFollow = NO;
    _analyseHeight = 0.0;
    
    [self setupViews];
    
    [self loadData:nil];
    [[NSNotificationCenter defaultCenter] addObserverForName:kBuyPlanSuccess object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        dispatch_main_async_safe(^{
            [self loadData:nil];
        });
    }];
    [[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification  object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        dispatch_main_async_safe(^{
            [self loadData:nil];
        });
    }];
    
    [MobClick event:@"expert10" attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage}];
    
    [self.contentTableView addRefreshHeaderWithTarget:self textColor:UIColor.whiteColor action:@selector(loadData:)];
    [self.contentTableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleImageContent;
    
    [self showNavi];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

#pragma  mark - action
- (void)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)share:(id)sender {
    @weakify(self)
    [ESNetworkService planShareWithPlanId:@(self.planId).stringValue Response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            @strongify(self);
             NSDictionary*model = dict[@"data"];
                       [self shareWithModel:model];
        }
    }];
}

- (void)toTheMore:(id)sender {
    ExpertDetailViewController *vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",self.planModel.userId];
    vc.sourcePage = self.title;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)commentClick {
    //弹出评论框
    [self.commentView showPaperCommentView];
}

/// 支付飞驰币
- (IBAction)clickToPay:(id)sender {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
    }else{
        PlanConfirmViewController*vc = [PlanConfirmViewController new];
//        vc.avatar = self.planModel.expertAvatar;
//        vc.pTitle = self.planModel.title;
//        vc.price = [NSString stringWithFormat:@"%d",self.planModel.price.intValue];
//        vc.expertName = self.planModel.expertName;
//        vc.planId = self.planModel.planId;
        
        vc.model = self.planModel;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
}

///关注解锁
- (IBAction)clickToFollow:(id)sender {
    [self follow:(UIButton *)sender type:0];
}

- (void)follow:(UIButton *)sender type:(NSInteger)type {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
        
    @weakify(self)
    if (self.planModel.userId) {
        if (self.isSubscribed) {
            /// 取关
            [ESNetworkService unfollowExpert:self.planModel.userId.integerValue  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    @strongify(self)
                    dispatch_main_async_safe(^{
                        if (type == 1) sender.selected = !sender.selected;
                        [self loadData:sender];
                    });
                }
            }];
        }else{
            /// 关注
            [ESNetworkService followExpert:self.planModel.userId.integerValue  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    @strongify(self)
                    dispatch_main_async_safe(^{
                        if (type == 1) sender.selected = !sender.selected;
                        [self loadData:sender];
                    });
                }
            }];
        }
    }
}

- (void)matchCardClick:(MatchModel *)model {
    @weakify(self)
//    if (self.model.field.integerValue == 2) {
//        return;
//    }
    [ESNetworkService getMatchId:model.matchId response:^(id dict, ESError *error) {
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSUInteger matchId = [dict[@"data"] integerValue];
            dispatch_main_async_safe(^{
                if (matchId == 0) {
                    [[LPUnitily sharedManager] showToastWithText:@"暂无比赛信息"];
                    return;
                }
                MatchDetailViewController *matchVC = [[MatchDetailViewController alloc] init];
                matchVC.field = self.planModel.field.integerValue;
                matchVC.matchId = matchId;
                matchVC.sourcePage = @"方案详情页";
                [self.navigationController pushViewController:matchVC animated:YES];
            });
        }
    }];
}


#pragma mark -
- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

#pragma mark - private method
- (void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    /// 获取方案详情
    @weakify(self);
    [ESNetworkService planDetailWithPlanId:self.planId Response:^(id dict, ESError *error) {
        
        [self endAllFreshing:self.contentTableView];
        
        if (dict&&[dict[@"code"] integerValue] == 0) {
            @strongify(self)
            id data = dict[@"data"];
            
            if ([data objectForKey:@"isSubscribed"]) {
                self.isSubscribed = [[data objectForKey:@"isSubscribed"] boolValue];
            }
            
            NSDictionary *match = [data objectForKey:@"info"];
            if (QM_IS_DICT_NIL(match)) return;
            
            PlanModel *model = [PlanModel mj_objectWithKeyValues:match];
            if (model.field.integerValue == 2) {
                [self configBasketBallData:model];
            }else{
                [self configFootBallData:model];
            }
            
//            self.planModel.showContentFlag = [NSNumber numberWithBool:YES];
//            self.planModel.content = @"昨天的单子顺利三单红两单，也算是打脸各位天天嚷嚷着兄弟们收米，然后发单收费的垃圾！今天的比赛挺多";
//            self.planModel.pic = @"1,1,1";
            
//            self.planModel.declaration = @"";
//            self.planModel.declarationPic = @"https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=1763239278,3943629193&fm=26&gp=0.jpg";
            self.declarationPicModel = [[PlanDetailAnalyseImageModel alloc] init];
            self.declarationPicModel.url = self.planModel.declarationPic;
            self.declarationPicModel.image = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:self.planModel.declarationPic];
            self.declarationPicModel.img_height = [self.declarationPicModel getPlanDetailImageHegiht];
            
            if (self.planModel.showContentFlag.boolValue &&
                [CommonUtils isEqualToNonNull:self.planModel.pic]) {
                NSArray *conditionImageArr = [self.planModel.pic componentsSeparatedByString:@","];
//                NSArray *conditionImageArr = @[@"https://dss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=3880341262,3308316348&fm=26&gp=0.jpg",
//                                                                          @"https://dss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2151136234,3513236673&fm=26&gp=0.jpg",
//                                                                          @"https://dss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3228549874,2173006364&fm=26&gp=0.jpg"];
                if (conditionImageArr.count) {
                    [self.imageDatas removeAllObjects];
                }
                
                [conditionImageArr enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//                    NSString *url = [[ImageDeliverManager sharedInstance] privateImageUrlWithImageName:[NSString stringWithFormat:@"plan/image/%@",conditionImageArr[idx]]];
                    NSString *url = [NSString stringWithFormat:@"plan/image/%@",conditionImageArr[idx]];
                    PlanDetailAnalyseImageModel *model = [[PlanDetailAnalyseImageModel alloc] init];
                    model.url = url;
                    model.image = [[SDImageCache sharedImageCache] imageFromDiskCacheForKey:url];
                    model.img_height = [model getPlanDetailImageHegiht];
                    
                    [self.imageDatas addObject:model];
                }];
            }
            
            /// 加载头部数据
            self.tableHeadView.model = self.planModel;
            self.tableHeadView.isSubscribed = self.isSubscribed;
            
            /// 加载底部栏数据
            //仅未开赛时需要判断是否展示支付
            _needPay = self.planModel.buyFlag.boolValue;
            /// 需判断是否需要粉丝关注
            _needFollow = (self.planModel.type.intValue == 4 && !self.isSubscribed);
            
            if (self.planModel.showContentFlag.boolValue) {
                _needPay = NO;
                _needFollow = NO;
            }
            
            self.payBtn.hidden = !_needPay;
            self.unlockBtn.hidden = !_needFollow;
            
            if (_needPay) {
                NSString *textStr = [NSString stringWithFormat:@"需支付：%@ 飞驰币",self.planModel.price];
                NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:textStr attributes:@{NSFontAttributeName: [UIFont addPingFangSCRegular:13.0], NSForegroundColorAttributeName:RGBCOLORV(0x000000)}];
                [attr addAttributes:@{NSFontAttributeName: kCustomFont(35), NSForegroundColorAttributeName:RGBCOLORV(0xE05047)} range:[textStr rangeOfString:[NSString stringWithFormat:@"%@",self.planModel.price]]];
                self.bottomTitleLabel.attributedText = attr;
            }
            if (_needFollow) {
                self.bottomTitleLabel.attributedText =
                [[NSMutableAttributedString alloc] initWithString:@"粉丝免费" attributes:@{NSFontAttributeName: [UIFont addPingFangSCRegular:13.0], NSForegroundColorAttributeName:RGBCOLORV(0x000000)}];
            }
            if (_needPay || _needFollow) {
                self.bottomView.hidden = NO;
                self.contentTableView.contentInset = UIEdgeInsetsMake(0, 0, (kBottomSafeArea + 44.0), 0);
            }else {
                self.bottomView.hidden = YES;
                self.contentTableView.contentInset = kTableViewDetailtContentInset;
            }
            
            [self.contentTableView reloadData];
            
            if ([CommonUtils isEqualToNonNull:self.planModel.userId.stringValue]) {
                /// 获取该方案作者的其他方案列表
                [self loadPlansList:sender];
            }
            if (self.planModel.commentAreaType != 0) {
                self.contentTableView.mj_footer.hidden = NO;
                /// 获取该方案评论列表
                [self loadCommentList:sender];
            }else {
                self.contentTableView.mj_footer.hidden = YES;
            }
        }
    }];
}

-(void)loadPlansList:(id)sender {
    @weakify(self);
    [ESNetworkService expertPlanListWithPage:1
                                    PageSize:4
                                       Field:self.planModel.field
                                        Type:@""
                                    ExpertId:self.planModel.userId.integerValue
                                   ForExpert:0
                                    Response:^(id dict, ESError *error) {
        NSArray*array = nil;
        if (dict&&[dict[@"code"] integerValue] == 0) {
            @strongify(self);
            id da = dict[@"data"];
            id data = da[@"data"];
            if ([data isKindOfClass:[NSString class]]) {
                array = [data objectFromJSONString];
            }
            
            if ([data isKindOfClass:[NSArray class]]) {
                array = data;
            }
            [self.dataSource removeAllObjects];
            
            for (NSDictionary *dic in array) {
                PlanModel *model = [PlanModel mj_objectWithKeyValues:dic];
                NSMutableArray *arrM = [NSMutableArray arrayWithCapacity:0];
                NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
                for (NSDictionary*dic_info in matchInfo) {
                    MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
                    [arrM addObject:tag];
                }
                model.matchInfoArr = [arrM copy];
                
                if (self.dataSource.count< 3 &&
                    model.planId.longLongValue != self.planId) {
                    [self.dataSource addObject:model];
                }
            }
            [self.contentTableView reloadData];
        }
    }];
}

/// 获取评论列表
-(void)loadCommentList:(id)sender {
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
    @weakify(self)
    [ESNetworkService planDetailCommentList:self.planId Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
        [self.contentTableView endAllFreshing];
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            PlanCommentModel *model = [PlanCommentModel mj_objectWithKeyValues:dict[@"data"]];
            if (model.content.count) {
                if (self.currentPage == 1 && self.commentData.count) {
                    [self.commentData removeAllObjects];
                }
                [self.commentData addObjectsFromArray:model.content];
            }
            [self.contentTableView updataFreshFooter:(self.commentData.count < kPageSize && self.currentPage >= model.totalPages)];
        }
        self.contentTableView.mj_footer.hidden = !self.commentData.count;
        if ([sender isKindOfClass:[UIButton class]]) {
            [self.contentTableView reloadSections:[[NSIndexSet alloc] initWithIndex:self.contentTableView.numberOfSections - 1] withRowAnimation:(UITableViewRowAnimationNone)];
        }else
            [self.contentTableView reloadData];
    }];
}

//-(void)loadImageWithStr:(NSString*)imgStr {
//
//    _analyseHeight = 0.0;
//    NSArray *conditionImageArr = [imgStr componentsSeparatedByString:@","];
////    NSArray *conditionImageArr = @[@"https://dss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2496571732,442429806&fm=26&gp=0.jpg",
////                                   @"https://dss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=3206689113,2237998950&fm=26&gp=0.jpg",
////                                   @"https://dss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3228549874,2173006364&fm=26&gp=0.jpg"];
//    NSInteger count = conditionImageArr.count;
//    /// 无图片返回
//    if (!count) {
////        [self changeFrames];
//        return;
//    }
//
//    /// 预排 文本高度+图片预高度
//    CGFloat mH = 45.0 + _height + 8;
//    CGFloat height = mH + (self.defaultImageHegiht + 5) *count + 10;
//
//    /// 创建图片，初始状态为默认高度的占位图
//    NSArray <PlanDetailAnalyseImageModel *>*imageDatas = self.imageDatas.copy;
//    for (int i = 0;  i < count; i++) {
//        PlanDetailAnalyseImageModel *model;
//        if (i < imageDatas.count &&
//            [[imageDatas objectAtIndex:i] isKindOfClass:[PlanDetailAnalyseImageModel class]]) {
//            model = [imageDatas objectAtIndex:i];
//        }else
//            model = [[PlanDetailAnalyseImageModel alloc] init];
//
//        model.index = i;
//
//        //        NSString *url = conditionImageArr[i];
//        NSString *url = [[ImageDeliverManager sharedInstance] privateImageUrlWithImageName:[NSString stringWithFormat:@"plan/image/%@",conditionImageArr[i]]];
//
//        model.url = url;
//        model.image = GetImage(@"无内容");
//        model.height = self.defaultImageHegiht;
//
//        UIImageView *imgV;
//        if (model.imageView) {
//            imgV = model.imageView;
//        }else
//            imgV = [UIImageView new];
//
//        imgV.frame = CGRectMake(15, mH +  ((self.defaultImageHegiht + 5) * i), kScreen_Width - 30, self.defaultImageHegiht);
//        [self.analyseView addSubview:imgV];
//
//        model.imageView = imgV;
//
//        imgV.image = model.image;
//        imgV.userInteractionEnabled = NO;
//        imgV.backgroundColor = ColorGrayBack;
//        imgV.contentMode = UIViewContentModeScaleAspectFill;
//        imgV.tag = 2000 + model.index;
//
//        if (i < imageDatas.count) {
//            [self.imageDatas replaceObjectAtIndex:i withObject:model];
//        }else {
//            [self.imageDatas addObject:model];
//        }
//    }
//
//    /// 下载图片并缓存
//    dispatch_group_t group = dispatch_group_create();
//    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
//    [self.imageDatas enumerateObjectsUsingBlock:^(PlanDetailAnalyseImageModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        dispatch_group_async(group, queue, ^{
//            dispatch_group_enter(group);
//            [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:obj.url] options:0 progress:nil completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
//                if (image && [obj.url isEqualToString:imageURL.absoluteString]) {
//                    obj.imageView.image = image;
//
//                    CGFloat imageW = kScreen_Width - 30.0;
//                    CGFloat imageYW = CGImageGetWidth(image.CGImage);
//                    CGFloat imageH = imageW / (imageYW / CGImageGetHeight(image.CGImage));
//
//                    WTCLog(@"%.2f",imageH);
//
//                    obj.height = imageH;
//                }
//
//                dispatch_group_leave(group);
//            }];
//        });
//    }];
//    @weakify(self)
//    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
//        @strongify(self)
//        [self setNeedsLayout];
//
//        [self changeFrames];
//    });
//}

#pragma mark -
- (void)configBasketBallData:(PlanModel *)model {
    
    for (MatchModel *matchModel in model.matches) {
        /// 胜负
        NSString *winLose = matchModel.odds[@"sf"];
        /// 让分
        NSString *concedeWinLose = matchModel.odds[@"rf"];
        /// 大小分
        NSString *dxfWinLose = matchModel.odds[@"dxf"];
        
        //专家方案选择结果(因2串1方案存在目前结构为数组)
        self.selectData = matchModel.selects;
        
        matchModel.winLose = [winLose objectFromJSONString];
        NSString*p_status = matchModel.winLose[@"p_status"];
        matchModel.sfAllow = [p_status isEqualToString:@"Selling"];
        for (int i = 0; i < 2; i++) {
            SelectedMatchModel*modelS = [SelectedMatchModel new];
            modelS.selected = NO;
            modelS.matchDateNum = matchModel.matchDateNum;
            modelS.selectType = @"sf";
            switch (i) {
                case 0: {
                modelS.title = @"客胜";
                modelS.odds = matchModel.winLose[@"a"];
                modelS.selectOdds = @"a";
                
                }
                    break;
                case 1: {
                modelS.title = @"主胜";
                modelS.odds = matchModel.winLose[@"h"];
                modelS.selectOdds = @"h";
                }
                    break;
                    
                default:
                    break;
            }
            for (SelectResult *res in self.selectData) {
                if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
                    modelS.selected = YES;
                }
            }
            [matchModel.sfArray addObject:modelS];
        }
        
        matchModel.concedeWinLose = [concedeWinLose objectFromJSONString];
        matchModel.rangNumStr = matchModel.concedeWinLose[@"fixedodds"];
        NSString *p_status_rq = matchModel.concedeWinLose[@"p_status"];
        matchModel.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
        for (int i = 0; i < 3; i++) {
            SelectedMatchModel*modelS = [SelectedMatchModel new];
            modelS.selected = NO;
            modelS.matchDateNum = matchModel.matchDateNum;
            modelS.selectType = @"rf";
            switch (i) {
                case 0:
                {
                modelS.title = @"让分客胜";
                modelS.odds = matchModel.concedeWinLose[@"a"];
                modelS.selectOdds = @"a";
                }
                    break;
                case 1:
                {
                modelS.title = @"让分主胜";
                modelS.odds = matchModel.concedeWinLose[@"h"];
                modelS.selectOdds = @"h";
                }
                    break;
                    
                default:
                    break;
            }
            for (SelectResult *res in self.selectData) {
                if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
                    modelS.selected = YES;
                }
            }
            [matchModel.rqsfArray addObject:modelS];
        }
        
        matchModel.dxfWinLose = [dxfWinLose objectFromJSONString];
        matchModel.dxfNumStr = matchModel.dxfWinLose[@"fixedodds"];
        NSString*p_status_dxf = matchModel.dxfWinLose[@"p_status"];
        matchModel.dxfAllow = [p_status_dxf isEqualToString:@"Selling"];
        
        for (int i = 0; i < 3; i++) {
            SelectedMatchModel*modelS = [SelectedMatchModel new];
            modelS.selected = NO;
            modelS.matchDateNum = matchModel.matchDateNum;
            modelS.selectType = @"dxf";
            switch (i) {
                case 0:
                {
                modelS.title = @"大分";
                modelS.odds = matchModel.dxfWinLose[@"h"];
                modelS.selectOdds = @"h";
                }
                    break;
                case 1:
                {
                modelS.title = @"小分";
                modelS.odds = matchModel.dxfWinLose[@"l"];
                modelS.selectOdds = @"l";
                }
                    break;
                    
                default:
                    break;
            }
            for (SelectResult*res in self.selectData) {
                if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
                    modelS.selected = YES;
                }
            }
            [matchModel.dxfArray addObject:modelS];
        }
    }
    self.planModel = model;
}

- (void)configFootBallData:(PlanModel *)model {
    
    for (MatchModel *matchModel in model.matches) {
        NSString*winLose = matchModel.odds[@"winLose"];
        NSString*concedeWinLose = matchModel.odds[@"concedeWinLose"];
        //专家方案选择结果(因2串1方案存在目前结构为数组)
        self.selectData = matchModel.selects;
        
        matchModel.winLose = [winLose objectFromJSONString];
        NSString *p_status = matchModel.winLose[@"p_status"];
        matchModel.sfAllow = [p_status isEqualToString:@"Selling"];
        for (int i = 0; i < 3; i++) {
            SelectedMatchModel *modelS = [SelectedMatchModel new];
            modelS.selected = NO;
            modelS.matchDateNum = matchModel.matchDateNum;
            modelS.selectType = @"winLose";
            switch (i) {
                case 0:
                {
                modelS.title = @"胜";
                modelS.odds = matchModel.winLose[@"h"];
                modelS.selectOdds = @"h";
                }
                    break;
                case 1:
                {
                modelS.title = @"平";
                modelS.odds = matchModel.winLose[@"d"];
                modelS.selectOdds = @"d";
                }
                    break;
                case 2:
                {
                modelS.title = @"负";
                modelS.odds = matchModel.winLose[@"a"];
                modelS.selectOdds = @"a";
                }
                    break;
                    
                default:
                    break;
            }
            for (SelectResult*res in self.selectData) {
                if ([res.type isEqualToString:modelS.selectType] &&
                    [res.result isEqualToString:modelS.selectOdds]) {
                    modelS.selected = YES;
                }
            }
            [matchModel.sfArray addObject:modelS];
        }
        
        matchModel.concedeWinLose = [concedeWinLose objectFromJSONString];
        matchModel.rangNumStr = matchModel.concedeWinLose[@"fixedodds"];
        NSString*p_status_rq = matchModel.concedeWinLose[@"p_status"];
        matchModel.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
        for (int i = 0; i<3; i++) {
            SelectedMatchModel*modelS = [SelectedMatchModel new];
            modelS.selected = NO;
            modelS.matchDateNum = matchModel.matchDateNum;
            modelS.selectType = @"concedeWinLose";
            switch (i) {
                case 0:
                {
                modelS.title = @"胜";
                modelS.odds = matchModel.concedeWinLose[@"h"];
                modelS.selectOdds = @"h";
                }
                    break;
                case 1:
                {
                modelS.title = @"平";
                modelS.odds = matchModel.concedeWinLose[@"d"];
                modelS.selectOdds = @"d";
                }
                    break;
                case 2:
                {
                modelS.title = @"负";
                modelS.odds = matchModel.concedeWinLose[@"a"];
                modelS.selectOdds = @"a";
                }
                    break;
                    
                default:
                    break;
            }
            for (SelectResult*res in self.selectData) {
                if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
                    modelS.selected = YES;
                }
            }
            [matchModel.rqsfArray addObject:modelS];
        }
    }
    self.planModel = model;
}

#pragma mark - view layout
-(void)setupViews {
    self.navigationItem.titleView = self.naviTitleLabel;
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem createBackBarItemWithImage:@"expert_detail_back" withHightImg:nil target:self action:@selector(back:)];
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem createPostionBarItemWithImage:@"expert_detail_share" withHightImg:nil horizontalAlignment:(CYBarButtonItemPositionRight) target:self action:@selector(share:)];
    
    self.contentTableView.backgroundColor  = ColorDefaultGrayBackground;
    self.contentTableView.delegate = self;
    self.contentTableView.dataSource = self;
    
    self.contentTableView.estimatedSectionFooterHeight = 150.0;
    self.contentTableView.estimatedSectionHeaderHeight = 0;
    
    [self.contentTableView registerNibCell:[PlanDetailHeadDescTableCell class]];
    [self.contentTableView registerNibCell:[ExpertDetailHistoryPlanTableViewCell class]];
    [self.contentTableView registerNibCell:[PlanDetailTitleTableCell class]];
    [self.contentTableView registerCell:[PlanCommentCell class]];
    [self.contentTableView registerNibCell:[PlanGameInfoTableCell class]];
    [self.contentTableView registerNibCell:[PlanDetailAnalyseImageTableCell class]];
    [self.contentTableView registerNibCell:[PlanDetailAnalyseTableViewCell class]];
    [self.contentTableView registerNibCell:[PlanDetailAnalyseLockedTableCell class]];
    
    [self.view bringSubviewToFront:self.bottomView];
    self.bottomView.hidden = YES;
    self.contentTableView.contentInset = kTableViewDetailtContentInset;
    
    if (@available(iOS 11.0, *)) {
        self.contentTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self dropShadowWithOffset:CGSizeMake(0, -1.0) radius:25.0 color:[UIColor.grayColor colorWithAlphaComponent:1.0] opacity:0.3];
    
    /// 背景图
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectOffset(self.contentTableView.bounds, 0, -self.contentTableView.bounds.size.height)];
        bgView.contentMode = UIViewContentModeScaleAspectFill;
        bgView.image = [UIImage imageNamed:@"head_bg_single"];
        [self.contentTableView insertSubview:bgView atIndex:0];
    });
}

- (void)configureImageCell:(PlanDetailAnalyseImageTableCell *)cell indexPath:(NSIndexPath *)indexPath {
    
    if (!cell.model.image) {
        [self downloadImage:cell.model.url forIndexPath:indexPath];
    }else {
        WTCLog(@"configureImageCell - %@ - %@",cell.model.url, @(indexPath.row));
        cell.imageIV.image = cell.model.image;
    }
}

- (void)downloadImage:(NSString *)imageURL forIndexPath:(NSIndexPath *)indexPath {
    
    NSString *image_url = imageURL;
    if (![imageURL hasPrefix:@"http"]) {
        image_url = [[ImageDeliverManager sharedInstance] privateImageUrlWithImageName:imageURL];
    }
    WTCLog(@"downloadImage - %@ - %@ - %@",imageURL ,image_url ,@(indexPath.row));
    [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:[NSURL URLWithString:image_url] options:SDWebImageDownloaderUseNSURLCache progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
        //nothing to do
    } completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, BOOL finished) {
        if (!error) {
            if ([imageURL isEqualToString:self.declarationPicModel.url]) {
                self.declarationPicModel.image = image;
            }else {
                [self.imageDatas enumerateObjectsUsingBlock:^(PlanDetailAnalyseImageModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    if ([imageURL isEqualToString:obj.url]) {
                        obj.image = image;
                        obj.img_height = [obj getPlanDetailImageHegiht];
                        *stop = YES;
                    }
                }];
            }
            [[SDImageCache sharedImageCache] storeImage:image forKey:imageURL toDisk:YES completion:^{
                WTCLog(@"SDImageCache sharedImageCache");
            }];
//            [[SDImageCache sharedImageCache] storeImageToMemory:image forKey:imageURL];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.contentTableView reloadData];
            });
        }
    }];
}



- (void)dropShadowWithOffset:(CGSize)offset
                      radius:(CGFloat)radius
                       color:(UIColor *)color
                     opacity:(CGFloat)opacity {
    
    // Creating shadow path for better performance
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, self.bottomView.bounds);
    self.bottomView.layer.shadowPath = path;
    CGPathCloseSubpath(path);
    CGPathRelease(path);
    
    self.bottomView.layer.shadowColor = color.CGColor;
    self.bottomView.layer.shadowOffset = offset;
    self.bottomView.layer.shadowRadius = radius;
    self.bottomView.layer.shadowOpacity = opacity;
    
    // Default clipsToBounds is YES, will clip off the shadow, so we disable it.
    self.bottomView.clipsToBounds = NO;
}

- (void)tapImageWith:(NSIndexPath *)indexPath {

    if (indexPath.section) {
        self.browserVc = [[HZPhotoBrowser alloc] init];
        
        NSMutableArray *urls = @[].mutableCopy;
        [self.imageDatas enumerateObjectsUsingBlock:^(PlanDetailAnalyseImageModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [urls addObject:obj.url];
        }];
        //方案内容图片
        self.browserVc.imageArray = urls.copy;
        self.browserVc.imageCount = urls.count;

        PlanDetailAnalyseImageTableCell *cell = [self.contentTableView cellForRowAtIndexPath:indexPath];
        if ([self.imageDatas containsObject:cell.model]) {
            self.browserVc.currentImageIndex = (int)[self.imageDatas indexOfObject:cell.model];
        }else {
            self.browserVc.currentImageIndex = 0;
        }
        
    }else {
        self.browserVc = [[HZPhotoBrowser alloc] init];
        
        self.browserVc.imageArray = @[self.planModel.declarationPic];
        self.browserVc.imageCount = 1;
        self.browserVc.currentImageIndex = 0;
    }
    
    dispatch_main_async_safe(^{
        [self.browserVc show:self];
    });
}

#pragma mark - scorllerDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    self.offsetY = scrollView.contentOffset.y;
    [self showNavi];
}

- (void)showNavi {
    CGFloat alpha = self.offsetY / NavBarHeight;

    self.navigationController.navigationBar.translucent = (alpha >= 1.0f) ? NO : YES;
    UIImage *image = [UIImage imageNamed:@"head_bg_single"];
    if (@available(iOS 13.0, *)) {
        UINavigationBarAppearance *barApp = self.navigationController.navigationBar.standardAppearance;
        barApp.backgroundImage = [UIImage changeAlphaOfImageWith:alpha withImage:image];
        
        self.navigationController.navigationBar.standardAppearance = barApp;
//        self.navigationController.navigationBar.scrollEdgeAppearance = barApp;
    }else {
        [self.navigationController.navigationBar setBackgroundImage:[UIImage changeAlphaOfImageWith:alpha withImage:image] forBarMetrics:UIBarMetricsDefault];
    }
}

#pragma mark - uitableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSInteger sections = 3;
    if (self.dataSource.count) sections += 1;
    if (self.planModel.commentAreaType != 0) {
        return (++ sections);
    }
    return  sections;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        NSInteger rows = 1;
        if ([CommonUtils isEqualToNonNull:self.planModel.declaration]) {
            rows += 1;
        }
        if ([CommonUtils isEqualToNonNull:self.planModel.declarationPic]) {
            rows += 1;
        }
        return rows;
    }
    if (section == 1) {
        return self.planModel.matches.count;
    }
    if (section == 2) {
        if (self.planModel.showContentFlag.boolValue) {
            if ([CommonUtils isEqualToNonNull:self.planModel.content]) {
                return self.imageDatas.count + 1;
            }
            /// 专家分析
            return self.imageDatas.count;
        }
        /// 方案解锁
        return 1;
    }
    if (section == 3 && self.dataSource.count) {
        /// 专家其他方案
        return self.dataSource.count;
    }
    /// 评论
    return self.commentData.count?:0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            /// 方案标题
            PlanDetailTitleTableCell *cell = [tableView dequeueReusableCell:[PlanDetailTitleTableCell class]];
            
            cell.model = self.planModel;
            
            return cell;
        }else if (indexPath.row == 1 && [CommonUtils isEqualToNonNull:self.planModel.declaration]) {
            /// 专家宣言
            PlanDetailHeadDescTableCell *cell = [tableView dequeueReusableCell:[PlanDetailHeadDescTableCell class]];
            
            cell.descStr = self.planModel.declaration;
            
            return cell;
        }else {
            PlanDetailAnalyseImageTableCell *cell = [tableView dequeueReusableCell:[PlanDetailAnalyseImageTableCell class]];
            
            cell.model = self.declarationPicModel;
            [self configureImageCell:cell indexPath:indexPath];
            
            return cell;
        }
    }
    if (indexPath.section == 1 && self.planModel.matches.count) {
        PlanGameInfoTableCell *cell = [tableView dequeueReusableCell:[PlanGameInfoTableCell class]];
        
        [cell configPlanDetailGameInfoView:self.planModel atIndexPath:indexPath];
        
        return cell;
    }
    if (indexPath.section == 2) {
        if (self.planModel.showContentFlag.boolValue) {
            
            if (indexPath.row == 0 && [CommonUtils isEqualToNonNull:self.planModel.content]) {
                PlanDetailAnalyseTableViewCell *cell = [tableView dequeueReusableCell:[PlanDetailAnalyseTableViewCell class]];
                cell.analyseStr = self.planModel.content;
                return cell;
            }
            
            PlanDetailAnalyseImageTableCell *cell = [tableView dequeueReusableCell:[PlanDetailAnalyseImageTableCell class]];
            if ([CommonUtils isEqualToNonNull:self.planModel.content]) {
                cell.model = [self.imageDatas objectAtIndex:indexPath.row - 1];
            }else
                cell.model = [self.imageDatas objectAtIndex:indexPath.row];
            
            [self configureImageCell:cell indexPath:indexPath];
            
            return cell;
        }
        
        PlanDetailAnalyseLockedTableCell *cell = [tableView dequeueReusableCell:[PlanDetailAnalyseLockedTableCell class]];
        
        cell.delegate = self;
        cell.needPay = _needPay;
        cell.needFollow = _needFollow;
        cell.model = self.planModel;
        
        return cell;
    }
    if (indexPath.section == 3 && self.dataSource.count) {
        ExpertDetailHistoryPlanTableViewCell *cell = [tableView dequeueReusableCell:[ExpertDetailHistoryPlanTableViewCell class]];
        cell.cellType = 1;
        if (indexPath.row < self.dataSource.count) cell.model = [self.dataSource objectAtIndex:indexPath.row];
        
        return cell;
    }
    PlanCommentCell *cell = [tableView dequeueReusableCell:[PlanCommentCell class]];
    if (!cell) {
        cell = [[PlanCommentCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:NSStringFromClass([PlanCommentCell class])];
    }
    cell.hideSeperatorLine = (indexPath.row == tableView.numberOfSections - 1);
    if (indexPath.row < self.commentData.count) {
        [cell configCellWithModel:[self.commentData objectAtIndex:indexPath.row]];
    }
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    id cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (indexPath.section == 1 && [cell isKindOfClass:[PlanGameInfoTableCell class]]) {
        MatchModel *model = [(PlanGameInfoTableCell *)cell matchModel];
        [self matchCardClick:model];
    }
    if ((indexPath.section == 0 || indexPath.section == 2) &&
        [cell isKindOfClass:[PlanDetailAnalyseImageTableCell class]]) {
        [self tapImageWith:indexPath];
    }
    if (indexPath.section == 3 && [cell isKindOfClass:[ExpertDetailHistoryPlanTableViewCell class]]) {
        PlanModel*model = [(ExpertDetailHistoryPlanTableViewCell *)cell model];
        CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
        vc.back = YES;
        vc.planId = [model.planId integerValue];
        vc.sourcePage = @"专家主页页面";
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (indexPath.row == 1 && [CommonUtils isEqualToNonNull:self.planModel.declaration]) {
            return UITableViewAutomaticDimension;
        }
        if (indexPath.row && [CommonUtils isEqualToNonNull:self.declarationPicModel.url]) {
            if (!self.declarationPicModel.image) {
                return 200.0;
            }
            return self.declarationPicModel.img_height;
        }
        return UITableViewAutomaticDimension;
    }
    if (indexPath.section == 2 && self.imageDatas.count) {
        if ([CommonUtils isEqualToNonNull:self.planModel.content] && indexPath.row == 0) {
            return UITableViewAutomaticDimension;
        }
        PlanDetailAnalyseImageModel *model;
        if ([CommonUtils isEqualToNonNull:self.planModel.content]) {
            model = [self.imageDatas objectAtIndex:indexPath.row - 1];
        }else {
            model = [self.imageDatas objectAtIndex:indexPath.row];
        }
        
        if (!model.image) {
            return 200.0;
        }
        return model.img_height;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return kPlanTableHeadHeight;
    }
    if (section == 1) {
        return CGFLOAT_MIN;
    }
    if (section == 2) {
        if (self.planModel.showContentFlag.boolValue) {
            if ([CommonUtils isEqualToNonNull:self.planModel.content] || self.imageDatas.count) {
                return 40.0;
            }
        }
        return CGFLOAT_MIN;
    }
    
    return 40;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return self.tableHeadView;
    }
    if (section == 1) {
        return [UIView new];
    }
    if (section == 2) {
        if (self.planModel.showContentFlag.boolValue) {
            if ([CommonUtils isEqualToNonNull:self.planModel.content] ||
                self.imageDatas.count) {
                
                UIView *wrapView = [UIView new];
                wrapView.backgroundColor = UIColor.whiteColor;
                
                UIView *line = [[UIView alloc] init];
                [wrapView addSubview:line];
                line.backgroundColor = [RGBCOLORV(0xEDEDED) colorWithAlphaComponent:0.4];
                [line mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.right.equalTo(wrapView);
                    make.bottom.equalTo(wrapView.mas_bottom).offset(-8.0);
                    make.height.offset(1.0);
                }];
                
                UILabel *label = [[UILabel alloc] init];
                [wrapView addSubview:label];
                
                label.text = @"专家分析";
                label.textColor = RGBCOLORV(0x282828);
                label.font = [UIFont addPingFangSCMedium:13.0];
                [label sizeToFit];
                
                [label mas_makeConstraints:^(MASConstraintMaker *make) {
                    make.left.equalTo(wrapView.mas_left).offset(15.0);
                    make.top.equalTo(wrapView.mas_top);
                    make.bottom.equalTo(line.mas_top);
                }];
                
                return wrapView;
            }
        }
        return [UIView new];
    }
    
    CYCommonListHeaderView *headView = [CYCommonListHeaderView shareInstance];
    
    if (section == 3 && self.dataSource.count) {// 其他方案
        headView.titleLabel.text = @"该专家近期其他方案";
    }else {
        headView.titleLabel.text = @"全部评论";
        if (self.planModel.forbidComment != 1) {
            CYButton *commentBtn = [CYButton buttonWithType:UIButtonTypeCustom]
            .backgroundPrams(RGBCOLORV(0xF4F4F4), nil, UIControlStateNormal)
            .titlePrams(@"我也来评论",
                        [UIFont addPingFangSCRegular:14.0],
                        RGBCOLORV(0xA8A8A8),
                        UIControlStateNormal)
            .stylePrams(UIRectCornerAllCorners,
                        2.0,
                        nil,
                        0.0)
            .actionPrams(self,
                         @selector(commentClick),
                         UIControlEventTouchUpInside);
            [headView.contentView addSubview:commentBtn];
            [commentBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.lessThanOrEqualTo(headView.titleLabel.mas_right).offset(8.0);
                make.centerY.equalTo(headView.contentView);
                make.right.equalTo(headView.contentView).offset(-15.0);
                make.height.equalTo(headView.contentView.mas_height).multipliedBy(0.75);
                make.width.equalTo(commentBtn.mas_height).multipliedBy(4.0);
            }];
        }
    }
    
    return headView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }
    if (section == 1) {
        return CGFLOAT_MIN;
    }
    if (section == 2) {
        return 30.0;
    }
    if (section == 3) {
        if (self.dataSource.count) {/// 查看更多评论
            return 50.0;
        }else {/// 评论
            return (self.planModel.commentAreaType != 0)?(tableView.width/5+10):CGFLOAT_MIN;
        }
    }
    if (section == 4) {
        return ((self.planModel.commentAreaType != 0) && !self.commentData.count)?(tableView.width/5+10):CGFLOAT_MIN;
    }
    return 10.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == 2) {
        UIView *wrapView = [[UIView alloc] init];
        
        UILabel *tipsLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 30)];
        tipsLabel.text = @"分析仅供参考，如需购彩请前往彩票店";
        tipsLabel.textColor = RGBCOLORV(0xA8A8A8);
        tipsLabel.backgroundColor = ColorGrayBack;
        tipsLabel.textAlignment = NSTextAlignmentCenter;
        tipsLabel.font = [UIFont addPingFangSCRegular:10.0];
        [wrapView addSubview:tipsLabel];
        [tipsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(wrapView);
            make.height.offset(30.0);
        }];
        return wrapView;
    }
    if (section == 3 && self.dataSource.count) {/// 查看更多
        UIView *wrapView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 50)];
        wrapView.backgroundColor = tableView.backgroundColor;
        
        CYButton *moreBtn = [CYButton buttonWithType:UIButtonTypeCustom];
        moreBtn.backgroundColor = UIColor.whiteColor;
        moreBtn.frame = CGRectMake(0, 0, wrapView.width, 40);
        [moreBtn setTitle:@"查看更多" forState:UIControlStateNormal];
        [moreBtn setTitleColor:RGBCOLORV(0xE05047) forState:UIControlStateNormal];
        moreBtn.titleLabel.font = [UIFont addPingFangSCRegular:12.0];
        
        [moreBtn addTarget:self action:@selector(toTheMore:) forControlEvents:UIControlEventTouchUpInside];
        [wrapView addSubview:moreBtn];
        
        return wrapView;
    }
    if (self.planModel.commentAreaType != 0 &&
        !self.commentData.count &&
        (section == 4 || (section == 3 && !self.dataSource.count))) {
        PlanEmptyCommentView *emptyView = [PlanEmptyCommentView shareInstance];
        emptyView.frame = CGRectMake(0, 0, tableView.width, tableView.width/5+10);
        return emptyView;
    }
    return [UIView new];
}

#pragma mark - PaperCommentViewDelegate
- (void)sendBtnClick:(id)sender content:(NSString *)content {
    //调用文章评论接口
    @weakify(self)
    [ESNetworkService planDetailComment:self.planId content:content Response:^(id dict, ESError *error) {
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            self.commentView.textView.text = @"";
            [self.commentView hidePaperCommentView];
            [self loadCommentList:sender];
        } else {
            [self.commentView hidePaperCommentView];
        }
    }];
}

#pragma mark - PlanDetailHeadDelegate
/// 用户关注/取关
- (void)headView:(PlanDetailHeadView *)head clickToFollow:(CYButton *)sender {
    [self follow:sender type:1];
}

/// 点击用户头像
- (void)headView:(PlanDetailHeadView *)head clickToAvatar:(id _Nullable)sender {
    [self toTheMore:nil];
}

#pragma mark - PlanDetailAnalyseLockedTableCellDelegate
- (void)lockedCell:(PlanDetailAnalyseLockedTableCell *)lockedCell clickToBuy:(id)sender {
    [self clickToPay:sender];
}

- (void)lockedCell:(PlanDetailAnalyseLockedTableCell *)lockedCell clickToFollow:(id)sender {
    [self follow:(UIButton *)sender type:0];
}

#pragma mark - lazy init
- (UILabel *)naviTitleLabel {
    if (!_naviTitleLabel) {
        _naviTitleLabel = [[UILabel alloc] init];
        _naviTitleLabel.text = @"方案详情";
        _naviTitleLabel.textColor = UIColor.whiteColor;
        _naviTitleLabel.font = [UIFont addPingFangSCRegular:19];
        _naviTitleLabel.textAlignment = NSTextAlignmentCenter;
        [_naviTitleLabel sizeToFit];
    }return _naviTitleLabel;
}

- (PlanDetailHeadView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [PlanDetailHeadView shareInstance];
        _tableHeadView.delegate = self;
        _tableHeadView.frame = CGRectMake(0, 0, kScreen_Width, kPlanTableHeadHeight);
    }return _tableHeadView;
}

- (PaperCommentView *)commentView {
    if (!_commentView) {
        _commentView = [[PaperCommentView alloc] init];
        _commentView.hidden = YES;
        _commentView.delegate = self;
        _commentView.placeHolderLabel.text = @"说说你的看法";
        _commentView.fullScreenBtn.hidden = YES;
        [self.view addSubview:_commentView];
        [_commentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.top.equalTo(self.view);
        }];
    }
    return _commentView;
}


@end
