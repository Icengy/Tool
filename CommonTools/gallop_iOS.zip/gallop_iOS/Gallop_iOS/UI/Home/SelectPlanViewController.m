//
//  SelectPlanViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SelectPlanViewController.h"
#import "MatchBasketBallTableViewCell.h"
#import "MatchDetailViewController.h"
#import "SelectedMatchModel.h"
#import "MatchTableViewCell.h"
#import "CreatPlanViewController.h"

#import "MatchModel.h"

@interface SelectPlanViewController ()

@property (nonatomic,strong) UIView*footerView;
@property (nonatomic,strong) CYButton*selectB;
@property (nonatomic,strong) CYButton*confirmB;
@property (nonatomic,strong) UILabel*detailL;
@property (nonatomic,strong) NSMutableArray*selectMatchArr;
@property (nonatomic,assign) BOOL showSelect;
@property (nonatomic, assign) NSInteger field;//0:足球 1:篮球
@property (nonatomic,strong) NSMutableArray*dataSource_basket;
@property (nonatomic,strong) NSMutableArray*selectMatchArr_basket;

@property (nonatomic,assign) float bouns;
@property (nonatomic,assign) float bouns_basket;
@property (nonatomic,strong) UILabel*benifitL;
@property (nonatomic,assign) CGFloat benefit_0;
@property (nonatomic,assign) CGFloat benefit_1;
@property (nonatomic,strong) NSArray*selected_0;
@property (nonatomic,strong) NSArray*selected_1;

@end

@implementation SelectPlanViewController

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.field = 0;
    
    self.selectMatchArr = [NSMutableArray arrayWithCapacity:0];
    self.selectMatchArr_basket = [NSMutableArray arrayWithCapacity:0];
    self.dataSource_basket = [NSMutableArray arrayWithCapacity:0];
    self.selected_0  =[NSArray array];
    self.selected_1 = [NSArray array];
    
    [self initWithSubViews];
    
    [self loadData:nil];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.footerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.equalTo(self.view);
        make.height.offset(40.0+kBottomSafeArea);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).offset(NavBarHeight);
        make.left.right.equalTo(self.view);
        make.bottom.equalTo(self.footerView.mas_top);
    }];
}

- (void)initWithSubViews{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkLegal) name:kSelectMatchMessageNotification object:nil];
    //    self.navigationItem.titleView = self.switchView;
    self.navigationItem.title = @"选择比赛";
    
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.footerView];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.placeHolderView.hidden = YES;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.selectB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.footerView).offset(10);
        make.left.mas_equalTo(self.footerView).offset(15);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn"] forState:UIControlStateNormal];
    [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn_seleted"] forState:UIControlStateSelected];
    
    [self.selectB addTarget:self action:@selector(onlyselectd:) forControlEvents:UIControlEventTouchUpInside];
    [self.detailL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.selectB.mas_right).offset(5);
        make.centerY.mas_equalTo(self.selectB);
    }];
    UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onlyselectd:)];
    [self.detailL addGestureRecognizer:tap];
    self.detailL.userInteractionEnabled = YES;
    [self.confirmB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.top.mas_equalTo(self.footerView).offset(0);
        make.width.mas_equalTo(Adapt(85));
        make.height.mas_equalTo(40);
    }];
    [self.confirmB addTarget:self action:@selector(confirm:) forControlEvents:UIControlEventTouchUpInside];
    self.detailL.text = @"已选项";
    [self.benifitL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.confirmB);
        make.right.mas_equalTo(self.confirmB.mas_left).offset(-15);
    }];
    [self checkLegal];
}

#pragma mark -
- (void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    [ESNetworkService getPlanInitWithResponse:^(id dict, ESError *error) {
        [self endAllFreshing:self.tableView];
        
        if (dict &&
            [[dict objectForKey:@"code"] integerValue] == 0) {
            NSDictionary *data = [dict objectForKey:@"data"];
            self.field = [[data objectForKey:@"field"] integerValue] - 1;
            NSArray *matchs = [data objectForKey:@"matches"];
            if (self.field) {
                [self handlebasketballData:matchs];
            }else {
                [self handlefootballData:matchs];
            }
        }
    }];
}

- (void)handlefootballData:(NSArray *)data {
    if (!QM_IS_ARRAY_NIL(data)) {
        NSMutableArray*dateA = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray*matchA = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray*dateShowA = [NSMutableArray arrayWithCapacity:0];
        for (NSDictionary*dayDic in data) {
            NSMutableArray *dayMatchArr = [NSMutableArray arrayWithCapacity:0];
            [dateA addObject:dayDic[@"date"]];
            [dateShowA addObject:@"1"];
            NSArray*list = dayDic[@"list"];
            if (!QM_IS_ARRAY_NIL(list)) {
                for (NSDictionary*matchDic in list) {
                    MatchModel*model = [MatchModel mj_objectWithKeyValues:matchDic];
                    NSString*winLose = matchDic[@"odds"][@"winLose"];
                    NSString*concedeWinLose = matchDic[@"odds"][@"concedeWinLose"];
                    
                    model.winLose = [winLose objectFromJSONString];
                    model.concedeWinLose = [concedeWinLose objectFromJSONString];
                    model.rangNumStr = model.concedeWinLose[@"fixedodds"];
                    NSString*p_status_rq = model.concedeWinLose[@"p_status"];
                    NSString*p_status = model.winLose[@"p_status"];
                    model.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
                    model.sfAllow = [p_status isEqualToString:@"Selling"];
                    for (int i = 0; i<3; i++) {
                        SelectedMatchModel*modelS = [SelectedMatchModel new];
                        modelS.selected = NO;
                        modelS.matchDateNum = model.matchDateNum;
                        modelS.selectType = @"winLose";
                        switch (i) {
                            case 0:
                            {
                                modelS.title = @"胜";
                                modelS.odds = model.winLose[@"h"];
                                modelS.selectOdds = @"h";
                                
                            }
                                break;
                            case 1:
                            {
                                modelS.title = @"平";
                                modelS.odds = model.winLose[@"d"];
                                modelS.selectOdds = @"d";
                            }
                                break;
                            case 2:
                            {
                                modelS.title = @"负";
                                modelS.odds = model.winLose[@"a"];
                                modelS.selectOdds = @"a";
                            }
                                break;
                                
                            default:
                                break;
                        }
                        [model.sfArray addObject:modelS];
                    }
                    for (int i = 0; i<3; i++) {
                        SelectedMatchModel*modelS = [SelectedMatchModel new];
                        modelS.selected = NO;
                        modelS.matchDateNum = model.matchDateNum;
                        modelS.selectType = @"concedeWinLose";
                        switch (i) {
                            case 0:
                            {
                                modelS.title = @"胜";
                                modelS.odds = model.concedeWinLose[@"h"];
                                modelS.selectOdds = @"h";
                            }
                                break;
                            case 1:
                            {
                                modelS.title = @"平";
                                modelS.odds = model.concedeWinLose[@"d"];
                                modelS.selectOdds = @"d";
                            }
                                break;
                            case 2:
                            {
                                modelS.title = @"负";
                                modelS.odds = model.concedeWinLose[@"a"];
                                modelS.selectOdds = @"a";
                            }
                                break;
                                
                            default:
                                break;
                        }
                        [model.rqsfArray addObject:modelS];
                        
                    }
                    if (!QM_IS_ARRAY_NIL(self.haveSelectArr)) {
                        for (MatchModel*modle_old in self.haveSelectArr) {
                            if ([model.matchDateNum longValue] == [modle_old.matchDateNum longValue]) {
                                model = modle_old;
                            }
                        }
                    }
                    
                    [dayMatchArr addObject:model];
                }
            }
            [matchA addObject:dayMatchArr];
        }
        
        [self.dataSource addObject:matchA];
        [self.dataSource addObject:dateA];
        [self.dataSource addObject:dateShowA];
        dispatch_main_async_safe(^{
            [self.tableView reloadData];
        });
    }
}

- (void)handlebasketballData:(NSArray *)data {
    if (!QM_IS_ARRAY_NIL(data)) {
        NSMutableArray*dateA = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray*matchA = [NSMutableArray arrayWithCapacity:0];
        NSMutableArray*dateShowA = [NSMutableArray arrayWithCapacity:0];
        for (NSDictionary *dayDic in data) {
            NSMutableArray *dayMatchArr = [NSMutableArray arrayWithCapacity:0];
            [dateA addObject:dayDic[@"date"]];
            [dateShowA addObject:@"1"];
            NSArray*list = dayDic[@"list"];
            if (!QM_IS_ARRAY_NIL(list)) {
                for (NSDictionary*matchDic in list) {
                    MatchModel*model = [MatchModel mj_objectWithKeyValues:matchDic];
                    NSString*winLose = matchDic[@"odds"][@"sf"];
                    NSString*concedeWinLose = matchDic[@"odds"][@"rf"];
                    NSString*dxfWinLose = matchDic[@"odds"][@"dxf"];
                    model.winLose = [winLose objectFromJSONString];
                    model.concedeWinLose = [concedeWinLose objectFromJSONString];
                    model.dxfWinLose = [dxfWinLose objectFromJSONString];
                    model.rangNumStr = model.concedeWinLose[@"fixedodds"];
                    model.dxfNumStr = model.dxfWinLose[@"fixedodds"];
                    NSString*p_status_rq = model.concedeWinLose[@"p_status"];
                    NSString*p_status = model.winLose[@"p_status"];
                    NSString*p_status_dxf = model.dxfWinLose[@"p_status"];
                    model.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
                    model.sfAllow = [p_status isEqualToString:@"Selling"];
                    model.dxfAllow = [p_status_dxf isEqualToString:@"Selling"];
                    for (int i = 0; i<2; i++) {
                        SelectedMatchModel*modelS = [SelectedMatchModel new];
                        modelS.selected = NO;
                        modelS.matchDateNum = model.matchDateNum;
                        modelS.selectType = @"sf";
                        switch (i) {
                            case 0:
                            {
                                modelS.title = @"客胜";
                                modelS.odds = model.winLose[@"a"];
                                modelS.selectOdds = @"a";
                                
                            }
                                break;
                            case 1:
                            {
                                modelS.title = @"主胜";
                                modelS.odds = model.winLose[@"h"];
                                modelS.selectOdds = @"h";
                            }
                                break;
                                
                            default:
                                break;
                        }
                        [model.sfArray addObject:modelS];
                        
                        
                    }
                    for (int i = 0; i<2; i++) {
                        SelectedMatchModel*modelS = [SelectedMatchModel new];
                        modelS.selected = NO;
                        modelS.matchDateNum = model.matchDateNum;
                        modelS.selectType = @"rf";
                        switch (i) {
                            case 0:
                            {
                                modelS.title = @"让分客胜";
                                modelS.odds = model.concedeWinLose[@"a"];
                                modelS.selectOdds = @"a";
                            }
                                break;
                            case 1:
                            {
                                modelS.title = @"让分主胜";
                                modelS.odds = model.concedeWinLose[@"h"];
                                modelS.selectOdds = @"h";
                            }
                                break;
                                
                            default:
                                break;
                        }
                        [model.rqsfArray addObject:modelS];
                        
                    }
                    for (int i = 0; i<2; i++) {
                        SelectedMatchModel*modelS = [SelectedMatchModel new];
                        modelS.selected = NO;
                        modelS.matchDateNum = model.matchDateNum;
                        modelS.selectType = @"dxf";
                        switch (i) {
                            case 0:
                            {
                                modelS.title = @"大分";
                                modelS.odds = model.dxfWinLose[@"h"];
                                modelS.selectOdds = @"h";
                            }
                                break;
                            case 1:
                            {
                                modelS.title = @"小分";
                                modelS.odds = model.dxfWinLose[@"l"];
                                modelS.selectOdds = @"l";
                            }
                                break;
                                
                            default:
                                break;
                        }
                        [model.dxfArray addObject:modelS];
                        
                    }
                    if (!QM_IS_ARRAY_NIL(self.haveSelectArr)) {
                        for (MatchModel*modle_old in self.haveSelectArr) {
                            if ([model.matchDateNum longValue] == [modle_old.matchDateNum longValue]) {
                                model = modle_old;
                            }
                        }
                    }
                    
                    [dayMatchArr addObject:model];
                }
            }
            [matchA addObject:dayMatchArr];
        }
        
        dispatch_main_async_safe(^{
            [self.dataSource_basket addObject:matchA];
            [self.dataSource_basket addObject:dateA];
            [self.dataSource_basket addObject:dateShowA];
            [self.tableView reloadData];
        });
        
        
    } else {
        dispatch_main_async_safe(^{
            [self.dataSource_basket removeAllObjects];
            [self.tableView reloadData];
        });
    }
}

#pragma mark -
-(void)confirm:(CYButton*)button{
    if (self.field !=0) {
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        //崩溃保护
        if (!(self.dataSource_basket.count > 0 && [(NSArray*)self.dataSource_basket[0] count] > 0)) {
            [CMMUtility showToastWithText:@"请选择比赛"];
            return;
        }
        for (NSArray*arr in self.dataSource_basket[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count == 0) {
            [CMMUtility showToastWithText:@"请选择比赛"];
            return;
        }
        if (mutArr.count>2) {
            [CMMUtility showToastWithText:@"最多选择2场比赛"];
            return;
        }
        
        NSMutableArray*matchStrArr = [NSMutableArray arrayWithCapacity:0];
        for (MatchModel*model in mutArr) {
            [matchStrArr addObject:model.matchDateNum];
        }
        NSString*matchDateNums = [matchStrArr componentsJoinedByString:@","];
        @weakify(self)
        [ESNetworkService checkPlanWithMatchDateNums:matchDateNums  Response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                [ESNetworkService sendPreNewResponse:^(id dict, ESError *error) {
                    if (dict&&[dict[@"code"] integerValue] == 0) {
                        NSDictionary*data = dict[@"data"];
                        @strongify(self)
                        dispatch_main_async_safe(^{
                            CreatPlanViewController*vc = [[CreatPlanViewController alloc] init];
                            vc.max = [data[@"maxReleaseCntRule"] intValue];
                            vc.avail = [data[@"releasedCntToday"] intValue];
                            vc.priceRule = data[@"priceRule"];
                            vc.minPrice = [data[@"minPrice"] intValue];
                            vc.maxPrice = [data[@"maxPrice"] intValue];
                            [vc didSelectModelArr:[mutArr copy] andCurrentType:self.field];
                            [self.navigationController pushViewController:vc animated:YES];
                        });
                        
                    }
                }];
            }
        }];
        //             NSMutableArray*mutArr_tem = [NSMutableArray arrayWithCapacity:0];
        //             for (NSArray*arr in self.dataSource_basket[0]) {
        //                 NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
        //                 [mutArr_tem addObjectsFromArray:arrTmp];
        //             }
        
        
        
    }else{
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        //崩溃保护
        if (!(self.dataSource.count > 0 && [(NSArray*)self.dataSource[0] count] > 0)) {
            [CMMUtility showToastWithText:@"请选择比赛"];
            return;
        }
        for (NSArray*arr in self.dataSource[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count == 0) {
            [CMMUtility showToastWithText:@"请选择比赛"];
            return;
        }
        if (mutArr.count>2) {
            [CMMUtility showToastWithText:@"最多选择2场比赛"];
            return;
        }
        if (self.selected_0.count == 1) {
            NSArray*arr1 = self.selected_0[0];
            if (arr1.count>1) {
                for (SelectedMatchModel*item in arr1) {
                    if (item.odds.floatValue<2) {
                        [CMMUtility showToastWithText:@"单关双选的选项赔率必须都>2"];
                        return;
                    }
                }
            }
            
        }
        //    NSMutableArray*mutArr_tem = [NSMutableArray arrayWithCapacity:0];
        //    for (NSArray*arr in self.dataSource[0]) {
        //        NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
        //        [mutArr_tem addObjectsFromArray:arrTmp];
        //    }
        NSMutableArray*matchStrArr = [NSMutableArray arrayWithCapacity:0];
        for (MatchModel*model in mutArr) {
            [matchStrArr addObject:model.matchDateNum];
        }
        NSString*matchDateNums = [matchStrArr componentsJoinedByString:@","];
        @weakify(self)
        [ESNetworkService checkPlanWithMatchDateNums:matchDateNums  Response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                [ESNetworkService sendPreNewResponse:^(id dict, ESError *error) {
                    if (dict&&[dict[@"code"] integerValue] == 0) {
                        NSDictionary*data = dict[@"data"];
                        @strongify(self)
                        dispatch_main_async_safe(^{
                            CreatPlanViewController*vc = [[CreatPlanViewController alloc] init];
                            vc.max = [data[@"maxReleaseCntRule"] intValue];
                            vc.avail = [data[@"releasedCntToday"] intValue];
                            vc.priceRule = data[@"priceRule"];
                            vc.minPrice = [data[@"minPrice"] intValue];
                            vc.maxPrice = [data[@"maxPrice"] intValue];
                            vc.hidesBottomBarWhenPushed = YES;
                            [vc didSelectModelArr:[mutArr copy] andCurrentType:self.field];
                            [self.navigationController pushViewController:vc animated:YES];
                        });
                        
                    }
                }];
            }
        }];
        
    }
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.field!=0) {
        if (self.showSelect) {
            if (!QM_IS_ARRAY_NIL(self.selectMatchArr_basket)) {
                NSArray *arr1 = self.selectMatchArr_basket[1];
                if (arr1.count == 0) {
                    tableView.placeHolderView.hidden = NO;
                }else{
                    tableView.placeHolderView.hidden = YES;
                }
                return arr1.count;
            }else{
                
                tableView.placeHolderView.hidden = NO;
                
                return 0;
            }
        }else{
            if (!QM_IS_ARRAY_NIL(self.dataSource_basket)) {
                NSArray *arr1 = self.dataSource_basket[1] ;
                tableView.placeHolderView.hidden = YES;
                return arr1.count;
            }else{
                tableView.placeHolderView.hidden = NO;
                return 0;
            }
        }
    }else{
        if (self.showSelect) {
            if (!QM_IS_ARRAY_NIL(self.selectMatchArr)) {
                NSArray *arr1 = self.selectMatchArr[1];
                if (arr1.count == 0) {
                    tableView.placeHolderView.hidden = NO;
                }else{
                    tableView.placeHolderView.hidden = YES;
                }
                return arr1.count;
            }else{
                
                tableView.placeHolderView.hidden = NO;
                
                return 0;
            }
        }else{
            if (!QM_IS_ARRAY_NIL(self.dataSource)) {
                NSArray *arr1 = self.dataSource[1] ;
                tableView.placeHolderView.hidden = YES;
                return arr1.count;
            }else{
                tableView.placeHolderView.hidden = NO;
                return 0;
            }
        }
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.field!=0) {
        NSMutableArray*arr = self.dataSource_basket[2];
        NSInteger canShow = [arr[section] integerValue];
        if (canShow) {
            
            if (self.showSelect) {
                NSArray*arr0 =self.selectMatchArr_basket[0] ;
                NSArray *arr;
                arr = arr0[section];
                
                return arr.count;
            }else{
                NSArray*arr0 =self.dataSource_basket[0] ;
                NSArray *arr;
                arr = arr0[section];
                if (arr.count == 0) {
                    tableView.placeHolderView.hidden = NO;
                }else{
                    tableView.placeHolderView.hidden = YES;
                }
                return arr.count;
            }
        }else{
            return 0;
        }
    }else{
        NSMutableArray*arr = self.dataSource[2];
        NSInteger canShow = [arr[section] integerValue];
        if (canShow) {
            
            if (self.showSelect) {
                NSArray*arr0 =self.selectMatchArr[0] ;
                NSArray *arr;
                arr = arr0[section];
                
                return arr.count;
            }else{
                NSArray*arr0 =self.dataSource[0] ;
                NSArray *arr;
                arr = arr0[section];
                if (arr.count == 0) {
                    tableView.placeHolderView.hidden = NO;
                }else{
                    tableView.placeHolderView.hidden = YES;
                }
                return arr.count;
            }
        }else{
            return 0;
        }
    }
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSArray *arr;
    if (self.field != 0) {
        if (self.showSelect) {
            NSArray*arr0 =self.selectMatchArr_basket[0];
            arr = arr0[indexPath.section];
        }else{
            NSArray*arr0 =self.dataSource_basket[0];
            arr = arr0[indexPath.section];
        }
        MatchModel*model = arr[indexPath.row];
        if (indexPath.section == 0&&indexPath.row ==0) {
            WTCLog(@"%@",model);
        }
        static NSString *identifier=@"MatchBasketBallTableViewCell";
        MatchBasketBallTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (cell==nil) {
            cell=[[MatchBasketBallTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        
        cell.forbidSelect = NO;
        cell.model = model;
        return cell;
    }else{
        if (self.showSelect) {
            NSArray*arr0 =self.selectMatchArr[0];
            arr = arr0[indexPath.section];
        }else{
            NSArray*arr0 =self.dataSource[0];
            arr = arr0[indexPath.section];
        }
        MatchModel*model = arr[indexPath.row];
        if (indexPath.section == 0&&indexPath.row ==0) {
            WTCLog(@"%@",model);
        }
        static NSString *identifier=@"MatchTableViewCell";
        MatchTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (cell==nil) {
            cell=[[MatchTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        
        cell.forbidSelect = NO;
        cell.model = model;
        return cell;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (self.field == 1) {
        [CMMUtility showToastWithText:@"暂无内容"];
        return;
    }
    NSArray *arr;
    if (self.showSelect) {
        NSArray*arr0 =self.selectMatchArr[0];
        arr = arr0[indexPath.section];
    }else{
        NSArray*arr0 =self.dataSource[0];
        arr = arr0[indexPath.section];
    }
    MatchModel*model = arr[indexPath.row];
    //跳转比赛详情页
    @weakify(self)
    [ESNetworkService newGetMatchDateNum:model.matchDateNum.integerValue response:^(id dict, ESError *error) {
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSUInteger matchId = [dict[@"data"] integerValue];
            dispatch_main_async_safe(^{
                if (matchId == 0) {
                    [[LPUnitily sharedManager] showToastWithText:@"暂无比赛信息"];
                    return;
                }
                MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
                
                liveVC.field = self.field + 1;
                liveVC.matchId = matchId;
                liveVC.sourcePage = @"创建-方案选择比赛页";
                
                [self.navigationController pushViewController:liveVC animated:YES];
            });
        }
    }];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.field != 0) {
        return k6sVersusWidth*50+20+10+20+5+15+20+10+(kSPForJCCellHeight *3+WTCSPForJCMargin*2);
    }else{
        return k6sVersusWidth*50+20+10+20+5+15+20+10+(kSPForJCCellHeight *2+WTCSPForJCMargin);
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 40.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    NSArray*dataSource;
    if (self.field!=0) {
        dataSource = self.dataSource_basket;
    }else{
        dataSource = self.dataSource;
    }
    if (QM_IS_ARRAY_NIL(dataSource)) {
        return nil;
    }
    UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 40.0)];
    view.backgroundColor = RGBCOLORV(0xF4F4F4);
    UILabel*label = [UILabel new];
    label.textColor = RGBCOLORV(0x3A3A3A);
    label.font = [UIFont addPingFangSCRegular:12.0];
    [view addSubview:label];
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(view).offset(15.0);
        make.right.equalTo(view).offset(-15.0);
        make.centerY.equalTo(view);
    }];
    NSArray*dateArr = dataSource[1];
    NSString*date = dateArr[section];
    NSString*xinqi = [LPUnitily weekdayofDate:[LPUnitily changeSpToTime:[self changeTimeToTimeSp:date]]];
    NSArray*matchArr = dataSource[0];
    NSArray*dayMatchArr = matchArr[section];
    NSString*match = [NSString stringWithFormat:@"%ld场比赛",dayMatchArr.count];
    label.text = [NSString stringWithFormat:@"%@  %@  %@",date,xinqi,match];
    UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(showDate:)];
    [view addGestureRecognizer:tap];
    view.tag = section+2099;
    
    NSArray *arr = dataSource[2];
    BOOL isShow = [arr[section] boolValue];
    
    UIImageView*imageV = [[UIImageView alloc] initWithFrame:CGRectZero];
    [view addSubview:imageV];
    [imageV setImage:[UIImage imageNamed:isShow?@"black_down":@"black_right"]];
    [imageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(view);
        make.width.height.offset(15.0);
        make.right.equalTo(view.mas_right).offset(-15.0);
    }];
    
    return view;
}

#pragma mark -
-(void)showDate:(UITapGestureRecognizer*)tap {
    NSArray*dataSource;
    if (self.field!=0) {
        dataSource = self.dataSource_basket;
    }else{
        dataSource = self.dataSource;
    }
    NSInteger section = tap.view.tag - 2099;
    NSMutableArray*arr = dataSource[2];
    NSInteger isShow = [arr[section] integerValue];
    if (isShow) {
        arr[section] = @"0";
    }else{
        arr[section] = @"1";
    }
    [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationFade];
}
-(NSString*)changeTimeToTimeSp:(NSString *)timeStr{
    long time;
    NSDateFormatter *format=[[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSDate *fromdate=[format dateFromString:timeStr];
    time= (long)[fromdate timeIntervalSince1970];
    return [NSString stringWithFormat:@"%ld",time];
}
#pragma mark -
-(void)onlyselectd:(id)button {
    if (self.field != 0) {
        if (self.showSelect == NO) {
            [self.selectMatchArr_basket removeAllObjects];
            NSMutableArray*matchArr = [NSMutableArray arrayWithCapacity:0];
            NSMutableArray*dateArr  = [NSMutableArray arrayWithCapacity:0];
            //崩溃保护
            if (!(self.dataSource_basket.count > 0 && [(NSArray*)self.dataSource_basket[0] count] > 0)) {
                return;
            }
            for (int i = 0; i<[(NSArray*)self.dataSource_basket[0] count]; i++) {
                NSArray*arr = [self.dataSource_basket[0] objectAtIndex:i];
                NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
                if (!QM_IS_ARRAY_NIL(arrTmp)) {
                    [matchArr addObject:arrTmp];
                    [dateArr addObject:[(NSArray*)self.dataSource_basket[1] objectAtIndex:i]];
                }
                [self.selectMatchArr_basket addObject:matchArr];
                [self.selectMatchArr_basket addObject:dateArr];
            }
            [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn_seleted"] forState:UIControlStateNormal];
            self.showSelect = YES;
            [self.tableView reloadData];
        }else {
            [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn"] forState:UIControlStateNormal];
            self.showSelect = NO;
            [self.tableView reloadData];
        }
    }else {
        if (self.showSelect == NO) {
            [self.selectMatchArr removeAllObjects];
            NSMutableArray*matchArr = [NSMutableArray arrayWithCapacity:0];
            NSMutableArray*dateArr  = [NSMutableArray arrayWithCapacity:0];
            //崩溃保护
            if (!(self.dataSource.count > 0 && [(NSArray*)self.dataSource[0] count] > 0)) {
                return;
            }
            for (int i = 0; i<[(NSArray*)self.dataSource[0] count]; i++) {
                NSArray*arr = [self.dataSource[0] objectAtIndex:i];
                NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
                if (!QM_IS_ARRAY_NIL(arrTmp)) {
                    [matchArr addObject:arrTmp];
                    [dateArr addObject:[(NSArray*)self.dataSource[1] objectAtIndex:i]];
                }
                [self.selectMatchArr addObject:matchArr];
                [self.selectMatchArr addObject:dateArr];
                
            }
            [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn_seleted"] forState:UIControlStateNormal];
            self.showSelect = YES;
            [self.tableView reloadData];
        }else{
            [self.selectB setImage:[UIImage imageNamed:@"match_screen_chose_btn"] forState:UIControlStateNormal];
            self.showSelect = NO;
            [self.tableView reloadData];
        }
    }
}

-(BOOL)twoGameLimited {
    if (self.field !=0 ) {
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        for (NSArray*arr in self.dataSource_basket[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count<2) {
            return NO;
        }else{
            return YES;
        }
    }else{
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        for (NSArray*arr in self.dataSource[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count<2) {
            return NO;
        }else{
            return YES;
        }
    }
}
-(void)checkLegal{
    self.confirmB.userInteractionEnabled = YES;
    if (self.field != 0) {
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        //崩溃保护
        if (!(self.dataSource_basket.count > 0 && [(NSArray*)self.dataSource_basket[0] count] > 0)) {
            //            [CMMUtility showToastWithText:@"至少选择1场比赛"];
            self.benifitL.text  =@"请选择比赛";
            return;
        }
        for (NSArray*arr in self.dataSource_basket[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count == 0) {
            //            [CMMUtility showToastWithText:@"至少选择1场比赛"];
            self.benifitL.text  =@"请选择比赛";
            return;
        }
        if (mutArr.count>2) {
            //            [CMMUtility showToastWithText:@"最多选择2场比赛"];
            self.benifitL.text  =@"最多选择 2 场比赛";
            return;
        }
        self.confirmB.userInteractionEnabled = YES;
        NSMutableArray*selectedItemArr = [NSMutableArray arrayWithCapacity:0];
        [selectedItemArr removeAllObjects];
        for (MatchModel*model in mutArr) {
            NSArray*arr1 = [model.sfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            NSArray*arr2 = [model.rqsfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            NSArray*arr3 = [model.dxfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            NSMutableArray*arr_tmp = [NSMutableArray arrayWithCapacity:0];
            [arr_tmp addObjectsFromArray:arr1];
            [arr_tmp addObjectsFromArray:arr2];
            [arr_tmp addObjectsFromArray:arr3];
            [selectedItemArr addObject:[arr_tmp copy]];
        }
        self.selected_1 = [selectedItemArr copy];
        float odds1 = 1.0;
        float odds2 = 1.0;
        NSArray*arr1 = selectedItemArr[0];
        NSArray*arr2;
        if (selectedItemArr.count == 1) {
            arr2 = [NSArray array];
        }else{
            arr2 = selectedItemArr[1];
        }
        NSInteger totalCount = (arr2.count==0?1:arr2.count)*(arr1.count==0?1:arr1.count);
        for (SelectedMatchModel*modle in arr1) {
            if (odds1 == 1) {
                odds1 = modle.odds.floatValue;
            }
            if (modle.odds.floatValue<odds1) {
                odds1 = modle.odds.floatValue;
            }
        }
        for (SelectedMatchModel*modle in arr2) {
            if (odds2 == 1) {
                odds2 = modle.odds.floatValue;
            }
            if (modle.odds.floatValue<odds2) {
                odds2 = modle.odds.floatValue;
            }
        }
        float benifit = (odds1*odds2)/totalCount;
        self.benefit_0 = benifit;
        NSString*benifitStr = [NSString stringWithFormat:@"最低返奖率:%.1lf%%",benifit*100];
        self.benifitL.text = benifitStr;
        [LPUnitily setSubStrColorFromBecomeStr:@":" label:self.benifitL color:ColorButtonRed font:self.benifitL.font];
    }else{
        NSMutableArray*mutArr = [NSMutableArray arrayWithCapacity:0];
        //崩溃保护
        if (!(self.dataSource.count > 0 && [(NSArray*)self.dataSource[0] count] > 0)) {
            //            [CMMUtility showToastWithText:@"至少选择1场比赛"];
            self.benifitL.text  =@"请选择比赛";
            return;
        }
        for (NSArray*arr in self.dataSource[0]) {
            NSArray*arrTmp = [arr filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            [mutArr addObjectsFromArray:arrTmp];
        }
        if (mutArr.count == 0) {
            //            [CMMUtility showToastWithText:@"至少选择1场比赛"];
            self.benifitL.text  =@"请选择比赛";
            return;
        }
        if (mutArr.count>2) {
            //            [CMMUtility showToastWithText:@"最多选择2场比赛"];
            self.benifitL.text  =@"最多选择2场比赛";
            return;
        }
        self.confirmB.userInteractionEnabled = YES;
        
        NSMutableArray*selectedItemArr = [NSMutableArray arrayWithCapacity:0];
        [selectedItemArr removeAllObjects];
        for (MatchModel*model in mutArr) {
            NSArray*arr1 = [model.sfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            NSArray*arr2 = [model.rqsfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
            NSMutableArray*arr_tmp = [NSMutableArray arrayWithCapacity:0];
            [arr_tmp addObjectsFromArray:arr1];
            [arr_tmp addObjectsFromArray:arr2];
            [selectedItemArr addObject:[arr_tmp copy]];
        }
        self.selected_0 = [selectedItemArr copy];
        float odds1 = 1.0;
        float odds2 = 1.0;
        NSArray*arr1 = selectedItemArr[0];
        NSArray*arr2;
        if (selectedItemArr.count == 1) {
            arr2 = [NSArray array];
        }else{
            arr2 = selectedItemArr[1];
        }
        NSInteger totalCount = (arr2.count==0?1:arr2.count)*(arr1.count==0?1:arr1.count);
        for (SelectedMatchModel*modle in arr1) {
            if (odds1 == 1) {
                odds1 = modle.odds.floatValue;
            }
            if (modle.odds.floatValue<odds1) {
                odds1 = modle.odds.floatValue;
            }
        }
        for (SelectedMatchModel*modle in arr2) {
            if (odds2 == 1) {
                odds2 = modle.odds.floatValue;
            }
            if (modle.odds.floatValue<odds2) {
                odds2 = modle.odds.floatValue;
            }
        }
        float benifit = (odds1*odds2)/totalCount;
        self.benefit_1 = benifit;
        NSString*benifitStr = [NSString stringWithFormat:@"最低返奖率:%.1lf%%",benifit*100];
        self.benifitL.text = benifitStr;
        [LPUnitily setSubStrColorFromBecomeStr:@":" label:self.benifitL color:ColorButtonRed font:self.benifitL.font];
        
        
    }
}
#pragma mark -
-(CYButton *)selectB
{
    if(!_selectB){
        _selectB = [CYButton buttonWithType:UIButtonTypeCustom];
        [self.footerView addSubview:_selectB];
    }
    return _selectB;
}
-(UILabel *)benifitL
{
    if (!_benifitL) {
        _benifitL = [UILabel new];
        _benifitL.textColor = ColorTitle;
        _benifitL.font = fcFont(14.0f);
        _benifitL.textAlignment = NSTextAlignmentCenter;
        [self.footerView addSubview:_benifitL];
    }
    return _benifitL;
}
-(CYButton *)confirmB
{
    if(!_confirmB){
        _confirmB = [CYButton buttonWithType:UIButtonTypeCustom];
        _confirmB.backgroundColor = ColorMainAppRed;
        [_confirmB setTitle:@"确认比赛" forState:UIControlStateNormal];
        _confirmB.titleLabel.font = GetFont(12);
        [_confirmB setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.footerView addSubview:_confirmB];
    }
    return _confirmB;
}
-(UILabel*)detailL
{
    if (!_detailL) {
        _detailL = [UILabel new];
        _detailL.textColor = ColorTitle;
        _detailL.font = GetFont(12.0f);
        [self.footerView addSubview:_detailL];
    }
    return _detailL;
}

-(UIView*)footerView
{
    if (!_footerView) {
        _footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 40.0+kBottomSafeArea)];
        _footerView.backgroundColor = [UIColor whiteColor];
    }
    return _footerView;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
