//
//  LeagueCountViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "LeagueCountViewController.h"
#import "ExpertDetail.h"
#import "ExpertLeagueListCell.h"

@interface LeagueCountViewController ()
@property (nonatomic,assign) NSUInteger page;
@property (nonatomic,strong) NSMutableArray *dataList;
@end

@implementation LeagueCountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.navigationItem.title = @"联赛统计";
	self.dataList = [NSMutableArray array];
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.bottom.equalTo(self.view);
		make.top.equalTo(self.view).offset(NavBarHeight);
	}];
	[self.tableView registerClass:[ExpertLeagueListCell class] forCellReuseIdentifier:@"ExpertLeagueListCell"];
	[self loadData];
	
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
}

- (void)loadData {
	self.page = 1;
	//联赛统计列表
	[ESNetworkService expertLeagueCountWithExpertId:self.expertId field:self.field page:self.page pageSize:1000 Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				[self.dataList removeAllObjects];
				ExpertLeagueCountModel *model = [ExpertLeagueCountModel mj_objectWithKeyValues:dict[@"data"]];
				[self.dataList addObjectsFromArray:model.expertLeagueList];
				[self.tableView reloadData];
			});
		}
	}];
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.dataList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	ExpertLeagueListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ExpertLeagueListCell"];
	[cell configCellWithModel:self.dataList[indexPath.row]];
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 30;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 35;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
	view.backgroundColor = RGBCOLOR(244, 244, 244);
	NSArray *arr = @[@"联赛",@"总场",@"命中场",@"命中率"];
	for (NSUInteger i = 0; i < 4; i++) {
		UILabel *label = [UILabel new];
		label.frame = CGRectMake(0 + SCREEN_WIDTH / 4 * i, 0, SCREEN_WIDTH / 4, 35);
		label.text = arr[i];
		label.textAlignment = NSTextAlignmentCenter;
		label.font = fcFont(13);
		label.textColor = ColorAppBlack;
		[view addSubview:label];
	}
	
	return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 10;
}

@end

