//
//  SingleCutViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SingleCutViewController.h"
#import "PlanListManager.h"
#import "HomeTableViewCell.h"
#import "CYPlanDetailViewController.h"
#import "ExpertDetailViewController.h"

@interface SingleCutViewController ()<PlanListManagerDelegate,HomeTableViewCellDelegate>
@property (nonatomic, strong) PlanListManager *manager;
@end

@implementation SingleCutViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self initWithSubViews];
	// Do any additional setup after loading the view.
}
-(void)didSelectHeadV:(id)cell
{
	NSIndexPath*indexPath = [self.tableView indexPathForCell:cell];
	PlanModel*model  = self.manager.dataSource[indexPath.row];
	ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",model.userId];
	vc.sourcePage = self.title;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
	
}

- (void)initWithSubViews{
	self.navigationItem.title = self.field.intValue == 1 ? @"足球单关专区" : @"篮球单关专区";
	
	self.tableView.frame = CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight);
	self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	if (@available(iOS 11.0, *)){
		self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
	}
	[self.view addSubview:self.tableView];
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	//    [self.tableView.mj_header beginRefreshing];
	[self loadData];
	
}
-(void)planListManager:(PlanListManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
	
	dispatch_main_async_safe(^{
		[self.tableView.mj_header endRefreshing];
		[self.tableView.mj_footer endRefreshing];
		
		if (self.manager.dataSource.count == 0) {
		}
		
		if (!isRefresh && self.manager.dataSource.count >= 20) {
			self.tableView.mj_footer.hidden = NO;
		}else{
			self.tableView.mj_footer.hidden = YES;
		}
		
		[self.tableView reloadData];
		
	});
}
-(void)loadData{
	[self.manager refreshDataWithType:@"" andField:self.field SelectedLeague:@"" SortType:1 MatchSelectType:1];
}

-(void)loadMoreData
{
	[self.manager loadDataWithType:@"" andField:self.field SelectedLeague:@"" SortType:1 MatchSelectType:1];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return  self.manager.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	PlanModel*model  = self.manager.dataSource[indexPath.row];
	static NSString *identifier=@"homeTableViewCell";
	HomeTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
	cell.selectionStyle = UITableViewCellSelectionStyleDefault;
	if (cell==nil) {
		cell=[[HomeTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
		
		
	}
	//cell贴边
	UIEdgeInsets inset;
	inset.bottom=0;
	inset.top=0;
	inset.left=0;
	inset.right=0;
	if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
		[cell setLayoutMargins:inset];
	}
	if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
		[cell setSeparatorInset:inset];
	}
	cell.delegate = self;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.isBasket = (self.field.integerValue == 2);
	cell.model = model;
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	PlanModel*model  = self.manager.dataSource[indexPath.row];
    CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
	vc.planId = [model.planId integerValue];
	vc.sourcePage = @"免费专区页面";
//	vc.hidesBottomBarWhenPushed = YES;
//    vc.isBasket = (model.field.integerValue == 2);
	[self.navigationController pushViewController:vc animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	tableView.rowHeight = UITableViewAutomaticDimension;
	tableView.estimatedRowHeight = 150;
	return tableView.rowHeight;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 0.01;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
	return 0.01;
}
-(PlanListManager*)manager
{
	if (!_manager) {
		_manager = [PlanListManager new];
		_manager.delegate = self;
	}
	return _manager;
}

@end
