//
//  ExpertDetailViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface ExpertDetailViewController : ESViewController
@property (nonatomic, copy) NSString *expertId;
//@property (nonatomic, assign) BOOL isRecieveNotificate;
//@property (nonatomic, assign) BOOL isBasket;//YES-篮球 NO-足球
@property (nonatomic, strong) NSString *sourcePage; //埋点使用字段
@end

NS_ASSUME_NONNULL_END
