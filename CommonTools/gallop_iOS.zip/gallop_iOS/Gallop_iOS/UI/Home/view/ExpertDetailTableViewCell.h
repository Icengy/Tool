//
//  ExpertDetailTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SelectMatchTableView.h"
#import "PlanModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ExpertDetailTableViewCell : UITableViewCell
@property (nonatomic, strong) SelectMatchTableView *matchTableView;
@property (nonatomic, strong) UILabel *descripLabel;
@property (nonatomic, strong) UILabel *declarationTitleLabel;
@property (nonatomic, strong) UILabel *declarationLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *backAbleLabel;
@property (nonatomic, strong) UILabel *amountLabel;
@property (nonatomic, strong) UIImageView *gallopCoinImageV;
@property (nonatomic, strong) UIImageView *shotV;
@property (nonatomic, strong) UILabel *typeLabel;
@property (nonatomic, strong) UILabel *seperatorL;
@property (nonatomic, strong) UILabel *seperatorM;
@property (nonatomic, strong) UIImageView *viewCountImageView;
@property (nonatomic, strong) UILabel *viewCountLabel;
@property (nonatomic, strong) PlanModel*model;
@property (nonatomic, assign) BOOL isBasket;
@end

NS_ASSUME_NONNULL_END
