//
//  YinLiTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/2.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "YinLiTableViewCell.h"

@implementation YinLiTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.headV.layer.cornerRadius = 18;
    self.headV.clipsToBounds = YES;
    
    // Initialization code
}

- (void)configCell:(id)data index:(NSUInteger)index {
	if ([data isKindOfClass:[YinLi class]]) {
		YinLi *model = data;
		self.nameL.text = model.expertName;
		[self.headV sd_setImageWithURL:[NSURL URLWithString:model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
		self.titleL.text = @"返奖率:";
		self.yinliL.text = [NSString stringWithFormat:@"%.0f%%",model.profit.floatValue*100];
		//返奖
	} else if ([data isKindOfClass:[RedRank class]]) {
		RedRank *model = data;
		self.nameL.text = model.expertName;
		[self.headV sd_setImageWithURL:[NSURL URLWithString:model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
		self.titleL.text = @"连红数:";
		self.yinliL.text = model.continueRedCnt.stringValue;
	} else {
		//命中
		HitRank *model = data;
		self.nameL.text = model.expertName;
		[self.headV sd_setImageWithURL:[NSURL URLWithString:model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
		self.titleL.text = @"命中率:";
		self.yinliL.text = [NSString stringWithFormat:@"%.0f%%",model.gotRate.floatValue*100];
		self.recentL.hidden = NO;
		self.recentL.text = model.recentGot;
	}
	NSArray *rankImageArr = @[@"rank_first_icon",@"rank_second_icon",@"rank_third_icon"];
	if (index > 2) {
		self.rankLabel.hidden = NO;
		self.rankImage.hidden = YES;
		self.rankLabel.text = @(index + 1).stringValue;
	} else {
		self.rankLabel.hidden = YES;
		self.rankImage.hidden = NO;
		self.rankImage.image = GetImage(rankImageArr[index]);
	}
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
