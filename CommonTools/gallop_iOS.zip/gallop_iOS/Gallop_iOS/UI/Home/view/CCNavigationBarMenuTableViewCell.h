//
//  CCNavigationBarMenuTableViewCell.h
//  ESTicket
//
//  Created by Homosum on 2018/3/19.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCNavigationBarMenuItem.h"
@interface CCNavigationBarMenuTableViewCell : UITableViewCell
@property (nonatomic, strong) UIImageView             *itemImageView;
@property (nonatomic, strong) UILabel                 *itemTitleLabel;

@property (nonatomic, strong) CCNavigationBarMenuItem *model;

@end
