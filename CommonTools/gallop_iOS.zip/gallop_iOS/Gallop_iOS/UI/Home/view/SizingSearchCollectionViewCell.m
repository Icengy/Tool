//
//  SizingSearchCollectionViewCell.m
//  JUXIU_iOS
//
//  Created by Homosum on 17/3/29.
//  Copyright © 2017年 JuXiuSheQu. All rights reserved.
//

#import "SizingSearchCollectionViewCell.h"
#define itemHeight 20
@implementation SizingSearchCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.backgroundColor = [UIColor colorWithHexString:@"#E1E1E1"];
        // 用约束来初始化控件:
        self.tLabel = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, frame.size.width-10, 20)];
        self.tLabel.textAlignment =NSTextAlignmentCenter;
        self.tLabel.backgroundColor = [UIColor colorWithHexString:@"#E1E1E1"];
        self.tLabel.font=[UIFont systemFontOfSize:13];
        self.tLabel.textColor=[UIColor blackColor];
        [self.contentView addSubview:self.tLabel];
        self.contentView.layer.cornerRadius=5;
        [self.contentView clipsToBounds];
        
    }
    return self;
}
-(UICollectionViewLayoutAttributes*)preferredLayoutAttributesFittingAttributes:(UICollectionViewLayoutAttributes *)layoutAttributes
{
     UICollectionViewLayoutAttributes *attributes = [super preferredLayoutAttributesFittingAttributes:layoutAttributes];
    CGRect frame = [self.tLabel.text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.tLabel.frame.size.height) options:(NSStringDrawingUsesLineFragmentOrigin) attributes:[NSDictionary dictionaryWithObjectsAndKeys:self.tLabel.font,NSFontAttributeName, nil] context:nil];
    frame.size.height = itemHeight;
    attributes.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width+10, frame.size.height);
    self.tLabel.frame = CGRectMake(5, 0, attributes.frame.size.width-10, 20);
    return attributes;

}
@end
