//
//  ExpertLeagueListCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertLeagueListCell.h"
#import "ExpertDetail.h"

@interface ExpertLeagueListCell()
@property (nonatomic,strong) NSMutableArray<UILabel *> *labelArr;
@end

@implementation ExpertLeagueListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self setupView];
	}
	return self;
}

- (void)setupView {
	UIView *seprator = [[UIView alloc] initWithFrame:CGRectMake(0, 29, SCREEN_WIDTH, 1)];
	seprator.backgroundColor = RGBCOLOR(244, 244, 244);
	[self.contentView addSubview:seprator];
}

- (void)configCellWithModel:(ExpertLeagueListItem *)model {
	self.labelArr[0].text = model.leagueName;
	self.labelArr[1].text = @(model.totalCount).stringValue;
	self.labelArr[2].text = @(model.redCount).stringValue;
	CGFloat rate = model.redCount * 100.0 / model.totalCount;
	self.labelArr[3].text = [NSString stringWithFormat:@"%.1f%%",rate];
}

#pragma mark - lazy init
- (NSMutableArray<UILabel *> *)labelArr {
	if (!_labelArr) {
		_labelArr = [NSMutableArray array];
		for (NSUInteger i = 0; i < 4; i++) {
			UILabel *label = [UILabel new];
			label.frame = CGRectMake(0 + SCREEN_WIDTH / 4 * i, 0, SCREEN_WIDTH / 4, 30);
			label.textAlignment = NSTextAlignmentCenter;
			label.font = fcFont(12);
			label.textColor = RGBCOLOR(58, 58, 58);
			[self.contentView addSubview:label];
			[_labelArr addObject:label];
		}
	}
	return _labelArr;
}
@end
