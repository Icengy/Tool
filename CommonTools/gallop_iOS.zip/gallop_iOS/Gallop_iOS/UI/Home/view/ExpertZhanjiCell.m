//
//  ExpertZhanjiCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertZhanjiCell.h"
#import "ExpertDetail.h"

@interface ExpertZhanjiCell()
/**战绩view*/
@property (nonatomic,strong) UIView*zhanjiV;
@property (nonatomic,strong) UIView*line2;
@property (nonatomic,strong) UIView*line3;
@property (nonatomic,strong) UILabel*recentL;
@property (nonatomic,strong) UILabel*rcL;
@property (nonatomic,strong) UILabel*mingzhongL;
@property (nonatomic,strong) UILabel*mzL;
@property (nonatomic,strong) UILabel*yingliL;
@property (nonatomic,strong) UILabel*ylL;

//近期战绩
@property (nonatomic,strong) UILabel*recentSeventLabel;
@property (nonatomic,strong) UIButton*redCountBtn;
@property (nonatomic,strong) NSMutableArray<UIButton *> *resultBtnArr;

@end

@implementation ExpertZhanjiCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self setupView];
	}
	return self;
}

-(void)setupView
{
	//战绩
	[self.zhanjiV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.left.right.bottom.equalTo(self.contentView);
	}];
	
	[@[self.recentL,self.mingzhongL,self.yingliL] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.zhanjiV).offset(9);
	}];
	[@[self.recentL,self.mingzhongL,self.yingliL] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:SCREEN_WIDTH / 3 leadSpacing:0 tailSpacing:0];
	[@[self.rcL,self.mzL,self.ylL] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.zhanjiV).offset(27);
	}];
	[@[self.rcL,self.mzL,self.ylL] mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedItemLength:SCREEN_WIDTH / 3 leadSpacing:0 tailSpacing:0];
	
	UIView *line1 = [UIView new];
	line1.backgroundColor = RGBCOLOR(231, 231, 231);
	[self.zhanjiV addSubview:line1];
	[line1 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.mingzhongL);
		make.top.equalTo(self.zhanjiV).offset(9);
		make.size.mas_equalTo(CGSizeMake(2, 40));
	}];
	
	UIView *line2 = [UIView new];
	line2.backgroundColor = RGBCOLOR(231, 231, 231);
	[self.zhanjiV addSubview:line2];
	[line2 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.mingzhongL);
		make.top.equalTo(self.zhanjiV).offset(9);
		make.size.mas_equalTo(CGSizeMake(2, 40));
	}];
	
	UIView *line3 = [UIView new];
	line3.backgroundColor = RGBCOLOR(231, 231, 231);
	[self.zhanjiV addSubview:line3];
	[line3 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.zhanjiV);
		make.top.equalTo(self.zhanjiV).offset(61);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 1));
	}];
	
	//近期战绩
	[self.recentSeventLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.zhanjiV).offset(15);
		make.bottom.equalTo(self.zhanjiV).offset(-12);
	}];
	[self.resultBtnArr mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.recentSeventLabel);
		make.size.mas_equalTo(CGSizeMake(22, 22));
	}];
	[self.redCountBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.recentSeventLabel);
		make.right.equalTo(self.zhanjiV).offset(-15);
		make.size.mas_equalTo(CGSizeMake(45, 22));
	}];
	[self.resultBtnArr mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:10 leadSpacing:67 tailSpacing:93.5];
}

- (void)configCellWithModel:(ExpertPrize *)model {
	self.rcL.text = [NSString stringWithFormat:@"%@中%@",@(model.planCnt),@(model.redCnt)];
	CGFloat mzValue = model.redCnt * 100.0 / model.planCnt;
	if (mzValue > 0) {
		self.mzL.text = [NSString stringWithFormat:@"%.1f%%",mzValue];
	}
	self.ylL.text = [NSString stringWithFormat:@"%.1f%%",model.sevenProfit * 100.0];
	if (model.lastContinueCnt >= 2) {
		[self.redCountBtn setTitle:[NSString stringWithFormat:@"%@连红",@(model.lastContinueCnt)] forState:UIControlStateNormal];
		self.redCountBtn.hidden = NO;
	} else {
		self.redCountBtn.hidden = YES;
	}
	[model.sevenRedList enumerateObjectsUsingBlock:^(NSNumber * obj, NSUInteger idx, BOOL * _Nonnull stop) {
		if (obj.intValue == 1) {
			[self.resultBtnArr[idx] setTitle:@"红" forState:UIControlStateNormal];
			self.resultBtnArr[idx].backgroundColor = RGBCOLOR(240, 72, 68);
		} else {
			[self.resultBtnArr[idx] setTitle:@"黑" forState:UIControlStateNormal];
			self.resultBtnArr[idx].backgroundColor = RGBCOLOR(58, 58, 58);
		}
		self.resultBtnArr[idx].hidden = NO;
	}];
}

#pragma mark - lazy init
-(UILabel*)ylL
{
	if (!_ylL) {
		_ylL = [UILabel new];
		_ylL.textColor = [UIColor colorWithHexString:@"#f04844"];
		_ylL.font = fcFont(14.0f);
		_ylL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_ylL];
	}
	return _ylL;
}
-(UILabel*)mzL
{
	if (!_mzL) {
		_mzL = [UILabel new];
		_mzL.textColor = [UIColor colorWithHexString:@"#f04844"];
		_mzL.font = fcFont(14.0f);
		_mzL.text = @"0.0%";
		_mzL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_mzL];
	}
	return _mzL;
}
-(UILabel*)rcL
{
	if (!_rcL) {
		_rcL = [UILabel new];
		_rcL.textColor = [UIColor colorWithHexString:@"#f04844"];
		_rcL.font = fcFont(14.0f);
		_rcL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_rcL];
	}
	return _rcL;
}
-(UILabel*)yingliL
{
	if (!_yingliL) {
		_yingliL = [UILabel new];
		_yingliL.textColor = ColorTitle;
		_yingliL.font = fcFont(12.0f);
		_yingliL.text = @"7日返奖率";
		_yingliL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_yingliL];
	}
	return _yingliL;
}
-(UILabel*)mingzhongL
{
	if (!_mingzhongL) {
		_mingzhongL = [UILabel new];
		_mingzhongL.textColor = ColorAppBlack;
		_mingzhongL.font = fcFont(12.0f);
		_mingzhongL.text = @"命中率";
		_mingzhongL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_mingzhongL];
	}
	return _mingzhongL;
}

-(UILabel*)recentL
{
	if (!_recentL) {
		_recentL = [UILabel new];
		_recentL.textColor = ColorAppBlack;
		_recentL.font = fcFont(12.0f);
		_recentL.text = @"近期发单";
		_recentL.textAlignment = NSTextAlignmentCenter;
		[self.zhanjiV addSubview:_recentL];
	}
	return _recentL;
}

-(UIView*)zhanjiV
{
	if (!_zhanjiV) {
		_zhanjiV = [[UIView alloc] init];
		_zhanjiV.backgroundColor = [UIColor whiteColor];
		[self.contentView addSubview:_zhanjiV];
	}
	return _zhanjiV;
}

- (UILabel *)recentSeventLabel {
	if (!_recentSeventLabel) {
		_recentSeventLabel = [UILabel new];
		_recentSeventLabel.text = @"近7单";
		_recentSeventLabel.textColor = ColorAppBlack;
		_recentSeventLabel.font = fcFont(14);
		[self.zhanjiV addSubview:_recentSeventLabel];
	}
	return _recentSeventLabel;
}

- (UIButton *)redCountBtn {
	if (!_redCountBtn) {
		_redCountBtn = [UIButton new];
		[_redCountBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_redCountBtn.titleLabel.font = fcFont(11);
		_redCountBtn.backgroundColor = RGBCOLOR(240, 72, 68);
		_redCountBtn.layer.cornerRadius = 4;
		_redCountBtn.clipsToBounds = YES;
		_redCountBtn.enabled = NO;
		_redCountBtn.hidden = YES;
		[self.zhanjiV addSubview:_redCountBtn];
	}
	return _redCountBtn;
}

- (NSMutableArray<UIButton *> *)resultBtnArr {
	if (!_resultBtnArr) {
		_resultBtnArr = [NSMutableArray array];
		for (NSUInteger i = 0; i < 7; i ++) {
			UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
			[btn setTitle:@"红" forState:UIControlStateNormal];
			[btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
			btn.backgroundColor = RGBCOLOR(240, 72, 68);
			btn.titleLabel.font = fcFont(11);
			btn.layer.cornerRadius = 11;
			btn.clipsToBounds = YES;
			btn.enabled = NO;
			btn.hidden = YES;
			[_resultBtnArr addObject:btn];
			
			[self.zhanjiV addSubview:btn];
		}
	}
	return _resultBtnArr;
}
@end
