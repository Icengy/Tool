//
//  ESRFForJCNotSellCollectionCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/28.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESRFForJCNotSellCollectionCell.h"

@implementation ESRFForJCNotSellCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
