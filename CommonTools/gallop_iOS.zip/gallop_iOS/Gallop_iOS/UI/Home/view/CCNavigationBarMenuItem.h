//
//  CCNavigationBarMenuItem.h
//  ESTicket
//
//  Created by Homosum on 2018/3/19.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCNavigationBarMenuItem : NSObject
@property (nonatomic, strong) UIImage  *image;// 图标
@property (nonatomic, copy  ) NSString *title;// 标题

@property (nonatomic, strong) UIColor  *titleColor;// 颜色   #4a4a4a
@property (nonatomic, strong) UIFont   *titleFont;// 字体大小 system 15.5  17

+ (instancetype)navigationBarMenuItemWithImage:(UIImage *)image title:(NSString *)title;

@end


