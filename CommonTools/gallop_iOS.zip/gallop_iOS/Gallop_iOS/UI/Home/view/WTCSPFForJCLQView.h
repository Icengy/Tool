//
//  WTCSPFForJCLQView.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchModel.h"
#import "SelectedMatchModel.h"

@class WTCSPFForJCLQView;
NS_ASSUME_NONNULL_BEGIN
@protocol WTCSPFForJCLQViewDelegate <NSObject>

- (void)spfForJCLQView:(WTCSPFForJCLQView *)sfpView didSelectItem:(MatchModel *)model;

@end
@interface WTCSPFForJCLQView : UIView
@property (nonatomic, weak) id<WTCSPFForJCLQViewDelegate> delegate;
@property (nonatomic, strong) MatchModel*model;
@property (nonatomic, assign) BOOL forbidSelect;
@property (nonatomic,assign) BOOL isExtreme;

//0:都显示，1：显示胜负平；2:显示亚指胜负平；3:显示大小分
@property (nonatomic, assign) long showResultType;

@end

NS_ASSUME_NONNULL_END
