//
//  TypeChooseView.m
//  Gallop_iOS
//
//  Created by Homosum on 2021/4/22.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "TypeChooseView.h"
#pragma mark 选择用的cell
@interface ChooseCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) UILabel *titleLabel;

@end
@implementation ChooseCollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor clearColor];
        [self setupView];
    }
    return self;
}

- (void)setupView
{
    __weak ChooseCollectionViewCell *weakSelf = self;
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.contentView).with.insets(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.font = GetFont(12.0f);
        _titleLabel.textColor = ColorTitle;
        _titleLabel.layer.borderColor = [ColorLineGray CGColor];
        _titleLabel.layer.borderWidth = 1;
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        [LPUnitily addCornerToView:_titleLabel withRadius:15];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

@end
#pragma mark 主体
@interface TypeChooseView()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,UICollectionViewDelegate>
{
    CGFloat _height;
    NSIndexPath *_selectedIndexPath;
    ChooseCollectionViewCell *_markCell;
    NSInteger _index;
}
@property (nonatomic, strong)UICollectionViewFlowLayout *layout;
@property (nonatomic, strong)UICollectionView *collectionView;
@property (nonatomic, strong)NSArray *dataSource;
@property (nonatomic,strong) UIView *cancelView ;
@end
@implementation TypeChooseView

- (id)initWithView:(UIView *)view
{
    self = [super init];
    if (self) {
        self.frame = CGRectMake(0, kStatusBarHeight+40, SCREEN_WIDTH, SCREEN_HEIGHT - kStatusBarHeight-40);
        self.backgroundColor = RGBACOLOR(1, 1, 1, 0.3);
        self.alpha = 0;
        self.hidden = YES;
        [view addSubview:self];
        
        [self setupView];
    }
    return self;
}
-(void)setupView{
    self.layout=[[UICollectionViewFlowLayout alloc] init];
    _layout.sectionInset=UIEdgeInsetsMake(10, 15, 10, 15);//上 左 下 右
    _layout.minimumInteritemSpacing = 10;
    _layout.minimumLineSpacing = 10;
    
    _height = 20+30*(self.dataSource.count/4+(self.dataSource.count%4==0?0:1))+((self.dataSource.count/4+(self.dataSource.count%4==0?0:1))-1)*10;
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, -_height, self.frame.size.width, _height) collectionViewLayout:_layout];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    _collectionView.backgroundColor = [UIColor whiteColor];
    
    [_collectionView registerClass:[ChooseCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    [self addSubview:_collectionView];

    self.cancelView = [[UIView alloc] initWithFrame:CGRectMake(0, _height, SCREEN_WIDTH, SCREEN_HEIGHT - (kStatusBarHeight+40) - _height)];
    self.cancelView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.cancelView];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hidden)];
    [self.cancelView addGestureRecognizer:tapGesture];
}

-(void)showWithdataSource:(NSArray *)dataSource index:(NSInteger)index {
    //创建一个布局方式的对象
   
    self.dataSource = dataSource;
    _index = index;
    _height = 20+30*(self.dataSource.count/4+(self.dataSource.count%4==0?0:1))+((self.dataSource.count/4+(self.dataSource.count%4==0?0:1))-1)*10;
    [self show];
}

#pragma mark - UICollectionViewDataSource , UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.dataSource.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier=@"cell";
    ChooseCollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    cell.titleLabel.text = self.dataSource[indexPath.row];
    if (indexPath.row==_index) {
        _markCell = cell;
        cell.titleLabel.layer.borderColor = [ColorButtonRed CGColor];
        cell.titleLabel.backgroundColor = ColorButtonRed;
        cell.titleLabel.textColor = [UIColor whiteColor];
    }else{
        cell.titleLabel.layer.borderColor = [ColorLineGray CGColor];
        cell.titleLabel.backgroundColor = [UIColor whiteColor];
        cell.titleLabel.textColor = ColorTitle;
    }
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((SCREEN_WIDTH-30-30)/4 - 0.1, 30);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    [self hidden];
    if (_selectedIndexPath) {
        //上一个选中cell的状态
        ChooseCollectionViewCell *cell=(ChooseCollectionViewCell *)[self.collectionView cellForItemAtIndexPath:_selectedIndexPath];
        cell.titleLabel.backgroundColor = [UIColor whiteColor];
        cell.titleLabel.textColor = ColorTitle;
        cell.titleLabel.layer.borderColor = [ColorLineGray CGColor];
    }
    //去掉默认cell的选中状态
    if (indexPath.row!=_index) {
        ChooseCollectionViewCell *cell=_markCell;
        cell.titleLabel.backgroundColor = [UIColor whiteColor];
        cell.titleLabel.textColor = ColorTitle;
        cell.titleLabel.layer.borderColor = [ColorLineGray CGColor];
    }
    //被选中的cell的状态
    ChooseCollectionViewCell *cell=(ChooseCollectionViewCell *)[self.collectionView cellForItemAtIndexPath:indexPath];
    cell.titleLabel.layer.borderColor = [ColorButtonRed CGColor];
    cell.titleLabel.backgroundColor = ColorButtonRed;
    cell.titleLabel.textColor = [UIColor whiteColor];
    _selectedIndexPath=indexPath; //记录当前被选中的cell的下标

    if (self.delegate&&[self.delegate respondsToSelector:@selector(chooseTypeWithTypeStr:index:)]) {
        [self.delegate chooseTypeWithTypeStr:self.dataSource[indexPath.row] index:indexPath.row];
    }
}

- (void)show
{
//    ESViewController *controller = (ESViewController *)[self viewController];
//    controller.iconImageUp = YES;
    self.hidden = NO;
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1;
        self.collectionView.frame = CGRectMake(0, 0, SCREEN_WIDTH, _height);
        [self.cancelView setFrame:CGRectMake(0, _height, SCREEN_WIDTH, SCREEN_HEIGHT - (kStatusBarHeight+40) - _height)];
        [self.collectionView reloadData];
    } completion:^(BOOL finished) {
        
    }];
}

- (void)hidden
{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(viewHide)]) {
        [self.delegate viewHide];
    }
//    ESViewController *controller = (ESViewController *)[self viewController];
    [UIView animateWithDuration:0.4 animations:^{
        self.alpha = 0;
//        self.collectionView.frame = CGRectMake(0, -_height+NavBarHeight, SCREEN_WIDTH, _height);
    } completion:^(BOOL finished) {
        self.hidden = YES;
    }];
}

- (ESViewController*)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview) {
        UIResponder* nextResponder = [next nextResponder];
        if ([nextResponder isKindOfClass:[ESViewController class]]) {
            return (ESViewController*)nextResponder;
        }
    }
    return nil;
}


@end
