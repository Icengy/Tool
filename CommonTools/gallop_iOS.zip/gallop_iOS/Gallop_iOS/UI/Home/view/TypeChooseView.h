//
//  TypeChooseView.h
//  Gallop_iOS
//
//  Created by Homosum on 2021/4/22.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TypeChooseView;

@protocol TypeChooseViewDelegate <NSObject>

- (void)chooseTypeWithTypeStr:(NSString *)typeStr index:(NSInteger)index;
-(void)viewHide;

@end

@interface TypeChooseView : UIView

@property (nonatomic, weak) id<TypeChooseViewDelegate> delegate;

- (id)initWithView:(UIView *)view;

- (void)showWithdataSource:(NSArray *)dataSource index:(NSInteger)index;

- (void)hidden;
@end


