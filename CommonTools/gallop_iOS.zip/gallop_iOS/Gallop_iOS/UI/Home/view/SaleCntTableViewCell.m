//
//  SaleCntTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SaleCntTableViewCell.h"

@implementation SaleCntTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
