//
//  HomeExpertCollectionViewCell.h
//  Gallop_iOS
//
//  Created by icengy on 2021/4/26.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
@class GallopExpertModel;
NS_ASSUME_NONNULL_BEGIN

@interface HomeExpertCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) GallopExpertModel *model;
@end

NS_ASSUME_NONNULL_END
