//
//  ESRFForJCZQCollectionViewCell.m
//  ESTicket
//
//  Created by 王帅 on 15/12/15.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import "ESRFForJCZQCollectionViewCell.h"
//#define kZQDGHGFont SCREEN_WIDTH==320?11.0f:13.0f

@interface ESRFForJCZQCollectionViewCell ()

//@property (nonatomic, strong) UIView *stackView;
@property (nonatomic, strong) UIImageView *winStateImageView;
@property (nonatomic, strong) UILabel *titleLabel;
//@property (nonatomic, strong) UILabel *detailLabel;

@end

@implementation ESRFForJCZQCollectionViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.backgroundColor = ColorDefaultGrayBackground;
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self.contentView addSubview:self.titleLabel];
    [self.contentView addSubview:self.winStateImageView];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.contentView);
    }];
    
   [self.winStateImageView mas_updateConstraints:^(MASConstraintMaker *make) {
       make.right.equalTo(self.contentView).offset(-8);
       make.left.lessThanOrEqualTo(self.titleLabel.mas_right).offset(0);
       make.centerY.equalTo(self.titleLabel);
       make.size.mas_equalTo(CGSizeMake(20, 20));
   }];
}

-(void)setCuttentType:(BOOL)cuttentType
{
    _cuttentType = cuttentType;
}
- (void)setTitleText:(NSString *)titleText
{
    _titleText = titleText;
    self.titleLabel.text = titleText;
//    self.titleLabel.hidden = NO;
}

- (void)setIsSelected:(BOOL)isSelected
{
    _isSelected = isSelected;
    if (_isSelected) {
        self.contentView.backgroundColor = ColorMainBlue;
        self.titleLabel.textColor = [UIColor whiteColor];
    }else{
        self.contentView.backgroundColor = ColorDefaultGrayBackground;
        self.titleLabel.textColor = RGBCOLORV(0x282828);
    }
}

- (void)setIsWinResult:(BOOL)isWinResult
{
    _isWinResult = isWinResult;
    if (_isWinResult) {
        self.winStateImageView.hidden = NO;
    }else{
        self.winStateImageView.hidden = YES;
    }
}

//- (UIView *)stackView
//{
//    if (!_stackView) {
//        _stackView = [[UIView alloc] init];
//        _stackView.backgroundColor = [UIColor clearColor];
//        [self addSubview:_stackView];
//    }
//    return _stackView;
//}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = RGBCOLORV(0x282828);
        _titleLabel.font = [UIFont addPingFangSCRegular:12];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _titleLabel;
}

//- (UILabel *)detailLabel
//{
//    if (!_detailLabel) {
//        _detailLabel = [[UILabel alloc] init];
//        _detailLabel.textColor = RGBCOLORV(0x282828);
//        _detailLabel.font = [UIFont addPingFangSCRegular:10];
//        _detailLabel.textAlignment = NSTextAlignmentCenter;
//        [_stackView addSubview:_detailLabel];
//    }
//    return _detailLabel;
//}

- (UIImageView *)winStateImageView {
    if (!_winStateImageView) {
        _winStateImageView = [[UIImageView alloc] init];
        _winStateImageView.image = [UIImage imageNamed:@"scheme_detail_right_icon"];
        _winStateImageView.hidden = YES;
    }
    return _winStateImageView;
}

@end
