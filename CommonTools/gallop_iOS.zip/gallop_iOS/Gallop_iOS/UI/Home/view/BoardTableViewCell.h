//
//  BoardTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BoardExpert.h"
NS_ASSUME_NONNULL_BEGIN

@interface BoardTableViewCell : UITableViewCell
@property (nonatomic,strong) UIImageView*headV;
@property (nonatomic,strong) UILabel*nameL;
@property (nonatomic,strong) UIImageView*rankV;
@property (nonatomic,strong) UILabel*shotL;
@property (nonatomic,strong) UILabel*benifitL;
@property (nonatomic,strong) BoardExpert*model;
@end

NS_ASSUME_NONNULL_END
