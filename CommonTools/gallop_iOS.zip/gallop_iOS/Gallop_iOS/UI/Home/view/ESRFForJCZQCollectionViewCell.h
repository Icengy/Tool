//
//  ESRFForJCZQCollectionViewCell.h
//  ESTicket
//
//  Created by 王帅 on 15/12/15.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SelectedMatchModel;

@interface ESRFForJCZQCollectionViewCell : UICollectionViewCell

@property (nonatomic ,strong) SelectedMatchModel *model;

@property (nonatomic, assign) BOOL isSelected;
@property (nonatomic, assign) BOOL isWinResult;
@property (nonatomic, strong) NSString *titleText;
//@property (nonatomic, strong) NSString *detailText;
@property (nonatomic,assign) BOOL cuttentType;//足球0，篮球1

@end
