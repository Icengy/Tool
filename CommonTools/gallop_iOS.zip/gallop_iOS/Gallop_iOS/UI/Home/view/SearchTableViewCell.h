//
//  SearchTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/6.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SearchExpert.h"
NS_ASSUME_NONNULL_BEGIN

@interface SearchTableViewCell : UITableViewCell
@property (nonatomic, strong)SearchExpert*model;
@property (nonatomic,strong) UIImageView*headV;
@property (nonatomic,strong) UILabel*nameL;
@property (nonatomic,strong) UILabel*detailL;
@end

NS_ASSUME_NONNULL_END
