//
//  ExpertDetailTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertDetailTableViewCell.h"
#import "SelectMatchTableViewCell.h"

@interface ExpertDetailTableViewCell ()<UITableViewDataSource,UITableViewDelegate>

@end
@implementation ExpertDetailTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self setupView];
    }
    return self;
}
-(void)setModel:(PlanModel *)model
{
    _model = model;
        
	self.timeLabel.text = [NSString stringWithFormat:@"%@ 发布",model.releaseTime];
	
	self.viewCountLabel.text = @(self.model.browseCount).stringValue;

	self.gallopCoinImageV.image = [UIImage imageNamed:@"gold"];
	
	self.backAbleLabel.text = [NSString stringWithFormat:@" %@ 不中退款 %@ ",@"\U0000200C",@"\U0000200C"];
	self.descripLabel.text = model.title;
	if (self.model.guessStatus.integerValue == 1||self.model.guessStatus.integerValue == 2)
	{
	   
		self.amountLabel.hidden = YES;
		self.gallopCoinImageV.hidden = YES;
		self.shotV.hidden = NO;
	   
		if (self.model.guessStatus.integerValue == 1) {
			self.shotV.image = [UIImage imageNamed:@"win"];
		}else{
			self.shotV.image = [UIImage imageNamed:@"loss"];
		}
		
		if ([model.type integerValue] == 2) {
			self.backAbleLabel.hidden = NO;
		}else{
			 self.backAbleLabel.hidden = YES;
		}
	}else{
		self.shotV.hidden = YES;
		self.amountLabel.hidden = NO;
		if ([model.type integerValue] == 2) {
			self.backAbleLabel.hidden = NO;
			self.gallopCoinImageV.hidden = NO;
			self.amountLabel.text = [NSString stringWithFormat:@"%d",[model.price intValue]];
			self.amountLabel.textColor = [UIColor colorWithHexString:@"#F04844"];
		}else if([model.type integerValue] ==3){
			self.backAbleLabel.hidden = YES;
			self.amountLabel.text = @"免费";
			self.gallopCoinImageV.hidden = YES;
			self.amountLabel.textColor = [UIColor colorWithHexString:@"#0091FF"];
		} else if([model.type integerValue] == 4){
			self.backAbleLabel.hidden = YES;
			self.amountLabel.text = @"粉丝免费";
			self.gallopCoinImageV.hidden = YES;
			self.amountLabel.textColor = [UIColor colorWithHexString:@"#0091FF"];
		} else{
			self.backAbleLabel.hidden = YES;
			self.gallopCoinImageV.hidden = NO;
			self.amountLabel.text = [NSString stringWithFormat:@"%d",[model.price intValue]];
			self.amountLabel.textColor = [UIColor colorWithHexString:@"#F04844"];
		}
	   if (self.model.state.integerValue == 2||self.model.guessStatus.integerValue == 3){
		   self.shotV.hidden = NO;
		   self.gallopCoinImageV.hidden = YES;
		   self.backAbleLabel.hidden = YES;
		   self.amountLabel.hidden = YES;
						self.shotV.image = [UIImage imageNamed:@"abnormal"];
		}
	}
   
	NSInteger matchNum = model.matchInfoArr.count;
	
	if (QM_IS_STR_NIL(model.declaration)) {
		[self.matchTableView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.descripLabel.mas_bottom).offset(10);
			make.left.equalTo(self.contentView).offset(15);
			make.right.equalTo(self.contentView).offset(-15);
			make.height.mas_equalTo(@(28*matchNum));
		}];
		self.declarationLabel.hidden = YES;
		self.declarationTitleLabel.hidden = YES;
	} else {
		[self.matchTableView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.declarationLabel.mas_bottom).offset(10);
			make.left.equalTo(self.contentView).offset(15);
			make.right.equalTo(self.contentView).offset(-15);
			make.height.mas_equalTo(@(28*matchNum));
		}];
		self.declarationLabel.hidden = NO;
		self.declarationTitleLabel.hidden = NO;
		self.declarationLabel.text = model.declaration;
	}
   
	[self.matchTableView reloadData];
	
	NSString *typeStr = @"";
	if (self.model.matchInfoArr.count > 1) {
		typeStr = (self.model.field.intValue ==2) ? @"篮球-2串1" : @"足球-2串1";
	} else {
		typeStr = (self.model.field.intValue ==2) ? @"篮球-单关" : @"足球-单关";
	}
	self.typeLabel.text = typeStr;
	self.timeLabel.text = [NSString stringWithFormat:@"%@ 发布",model.releaseTime];
}

-(void)setupView
{
    [self.descripLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView).offset(10);
        make.left.equalTo(self.contentView).offset(15);
		make.width.mas_equalTo(SCREEN_WIDTH - 30);
    }];
	
	[self.declarationTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.descripLabel.mas_bottom).offset(20);
		make.left.equalTo(self.descripLabel);
	}];
	
	[self.declarationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.declarationTitleLabel.mas_bottom).offset(5);
		make.left.equalTo(self.contentView).offset(15);
		make.right.equalTo(self.contentView).offset(-15);
	}];
    
    [self.amountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.contentView).offset(-15);
		make.centerY.equalTo(self.typeLabel);
        make.height.mas_equalTo(15);
    }];
    [self.gallopCoinImageV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.amountLabel.mas_left).offset(-3);
        make.centerY.equalTo(self.typeLabel);
        make.height.mas_equalTo(13);
        make.width.mas_equalTo(13);
    }];
    [self.backAbleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.viewCountLabel.mas_right).offset(10);
        make.centerY.equalTo(self.typeLabel);
        make.height.mas_equalTo(15);
    }];
    
    [self.matchTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).offset(15);
        make.right.equalTo(self.contentView).offset(-15);
		make.top.equalTo(self.descripLabel.mas_bottom).offset(11);
		make.height.mas_equalTo(28);
    }];
    
    [self.shotV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.matchTableView).offset(-15);
		make.right.equalTo(self.contentView).offset(-15);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
	
	[self.typeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.contentView).offset(15);
		make.top.equalTo(self.matchTableView.mas_bottom).offset(10);
		make.height.mas_equalTo(15);
	}];
	
	[self.seperatorL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.typeLabel.mas_right).offset(6.5);
		make.top.equalTo(self.typeLabel);
		make.size.mas_equalTo(CGSizeMake(1, 15));
	}];
	
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.seperatorL.mas_right).offset(6.5);
		make.top.equalTo(self.typeLabel);
		make.height.mas_equalTo(15);
	}];
	
	[self.seperatorM mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.timeLabel.mas_right).offset(6.5);
		make.top.equalTo(self.typeLabel);
		make.size.mas_equalTo(CGSizeMake(1, 15));
	}];
	
    UIView*line = [[UIView alloc]init];
    [self.contentView addSubview:line];
    line.backgroundColor = RGBCOLOR(244, 244, 244);
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.typeLabel.mas_bottom).offset(9);
        make.left.right.bottom.mas_equalTo(self.contentView);
        make.height.mas_equalTo(6);
    }];
	
	[self.viewCountImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.seperatorM.mas_right).offset(7.5);
		make.size.mas_equalTo(CGSizeMake(14, 14));
		make.centerY.equalTo(self.typeLabel);
	}];
	[self.viewCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.typeLabel);
		make.left.equalTo(self.viewCountImageView.mas_right).offset(4);
	}];

}

#pragma mark tableView代理
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.01;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 24.0f;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

	NSString *cellIdentifier = @"SelectMatchTableViewCell";
	SelectMatchTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if (!cell) {
		cell = [[SelectMatchTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
	}
	
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
	MatchTag*tag  = self.model.matchInfoArr[indexPath.row];
	
	cell.timeLabel.text = [CMMUtility timeConvertWithTimeStamp:tag.matchTime.stringValue andTimeFormat:@"MM-dd HH:mm"];
						   
	if (self.model.field.intValue ==2) {
		NSString *type = @"";
		//篮球
		if ([tag.selected.type isEqualToString:@"sf"]) {
			type = @"胜负";
		} else if ([tag.selected.type isEqualToString:@"rf"]) {
			type = @"让分";
		} else if ([tag.selected.type isEqualToString:@"dxf"]) {
			type = @"大小分";
		}
		NSString *handicap = tag.selected.handicap;
		
		if (!QM_IS_STR_NIL(tag.hostScore) && tag.hostScore.integerValue >= 0) {
			handicap = [NSString stringWithFormat:@" %@:%@ ",tag.awayScore,tag.hostScore];
		} else {
			if ([handicap isEqualToString:@"0"]) {
				handicap = @"vs";
			}
		}
		
		cell.classL.text = [NSString stringWithFormat:@"[%@][%@]",tag.leagueShortName,type];
		cell.teamLabel.text = [NSString stringWithFormat:@"%@ %@ %@",tag.awayName,handicap,tag.hostName];
	} else {
		//足球
		cell.classL.text = [NSString stringWithFormat:@"[%@][竞彩]",tag.leagueShortName];
		if (!QM_IS_STR_NIL(tag.hostScore) && tag.hostScore.integerValue >= 0) {
			cell.teamLabel.text = [NSString stringWithFormat:@"%@ %@:%@ %@",tag.hostName,tag.hostScore,tag.awayScore,tag.awayName];
		} else {
			cell.teamLabel.text = [NSString stringWithFormat:@"%@ vs %@",tag.hostName,tag.awayName];
		}
	}
	return cell;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
      return self.model.matchInfoArr.count;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

#pragma mark - lazy init
-(UIImageView*)shotV
{
	if (!_shotV) {
		_shotV = [UIImageView new];
		[self.contentView addSubview:_shotV];
	}
	return _shotV;
}
-(UILabel*)descripLabel
{
	if (!_descripLabel) {
		_descripLabel = [UILabel new];
		_descripLabel.textColor = ColorTitle;
		_descripLabel.font = fcFont(15.0f);
		_descripLabel.numberOfLines = 0;
		[self.contentView addSubview:_descripLabel];
	}
	return _descripLabel;
}

-(UILabel*)declarationTitleLabel
{
	if (!_declarationTitleLabel) {
		_declarationTitleLabel = [UILabel new];
		_declarationTitleLabel.textColor = RGBCOLOR(58, 58, 58);
		_declarationTitleLabel.font = fcFont(14.0f);
		_declarationTitleLabel.text = @"专家宣言";
		[self.contentView addSubview:_declarationTitleLabel];
	}
	return _declarationTitleLabel;
}

-(UILabel*)declarationLabel
{
	if (!_declarationLabel) {
		_declarationLabel = [UILabel new];
		_declarationLabel.textColor = RGBCOLOR(102, 102, 102);
		_declarationLabel.font = fcFont(14.0f);
		_declarationLabel.numberOfLines = 2;
		[self.contentView addSubview:_declarationLabel];
	}
	return _declarationLabel;
}

-(UILabel*)timeLabel
{
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.textColor = ColorSubTitle;
		_timeLabel.font = fcFont(11);
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}
-(UILabel*)backAbleLabel
{
	if (!_backAbleLabel) {
		_backAbleLabel = [UILabel new];
		_backAbleLabel.textColor = [UIColor colorWithHexString:@"#3A3A3A"];
		_backAbleLabel.layer.borderColor = [UIColor colorWithHexString:@"#3A3A3A"].CGColor;
		_backAbleLabel.layer.cornerRadius =2;
		_backAbleLabel.layer.borderWidth = 0.5;
		_backAbleLabel.clipsToBounds = YES;
		_backAbleLabel.font = fcFont(11);;
		[self.contentView addSubview:_backAbleLabel];
	}
	return _backAbleLabel;
}
-(UILabel*)amountLabel
{
	if (!_amountLabel) {
		_amountLabel = [UILabel new];
		_amountLabel.textColor = [UIColor colorWithHexString:@"#F04844"];
		_amountLabel.font = fcFont(11);
		[self.contentView addSubview:_amountLabel];
	}
	return _amountLabel;
}
-(UIImageView*)gallopCoinImageV
{
	if (!_gallopCoinImageV) {
		_gallopCoinImageV = [UIImageView new];
		[self.contentView addSubview:_gallopCoinImageV];
	}
	return _gallopCoinImageV;
}
-(SelectMatchTableView*)matchTableView
{
	if (!_matchTableView) {
		_matchTableView = [SelectMatchTableView new];
		_matchTableView.userInteractionEnabled = NO;
		_matchTableView.delegate = self;
		_matchTableView.dataSource = self;
		[self.contentView addSubview:_matchTableView];
	}
	
	return _matchTableView;
}

-(UILabel*)typeLabel
{
	if (!_typeLabel) {
		_typeLabel = [UILabel new];
		_typeLabel.textColor = ColorSubTitle;
		_typeLabel.font = fcFont(11);
		[self.contentView addSubview:_typeLabel];
	}
	return _typeLabel;
}

- (UILabel *)seperatorL {
	if (!_seperatorL) {
		_seperatorL = [UILabel new];
		_seperatorL.backgroundColor = RGBCOLOR(216, 216, 216);
		[self.contentView addSubview:_seperatorL];
	}
	return _seperatorL;
}

- (UILabel *)seperatorM {
	if (!_seperatorM) {
		_seperatorM = [UILabel new];
		_seperatorM.backgroundColor = RGBCOLOR(216, 216, 216);
		[self.contentView addSubview:_seperatorM];
	}
	return _seperatorM;
}

- (UIImageView *)viewCountImageView {
	if (!_viewCountImageView) {
		_viewCountImageView = [UIImageView new];
		_viewCountImageView.image = GetImage(@"comunity_viewcount_icon");
		[self.contentView addSubview:_viewCountImageView];
	}
	return _viewCountImageView;
}

- (UILabel *)viewCountLabel {
	if (!_viewCountLabel) {
		_viewCountLabel = [UILabel new];
		_viewCountLabel.textColor = RGBCOLOR(102, 102, 102);
		_viewCountLabel.font = fcFont(12);
		[self.contentView addSubview:_viewCountLabel];
	}
	return _viewCountLabel;
}


@end
