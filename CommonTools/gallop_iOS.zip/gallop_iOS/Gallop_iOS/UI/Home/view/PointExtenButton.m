//
//  PointExtenButton.m
//  Gallop_iOS
//
//  Created by caizx on 2019/7/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PointExtenButton.h"

@implementation PointExtenButton

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    CGRect frame = self.bounds;
    frame.origin.x -= 15;
    frame.origin.y -= 15;
    frame.size.width += 30;
    frame.size.height += 30;
    
    if (CGRectContainsPoint(frame, point)) {
        return true;
    }
    
    return [super pointInside:point withEvent:event];
}

@end
