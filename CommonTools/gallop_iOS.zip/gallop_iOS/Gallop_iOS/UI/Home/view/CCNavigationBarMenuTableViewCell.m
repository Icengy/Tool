//
//  CCNavigationBarMenuTableViewCell.m
//  ESTicket
//
//  Created by Homosum on 2018/3/19.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//


#import "CCNavigationBarMenuTableViewCell.h"
#import "CCNavigationBarMenuItem.h"
#define imageItemSize CGSizeMake(22, 22)
@implementation CCNavigationBarMenuTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self _initSubviews];
    }
    return self;
}

- (void)_initSubviews {
    self.itemImageView = [[UIImageView alloc] init];
    self.itemImageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.contentView addSubview:self.itemImageView];
//    [self.itemImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.contentView).offset(15);
//        make.centerY.equalTo(self.contentView);
//        make.size.mas_equalTo(imageItemSize);
//    }];
    
    self.itemTitleLabel = [[UILabel alloc] init];
    self.itemTitleLabel.font = GetFont(17.0f);
    self.itemTitleLabel.textColor = [UIColor colorWithHexString:@"#4a4a4a"];
    [self.contentView addSubview:self.itemTitleLabel];
    [self.itemTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.left.equalTo(self.itemImageView.mas_right).offset(10);
        make.centerX.equalTo(self.contentView);
        make.centerY.equalTo(self.contentView);
    }];
}



- (void)setModel:(CCNavigationBarMenuItem*)model{
    self.itemImageView.image = model.image;
    self.itemTitleLabel.text = model.title;
    self.itemTitleLabel.font = model.titleFont;
    self.itemTitleLabel.textColor = model.titleColor;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
