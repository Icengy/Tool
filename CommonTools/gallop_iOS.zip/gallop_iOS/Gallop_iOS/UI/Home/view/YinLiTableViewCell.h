//
//  YinLiTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/2.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YinLi.h"

@interface YinLiTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *rankImage;
@property (weak, nonatomic) IBOutlet UILabel *rankLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headV;
@property (weak, nonatomic) IBOutlet UILabel *nameL;
@property (weak, nonatomic) IBOutlet UILabel *titleL;
@property (weak, nonatomic) IBOutlet UILabel *recentL;
@property (weak, nonatomic) IBOutlet UILabel *yinliL;

- (void)configCell:(id)model index:(NSUInteger)index;

@end

