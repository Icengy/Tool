//
//  WTCSPFForSNCollectionViewCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/28.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WTCSPFForSNModel : NSObject
/** 左边 中/未中 结果*/
@property (nonatomic, assign) BOOL guessState;
/** 左边 中/未中 显示*/
@property (nonatomic, assign) BOOL showGuessState;
/** 左边 中/未中 结果*/
@property (nonatomic, copy) NSString *title;

@end

NS_ASSUME_NONNULL_BEGIN

@interface WTCSPFForSNCollectionViewCell : UICollectionViewCell

@property (nonatomic ,strong) WTCSPFForSNModel *model;

@end

NS_ASSUME_NONNULL_END
