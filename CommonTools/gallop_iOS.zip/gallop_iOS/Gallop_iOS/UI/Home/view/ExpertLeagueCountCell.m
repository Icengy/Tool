//
//  ExpertLeagueCountCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertLeagueCountCell.h"
#import "ExpertDetail.h"

@interface ExpertLeagueCountCell()
@property (nonatomic,strong) UIButton *rankBtn;
@property (nonatomic,strong) UILabel  *leagueLabel;
@property (nonatomic,strong) UILabel  *recentLabel;
@property (nonatomic,strong) UILabel  *totalLabel;

@end

@implementation ExpertLeagueCountCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.rankBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.contentView).offset(15);
		make.size.mas_equalTo(CGSizeMake(18, 18));
		make.centerY.equalTo(self.contentView);
	}];
	[self.leagueLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.rankBtn.mas_right).offset(10);
		make.centerY.equalTo(self.contentView);
	}];
	[self.totalLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.contentView).offset(-17);
		make.centerY.equalTo(self.contentView);
	}];
	[self.recentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.totalLabel.mas_left).offset(-27);
		make.centerY.equalTo(self.contentView);
	}];
}


- (void)configCellWithModel:(ExpertLeagueListItem *)model row:(NSUInteger)row;{
	[self.rankBtn setTitle:@(row + 1).stringValue forState:UIControlStateNormal];
	self.rankBtn.backgroundColor = row == 0 ? RGBCOLOR(240, 72, 68) : row == 1 ? RGBCOLOR(249, 129, 49) : ColorAppBlack;
	self.leagueLabel.text = model.leagueName;
	self.recentLabel.text = [NSString stringWithFormat:@"( %@中  %@输 )",@(model.redCount),@(model.totalCount - model.redCount)];
	[self.recentLabel setColorArr:@[RGBCOLOR(240, 72, 68)] forTextArr:@[[NSString stringWithFormat:@"%@中",@(model.redCount)]]];
	self.totalLabel.text = [NSString stringWithFormat:@"共%@场",@(model.totalCount)];
}

#pragma mark - lazy init
- (UIButton *)rankBtn {
	if (!_rankBtn) {
		_rankBtn = [UIButton new];
		[_rankBtn setTitleColor:RGBCOLOR(255, 255, 255) forState:UIControlStateNormal];
		_rankBtn.titleLabel.font = fcFont(11);
		[self.contentView addSubview:_rankBtn];
		_rankBtn.layer.cornerRadius = 9;
		_rankBtn.clipsToBounds = YES;
		_rankBtn.enabled = NO;
		[self.contentView addSubview:_rankBtn];
	}
	return _rankBtn;
}

- (UILabel *)leagueLabel {
	if (!_leagueLabel) {
		_leagueLabel = [UILabel new];
		_leagueLabel.textColor = ColorAppBlack;
		_leagueLabel.font = fcFont(13);
		[self.contentView addSubview:_leagueLabel];
	}
	return _leagueLabel;
}

- (UILabel *)recentLabel {
	if (!_recentLabel) {
		_recentLabel = [UILabel new];
		_recentLabel.textColor = ColorAppBlack;
		_recentLabel.font = fcFont(13);
		[self.contentView addSubview:_recentLabel];
	}
	return _recentLabel;
}

- (UILabel *)totalLabel {
	if (!_totalLabel) {
		_totalLabel = [UILabel new];
		_totalLabel.textColor = ColorAppBlack;
		_totalLabel.font = fcFont(12);
		[self.contentView addSubview:_totalLabel];
	}
	return _totalLabel;
}
@end
