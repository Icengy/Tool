//
//  ExpertSearchTableViewCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/14.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESTableViewCell.h"

@class GallopExpertModel;
@class ExpertSearchTableViewCell;

NS_ASSUME_NONNULL_BEGIN

@protocol ExpertSearchTableViewCellDelegate <NSObject>

@optional

/// 关注按钮方法返回
/// @param cell cell
/// @param model model
/// @param state 0:未关注 1:已关注
/// @param btns btns
- (void)listCell:(ExpertSearchTableViewCell *)cell didClickToFollow:(GallopExpertModel *)model withState:(NSInteger)state withBtns:(NSArray <UIButton *>*)btns;

@optional
/// 头像点击
/// @param cell cell
/// @param model model
- (void)listCell:(ExpertSearchTableViewCell *)cell didClickToAvatar:(GallopExpertModel *)model;

@end

@interface ExpertSearchTableViewCell : ESTableViewCell

@property (nonatomic ,weak) id <ExpertSearchTableViewCellDelegate> delegate;
@property (nonatomic ,strong) GallopExpertModel *model;

@end

NS_ASSUME_NONNULL_END
