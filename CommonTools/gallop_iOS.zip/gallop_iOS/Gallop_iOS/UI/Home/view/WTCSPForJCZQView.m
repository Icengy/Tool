//
//  WTCSPForJCZQView.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "WTCSPForJCZQView.h"
#import "SelectPlanViewController.h"
#import "ESRFForJCZQCollectionViewCell.h"
#import "ESRFForJCNotSellCollectionCell.h"

#import "WTCSPFForSNCollectionViewCell.h"

@interface WTCSPForJCZQView()<UICollectionViewDataSource,UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@property (nonatomic, strong) UICollectionView *leftCollectionView;
@property (nonatomic, strong) UICollectionView *collectionView;

@property (nonatomic, strong) NSIndexPath *lastIndex;
@property (nonatomic, strong) NSMutableArray *selectedItemArr;

@property (nonatomic, strong) NSMutableArray <NSArray *>*dataArray;
@property (nonatomic, strong) NSMutableArray <WTCSPFForSNModel *>*snDatas;


@end
@implementation WTCSPForJCZQView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = ColorDefaultBackground;
        self.selectedItemArr = [NSMutableArray arrayWithCapacity:0];
        self.dataArray = @[].mutableCopy;
        self.snDatas = @[].mutableCopy;
        
        [self setupView];
    }
    return self;
}

- (void)setupView {

    [self addSubview:self.leftCollectionView];
    [self addSubview:self.collectionView];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.leftCollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(0);
        make.centerY.height.equalTo(self);
        make.width.offset(45.0);
    }];
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.leftCollectionView.mas_right).offset(16);
        make.centerY.height.right.equalTo(self);
    }];
}

-(void)setForbidSelect:(BOOL)forbidSelect {
    _forbidSelect = forbidSelect;
    self.userInteractionEnabled = !forbidSelect;
    self.collectionView.userInteractionEnabled = !forbidSelect;
}

#pragma mark - UICollectionViewDataSource , UICollectionViewDelegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    if (collectionView.tag % 2) {
        return self.snDatas.count;
    }
    return self.dataArray.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    if (collectionView.tag % 2) {
        return 1;
    }
    if (self.showResultType == 0) {
        switch (section) {
            case 0: {
                if (!self.model.sfAllow) return 1;
                break;
            }
            case 1: {
                if (!self.model.rqsfAllow) return 1;
                break;
            }
                
            default:
                break;
        }
    }else {
        switch (self.showResultType) {
            case 1: {
                if (!self.model.sfAllow) return 1;
                break;
            }
            case 2: {
                if (!self.model.rqsfAllow) return 1;
                break;
            }
                
            default:
                break;
        }
    }
    return 3;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (collectionView.tag % 2) {
        WTCSPFForSNCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([WTCSPFForSNCollectionViewCell class]) forIndexPath:indexPath];
        cell.model = [self.snDatas objectAtIndex:indexPath.section];
        
        return cell;
    }
    
    NSInteger items = [collectionView numberOfItemsInSection:indexPath.section];
    if (items == 1) {
        ESRFForJCNotSellCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ESRFForJCNotSellCollectionCell class]) forIndexPath:indexPath];
        return cell;
    }
    
    ESRFForJCZQCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ESRFForJCZQCollectionViewCell class]) forIndexPath:indexPath];
    cell.cuttentType = 0;
    
    
    NSArray *datas = [self.dataArray objectAtIndex:indexPath.section];
    SelectedMatchModel *item = [datas objectAtIndex:indexPath.item];
    
    if (self.isExtreme) {
        item.winResult = NO;
    }
    NSString *title;
    if ([CommonUtils isEqualToNonNull:item.title]) {
        title = item.title;
        if ([CommonUtils isEqualToNonNull:item.odds]) {
            title = [NSString stringWithFormat:@"%@ %@",title, item.odds];
        }
    }
    
    cell.titleText = title;
    cell.isSelected = item.selected;
    cell.isWinResult = item.winResult;
    
    cell.model = item;
    
    return cell;
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView.tag % 2) {
        NSInteger sections = self.snDatas.count;
        CGFloat height = (collectionView.height - WTCSPForJCMargin *(sections - 1)) / sections;
        return CGSizeMake(collectionView.width  , height);
    }
    
    NSInteger items = [collectionView numberOfItemsInSection:indexPath.section];
    NSInteger sections = self.dataArray.count;
    
    CGFloat width = (collectionView.width - WTCSPForJCMargin *(items - 1)) / items;
    CGFloat height = (collectionView.height - WTCSPForJCMargin *(sections - 1)) / sections;
    if (items == 1) {
        width = collectionView.width - WTCSPForJCMargin *2;
        height = (collectionView.height - WTCSPForJCMargin *(sections + 1)) / sections;
    }
    
    return CGSizeMake(width  , height);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    if (collectionView.tag % 2) {
        return UIEdgeInsetsMake(0, 0, WTCSPForJCMargin, 0);;
    }
    NSInteger items = [collectionView numberOfItemsInSection:section];
    if (items == 1) {
        return UIEdgeInsetsMake(section?0:WTCSPForJCMargin, WTCSPForJCMargin, WTCSPForJCMargin, WTCSPForJCMargin);
    }
    return UIEdgeInsetsMake(0, 0, WTCSPForJCMargin, 0);
}


#pragma mark -
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (collectionView.tag % 2) return;
    
    NSInteger items = [collectionView numberOfItemsInSection:indexPath.section];
    
    if (items == 1) return;
    
    if (self.model.selected == NO) {
         [self.selectedItemArr removeAllObjects];
    }else{
         [self.selectedItemArr removeAllObjects];
    
        NSArray*arr1 = [_model.sfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
        NSArray*arr2 = [_model.rqsfArray filteredArrayUsingPredicate:[NSPredicate predicateWithFormat:@"selected = %@",[NSNumber numberWithBool:YES]]];
        [self.selectedItemArr addObjectsFromArray:arr1];
        [self.selectedItemArr addObjectsFromArray:arr2];
    }
    
    SelectedMatchModel *item;
    
    if (indexPath.section == 0) {
        item = [_model.sfArray objectAtIndex:indexPath.item];
    }else{
        item = [_model.rqsfArray objectAtIndex:indexPath.item];
    }
    if (self.selectedItemArr.count==2) {
        if (![self.selectedItemArr containsObject:item]) {
            [CMMUtility showToastWithText:@"单场比赛最多选择2个选项"];
            return;
        }
    }
    
     if (![item.odds isEqualToString:@"--"]&&!QM_IS_STR_NIL(item.odds)) {
        item.selected = !item.selected;
        if (item.selected) {
            if (![self.selectedItemArr containsObject:item]) {
                [self.selectedItemArr addObject:item];
            }
        }else{
            if ([self.selectedItemArr containsObject:item]) {
                [self.selectedItemArr removeObject:item];
            }
        }
    }
    if (self.selectedItemArr.count>0) {
        self.model.selected = YES;
    }else{
        self.model.selected = NO;
    }
    if (self.delegate&&[self.delegate respondsToSelector:@selector(spfForJCZQView:didSelectItem:)]) {
        [self.delegate spfForJCZQView:self didSelectItem:self.model];
    }
    
    
    [collectionView reloadItemsAtIndexPaths:@[indexPath]];
}

#pragma mark -
-(UIViewController *)getControllerFromView:(UIView *)view {
    // 遍历响应者链。返回第一个找到视图控制器
    UIResponder *responder = view;
    while ((responder = [responder nextResponder])){
        if ([responder isKindOfClass: [UIViewController class]]){
            return (UIViewController *)responder;
        }
    }
    // 如果没有找到则返回nil
    return nil;
}

#pragma mark -
- (UICollectionView *)collectionView
{
    if (!_collectionView) {
        UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
        layout.minimumInteritemSpacing = WTCSPForJCMargin;
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = RGBCOLORV(0xE6E6E6);
        _collectionView.scrollEnabled = NO;
        
        _collectionView.layer.masksToBounds = YES;
        _collectionView.layer.cornerRadius = 3.0;
        
        [_collectionView registerClass:[ESRFForJCZQCollectionViewCell class] forCellWithReuseIdentifier:NSStringFromClass([ESRFForJCZQCollectionViewCell class])];
        
        [_collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ESRFForJCNotSellCollectionCell class]) bundle:nil] forCellWithReuseIdentifier:NSStringFromClass([ESRFForJCNotSellCollectionCell class])];
    }
    return _collectionView;
}

- (UICollectionView *)leftCollectionView {
    if (!_leftCollectionView) {
        UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
        _leftCollectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _leftCollectionView.tag = 200001;
        _leftCollectionView.dataSource = self;
        _leftCollectionView.delegate = self;
        _leftCollectionView.backgroundColor = RGBCOLORV(0xE6E6E6);
        
        _leftCollectionView.layer.masksToBounds = YES;
        _leftCollectionView.layer.cornerRadius = 3.0;
        
        [_leftCollectionView registerNib:[UINib nibWithNibName:NSStringFromClass([WTCSPFForSNCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:NSStringFromClass([WTCSPFForSNCollectionViewCell class])];
    }
    return _leftCollectionView;
}

-(void)setModel:(MatchModel *)model {
    _model = model;
    
    if (self.dataArray.count) [self.dataArray removeAllObjects];
    if (self.snDatas.count) [self.snDatas removeAllObjects];
    
    __block BOOL showGuessState = NO, showGuessState1 = NO;
    __block BOOL guessState = NO, guessState1 = NO;
    if (self.forbidSelect) {
        [_model.sfArray enumerateObjectsUsingBlock:^(SelectedMatchModel *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (self.isExtreme) {
                obj.winResult = NO;
            }
            if (obj.winResult) showGuessState = YES;
            
            if (obj.winResult && obj.selected) {
                guessState = YES;
            }
        }];
        [_model.rqsfArray enumerateObjectsUsingBlock:^(SelectedMatchModel *  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if (self.isExtreme) {
                obj.winResult = NO;
            }
            if (obj.winResult) showGuessState1 = YES;
            if (obj.winResult && obj.selected) {
                guessState1 = YES;
            }
        }];
    }
    switch (self.showResultType) {
        case 1: {
            [self.dataArray addObject:_model.sfArray];
            
            [_snDatas addObject:[self sfModel:guessState showGuessState:showGuessState]];
            break;
        }
        case 2: {
            [self.dataArray addObject:_model.rqsfArray];
            
            [_snDatas addObject:[self sqspfModel:guessState showGuessState:showGuessState]];
            break;
        }
            
        default: {
            [self.dataArray addObject:_model.sfArray];
            [self.dataArray addObject:_model.rqsfArray];
            
            [_snDatas addObject:[self sfModel:guessState showGuessState:showGuessState]];
            [_snDatas addObject:[self sqspfModel:guessState showGuessState:showGuessState]];
            break;
        }
    }
    
    [self.leftCollectionView reloadData];
    [self.collectionView reloadData];

    [self setNeedsLayout];
}


#pragma mark -
- (WTCSPFForSNModel *)sfModel:(BOOL)guessState showGuessState:(BOOL)showGuessState  {
    WTCSPFForSNModel *model = [WTCSPFForSNModel new];
    model.guessState = guessState;
    model.showGuessState = showGuessState;
    model.title = @"0";
    return model;
}

- (WTCSPFForSNModel *)sqspfModel:(BOOL)guessState showGuessState:(BOOL)showGuessState  {
    WTCSPFForSNModel *model = [WTCSPFForSNModel new];
    model.guessState = guessState;
    model.showGuessState = showGuessState;
    model.title = [NSString stringWithFormat:@"%@", QM_IS_STR_NIL(self.model.rangNumStr) ? @"-" : self.model.rangNumStr];
    return model;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
