//
//  PlanDetailGameInfoView.m
//  Gallop_iOS
//
//  Created by IT on 2019/7/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PlanDetailGameInfoView.h"
#import "WTCSPForJCZQView.h"
#import "PlanModel.h"

@interface PlanDetailGameInfoView()
@property (nonatomic,strong) UILabel                 *headLabel;
//@property (nonatomic,strong) UILabel                 *refundLabel;
@property (nonatomic,strong) UIImageView             *winStateImageView;
@property (nonatomic,strong) UIView                  *lineView;
//第一场比赛(这里最多存在2串1情况,故未进行复用)
@property (nonatomic,strong) UIView                 *firstAgainstCardView;
@property (nonatomic,strong) UIImageView    *firstTeamAIconView;
@property (nonatomic,strong) UIImageView    *firstTeamBIconView;
@property (nonatomic,strong) UILabel        *firstLeagueLabel;
@property (nonatomic,strong) UILabel        *firstTimeLabel;
@property (nonatomic,strong) UILabel        *firstScoreLabel;
@property (nonatomic,strong) UILabel        *firstTeamANameLabel;
@property (nonatomic,strong) UILabel        *firstTeamBNameLabel;
@property (nonatomic,strong) UILabel        *firstStateLabel;
@property (nonatomic,strong) UIImageView    *firstArrowView;
@property (nonatomic,strong) UIView         *fistFatherPredictView;
@property (nonatomic,strong) WTCSPForJCZQView       *firstPredictView;
//第二场比赛(这里最多存在2串1情况,故未进行复用)
@property (nonatomic,strong) UIView                 *secondAgainstCardView;
@property (nonatomic,strong) UIImageView    *secondTeamAIconView;
@property (nonatomic,strong) UIImageView    *secondTeamBIconView;
@property (nonatomic,strong) UILabel        *secondLeagueLabel;
@property (nonatomic,strong) UILabel        *secondTimeLabel;
@property (nonatomic,strong) UILabel        *secondScoreLabel;
@property (nonatomic,strong) UILabel        *secondTeamANameLabel;
@property (nonatomic,strong) UILabel        *secondTeamBNameLabel;
@property (nonatomic,strong) UILabel        *secondStateLabel;
@property (nonatomic,strong) UIImageView    *secondArrowView;
@property (nonatomic,strong) UIView         *secondFatherPredictView;
@property (nonatomic,strong) WTCSPForJCZQView       *secondPredictView;
@property (nonatomic,assign) BOOL isExtreme;
//分割线
@property (nonatomic,strong) UILabel                *sepratorLabel;

@property(nonatomic, strong) PlanModel      *planModel;
@end

@implementation PlanDetailGameInfoView
#pragma mark - init
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self layout];
    }
    return self;
}

#pragma mark - layout
- (void)layout {
    self.backgroundColor = [UIColor whiteColor];
//    //圆角
//    self.layer.cornerRadius = 8;
//    //阴影
//    self.layer.shadowColor   = RGBCOLOR(187, 187, 187).CGColor;
//    self.layer.shadowOffset  = CGSizeMake(0, 0);
//    self.layer.shadowOpacity = 1;
//    self.layer.shadowOpacity = 5;
//    self.layer.shadowRadius  = 8;
//    self.layer.masksToBounds = NO;
//    self.clipsToBounds = NO;
    
    //headLabel
    [self.headLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(9.5);
        make.top.equalTo(self).offset(6);
    }];
//    [self.refundLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.right.equalTo(self).offset(-10.5);
//        make.centerY.equalTo(self.headLabel);
//        make.size.mas_equalTo(CGSizeMake(57, 17));
//    }];
    [self.winStateImageView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.size.mas_equalTo(CGSizeMake(30, 30));
        make.right.equalTo(self).offset(-10.5);
        make.top.equalTo(self).offset(12.5);
    }];
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headLabel.mas_bottom).offset(5);
        make.left.right.equalTo(self);
        make.height.mas_equalTo(0.5);
    }];
    //firstCard
    [self.firstAgainstCardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(self);
        make.top.equalTo(self).offset(28);
    }];
    [self.firstTeamAIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.firstAgainstCardView).offset(17.5);
        make.left.equalTo(self.firstAgainstCardView).offset(65);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [self.firstTeamANameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstTeamAIconView);
        make.top.equalTo(self.firstTeamAIconView.mas_bottom).offset(6);
		make.width.mas_equalTo(120);
    }];
    [self.firstTeamBIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.firstAgainstCardView).offset(-65);
        make.top.equalTo(self.firstAgainstCardView).offset(17.5);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [self.firstTeamBNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstTeamBIconView);
        make.top.equalTo(self.firstTeamBIconView.mas_bottom).offset(6);
		make.width.mas_equalTo(120);
    }];
    [self.firstLeagueLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstAgainstCardView);
        make.top.equalTo(self.firstTeamAIconView);
    }];
    [self.firstTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstAgainstCardView);
        make.top.equalTo(self.firstLeagueLabel.mas_bottom).offset(4);
    }];
    [self.firstScoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstAgainstCardView);
        make.top.equalTo(self.firstLeagueLabel.mas_bottom).offset(3);
    }];
    [self.firstStateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.firstAgainstCardView);
        make.centerY.equalTo(self.firstTeamANameLabel);
        make.bottom.equalTo(self.firstAgainstCardView).offset(-14).priority(700);
        make.bottom.equalTo(self.fistFatherPredictView.mas_top).offset(-10).priority(800);
    }];
    [self.firstArrowView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.firstAgainstCardView).offset(-11);
        make.centerY.equalTo(self.firstTeamBIconView);
        make.size.mas_equalTo(CGSizeMake(7, 14));
    }];
    [self.fistFatherPredictView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.firstStateLabel.mas_bottom).offset(10);
        make.left.equalTo(self.firstAgainstCardView).offset(10);
        make.right.equalTo(self.firstAgainstCardView).offset(-10);
        make.bottom.equalTo(self.firstAgainstCardView).offset(-14);
        make.height.mas_equalTo(80);
    }];
    //secondCard
    [self.secondAgainstCardView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.firstAgainstCardView.mas_bottom);
        make.left.right.equalTo(self);
        make.bottom.equalTo(self);
    }];
    [self.sepratorLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.secondAgainstCardView);
        make.left.equalTo(self.secondAgainstCardView).offset(10);
        make.right.equalTo(self.secondAgainstCardView).offset(-10);
        make.height.mas_equalTo(6);
    }];
    [self.secondTeamAIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.sepratorLabel.mas_bottom).offset(13.5);
        make.left.equalTo(self.secondAgainstCardView).offset(65);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [self.secondTeamANameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondTeamAIconView);
        make.top.equalTo(self.secondTeamAIconView.mas_bottom).offset(6);
		make.width.mas_equalTo(120);
    }];
    [self.secondTeamBIconView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.secondAgainstCardView).offset(-65);
        make.top.equalTo(self.sepratorLabel.mas_bottom).offset(13.5);
        make.size.mas_equalTo(CGSizeMake(50, 50));
    }];
    [self.secondTeamBNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondTeamBIconView);
        make.top.equalTo(self.secondTeamBIconView.mas_bottom).offset(6);
		make.width.mas_equalTo(120);
    }];
    [self.secondLeagueLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondAgainstCardView);
        make.top.equalTo(self.secondTeamAIconView);
    }];
    [self.secondTimeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondAgainstCardView);
        make.top.equalTo(self.secondLeagueLabel.mas_bottom).offset(4);
    }];
    [self.secondScoreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondAgainstCardView);
        make.top.equalTo(self.secondLeagueLabel.mas_bottom).offset(3);
    }];
    [self.secondStateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.secondAgainstCardView);
        make.centerY.equalTo(self.secondTeamANameLabel);
        make.bottom.equalTo(self.secondAgainstCardView).offset(-14).priority(700);
        make.bottom.equalTo(self.secondFatherPredictView.mas_top).offset(-10).priority(800);
    }];
    [self.secondArrowView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.secondAgainstCardView).offset(-11);
        make.centerY.equalTo(self.secondTeamBIconView);
        make.size.mas_equalTo(CGSizeMake(7, 14));
    }];
    [self.secondFatherPredictView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.secondAgainstCardView).offset(10);
        make.right.equalTo(self.secondAgainstCardView).offset(-10);
        make.height.mas_equalTo(80);
        make.bottom.equalTo(self.secondAgainstCardView).offset(-14);
    }];
}

#pragma mark - action
- (void)cardClick:(UITapGestureRecognizer *)tap {
    MatchModel *matchModel;
    if (tap.view.tag == 10001) {
        if (!QM_IS_ARRAY_NIL(self.planModel.matches)&&self.planModel.matches.count>=1) {
            matchModel = self.planModel.matches[0];
        }
        
    } else {
         if (!QM_IS_ARRAY_NIL(self.planModel.matches)&&self.planModel.matches.count>=2) {
        matchModel = self.planModel.matches[1];
         }
    }
    if ([self.delegate respondsToSelector:@selector(matchCardClick:)]) {
        if (matchModel) {
            [self.delegate matchCardClick:matchModel];
        }
        
    }
}

#pragma mark - config
//数据配置
- (void)configPlanDetailGameInfoView:(id)model {
    self.planModel = model;
//    //不中退款
//    if (self.planModel.type.integerValue == 2) {
//        self.refundLabel.hidden = NO;
//    } else if (self.planModel.type.integerValue == 3) {
//        self.refundLabel.hidden = NO;
//        self.refundLabel.text = @"免费";
//        self.refundLabel.textColor  = [UIColor colorWithHexString:@"#0091FF"];
//        self.refundLabel.layer.borderWidth = 0;
//	} else if (self.planModel.type.integerValue == 4) {
//		self.refundLabel.hidden = NO;
//		self.refundLabel.text = @"粉丝免费";
//		self.refundLabel.textColor  = [UIColor colorWithHexString:@"#0091FF"];
//		self.refundLabel.layer.borderWidth = 0;
//	} else {
//		self.refundLabel.hidden = YES;
//	}
    //第一场
    if (self.planModel.matches.count <= 0) {
        return;
    }
    MatchModel *matchModel = self.planModel.matches[0];
    self.firstTeamANameLabel.text = matchModel.hostName;
    self.firstTeamBNameLabel.text =  matchModel.awayName;
    NSString *mathTime = [[matchModel.matchTime substringToIndex:matchModel.matchTime.length-3] substringFromIndex:5];
    self.firstLeagueLabel.text = [NSString stringWithFormat:@"%@ %@",matchModel.matchNum,matchModel.leagueShortName];
    self.firstTimeLabel.text = mathTime;
    if (self.planModel.state.integerValue == 2) {
        self.firstStateLabel.text = @"比赛异常取消";
        self.winStateImageView.hidden = NO;
        self.winStateImageView.image = [UIImage imageNamed:@"abnormal"];
        [self bringSubviewToFront:self.winStateImageView];
        self.firstStateLabel.textColor = ColorButtonRed;
        self.isExtreme = YES;
    }else{
        if (self.planModel.guessStatus.integerValue == 9) {
            if ([CMMUtility timeCompareWithNow:[CMMUtility timeSwitchTimestamp:matchModel.matchTime andFormatter:@"yyyy-MM-dd HH:mm:ss"]]) {
                //未开始
                self.firstStateLabel.text = @"未开始";
                self.firstStateLabel.textColor = RGBCOLOR(249, 129, 29);
            }else if (!QM_IS_STR_NIL(matchModel.lotteryTime)){
                self.firstScoreLabel.text = [NSString stringWithFormat:@"%@:%@",matchModel.hostScore,matchModel.awayScore];
                self.firstScoreLabel.hidden = NO;
                self.firstTimeLabel.hidden = YES;
                self.firstStateLabel.text = @"已结束";
                self.firstStateLabel.textColor = RGBCOLOR(168, 168, 168);
                //比赛结果处理
                [self dealWinResult:matchModel];
                
                self.firstPredictView.isExtreme = self.isExtreme;
                self.firstPredictView.model = matchModel;
//                [self.firstPredictView setupView];
                
            }else{
                //已开始
                self.firstStateLabel.text = @"进行中";
                self.firstStateLabel.textColor = ColorAppBlack;
            }
            
        }else if (self.planModel.guessStatus.integerValue == 1 || self.planModel.guessStatus.integerValue == 2){
            self.firstScoreLabel.text = [NSString stringWithFormat:@"%@:%@",matchModel.hostScore,matchModel.awayScore];
            self.firstScoreLabel.hidden = NO;
            self.firstTimeLabel.hidden = YES;
            self.firstStateLabel.text = @"已结束";
            self.firstStateLabel.textColor = RGBCOLOR(168, 168, 168);
            //比赛结果处理
            [self dealWinResult:matchModel];
            
            self.firstPredictView.isExtreme = self.isExtreme;
            self.firstPredictView.model = matchModel;
            
//            [self.firstPredictView setupView];
            //中奖标识(仅在第一张卡片显示)
            self.winStateImageView.hidden = NO;
            [self bringSubviewToFront:self.winStateImageView];
            if (self.planModel.guessStatus.integerValue == 2) {
                //未中奖
                self.winStateImageView.image = [UIImage imageNamed:@"loss"];
            }
        }else{
            self.firstStateLabel.text = @"比赛异常取消";
            self.winStateImageView.hidden = NO;
            self.winStateImageView.image = [UIImage imageNamed:@"abnormal"];
            [self bringSubviewToFront:self.winStateImageView];
            [self bringSubviewToFront:self.winStateImageView];
            self.isExtreme = YES;
        }
    }
    
    //是否购买
    if (matchModel.selects.count) {
        //选中处理
        [self dealSelected:matchModel];
        if (!QM_IS_STR_NIL(matchModel.lotteryTime)) {
            [self dealWinResult:matchModel];
        }
        self.firstPredictView.isExtreme = self.isExtreme;
        self.firstPredictView.model = matchModel;
        
//        [self.firstPredictView setupView];
        
        NSString *finalType;
        NSInteger sCount = matchModel.selects.count;
        long sResult = 0;//0:都显示，1：显示胜负平；2:显示亚指胜负平
        NSArray*resArr = @[@"winLose",@"concedeWinLose"];
        if (sCount == 1) {
             SelectResult *sModel = matchModel.selects[0];
            sResult = [resArr indexOfObject:sModel.type]+1;
        }else{
            for (int i = 0; i<sCount; i++) {
                SelectResult *sModel = matchModel.selects[i];
                if (QM_IS_STR_NIL(finalType)) {
                    finalType = sModel.type;
                }else{
                    if (![finalType isEqualToString:sModel.type]) {
                        break;
                    }
                    if (i==sCount-1) {
                        sResult = [resArr indexOfObject:sModel.type]+1;
                        
                    }
                }
            }
        }
        switch (sResult) {
            case 1:
            {
                [self.fistFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(40);
                }];
                 [self.firstPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
            }
                break;
            case 2:
            {
                [self.fistFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(40);
                }];
                [self.firstPredictView setFrame:CGRectMake(0, -40,SCREEN_WIDTH - 50 , 80)];
            }
                break;
                
            default:
            {
                [self.fistFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(80);
                }];
                [self.firstPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
            }
                break;
        }
    } else {
//        [self.fistFatherPredictView removeFromSuperview];
        self.firstPredictView.isExtreme = self.isExtreme;
        self.firstPredictView.model = matchModel;
        
//        [self.firstPredictView setupView];
        [self.fistFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(80);
        }];
        [self.firstPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
    }
    
    
    //第二场(2串1 存在第二场比赛)
    if (self.planModel.matches.count != 2) {
        [self.secondAgainstCardView removeFromSuperview];
        [self mas_updateConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.firstAgainstCardView);
        }];
        return;
    }
    self.headLabel.text = @"竞足-2串1";
    MatchModel *secondMatchModel = self.planModel.matches[1];
    self.secondTeamANameLabel.text = secondMatchModel.hostName;
    self.secondTeamBNameLabel.text =  secondMatchModel.awayName;
    mathTime = [[secondMatchModel.matchTime substringToIndex:secondMatchModel.matchTime.length-3] substringFromIndex:5];
    self.secondLeagueLabel.text = [NSString stringWithFormat:@"%@ %@",secondMatchModel.matchNum,secondMatchModel.leagueShortName];
    self.secondTimeLabel.text = mathTime;
    
    if (self.planModel.state.integerValue == 2) {
        self.secondStateLabel.text = @"比赛异常取消";
        self.winStateImageView.hidden = NO;
        self.winStateImageView.image = [UIImage imageNamed:@"abnormal"];
        [self bringSubviewToFront:self.winStateImageView];
        self.secondStateLabel.textColor = ColorButtonRed;
    }else{
        if (self.planModel.guessStatus.integerValue == 9) {
            if ([CMMUtility timeCompareWithNow:[CMMUtility timeSwitchTimestamp:secondMatchModel.matchTime andFormatter:@"yyyy-MM-dd HH:mm:ss"]]) {
                //未开始
                self.secondStateLabel.text = @"未开始";
                self.secondStateLabel.textColor = RGBCOLOR(249, 129, 29);
            }else if (!QM_IS_STR_NIL(secondMatchModel.lotteryTime)){
                self.secondScoreLabel.text = [NSString stringWithFormat:@"%@:%@",secondMatchModel.hostScore,secondMatchModel.awayScore];
                self.secondScoreLabel.hidden = NO;
                self.secondTimeLabel.hidden = YES;
                self.secondStateLabel.text = @"已结束";
                self.secondStateLabel.textColor = RGBCOLOR(168, 168, 168);
                //比赛结果处理
                [self dealWinResult:secondMatchModel];
                self.secondPredictView.isExtreme = self.isExtreme;
                self.secondPredictView.model = secondMatchModel;
                
//                [self.secondPredictView setupView];
            }else{
                //已开始
                self.secondStateLabel.text = @"进行中";
                self.secondStateLabel.textColor = ColorAppBlack;
            }
            
        }else if (self.planModel.guessStatus.integerValue == 1 || self.planModel.guessStatus.integerValue == 2){
            
            self.secondScoreLabel.text = [NSString stringWithFormat:@"%@:%@",secondMatchModel.hostScore,secondMatchModel.awayScore];
            self.secondScoreLabel.hidden = NO;
            self.secondTimeLabel.hidden = YES;
            self.secondStateLabel.text = @"已结束";
            self.secondStateLabel.textColor = RGBCOLOR(168, 168, 168);
            //比赛结果处理
            [self dealWinResult:secondMatchModel];
            
            self.secondPredictView.isExtreme = self.isExtreme;
            self.secondPredictView.model = secondMatchModel;
//            [self.secondPredictView setupView];
        }else{
            self.secondStateLabel.text = @"比赛异常取消";
            self.winStateImageView.hidden = NO;
            self.winStateImageView.image = [UIImage imageNamed:@"abnormal"];
            [self bringSubviewToFront:self.winStateImageView];
        }
    }
    
    //是否购买
    if (secondMatchModel.selects.count) {
        [self dealSelected:secondMatchModel];
        if (!QM_IS_STR_NIL(secondMatchModel.lotteryTime)) {
            [self dealWinResult:secondMatchModel];
        }
        self.secondPredictView.isExtreme = self.isExtreme;
        self.secondPredictView.model = secondMatchModel;
        
//        [self.secondPredictView setupView];
        
        NSString *finalType;
        NSInteger sCount = secondMatchModel.selects.count;
        long sResult = 0;//0:都显示，1：显示胜负平；2:显示亚指胜负平
        NSArray*resArr = @[@"winLose",@"concedeWinLose"];
        if (sCount == 1) {
            SelectResult *sModel = secondMatchModel.selects[0];
            sResult = [resArr indexOfObject:sModel.type]+1;
        }else{
            for (int i = 0; i<sCount; i++) {
                SelectResult *sModel = secondMatchModel.selects[i];
                if (QM_IS_STR_NIL(finalType)) {
                    finalType = sModel.type;
                }else{
                    if (![finalType isEqualToString:sModel.type]) {
                        break;
                    }
                    if (i==sCount-1) {
                        sResult = [resArr indexOfObject:sModel.type]+1;
                        
                    }
                }
            }
        }
        switch (sResult) {
            case 1:
            {
                [self.secondFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(40);
                }];
                [self.secondPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
            }
                break;
            case 2:
            {
                [self.secondFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(40);
                }];
                [self.secondPredictView setFrame:CGRectMake(0, -40,SCREEN_WIDTH - 50 , 80)];
            }
                break;
                
            default:
            {
                [self.secondFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
                    make.height.mas_equalTo(80);
                }];
                [self.secondPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
            }
                break;
        }
    } else {
//        [self.secondFatherPredictView removeFromSuperview];
        self.secondPredictView.isExtreme = self.isExtreme;
        self.secondPredictView.model = secondMatchModel;
        
//        [self.secondPredictView setupView];
        [self.secondFatherPredictView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.height.mas_equalTo(80);
        }];
        [self.secondPredictView setFrame:CGRectMake(0, 0,SCREEN_WIDTH - 50 , 80)];
    }
    
    
}

- (void)dealSelected:(MatchModel *)model {
//    if (model.selects.count == 0) {
//        return;
//    }
//    
//    NSMutableDictionary *tmpDict = [NSMutableDictionary dictionary];
//
//    for (SelectResult *result in model.selects) {
//        [tmpDict setObject:result.result forKey:result.type];
//    }
////
//    for (SelectedMatchModel *selectModel in model.sfArray) {
//        if ([[tmpDict objectForKey:selectModel.selectType] isEqualToString:selectModel.selectOdds]) {
//            selectModel.selected = YES;
//        }
//    }
////
//    for (SelectedMatchModel *selectModel in model.rqsfArray) {
//        if ([[tmpDict objectForKey:selectModel.selectType] isEqualToString:selectModel.selectOdds]) {
//            selectModel.selected = YES;
//        }
//    }
}

- (void)dealWinResult:(MatchModel *)model {
    //计算比分
    NSInteger scoreResult = model.hostScore.integerValue - model.awayScore.integerValue;
    NSString *result = scoreResult > 0 ? @"h" : scoreResult < 0 ? @"a" : @"d";
    for (SelectedMatchModel *selectModel in model.sfArray) {
        if ([selectModel.selectOdds isEqual:result]) {
            selectModel.winResult = YES;
            break;
        }
    }
    //计算比分(亚指)
    NSInteger rqscoreResult = model.hostScore.integerValue - model.awayScore.integerValue + model.rangNumStr.integerValue;
    NSString *rqResult = rqscoreResult > 0 ? @"h" : rqscoreResult < 0 ? @"a" : @"d";
    for (SelectedMatchModel *selectModel in model.rqsfArray) {
        if ([selectModel.selectOdds isEqual:rqResult]) {
            selectModel.winResult = YES;
            break;
        }
    }
}

#pragma mark - lazy init
- (UILabel *)headLabel {
    if (!_headLabel) {
        _headLabel= [[UILabel alloc] init];
        _headLabel.text = @"竞足-单关";
        _headLabel.font = GetFont(12);
        _headLabel.textColor = RGBACOLOR(21, 21, 26, 1);
        [self addSubview:_headLabel];
    }
    return _headLabel;
}

//- (UILabel *)refundLabel {
//    if (!_refundLabel) {
//        _refundLabel = [[UILabel alloc] init];
//        _refundLabel.layer.borderColor = RGBCOLOR(168, 168, 168).CGColor;
//        _refundLabel.layer.borderWidth = 1;
//        _refundLabel.font = GetFont(10);
//        _refundLabel.textColor = RGBCOLOR(58, 58, 58);
//        _refundLabel.text = @"不中退款";
//        _refundLabel.hidden = YES;
//        _refundLabel.textAlignment = NSTextAlignmentCenter;
//        [self addSubview:_refundLabel];
//    }
//    return _refundLabel;
//}

- (UIImageView *)winStateImageView {
    if (!_winStateImageView) {
        _winStateImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"win"]];
        _winStateImageView.hidden = YES;
        [self addSubview:_winStateImageView];
    }
    return _winStateImageView;
}

- (UIView *)lineView {
    if (!_lineView) {
        _lineView= [[UIView alloc] init];
        _lineView.backgroundColor = RGBACOLOR(244, 244, 244, 1);
        [self addSubview:_lineView];
    }
    return _lineView;
}
//firstCard
- (UIView *)firstAgainstCardView {
    if (!_firstAgainstCardView) {
        _firstAgainstCardView = [[UIView alloc] init];
        _firstAgainstCardView.backgroundColor = [UIColor whiteColor];
        _firstAgainstCardView.layer.cornerRadius = 8;
        _firstAgainstCardView.userInteractionEnabled = YES;
        _firstAgainstCardView.tag = 10001;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cardClick:)];
        [_firstAgainstCardView addGestureRecognizer:tap];
        [self addSubview:_firstAgainstCardView];
    }
    return _firstAgainstCardView;
}

- (UIImageView *)firstTeamAIconView {
    if (!_firstTeamAIconView) {
        _firstTeamAIconView = [[UIImageView alloc] init];
        _firstTeamAIconView.image = [UIImage imageNamed:@"host"];
        [self.firstAgainstCardView addSubview:_firstTeamAIconView];
    }
    return _firstTeamAIconView;
}

- (UIImageView *)firstTeamBIconView {
    if (!_firstTeamBIconView) {
        _firstTeamBIconView = [[UIImageView alloc] init];
        _firstTeamBIconView.image = [UIImage imageNamed:@"guest"];
        [self.firstAgainstCardView addSubview:_firstTeamBIconView];
    }
    return _firstTeamBIconView;
}

- (UILabel *)firstLeagueLabel {
    if (!_firstLeagueLabel) {
        _firstLeagueLabel = [[UILabel alloc] init];
        _firstLeagueLabel.textColor = RGBCOLOR(58, 58, 58);
        _firstLeagueLabel.font = GetFont(12);
        _firstLeagueLabel.textAlignment = NSTextAlignmentCenter;
        [self.firstAgainstCardView addSubview:_firstLeagueLabel];
    }
    return _firstLeagueLabel;
}

- (UILabel *)firstTimeLabel {
    if (!_firstTimeLabel) {
        _firstTimeLabel = [[UILabel alloc] init];
        _firstTimeLabel.textColor = RGBACOLOR(58, 58, 58, 1);
        _firstTimeLabel.font = GetFont(12);
        _firstTimeLabel.numberOfLines = 0;
        _firstTimeLabel.textAlignment = NSTextAlignmentCenter;
        [self.firstAgainstCardView addSubview:_firstTimeLabel];
    }
    return _firstTimeLabel;
}

- (UILabel *)firstScoreLabel {
    if (!_firstScoreLabel) {
        _firstScoreLabel = [[UILabel alloc] init];
        _firstScoreLabel.textColor = ColorAppBlack;
        _firstScoreLabel.font = [UIFont fontWithName:@"FZZYJW--GB1-0" size:26];
        _firstScoreLabel.textAlignment = NSTextAlignmentCenter;
        _firstScoreLabel.hidden = YES;
        [self.firstAgainstCardView addSubview:_firstScoreLabel];
    }
    return _firstScoreLabel;
}

- (UILabel *)firstTeamANameLabel {
    if (!_firstTeamANameLabel) {
        _firstTeamANameLabel = [[UILabel alloc] init];
        _firstTeamANameLabel.textColor = RGBACOLOR(21, 21, 26, 1);
        _firstTeamANameLabel.font = GetFont(12);
		_firstTeamANameLabel.textAlignment = NSTextAlignmentCenter;
        [self.firstAgainstCardView addSubview:_firstTeamANameLabel];
    }
    return _firstTeamANameLabel;
}

- (UILabel *)firstTeamBNameLabel {
    if (!_firstTeamBNameLabel) {
        _firstTeamBNameLabel = [[UILabel alloc] init];
        _firstTeamBNameLabel.textColor = RGBACOLOR(21, 21, 26, 1);
        _firstTeamBNameLabel.font = GetFont(12);
		_firstTeamBNameLabel.textAlignment = NSTextAlignmentCenter;
        [self.firstAgainstCardView addSubview:_firstTeamBNameLabel];
    }
    return _firstTeamBNameLabel;
}

- (UILabel *)firstStateLabel {
    if (!_firstStateLabel) {
        _firstStateLabel = [[UILabel alloc] init];
        _firstStateLabel.textColor = RGBACOLOR(249, 129, 49, 1);
        _firstStateLabel.font = GetFont(12);
        _firstStateLabel.text = @"未开始";
        [self.firstAgainstCardView addSubview:_firstStateLabel];
    }
    return _firstStateLabel;
}

- (UIImageView *)firstArrowView {
    if (!_firstArrowView) {
        _firstArrowView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"scheme_detail_arrow_icon"]];
        [self.firstAgainstCardView addSubview:_firstArrowView];
    }
    return _firstArrowView;
}
-(UIView*)fistFatherPredictView
{
    if (!_fistFatherPredictView) {
        _fistFatherPredictView = [[UIView alloc] initWithFrame:CGRectMake(10, 100, SCREEN_WIDTH - 50, 80)];
        _fistFatherPredictView.clipsToBounds = YES;
        
        [self.firstAgainstCardView addSubview:_fistFatherPredictView];
    }
    return _fistFatherPredictView;
}

- (WTCSPForJCZQView *)firstPredictView {
    if (!_firstPredictView) {
        _firstPredictView = [[WTCSPForJCZQView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 50, 80)];
        _firstPredictView.forbidSelect = YES;
        [self.fistFatherPredictView addSubview:_firstPredictView];
    }
    return _firstPredictView;
}

//seprator
- (UILabel *)sepratorLabel {
    if (!_sepratorLabel) {
        _sepratorLabel =  [[UILabel alloc] init];
        _sepratorLabel.backgroundColor = RGBACOLOR(231, 231, 231, 1);
        [self addSubview:_sepratorLabel];
    }
    return _sepratorLabel;
}
//secondCard
- (UIView *)secondAgainstCardView {
    if (!_secondAgainstCardView) {
        _secondAgainstCardView = [[UIView alloc] init];
        _secondAgainstCardView.backgroundColor = [UIColor whiteColor];
        _secondAgainstCardView.layer.cornerRadius = 8;
        _secondAgainstCardView.userInteractionEnabled = YES;
        _secondAgainstCardView.tag = 10002;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(cardClick:)];
        [_secondAgainstCardView addGestureRecognizer:tap];
        [self addSubview:_secondAgainstCardView];
    }
    return _secondAgainstCardView;
}

- (UIImageView *)secondTeamAIconView {
    if (!_secondTeamAIconView) {
        _secondTeamAIconView = [[UIImageView alloc] init];
        _secondTeamAIconView.image = [UIImage imageNamed:@"host"];
        [self.secondAgainstCardView addSubview:_secondTeamAIconView];
    }
    return _secondTeamAIconView;
}

- (UIImageView *)secondTeamBIconView {
    if (!_secondTeamBIconView) {
        _secondTeamBIconView = [[UIImageView alloc] init];
        _secondTeamBIconView.image = [UIImage imageNamed:@"guest"];
        [self.secondAgainstCardView addSubview:_secondTeamBIconView];
    }
    return _secondTeamBIconView;
}

- (UILabel *)secondLeagueLabel {
    if (!_secondLeagueLabel) {
        _secondLeagueLabel = [[UILabel alloc] init];
        _secondLeagueLabel.textColor = RGBCOLOR(58, 58, 58);
        _secondLeagueLabel.font = GetFont(12);
        _secondLeagueLabel.textAlignment = NSTextAlignmentCenter;
        [self.secondAgainstCardView addSubview:_secondLeagueLabel];
    }
    return _secondLeagueLabel;
}

- (UILabel *)secondTimeLabel {
    if (!_secondTimeLabel) {
        _secondTimeLabel = [[UILabel alloc] init];
        _secondTimeLabel.textColor = RGBACOLOR(58, 58, 58, 1);
        _secondTimeLabel.font = GetFont(12);
        _secondTimeLabel.textAlignment = NSTextAlignmentCenter;
        [self.secondAgainstCardView addSubview:_secondTimeLabel];
    }
    return _secondTimeLabel;
}

- (UILabel *)secondScoreLabel {
    if (!_secondScoreLabel) {
        _secondScoreLabel = [[UILabel alloc] init];
        _secondScoreLabel.textColor = ColorAppBlack;
        _secondScoreLabel.font = [UIFont fontWithName:@"FZZYJW--GB1-0" size:26];
        _secondScoreLabel.textAlignment = NSTextAlignmentCenter;
        _secondScoreLabel.hidden = YES;
        [self.secondAgainstCardView addSubview:_secondScoreLabel];
    }
    return _secondScoreLabel;
}

- (UILabel *)secondTeamANameLabel {
    if (!_secondTeamANameLabel) {
        _secondTeamANameLabel = [[UILabel alloc] init];
        _secondTeamANameLabel.textColor = RGBACOLOR(21, 21, 26, 1);
        _secondTeamANameLabel.font = GetFont(12);
		_secondTeamANameLabel.textAlignment = NSTextAlignmentCenter;
        [self.secondAgainstCardView addSubview:_secondTeamANameLabel];
    }
    return _secondTeamANameLabel;
}

- (UILabel *)secondTeamBNameLabel {
    if (!_secondTeamBNameLabel) {
        _secondTeamBNameLabel = [[UILabel alloc] init];
        _secondTeamBNameLabel.textColor = RGBACOLOR(21, 21, 26, 1);
        _secondTeamBNameLabel.font = GetFont(12);
		_secondTeamBNameLabel.textAlignment = NSTextAlignmentCenter;
        [self.secondAgainstCardView addSubview:_secondTeamBNameLabel];
    }
    return _secondTeamBNameLabel;
}

- (UILabel *)secondStateLabel {
    if (!_secondStateLabel) {
        _secondStateLabel = [[UILabel alloc] init];
        _secondStateLabel.textColor = RGBACOLOR(249, 129, 49, 1);
        _secondStateLabel.font = GetFont(12);
        _secondStateLabel.text = @"未开始";
        [self.secondAgainstCardView addSubview:_secondStateLabel];
    }
    return _secondStateLabel;
}

- (UIImageView *)secondArrowView {
    if (!_secondArrowView) {
        _secondArrowView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"scheme_detail_arrow_icon"]];
        [self.secondAgainstCardView addSubview:_secondArrowView];
    }
    return _secondArrowView;
}
-(UIView*)secondFatherPredictView
{
    if (!_secondFatherPredictView) {
        _secondFatherPredictView = [[UIView alloc] initWithFrame:CGRectMake(10, 100, SCREEN_WIDTH - 50, 80)];
        _secondFatherPredictView.clipsToBounds = YES;
        [self.secondAgainstCardView addSubview:_secondFatherPredictView];
    }
    return _secondFatherPredictView;
}

- (WTCSPForJCZQView *)secondPredictView {
    if (!_secondPredictView) {
        _secondPredictView = [[WTCSPForJCZQView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - 50, 80)];
        _secondPredictView.forbidSelect = YES;
        [self.secondFatherPredictView addSubview:_secondPredictView];
    }
    return _secondPredictView;
}
@end
