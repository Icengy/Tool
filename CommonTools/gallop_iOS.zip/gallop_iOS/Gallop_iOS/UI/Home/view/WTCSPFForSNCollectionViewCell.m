//
//  WTCSPFForSNCollectionViewCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/28.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "WTCSPFForSNCollectionViewCell.h"

@implementation WTCSPFForSNModel

@end

@interface WTCSPFForSNCollectionViewCell ()
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *guessStateIV;

@property (nonatomic ,copy) NSString *title;
/// 是否展示
@property (nonatomic ,assign) BOOL showGuessState;
/// 中/未中
@property (nonatomic ,assign) BOOL guessState;

@end

@implementation WTCSPFForSNCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.titleLabel.textColor = RGBCOLORV(0x282828);
    self.titleLabel.backgroundColor = ColorDefaultGrayBackground;
    self.titleLabel.font = [UIFont addPingFangSCRegular:13];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.numberOfLines = 0;
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
}

- (void)setModel:(WTCSPFForSNModel *)model {
    _model = model;
    self.title = _model.title;
    self.showGuessState = _model.showGuessState;
    self.guessState = _model.showGuessState;
    
    [self setNeedsLayout];
}

- (void)setTitle:(NSString *)title {
    _title = title;
    self.titleLabel.text = title;
}

- (void)setShowGuessState:(BOOL)showGuessState {
    _showGuessState = showGuessState;
    self.guessStateIV.hidden = !_showGuessState;
}

- (void)setGuessState:(BOOL)guessState {
    _guessState = guessState;
    if (_guessState) {
        self.guessStateIV.image = GetImage(@"plan_guess_right");
    }else {
        self.guessStateIV.image = GetImage(@"plan_guess_wrong");
    }
}


@end
