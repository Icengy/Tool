//
//  PlanCommentCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/7/1.
//  Copyright © 2020 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlanCommentModel.h"

typedef void(^GoHomePageBlock)(NSString *userId);

@interface PlanCommentCell : UITableViewCell

@property (nonatomic ,assign) BOOL hideSeperatorLine;
- (void)configCellWithModel:(PlanCommentItem *)model;
@property (nonatomic,copy)GoHomePageBlock goHomePageBlock;
@end
