//
//  BoardTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "BoardTableViewCell.h"
@interface BoardTableViewCell()
@end
@implementation BoardTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = ColorDefaultBackground;
        [self setupView];
        
    }
    return self;
}
-(void)setModel:(BoardExpert *)model
{
    _model = model;
    if (!QM_IS_STR_NIL(model.expertAvatar)) {
        [self.headV sd_setImageWithURL:[NSURL URLWithString:model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
    }
    self.nameL.text = model.expertName;
}
-(void)setupView{
    [self.headV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.contentView).offset(0);
        make.left.mas_equalTo(self.contentView).offset(15);
        make.size.mas_equalTo(CGSizeMake(30, 30)).offset(0);
    }];
    [self.headV setImage:[UIImage imageNamed:@"avatar"]];
    [self.nameL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.headV.mas_right).offset(10);
        make.centerY.mas_equalTo(self.headV);
        make.height.mas_equalTo(15);
    }];
    [self.benifitL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(self.contentView).offset(-15);
        make.centerY.mas_equalTo(self.headV).offset(0);
        make.height.mas_equalTo(15);
    }];
    [self.shotL mas_makeConstraints:^(MASConstraintMaker *make) {
         make.centerY.mas_equalTo(self.headV).offset(0);
        make.centerX.mas_equalTo(self.contentView).offset(0);
         make.height.mas_equalTo(15);
    }];
    
}
-(UIImageView*)headV
{
    if (!_headV) {
        _headV = [UIImageView new];
        [self.contentView addSubview:_headV];
    }
    return _headV;
}
-(UILabel*)nameL
{
    if (!_nameL) {
        _nameL = [UILabel new];
        _nameL.textColor = ColorTitle;
        _nameL.font = GetFont(15.0f);
        [self.contentView addSubview:_nameL];
    }
    return _nameL;
}
-(UIImageView*)rankV
{
    if (!_rankV) {
        _rankV = [UIImageView new];
        [self.contentView addSubview:_rankV];
    }
    return _rankV;
}
-(UILabel*)shotL
{
    if (!_shotL) {
        _shotL = [UILabel new];
        _shotL.textColor = ColorTitle;
        _shotL.font = GetFont(15.0f);
        [self.contentView addSubview:_shotL];
    }
    return _shotL;
}
-(UILabel*)benifitL
{
    if (!_benifitL) {
        _benifitL = [UILabel new];
        _benifitL.textColor = ColorTitle;
        _benifitL.font = GetFont(15.0f);
        [self.contentView addSubview:_benifitL];
    }
    return _benifitL;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
