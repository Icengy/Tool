//
//  MatchTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchTableViewCell.h"
#import "WTCSPForJCZQView.h"

#import "MatchModel.h"
#import "SelectedMatchModel.h"

@interface MatchTableViewCell ()<WTCSPFForJCZQViewDelegate>
@property (nonatomic, strong) WTCSPForJCZQView *spfView;
@property (nonatomic, strong) UILabel *hostL;
@property (nonatomic, strong) UILabel *guestL;
@property (nonatomic, strong) UIImageView *hostIV;
@property (nonatomic, strong) UIImageView *guestIV;
@property (nonatomic, strong) UILabel *vsL;
@property (nonatomic, strong) UILabel *dateL;
@property (nonatomic, strong) UIImageView *arowIV;
@end

@implementation MatchTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = ColorDefaultBackground;
        [self setupView];
        
    }
    return self;
}

- (void)setupView
{
    __weak MatchTableViewCell *weakSelf = self;
    [self.dateL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.contentView).offset(10);
        make.left.mas_equalTo(weakSelf.contentView).offset(15);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
        make.height.mas_equalTo(20);
    }];
    
    [self.hostIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.contentView).offset(k6sVersusWidth*80);
        make.top.mas_equalTo(weakSelf.dateL.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(k6sVersusWidth*50, k6sVersusWidth*50));
    }];
    
    [self.vsL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(weakSelf.contentView);
        make.centerY.mas_equalTo(weakSelf.hostIV).offset(0);
        make.height.mas_equalTo(25);
    }];
    self.vsL.text = @"VS";
    [self.hostL mas_makeConstraints:^(MASConstraintMaker *make) {
       make.centerX.mas_equalTo(weakSelf.hostIV).offset(0);
        make.top.mas_equalTo(weakSelf.hostIV.mas_bottom).offset(5);
        make.height.mas_equalTo(20);
    }];
    [self.guestIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.contentView).offset(-k6sVersusWidth*80);
        make.top.mas_equalTo(weakSelf.dateL.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(k6sVersusWidth*50, k6sVersusWidth*50));
    }];
    [self.guestL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(weakSelf.guestIV).offset(0);
        make.top.mas_equalTo(weakSelf.guestIV.mas_bottom).offset(5);
        make.height.mas_equalTo(20);
    }];
    [self.arowIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(weakSelf.hostIV).offset(0);
        make.height.mas_equalTo(15);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
    }];
    self.arowIV.image = [UIImage imageNamed:@"go_arrow"];
    self.arowIV.contentMode = UIViewContentModeScaleAspectFit;
    
//    [self.spfView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.mas_equalTo(weakSelf.contentView.mas_bottom).offset(-15);
//        make.left.mas_equalTo(weakSelf.contentView).offset(15);
//        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
//        make.height.mas_equalTo(80);
//    }];
    self.spfView = [[WTCSPForJCZQView alloc] initWithFrame:CGRectMake(15, 40+k6sVersusWidth*50+25+20, kScreen_Width-30, (kSPForJCCellHeight *2 + 1))];
    self.spfView.delegate = self;
    
     [self.contentView addSubview:_spfView];
}

-(void)spfForJCZQView:(WTCSPForJCZQView *)sfpView didSelectItem:(MatchModel *)selectModel {
     [[NSNotificationCenter defaultCenter] postNotificationName:kSelectMatchMessageNotification object:nil];
//    if ([self.delegate respondsToSelector:@selector(matchCell:didSelectItem:)]) {
//        [self.delegate matchCell:self didSelectItem:selectModel];
//    }
}

-(void)setModel:(MatchModel *)model {
    _model = model;
    self.dateL.text = [NSString stringWithFormat:@"%@  %@  竞彩  %@", model.matchNum,model.leagueShortName,model.matchTime];
    self.guestL.text = model.awayName;
    self.hostL.text = model.hostName;
    self.guestIV.image = [UIImage imageNamed:@"guest"];
    self.hostIV.image = [UIImage imageNamed:@"host"];
    
    self.spfView.model = model;
//    [self.spfView setupView];
}
-(void)setForbidSelect:(BOOL)forbidSelect
{
    _forbidSelect =forbidSelect;
    self.spfView.forbidSelect = forbidSelect;
    self.arowIV.hidden = forbidSelect;
}

#pragma mark -
-(UILabel*)hostL
{
    if (!_hostL) {
        _hostL = [UILabel new];
        _hostL.textColor = ColorTitle;
        _hostL.font = GetFont(13.0f);
        [self.contentView addSubview:_hostL];
    }
    return _hostL;
}
-(UILabel*)guestL
{
    if (!_guestL) {
        _guestL = [UILabel new];
        _guestL.textColor = ColorTitle;
        _guestL.font = GetFont(13.0f);
        [self.contentView addSubview:_guestL];
    }
    return _guestL;
}
-(UILabel*)vsL
{
    if (!_vsL) {
        _vsL = [UILabel new];
        _vsL.textColor = [UIColor blackColor];
        _vsL.font = GetBoldFont(22.0f);
        [self.contentView addSubview:_vsL];
    }
    return _vsL;
}
-(UILabel*)dateL
{
    if (!_dateL) {
        _dateL = [UILabel new];
        _dateL.textColor = ColorSubTitle;
        _dateL.font = GetFont(12.0f);
        [self.contentView addSubview:_dateL];
    }
    return _dateL;
}
-(UIImageView*)hostIV
{
    if (!_hostIV) {
        _hostIV = [UIImageView new];
        [self.contentView addSubview:_hostIV];
    }
    return _hostIV;
}
-(UIImageView*)arowIV
{
    if (!_arowIV) {
        _arowIV = [UIImageView new];
        [self.contentView addSubview:_arowIV];
    }
    return _arowIV;
}
-(UIImageView*)guestIV
{
    if (!_guestIV) {
        _guestIV = [UIImageView new];
        [self.contentView addSubview:_guestIV];
    }
    return _guestIV;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
