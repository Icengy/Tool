//
//  SearchTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/6.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SearchTableViewCell.h"
@interface SearchTableViewCell()
@property (nonatomic,strong) UILabel*redL;
@end
@implementation SearchTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = ColorDefaultBackground;
        [self setupView];
        
    }
    return self;
}
-(void)setModel:(SearchExpert *)model
{
    _model = model;
    if (!QM_IS_STR_NIL(model.expertAvatar)) {
        [self.headV sd_setImageWithURL:[NSURL URLWithString:model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
        [self.nameL setText:model.expertName];
        [self.detailL setText:model.introduction];
        self.redL.text = [model.forSalePlanCount stringValue];
        self.redL.hidden = ![model.forSalePlanCount intValue];
    }
}
-(void)setupView{
    __weak SearchTableViewCell*weakSelf = self;
    [self.headV mas_makeConstraints:^(MASConstraintMaker *make) {
       make.centerY.mas_equalTo(weakSelf.contentView);
        make.left.mas_equalTo(weakSelf.contentView).offset(15);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    [self.redL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(self.headV.mas_top).offset(5);
        make.centerX.mas_equalTo(self.headV.mas_right).offset(-5);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    self.redL.layer.cornerRadius = 10;
    self.redL.clipsToBounds = YES;
    self.redL.hidden = YES;
    [self.headV setImage:[UIImage imageNamed:@"avatar"]];
    self.headV.layer.cornerRadius = 20;
    self.headV.clipsToBounds = YES;
    [self.nameL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.headV.mas_right).offset(12);
        make.top.mas_equalTo(weakSelf.headV).offset(3);
        make.height.mas_equalTo(20);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
    }];
    [self.detailL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.nameL.mas_bottom).offset(0);
        make.left.mas_equalTo(weakSelf.nameL).offset(0);
        make.height.mas_equalTo(20);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
    }];
    
    
    
}
-(UIImageView*)headV
{
    if (!_headV) {
        _headV = [UIImageView new];
        [self.contentView addSubview:_headV];
    }
    return _headV;
}
-(UILabel*)nameL
{
    if (!_nameL) {
        _nameL = [UILabel new];
        _nameL.textColor = ColorTitle;
        _nameL.font = GetFont(14.0f);
        [self.contentView addSubview:_nameL];
    }
    return _nameL;
}
-(UILabel*)detailL
{
    if (!_detailL) {
        _detailL = [UILabel new];
        _detailL.textColor = ColorSubTitle;
        _detailL.font = GetFont(12.0f);
        [self.contentView addSubview:_detailL];
    }
    return _detailL;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(UILabel*)redL
{
    if (!_redL) {
        _redL = [UILabel new];
        _redL.textColor = [UIColor whiteColor];
        _redL.backgroundColor = ColorAppRed;
        _redL.font = fcFont(12.0f);
        _redL.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_redL];
    }
    return _redL;
}
@end
