//
//  PointExtenButton.h
//  Gallop_iOS
//
//  Created by caizx on 2019/7/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "CYButton.h"

@interface PointExtenButton : CYButton

@end
