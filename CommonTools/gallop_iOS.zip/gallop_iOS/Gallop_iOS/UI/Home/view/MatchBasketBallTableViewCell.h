//
//  MatchBasketBallTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchModel.h"
#import "SelectedMatchModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface MatchBasketBallTableViewCell : UITableViewCell
@property (nonatomic, strong) MatchModel*model;
@property (nonatomic, strong) SelectedMatchModel*selectedModel;
@property (nonatomic, assign) BOOL forbidSelect;
@end

NS_ASSUME_NONNULL_END
