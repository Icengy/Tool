//
//  MatchBasketBallTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/26.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MatchBasketBallTableViewCell.h"
#import "WTCSPFForJCLQView.h"

@interface MatchBasketBallTableViewCell ()<WTCSPFForJCLQViewDelegate>

@property (nonatomic, strong) WTCSPFForJCLQView *spfView;
@property (nonatomic, strong) UILabel *hostL;
@property (nonatomic, strong) UILabel *guestL;
@property (nonatomic, strong) UIImageView *hostIV;
@property (nonatomic, strong) UIImageView *guestIV;
@property (nonatomic, strong) UILabel *vsL;
@property (nonatomic, strong) UILabel *dateL;
@property (nonatomic, strong) UIImageView *arowIV;

@end

@implementation MatchBasketBallTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = ColorDefaultBackground;
        
        [self setupView];
        
    }
    return self;
}

- (void)setupView {
    [self.contentView addSubview:self.dateL];
    [self.contentView addSubview:self.hostIV];
    [self.contentView addSubview:self.hostL];
    
    [self.contentView addSubview:self.vsL];
    
    [self.contentView addSubview:self.guestIV];
    [self.contentView addSubview:self.guestL];
    [self.contentView addSubview:self.arowIV];
    
    [self.contentView addSubview:self.spfView];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    __weak MatchBasketBallTableViewCell *weakSelf = self;
    [self.dateL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(weakSelf.contentView).offset(10);
        make.left.equalTo(weakSelf.contentView).offset(15);
        make.right.equalTo(weakSelf.contentView).offset(-15);
        make.height.offset(20);
    }];
    [self.hostIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.contentView).offset(k6sVersusWidth*80);
        make.top.equalTo(weakSelf.dateL.mas_bottom).offset(10);
        make.size.sizeOffset(CGSizeMake(k6sVersusWidth*50, k6sVersusWidth*50));
    }];
    [self.vsL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakSelf.contentView);
        make.centerY.equalTo(weakSelf.hostIV).offset(0);
        make.height.offset(25);
    }];
    
    [self.hostL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakSelf.hostIV).offset(0);
        make.top.equalTo(weakSelf.hostIV.mas_bottom).offset(5);
        make.height.offset(20);
    }];
    [self.guestIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.contentView).offset(-k6sVersusWidth*80);
        make.top.equalTo(weakSelf.dateL.mas_bottom).offset(10);
        make.size.sizeOffset(CGSizeMake(k6sVersusWidth*50, k6sVersusWidth*50));
    }];
    [self.guestL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakSelf.guestIV).offset(0);
        make.top.equalTo(weakSelf.guestIV.mas_bottom).offset(5);
        make.height.offset(20);
    }];
    [self.arowIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(weakSelf.hostIV).offset(0);
        make.height.offset(15);
        make.right.equalTo(weakSelf.contentView).offset(-15);
    }];
    
    [self.spfView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(weakSelf.contentView.mas_bottom).offset(-15);
        make.left.equalTo(weakSelf.contentView).offset(15);
        make.right.equalTo(weakSelf.contentView).offset(-15);
        make.top.equalTo(weakSelf.guestL.mas_bottom).offset(20.0);
    }];
}

#pragma mark -
-(void)spfForJCLQView:(WTCSPFForJCLQView *)sfpView didSelectItem:(MatchModel *)selectModel {
    [[NSNotificationCenter defaultCenter] postNotificationName:kSelectMatchMessageNotification object:nil];
}

#pragma mark -
-(void)setModel:(MatchModel *)model
{
    _model = model;
    self.dateL.text = [NSString stringWithFormat:@"%@  %@  竞彩  %@", model.matchNum,model.leagueShortName,model.matchTime];
    self.guestL.text = [NSString stringWithFormat:@"%@(主)",model.hostName];
    self.hostL.text = model.awayName;
    self.guestIV.image = [UIImage imageNamed:@"host"];
    self.hostIV.image = [UIImage imageNamed:@"guest"];
    
    self.spfView.model = model;

    [self setNeedsLayout];
}

-(void)setForbidSelect:(BOOL)forbidSelect
{
    _forbidSelect =forbidSelect;
    self.spfView.forbidSelect = forbidSelect;
    self.arowIV.hidden = forbidSelect;
}

#pragma mark -
-(UILabel*)hostL
{
    if (!_hostL) {
        _hostL = [UILabel new];
        _hostL.textColor = ColorTitle;
        _hostL.font = GetFont(13.0f);
    }
    return _hostL;
}
-(UILabel*)guestL
{
    if (!_guestL) {
        _guestL = [UILabel new];
        _guestL.textColor = ColorTitle;
        _guestL.font = GetFont(13.0f);
    }
    return _guestL;
}
-(UILabel*)vsL
{
    if (!_vsL) {
        _vsL = [UILabel new];
        _vsL.textColor = [UIColor blackColor];
        _vsL.font = GetBoldFont(22.0f);
        _vsL.text = @"VS";
    }
    return _vsL;
}
-(UILabel*)dateL
{
    if (!_dateL) {
        _dateL = [UILabel new];
        _dateL.textColor = ColorSubTitle;
        _dateL.font = GetFont(12.0f);
    }
    return _dateL;
}
-(UIImageView*)hostIV
{
    if (!_hostIV) {
        _hostIV = [UIImageView new];
    }
    return _hostIV;
}
-(UIImageView*)arowIV
{
    if (!_arowIV) {
        _arowIV = [UIImageView new];
        _arowIV.image = [UIImage imageNamed:@"go_arrow"];
        _arowIV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _arowIV;
}
-(UIImageView*)guestIV
{
    if (!_guestIV) {
        _guestIV = [UIImageView new];
    }
    return _guestIV;
}

- (WTCSPFForJCLQView *)spfView {
    if (!_spfView) {
        _spfView = [[WTCSPFForJCLQView alloc] initWithFrame:CGRectZero];
        _spfView.forbidSelect = NO;
        _spfView.delegate = self;
    }return _spfView;
}

#pragma mark -
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
