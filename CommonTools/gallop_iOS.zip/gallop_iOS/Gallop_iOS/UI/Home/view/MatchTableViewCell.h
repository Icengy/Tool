//
//  MatchTableViewCell.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MatchModel;
@class SelectedMatchModel;
@class MatchTableViewCell;

NS_ASSUME_NONNULL_BEGIN

@protocol MatchTableViewCellDelegate <NSObject>

@required
-(void)matchCell:(MatchTableViewCell *)cell didSelectItem:(MatchModel *)selectModel;

@end

@interface MatchTableViewCell : UITableViewCell

@property (nonatomic, weak) id <MatchTableViewCellDelegate> delegate;
@property (nonatomic, strong) MatchModel *model;
@property (nonatomic, strong) SelectedMatchModel *selectedModel;
@property (nonatomic, assign) BOOL forbidSelect;

@end

NS_ASSUME_NONNULL_END
