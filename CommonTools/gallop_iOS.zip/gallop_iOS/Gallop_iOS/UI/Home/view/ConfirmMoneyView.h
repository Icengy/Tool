//
//  ConfirmMoneyView.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/3.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^confirmMoney)(NSString*money);
NS_ASSUME_NONNULL_BEGIN
@class ConfirmMoneyView;
@protocol ConfirmMoneyViewDelegate <NSObject>
-(void)confirmMoney:(NSString*)money;
-(void)cancelBack;
-(void)showPriceRules:(UIButton*)button andView:(UIView*)view;
@end
@interface ConfirmMoneyView : UIView
-(id)initWithMoney:(NSString*)money descrip:(NSString*)descrip moneyArr:(NSArray*)moneyA;
-(void)hide;
-(void)show;
@property (nonatomic,strong)NSString*myText;
@property (nonatomic, weak) id delegate;
@property (nonatomic,copy) confirmMoney confirmBlock;
@end

NS_ASSUME_NONNULL_END
