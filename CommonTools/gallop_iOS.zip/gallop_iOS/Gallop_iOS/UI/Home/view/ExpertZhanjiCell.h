//
//  ExpertZhanjiCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpertZhanjiCell : UITableViewCell
- (void)configCellWithModel:(id)model;
@end
