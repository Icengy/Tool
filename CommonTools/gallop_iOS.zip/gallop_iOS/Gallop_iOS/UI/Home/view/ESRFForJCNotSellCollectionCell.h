//
//  ESRFForJCNotSellCollectionCell.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/28.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ESRFForJCNotSellCollectionCell : UICollectionViewCell

@end

NS_ASSUME_NONNULL_END
