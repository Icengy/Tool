//
//  CCNavigationBarMenuItem.m
//  ESTicket
//
//  Created by Homosum on 2018/3/19.
//  Copyright © 2018年 九辰_王添诚. All rights reserved.
//

#import "CCNavigationBarMenuItem.h"

@implementation CCNavigationBarMenuItem
+ (instancetype)navigationBarMenuItemWithImage:(UIImage *)image title:(NSString *)title {
    return [[CCNavigationBarMenuItem alloc] initWithImage:image title:title];
}

- (instancetype)initWithImage:(UIImage *)image title:(NSString *)title {
    self = [super init];
    if (self) {
        self.image = image;
        self.title = title;
        self.titleColor = [UIColor colorWithHexString:@"#4a4a4a"];
        self.titleFont = GetFont(17.0);
    }
    return self;
}

@end



