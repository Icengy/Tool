//
//  SizingSearchCollectionViewCell.h
//  JUXIU_iOS
//
//  Created by Homosum on 17/3/29.
//  Copyright © 2017年 JuXiuSheQu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SizingSearchCollectionViewCell : UICollectionViewCell
@property(nonatomic,strong)UILabel*tLabel;
@end
