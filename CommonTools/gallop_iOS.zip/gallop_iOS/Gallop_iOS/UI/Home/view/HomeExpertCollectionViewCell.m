//
//  HomeExpertCollectionViewCell.m
//  Gallop_iOS
//
//  Created by icengy on 2021/4/26.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "HomeExpertCollectionViewCell.h"

#import "GallopExpertModel.h"

@interface HomeExpertCollectionViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *headImageV;
@property (weak, nonatomic) IBOutlet UILabel *nameL;
@property (weak, nonatomic) IBOutlet GallopTagBgLabel *plansNumL;

@end

@implementation HomeExpertCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.plansNumL.backgroundColor = ColorMainAppRed;
    self.plansNumL.transformDegrees = 5.0;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    [self.headImageV addRoundedCorners:(UIRectCornerAllCorners) withRadii:self.headImageV.height/2];
    
}

#pragma mark -
-(void)setModel:(GallopExpertModel *)model {
    _model = model;
    if (!QM_IS_STR_NIL(_model.expertAvatar)) {
        [self.headImageV sd_setImageWithURL:[NSURL URLWithString:_model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
        self.nameL.text = _model.expertName;
        
        self.plansNumL.text = [NSString stringWithFormat:@"%@个方案",@(_model.forSalePlanCount)];
        self.plansNumL.hidden = !_model.forSalePlanCount;
    }
}

@end
