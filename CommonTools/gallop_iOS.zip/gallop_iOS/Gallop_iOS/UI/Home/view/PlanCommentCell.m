//
//  PlanCommentCell.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/7/1.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "PlanCommentCell.h"

@interface PlanCommentCell()
@property (nonatomic,strong) PlanCommentItem *model;
@property (nonatomic,strong) UIImageView *headImageView;
@property (nonatomic,strong) UILabel *contentLabel;
@property (nonatomic,strong) UILabel *timeLabel;
@property (nonatomic,strong) UILabel *authLabel;
@property (nonatomic,strong) UIView	*seperatorLine;
//data
@property (nonatomic,assign) NSUInteger row;

@end

@implementation PlanCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
	if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
		[self setupView];
	}
	return self;
}

- (void)setupView {
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(13);
		make.left.equalTo(self.contentView).offset(15);
		make.size.mas_equalTo(CGSizeMake(44, 44));
	}];
	[self.authLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView).offset(18);
		make.left.equalTo(self.contentView).offset(67);
	}];
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.authLabel.mas_bottom).offset(3);
		make.left.equalTo(self.contentView).offset(67);
	}];
	[self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headImageView.mas_bottom).offset(8);
        make.left.equalTo(self.headImageView);
		make.right.equalTo(self.contentView).offset(-7.5);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentLabel.mas_bottom).offset(16);
		make.height.mas_equalTo(1);
		make.right.bottom.left.equalTo(self.contentView);
	}];
}

- (void)configCellWithModel:(PlanCommentItem *)model {
	self.model = model;
	self.authLabel.text = model.userName;
	self.timeLabel.text = [TimeUnitily stampDateFormatForTimeStamp:model.createTime];
	self.contentLabel.text = model.content;
    [self.contentLabel sizeToFit];
    
	[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:GetImage(@"avatar")];
    
	if (model.status == 0) {
		//屏蔽
		self.contentLabel.textColor = RGBCOLOR(168, 168, 168);
	} else {
		//未屏蔽
		self.contentLabel.textColor = ColorAppBlack;
	}
}

- (void)setHideSeperatorLine:(BOOL)hideSeperatorLine {
    _hideSeperatorLine = hideSeperatorLine;
    self.seperatorLine.hidden = _hideSeperatorLine;
}

- (void)goHomePage {
	if (self.goHomePageBlock) {
		self.goHomePageBlock(self.model.userId);
	}
}

#pragma mark - lazy init
- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [[UIImageView alloc] init];
		_headImageView.contentMode = UIViewContentModeScaleAspectFill;
		_headImageView.clipsToBounds = YES;
		_headImageView.layer.cornerRadius = 22;
		_headImageView.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goHomePage)];
		[_headImageView addGestureRecognizer:tap];
		[self.contentView addSubview:_headImageView];
	}
	return _headImageView;
}

- (UILabel *)contentLabel {
	if (!_contentLabel) {
		_contentLabel = [UILabel new];
		_contentLabel.textColor = ColorAppBlack;
		_contentLabel.font = fcFont(14);
		_contentLabel.numberOfLines = 0;
		[self.contentView addSubview:_contentLabel];
	}
	return _contentLabel;
}

- (UILabel *)timeLabel {
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.font = fcFont(12);
		_timeLabel.textColor = RGBCOLOR(168, 168, 168);
		[self.contentView addSubview:_timeLabel];
	}
	return _timeLabel;
}

- (UILabel *)authLabel {
	if (!_authLabel) {
		_authLabel = [UILabel new];
		_authLabel.textColor = ColorAppBlack;
		_authLabel.font = fcFont(14);
		[self.contentView addSubview:_authLabel];
	}
	return _authLabel;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.contentView addSubview:_seperatorLine];
	}
	return _seperatorLine;
}

@end
