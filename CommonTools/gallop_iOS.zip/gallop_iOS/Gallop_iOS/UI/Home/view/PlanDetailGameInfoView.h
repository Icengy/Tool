//
//  PlanDetailGameInfoView.h
//  Gallop_iOS
//
//  Created by IT on 2019/7/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PlanDetailGameInfoViewDelegate <NSObject>

- (void)matchCardClick:(id)model;

@end

//用于方案详情页比赛详情展示
@interface PlanDetailGameInfoView : UIView
@property(nonatomic, weak)id<PlanDetailGameInfoViewDelegate> delegate;
- (void)configPlanDetailGameInfoView:(id)model;
@end
