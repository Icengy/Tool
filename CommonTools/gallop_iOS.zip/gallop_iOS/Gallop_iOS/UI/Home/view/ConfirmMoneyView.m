//
//  ConfirmMoneyView.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/3.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ConfirmMoneyView.h"

@interface ConfirmMoneyView ()<UITextFieldDelegate>
@property (nonatomic, strong) UIView*dialogView;
@property (nonatomic, strong) UIView*titleView;
@property (nonatomic, strong) UILabel*titleLabel;
@property (nonatomic, strong) UILabel*danchang;
@property (nonatomic,strong) UITextField*moneyField;
@property (nonatomic,strong) UILabel*feichibi;
@property (nonatomic, strong) UIButton*detailB;
@property (nonatomic, strong) UIButton*confirmB;
@property (nonatomic, strong) UILabel*changyong;
@property (nonatomic,strong) NSArray* moneyA;
@property (nonatomic,strong) NSString*discrip;
@property (nonatomic, strong) NSString*money;


@end
@implementation ConfirmMoneyView

-(id)initWithMoney:(NSString *)money descrip:(nonnull NSString *)descrip moneyArr:(nonnull NSArray *)moneyA
{
    self = [super init];
    if (self) {
        self.backgroundColor = RGBACOLOR(1, 1, 1, 0.5);
        self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
        self.money = money;
        self.discrip = descrip;
        self.moneyA = moneyA;
        [self setupView];
        
    }
    return self;
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self hide];
}
- (void)show
{
    self.alpha = 0;
    [APP_DELEGATE.window addSubview:self];
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 1;
    } completion:^(BOOL finished) {
        
    }];
}
-(void)hide{
    [UIView animateWithDuration:0.3 animations:^{
        self.alpha = 0;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}
- (void)setupView{
    __weak ConfirmMoneyView*weakSelf = self;
    [self.dialogView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.mas_equalTo(weakSelf);
        make.size.mas_equalTo(CGSizeMake(Adapt(275)>275?Adapt(275):275, 145+40));
    }];
    self.dialogView.layer.cornerRadius = 5;
    self.dialogView.clipsToBounds = YES;
    
    [self.titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(weakSelf.dialogView);
        make.height.mas_equalTo(36);
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(weakSelf.titleView);
        make.left.mas_equalTo(weakSelf.titleView).offset(15);
        make.height.mas_equalTo(20);
    }];
    self.titleLabel.text = @"价格";
    [self.danchang mas_makeConstraints:^(MASConstraintMaker *make) {
       make.left.mas_equalTo(weakSelf.dialogView).offset(15);
        make.top.mas_equalTo(weakSelf.titleView.mas_bottom).offset(15);
       make.height.mas_equalTo(30);
    }];
    self.danchang.text = @"";
    [self.moneyField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.danchang.mas_right).offset(5);
        make.top.mas_equalTo(weakSelf.titleView.mas_bottom).offset(15);
        make.height.mas_equalTo(30);
        make.width.mas_equalTo(Adapt(55));
    }];
    self.moneyField.text = self.money;
    self.moneyField.layer.borderWidth = 1;
    self.moneyField.layer.borderColor = ColorGrayBack.CGColor;
    [self.feichibi mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.moneyField.mas_right).offset(5);
        make.top.mas_equalTo(weakSelf.titleView.mas_bottom).offset(15);
        make.height.mas_equalTo(30);
    }];
    self.feichibi.text = @"飞驰币";
    [self.detailB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.feichibi.mas_right).offset(5);
        make.centerY.mas_equalTo(weakSelf.feichibi);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    [self.detailB setImage:[UIImage imageNamed:@"match_explain_icon"] forState:UIControlStateNormal];
    [self.detailB addTarget:self action:@selector(showDitail:) forControlEvents:UIControlEventTouchUpInside];
    [self.confirmB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.dialogView).offset(-15);
        make.top.mas_equalTo(weakSelf.titleView.mas_bottom).offset(15);
        make.size.mas_equalTo(CGSizeMake(Adapt(40),30));
    }];
    [self.confirmB setTitle:@"确定" forState:UIControlStateNormal];
    [self.confirmB setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self.confirmB setBackgroundColor:ColorAppRed];
    self.confirmB.titleLabel.font = GetFont(12.0f);
    self.confirmB.layer.cornerRadius = 5;
    self.confirmB.clipsToBounds = YES;
    
    [self.confirmB addTarget:self action:@selector(confirm) forControlEvents:UIControlEventTouchUpInside];
    UIView*line = [UIView new];
    [self.dialogView addSubview:line];
    [line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(weakSelf.dialogView);
        make.top.mas_equalTo(weakSelf.feichibi.mas_bottom).offset(15);
        make.height.mas_equalTo(1);
    }];
    line.backgroundColor = ColorGrayBack;
    [self.changyong mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.dialogView).offset(15);
        make.top.mas_equalTo(line).offset(5);
        make.height.mas_equalTo(20);
    }];
    self.changyong.text = @"常用价格";
    CGFloat width  = ((Adapt(275)>275?Adapt(275):275) - 60)*0.33;
    for ( int i = 0; i<3 ; i++) {
        UIButton*button = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.dialogView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(weakSelf.changyong.mas_bottom).offset(5);
            make.bottom.mas_equalTo(weakSelf.dialogView.mas_bottom).offset(-20);
            make.width.mas_equalTo(width);
            make.left.mas_equalTo(weakSelf.dialogView).offset(15+i*15+i*width);
        }];
        button.tag = 2000+i;
        [button addTarget:self action:@selector(selectMoney:) forControlEvents:UIControlEventTouchUpInside];
        [button setTitle:[NSString stringWithFormat:@"%@飞驰币",self.moneyA[i]] forState:UIControlStateNormal];
        [button setTitleColor:ColorTitle forState:UIControlStateNormal];
        button.titleLabel.font = GetFont(10.0f);
        button.layer.cornerRadius =2;
        button.layer.borderColor = ColorGrayBack.CGColor;
        button.layer.borderWidth = 1;
        button.clipsToBounds = YES;
    }
    
    
    
    
    
    
}
-(void)selectMoney:(UIButton*)button{
    NSInteger i = button.tag - 2000;
    self.moneyField.text = self.moneyA[i];
}
-(void)showDitail:(UIButton*)button{
    if (self.delegate&&[self.delegate respondsToSelector:@selector(showPriceRules:andView:)]) {
        [self.delegate showPriceRules:button andView:self.dialogView];
    }
}
-(void)confirm{
    [self endEditing:YES];
    NSString*money = self.moneyField.text;
    
    if (money.integerValue <= 0) {
        [CMMUtility showToastWithText:@"价格不符合规则"];
        [self.moneyField becomeFirstResponder];
        return;
    }
    if (self.confirmBlock) {
        self.confirmBlock(money);
        [self hide];
    }
}
-(UILabel*)changyong
{
    if (!_changyong) {
        _changyong = [UILabel new];
        _changyong.textColor = ColorAppRed;
        _changyong.font = GetFont(12.0f);
        [self.dialogView addSubview:_changyong];
    }
    return _changyong;
}
-(UILabel*)feichibi
{
    if (!_feichibi) {
        _feichibi = [UILabel new];
        _feichibi.textColor = ColorTitle;
        _feichibi.font = GetFont(12.0f);
        [self.dialogView addSubview:_feichibi];
    }
    return _feichibi;
}
-(UIButton*)confirmB
{
    if(!_confirmB){
        _confirmB = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.dialogView addSubview:_confirmB];
    }
    return _confirmB;
}
-(UIButton*)detailB
{
    if(!_detailB){
        _detailB = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.dialogView addSubview:_detailB];
    }
    return _detailB;
}
-(UITextField*)moneyField
{
    if (!_moneyField) {
        _moneyField = [[UITextField alloc] init];
        _moneyField.delegate = self;
        _moneyField.font = GetFont(13.0f);
        _moneyField.textAlignment = NSTextAlignmentCenter;
        _moneyField.keyboardType = UIKeyboardTypeNumberPad;
        [self.dialogView addSubview:_moneyField];
    }
    return _moneyField;
}
-(UILabel*)danchang
{
    if (!_danchang) {
        _danchang = [UILabel new];
        _danchang.textColor = ColorTitle;
        _danchang.font = GetFont(12.0f);
        [self.dialogView addSubview:_danchang];
    }
    return _danchang;
}
-(UILabel*)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.textColor = ColorAppRed;
        _titleLabel.font = GetFont(14.0f);
        [self.dialogView addSubview:_titleLabel];
    }
    return _titleLabel;
}
-(UIView*)titleView
{
    if (!_titleView) {
        _titleView = [[UIView alloc] init];
        _titleView.backgroundColor = ColorGrayBack;
        [self.dialogView addSubview:_titleView];
    }
    return _titleView;
}
-(UIView*)dialogView
{
    if (!_dialogView) {
        _dialogView = [[UIView alloc] init];
        self.dialogView.backgroundColor = [UIColor whiteColor];
        [self addSubview:_dialogView];
    }
    return _dialogView;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
