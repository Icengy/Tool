//
//  ExpertSearchTableViewCell.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/14.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ExpertSearchTableViewCell.h"

#import "GallopExpertAvatarView.h"

#import "GallopExpertModel.h"

@interface ExpertSearchTableViewCell ()

@property (weak, nonatomic) IBOutlet GallopExpertAvatarView *avatarView;

/// 专家名称
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;

/// 专家标签
@property (weak, nonatomic) IBOutlet UIStackView *tagStackView;
/// 最近胜率(近x中x)
@property (weak, nonatomic) IBOutlet GallopTagNonBgLabel *rateLabel;
/// 连红
@property (weak, nonatomic) IBOutlet GallopTagNonBgLabel *winsLabel;

/// 7日返奖+在售方案载体view
@property (weak, nonatomic) IBOutlet UIStackView *sourceView;
/// 7日返奖率
@property (weak, nonatomic) IBOutlet GallopTagBgLabel *rewardRateLabel;
/// 在售方案数
@property (weak, nonatomic) IBOutlet GallopTagBgLabel *plansLabel;

/// 擅长View
@property (weak, nonatomic) IBOutlet UIView *skilledView;
/// 联赛名称
@property (weak, nonatomic) IBOutlet UIStackView *skilledStackView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *center_margin_constraint;

/// 专家简介
@property (weak, nonatomic) IBOutlet UILabel *introLabel;

/// 关注按钮

@property (weak, nonatomic) IBOutlet UIStackView *followBtnStackView;
@property (weak, nonatomic) IBOutlet UIButton *followBtn;
@property (weak, nonatomic) IBOutlet UIButton *follow2Btn;

@end

@implementation ExpertSearchTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.plansLabel.transformDegrees = 5.0;
    self.rewardRateLabel.transformDegrees = 5.0;
    self.winsLabel.transformDegrees = 5.0;
    
    self.avatarView.userInteractionEnabled = NO;
    @weakify(self)
    self.avatarView.clickToAvatarBlock = ^{
        @strongify(self)
        if ([self.delegate respondsToSelector:@selector(listCell:didClickToAvatar:)]) {
            [self.delegate listCell:self didClickToAvatar:self.model];
        }
    };
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setModel:(GallopExpertModel *)model {
    _model = model;
    
    [self.avatarView configAvatar:_model.expertAvatar withfield:_model.field];
    // 专家名称
    self.nameLabel.text = _model.expertName;
    
    // 专家
    self.introLabel.hidden = ![CommonUtils isEqualToNonNull:_model.introduction];
    self.introLabel.text = _model.introduction;
    
    // 专家擅长的联赛名称
    NSUInteger namesCount = _model.expertInLeagueNames.count;
    self.skilledView.hidden = !namesCount;
    
    for (int i = 0; i < self.skilledStackView.arrangedSubviews.count; i ++) {
        GallopTagLeagueLabel *subview = (GallopTagLeagueLabel *)[self.skilledStackView.arrangedSubviews objectAtIndex:i];
        if (_model.field == 1) {
            /// 足球
            subview.tagTintColor = ColorMainAppRed;
        }
        if (_model.field == 2) {
            subview.tagTintColor = ColorMainAppBlue;
        }
        
        if (i < namesCount) {
            subview.hidden = NO;
            subview.text = [_model.expertInLeagueNames objectAtIndex:i];
        }else {
            subview.hidden = YES;
            subview.text = nil;
        }
    }
    self.rateLabel.hidden = !_model.redCnt;
    self.rateLabel.text = [NSString stringWithFormat:@"近%@中%@",@(_model.planCnt), @(_model.redCnt)];
    
    self.winsLabel.hidden = (_model.lastContinueCnt > 1)?NO:YES;
    self.winsLabel.text = [NSString stringWithFormat:@"%@连红",@(_model.lastContinueCnt)];
    
    self.rewardRateLabel.hidden = !_model.profitOfMinDays;
    NSString *profitOfMinDays = [NSString stringWithFormat:@"%.0f%%",_model.profitOfMinDays *100];
    self.rewardRateLabel.text = [NSString stringWithFormat:@"7日返奖率%@",profitOfMinDays];
    [self.rewardRateLabel addAttributedText:profitOfMinDays withAttributeds:@{NSForegroundColorAttributeName: ColorMainAppRed}];
    
    self.plansLabel.hidden = !_model.forSalePlanCount;
    if (!self.plansLabel.hidden) {
        self.plansLabel.text = [NSString stringWithFormat:@"在售方案%@",@(_model.forSalePlanCount)];
        [self.plansLabel addAttributedText:[NSString stringWithFormat:@"%@",@(_model.forSalePlanCount)] withAttributeds:@{NSForegroundColorAttributeName: ColorMainAppRed}];
    }
    
    self.sourceView.hidden = (self.rewardRateLabel.hidden && self.plansLabel.hidden);
    
    self.followBtn.hidden = _model.followed;
    self.follow2Btn.hidden = !_model.followed;
    
    if (self.sourceView.hidden && self.skilledView.hidden) {
        self.center_margin_constraint.constant = 0;
    }else {
        self.center_margin_constraint.constant = 8;
    }
}

/// tag 300001
- (IBAction)clickToFollowing:(UIButton *)sender {
    NSInteger tag = sender.tag - 300001;
    
    if ([self.delegate respondsToSelector:@selector(listCell:didClickToFollow:withState:withBtns:)]) {
        [self.delegate listCell:self didClickToFollow:self.model withState:tag withBtns:@[_followBtn, _follow2Btn]];
    }
}

@end
