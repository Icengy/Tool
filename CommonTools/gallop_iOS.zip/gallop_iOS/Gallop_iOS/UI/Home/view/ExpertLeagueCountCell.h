//
//  ExpertLeagueCountCell.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExpertLeagueCountCell : UITableViewCell
- (void)configCellWithModel:(id)model row:(NSUInteger)row;
@end
