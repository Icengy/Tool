//
//  UNSelectTableViewCell.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "UNSelectTableViewCell.h"
@interface UNSelectTableViewCell ()

@property (nonatomic, strong) UILabel *upLabel;
@property (nonatomic, strong) UILabel *downLabel;

@end
@implementation UNSelectTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier ]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        if ([self respondsToSelector:@selector(setSeparatorInset:)])
        {
            [self setSeparatorInset:UIEdgeInsetsZero];
        }
        if ([self respondsToSelector:@selector(setLayoutMargins:)])
        {
            [self setLayoutMargins:UIEdgeInsetsZero];
        }
        self.contentView.backgroundColor = [UIColor whiteColor];
        [self setupView];
        
    }
    return self;
}

- (void)setupView
{
    __weak UNSelectTableViewCell*weakSelf = self;
    [self.upLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.contentView).offset(10);
        
        make.left.mas_equalTo(weakSelf.contentView).offset(15);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
        make.height.mas_equalTo(29);
    }];
    [self.downLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(weakSelf.contentView).offset(-10);
        
        make.left.mas_equalTo(weakSelf.contentView).offset(15);
        make.right.mas_equalTo(weakSelf.contentView).offset(-15);
        make.height.mas_equalTo(20);
    }];
    
    
    self.upLabel.text = @"请选择比赛及玩法，可选1至2场比赛，每场比赛可选1或2种玩法";
}
-(UILabel*)upLabel
{
    if (!_upLabel) {
        _upLabel = [UILabel new];
        _upLabel.textColor = ColorTitle;
        _upLabel.font = fcFont(12.0f);
        _upLabel.numberOfLines = 2;
        [self.contentView addSubview:_upLabel];
    }
    return _upLabel;
}
-(UILabel*)downLabel
{
    if (!_downLabel) {
        _downLabel = [UILabel new];
        _downLabel.textColor = ColorTitle;
        _downLabel.font = fcFont(12.0f);
        [self.contentView addSubview:_downLabel];
    }
    return _downLabel;
}
-(void)setText:(NSString *)text
{
    _text = text;
    self.downLabel.text = [NSString stringWithFormat:@"今日还可发布 %@ 场比赛方案",text];
    [LPUnitily setSubStringWithLabel:self.downLabel textArray:@[text] font:self.downLabel.font color:ColorBallRed];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
