//
//  PlanBasketDetailGameInfoView.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol PlanBasketDetailGameInfoViewDelegate <NSObject>

- (void)matchCardClick:(id)model;

@end
@interface PlanBasketDetailGameInfoView : UIView
@property(nonatomic, weak)id<PlanBasketDetailGameInfoViewDelegate> delegate;
- (void)configPlanBasketDetailGameInfoView:(id)model;
@end


