//
//  WTCSPForJCZQView.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MatchModel.h"
#import "SelectedMatchModel.h"

NS_ASSUME_NONNULL_BEGIN
@class WTCSPForJCZQView;
@protocol WTCSPFForJCZQViewDelegate <NSObject>

- (void)spfForJCZQView:(WTCSPForJCZQView *)sfpView didSelectItem:(MatchModel *)model;

@end
@interface WTCSPForJCZQView : UIView

@property (nonatomic, weak) id<WTCSPFForJCZQViewDelegate> delegate;
@property (nonatomic, strong) MatchModel *model;
@property (nonatomic, assign) BOOL forbidSelect;
@property (nonatomic, assign) BOOL isExtreme;
//0:都显示，1：显示胜负平；2:显示亚指胜负平
@property (nonatomic, assign) long showResultType;

//- (void)setupView;
@end

NS_ASSUME_NONNULL_END
