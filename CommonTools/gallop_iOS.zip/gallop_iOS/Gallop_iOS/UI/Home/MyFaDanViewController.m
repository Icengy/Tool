//
//  MyFaDanViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "MyFaDanViewController.h"
#import "ReleaseRecordTableViewCell.h"
#import "HistorySaleManager.h"
#import "CYPlanDetailViewController.h"
#import "SaleCountViewController.h"
#import "BuyRecord.h"
@interface MyFaDanViewController ()<HistorySaleManagerDelegate,ReleaseRecordTableViewCellDelegate>
@property (nonatomic, strong) HistorySaleManager *manager;
@end

@implementation MyFaDanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     [self initWithSubViews];
    // Do any additional setup after loading the view.
}
- (void)initWithSubViews{
    self.navigationItem.title = @"方案发布记录";
    self.tableView.frame = CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight);
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
    
    [self loadData];
    
}
-(void)didSelectDetailWithBuyRecord:(BuyRecord *)model
{
    SaleCountViewController*vc = [SaleCountViewController new];
    vc.model = model;
    [self.navigationController pushViewController:vc animated:YES];
}
-(HistorySaleManager*)manager
{
    if (!_manager) {
        _manager = [HistorySaleManager new];
        _manager.delegate = self;
    }
    return _manager;
}
-(void)loadData{
    [ES_HttpService showLoading:YES];
    [self.manager refreshDataWithType:@"" andField:@"1"];
}
-(void)loadMoreData{
    [self.manager loadDataWithType:@"" andField:@"1"];
}
-(void)HistorySaleManager:(HistorySaleManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload{
    [self endAllFreshing:self.tableView];
    
    dispatch_main_async_safe(^{
          
          if (self.manager.dataSource.count == 0) {
          }
          
          if (!isRefresh && self.manager.dataSource.count >= 20) {
              self.tableView.mj_footer.hidden = NO;
          }else{
              self.tableView.mj_footer.hidden = YES;
          }
          
          [self.tableView reloadData];
          
      });
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  self.manager.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BuyRecord*model  = self.manager.dataSource[indexPath.row];
    static NSString *identifier=@"ReleaseRecordTableViewCell";
    ReleaseRecordTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (cell==nil) {
        cell=[[ReleaseRecordTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //cell贴边
    UIEdgeInsets inset;
    inset.bottom=0;
    inset.top=0;
    inset.left=0;
    inset.right=0;
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:inset];
    }
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
        [cell setSeparatorInset:inset];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.model = model;
    cell.delegate = self;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    BuyRecord*model  = self.manager.dataSource[indexPath.row];
    CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
    vc.back = YES;
    vc.planId = [model.planId integerValue];
//    vc.isBasket = (model.planInfo.field.integerValue == 2);
    vc.sourcePage = @"方案发布记录";
//    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	tableView.rowHeight = UITableViewAutomaticDimension;
    tableView.estimatedRowHeight = 165;
    return tableView.rowHeight;

}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.01;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
   
    
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
