//
//  LeagueCountViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/31.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface LeagueCountViewController : ESViewController
@property (nonatomic,assign) NSUInteger field;
@property (nonatomic,assign) NSUInteger expertId;
@end
