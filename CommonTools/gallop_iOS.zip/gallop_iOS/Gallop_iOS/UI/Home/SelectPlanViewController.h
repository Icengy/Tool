//
//  SelectPlanViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/28.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@class MatchModel;

NS_ASSUME_NONNULL_BEGIN

@interface SelectPlanViewController : ESViewController

- (BOOL)twoGameLimited;
@property (nonatomic,strong) NSMutableArray*haveSelectArr;
@end

NS_ASSUME_NONNULL_END
