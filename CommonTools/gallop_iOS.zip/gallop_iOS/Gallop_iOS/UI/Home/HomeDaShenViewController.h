//
//  HomeDaShenViewController.h
//  Gallop_iOS
//
//  Created by lcy on 2021/5/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "ESViewController.h"

#define kTitleBarListHeight 186.0

NS_ASSUME_NONNULL_BEGIN

@interface HomeDaShenViewController : ESViewController

/// 1足球 2篮球
@property (nonatomic ,assign) NSInteger field;
- (void)loadData:(id _Nullable)sender;

@end

NS_ASSUME_NONNULL_END
