//
//  HomeViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//
#define kheadViewHight (([UIScreen mainScreen].bounds.size.width)/2)
#define kswitchTabHight 40.0
#define kTitleBarHeight 40.0
#define kMatchBlockHeight  130.0
#define kMarginHeight 10.0

#import "HomeViewController.h"

#import "MatchDetailViewController.h"
#import "GallopExpertViewController.h"
#import "CYPlanDetailViewController.h"
#import "ExpertDetailViewController.h"
#import "WTCContentViewController.h"
#import "PaperContentViewController.h"
#import "PayViewController.h"
#import "WTCTabBarViewController.h"
#import "CommunityPaperContentViewController.h"
#import "MatchDetailViewController.h"
#import "TYTabButtonPagerController.h"
#import "CYTabTitleBar.h"
#import "HomeDaShenViewController.h"
#import "MatchHomeViewController.h"

#import "SelectPlanViewController.h"

#import "DiscoverHeadLineView.h"
#import "HomeMatchResultCollectionCell.h"

#import "TypeChooseView.h"
#import "ESNewMainScrollView.h"

#import "ExpertPlansListTableViewCell.h"
#import "CYHomeMatchFooterView.h"

//model
#import "GallopExpertModel.h"
#import "GallopBannerItemModel.h"
#import "PlanModel.h"
#import "YinLi.h"


@interface HomeViewController ()<ESNewMainScrollViewDelegate,
HeadLineDelegate,
TypeChooseViewDelegate,
TYTabPagerControllerDelegate,
TYPagerControllerDataSource,
ExpertPlansListTableCellDelegate,
CYHomeMatchFooterViewDelegate,
UIScrollViewDelegate>
{
    UIButton *_markButton;
    int _changingType;//筛选用的选择条的4个按钮，对应0，1，2，3，默认为0；
    GallopSwitchButton *allB;
    GallopSwitchButton *footballB;
    GallopSwitchButton *basketballB;
    GallopSwitchButton *typeB;
    /// 方案列表分页
    NSInteger _page;
    /// 转存列表数据的数组
    NSArray *_transitionArray;
    /// 选项卡与头部视图的差值
//    CGFloat _differenceHegiht;
    /// tableView的Y轴偏移量
    CGFloat _offsetY;
    
    BOOL _firstLoad;
}
@property (nonatomic ,strong) TYTabButtonPagerController *titleBarController;
@property (nonatomic ,strong) CYTabTitleBar *titleBarView;

@property (nonatomic ,copy) NSArray *titleBarArray;
@property (nonatomic ,copy) NSArray <HomeDaShenViewController *>*titleBarControllerArray;
@property (nonatomic ,assign) NSInteger currentBarIndex;

@property (nonatomic, strong) ESNewMainScrollView *mainScrollView;
@property (nonatomic, strong) UIView *tableHeadView;
@property (nonatomic, strong) CYHomeMatchFooterView *footerView;
@property (nonatomic, strong) UIView *muiltClickView;
//@property (nonatomic, strong) UIView *barView;
@property (nonatomic, strong) UIWindow *barWindow;

@property (nonatomic, strong) NSMutableArray*importantArr;

@property (nonatomic, strong) DiscoverHeadLineView *headLineView;
/// 头条model
@property (nonatomic, strong) GallopBannerModel *headLineModel;
//data
@property (nonatomic, strong) NSMutableArray <GallopBannerItemModel *>*banners;
@property (nonatomic, strong) NSMutableArray *dashens;
@property (nonatomic, strong) NSMutableArray *basketDashens;
@property (nonatomic, strong) NSMutableArray<NSString *> *leagueList;
@property (nonatomic, strong) NSMutableArray<NSString *> *leagueBasketList;
@property (nonatomic, strong) NSMutableArray<NSString *> *leagueCategatyList;

//@property (nonatomic, strong) NSString *field; //1:足球 2:篮球

@property (nonatomic,strong) NSString*footballType;//对应新的选择框的模式
@property (nonatomic,strong) NSString*basketballType;
@property (nonatomic,strong) NSString*planType;

@property (nonatomic, strong)TypeChooseView *typeChooseView;//类型选择

@end

@implementation HomeViewController

- (void)viewDidLoad {
	[super viewDidLoad];
    
    self.fd_prefersNavigationBarHidden = YES;
    
    self.footballType = @"";
    self.basketballType = @"";
    self.planType = @"";
    
    _changingType = 0;
//    _differenceHegiht = -100.0;
    _offsetY = 0.0;
    _firstLoad = YES;
    
    self.titleBarArray = @[@"足球大神", @"篮球大神"];
    self.titleBarControllerArray = [self getTitleControllerArray];
    
    self.importantArr = [NSMutableArray arrayWithCapacity:0];
    self.leagueList = @[].mutableCopy;
    self.leagueBasketList = @[].mutableCopy;
    self.leagueCategatyList = @[@"全部",@"单关",@"二串一",@"免费"].mutableCopy;
    
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogin:) name:kESDidLoginNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appDidLogout:) name:kESDidLogoutNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(tockenDidExpired:) name:kESTockenDidExpiredNotification object:nil];
    
    self.barStyle = UIStatusBarStyleLightContent;
    
	[self setupViews];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [ESNetworkService customPostionCode:@"002"];
    
    [self updateSwitchBar];
    
    if (!self.dataSource.count) {
        [self loadData:nil];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.barWindow.hidden = YES;
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.plainTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.top.left.right.equalTo(self.view);
    }];
}

#pragma mark - kESDidLoginNotification
- (void)appDidLogin:(NSNotification *)notification{
    [self loadData:nil];
}

- (void)appDidLogout:(NSNotification *)notification{
    [self loadData:nil];
}

- (void)tockenDidExpired:(NSNotification *)notification{
    dispatch_main_async_safe(^{
        [self.plainTableView reloadData];
        
        [APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
        }];
    })
}

#pragma mark -
-(void)loadData:(id)sender {
    [ES_HttpService showLoading:!sender];

    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    dispatch_group_t gcd_group = dispatch_group_create();
	
    if (![sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        if (_firstLoad || [sender isKindOfClass:[MJCostomAnimHeader class]]) {/// 首次加载数据
            
            if (sender) {
                ///获取足球大神数据
                [self.titleBarControllerArray.firstObject loadData:sender];
                /// 获取篮球大神
                [self.titleBarControllerArray.lastObject loadData:sender];
            }
            
            /// 获取banner
            dispatch_group_async(gcd_group, queue, ^{
                [self loadBanner:sender withGroup:gcd_group];
            });
            /// 获取飞驰头条
            dispatch_group_async(gcd_group, queue, ^{
                [self loadHeadlines:sender withGroup:gcd_group];
            });
        }
        /// 获取推荐赛事
        dispatch_group_async(gcd_group, queue, ^{
            [self loadImportantMatch:sender withGroup:gcd_group];
        });
        /// 获取足球筛选条件
        dispatch_group_async(gcd_group, queue, ^{
            [self loadLeagueList:sender withGroup:gcd_group];
        });
        /// 获取篮球筛选条件
        dispatch_group_async(gcd_group, queue, ^{
            [self loadBasketLeagueList:sender withGroup:gcd_group];
        });
        
    }
    
    dispatch_group_async(gcd_group, queue, ^{
        /// 获取方案列表
        [self loadPlanList:sender withGroup:gcd_group];
    });
    
	dispatch_group_notify(gcd_group, dispatch_get_main_queue(), ^{
        WTCLog(@"HomeViewController dispatch_group_notify");
        _firstLoad = NO;
        
        [self endAllFreshing:self.plainTableView];
        
        /// banner刷新
        [self.mainScrollView reloadData];
        /// 头条加载
        self.headLineView.hidden = !self.headLineModel.data.count;
        [self.headLineView configViewWithModel:self.headLineModel];

        [self.plainTableView updataFreshFooter:(self.dataSource.count && _transitionArray.count < 20)];
        self.plainTableView.mj_footer.hidden = !self.dataSource.count;
        
        [self.plainTableView reloadData];
	});
}

- (void)loadPlanList:(id)sender {
    [self loadPlanList:sender withGroup:nil];
}

- (void)loadPlanList:(id)sender withGroup:(dispatch_group_t)group {
    
    if (group) dispatch_group_enter(group);
    else
        [ES_HttpService showLoading:YES];
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        _page ++;
    }else {
        _page = 1;
    }
    
    WTCLog(@"%@,%@,%@",self.footballType, self.basketballType, self.planType);
    NSInteger matchSelectType = 0;
    NSString *type = @"";
    NSString *field = @"";
    NSString *selectedLeague = @"";

    if (![self.footballType isEqualToString:@""]) {
        /// 选中足球项
        field = @"1";
        selectedLeague = [self.footballType isEqualToString:@"全部足球"]?@"":self.footballType;
    }
    if (![self.basketballType isEqualToString:@""]) {
        /// 选中篮球项
        field = @"2";
        selectedLeague = [self.basketballType isEqualToString:@"全部篮球"]?@"":self.basketballType;
    }
    if (![self.planType isEqualToString:@"全部"]) {
        if ([self.planType isEqualToString:@"免费"]) {
            type = @"3";
            matchSelectType = 0;
        }else if ([self.planType isEqualToString:@"单关"]) {
            matchSelectType = 1;
            type = @"";
        }else if ([self.planType isEqualToString:@"二串一"]) {
            matchSelectType = 2;
            type = @"";
        }
    }
    
    [ESNetworkService planListWithoutHUDWithPage:(int)_page
                                        pageSize:20
                                           field:field
                                            type:type
                                  selectedLeague:selectedLeague
                                 matchSelectType:matchSelectType
                                        response:^(id dict, ESError *error) {
        
        WTCLog(@"loadPlanList");
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id da = dict[@"data"];
            id data = da[@"data"];
            if ([data isKindOfClass:[NSString class]]) {
                _transitionArray = [data objectFromJSONString];
            }
            
            if ([data isKindOfClass:[NSArray class]]) {
                _transitionArray = data;
            }
            if (_page == 1) {
                [self.dataSource removeAllObjects];
            }
            for (NSDictionary *dic in _transitionArray) {
                PlanModel*model = [PlanModel mj_objectWithKeyValues:dic];
                NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
                NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
                for (NSDictionary*dic_info in matchInfo) {
                    MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
                    [arrM addObject:tag];
                }
                model.matchInfoArr = [arrM copy];
                [self.dataSource addObject:model];
            }
        }
        if (group) {
            dispatch_group_leave(group);
        }else {
            [self endAllFreshing:self.plainTableView];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.plainTableView updataFreshFooter:(self.dataSource.count && _transitionArray.count < 20)];
                self.plainTableView.mj_footer.hidden = !self.dataSource.count;
                
                [self.plainTableView reloadData];
            });
        }
    }];
}

- (void)loadHeadlines:(id)sender withGroup:(dispatch_group_t)group {
    
    dispatch_group_enter(group);
    @weakify(self);
    [ESNetworkService getHeadlinesDiscoverWithResponse:^(id dict, ESError *error) {
        WTCLog(@"loadHeadlines");
        
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            self.headLineModel = [GallopBannerModel mj_objectWithKeyValues:dict];
        }
        dispatch_group_leave(group);
    }];
}


- (void)loadBasketballDaShen:(id)sender  withGroup:(dispatch_group_t)group {
    
    dispatch_group_enter(group);
    @weakify(self);
    [ESNetworkService getDaShenWithField:2 Response:^(id dict, ESError *error) {
        WTCLog(@"loadBasketballDaShen");
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* dsList = data[@"doyenList"];
            dispatch_main_async_safe(^{
                [self.basketDashens removeAllObjects];
                for (NSDictionary *dic in dsList) {
                    GallopExpertModel *model = [GallopExpertModel mj_objectWithKeyValues:dic];
                    [self.basketDashens addObject:model];
                }
            });
        }
        dispatch_group_leave(group);
    }];
}

- (void)loadFootballDaShen:(id)sender withGroup:(dispatch_group_t)group {
    
    dispatch_group_enter(group);
    @weakify(self);
    [ESNetworkService getDaShenWithField:1 Response:^(id dict, ESError *error) {
        WTCLog(@"loadFootballDaShen");
        
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* dsList = data[@"doyenList"];
            dispatch_main_async_safe(^{
                [self.dashens removeAllObjects];
                for (NSDictionary *dic in dsList) {
                    GallopExpertModel *model = [GallopExpertModel mj_objectWithKeyValues:dic];
                    [self.dashens addObject:model];
                }
            });
        }
        dispatch_group_leave(group);
    }];
}

- (void)loadLeagueList:(id)sender withGroup:(dispatch_group_t)group {
    dispatch_group_enter(group);
    
    @weakify(self);
    [ESNetworkService getHomeLeagueListWithField:1 Response:^(id dict, ESError *error) {
        WTCLog(@"loadLeagueList");
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                NSArray* list = dict[@"data"];
                if ([list isKindOfClass:[NSArray class]]) {
                    if (list.count) {
                        if (self.leagueList.count)
                            [self.leagueList removeAllObjects];
                        [self.leagueList addObjectsFromArray:list];
                    }
                }
            });
        }
        dispatch_group_leave(group);
    }];
}

- (void)loadBasketLeagueList:(id)sender withGroup:(dispatch_group_t)group {
    dispatch_group_enter(group);
    
    @weakify(self);
    [ESNetworkService getHomeLeagueListWithField:2 Response:^(id dict, ESError *error) {
        WTCLog(@"loadLeagueList");
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                NSArray* list = dict[@"data"];
                if ([list isKindOfClass:[NSArray class]]) {
                    if (list.count) {
                        if (self.leagueBasketList.count)
                            [self.leagueBasketList removeAllObjects];
                        [self.leagueBasketList addObjectsFromArray:list];
                    }
                }
            });
        }
        dispatch_group_leave(group);
    }];
}

- (void)loadBanner:(id)sender withGroup:(dispatch_group_t)group {
    
    dispatch_group_enter(group);
    @weakify(self);
    [ESNetworkService getBannersWithField:(self.currentBarIndex + 1) Response:^(id dict, ESError *error) {
        WTCLog(@"loadBanner");
        
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            GallopBannerModel *model = [GallopBannerModel mj_objectWithKeyValues:dict];
            if (model && model.data.count) {
                if (self.banners.count) [self.banners removeAllObjects];
                [self.banners addObjectsFromArray:model.data];
            }
        }
        dispatch_group_leave(group);
    }];
}

-(void)loadImportantMatch:(id)sender withGroup:(dispatch_group_t)group {
    
    dispatch_group_enter(group);
    [ESNetworkService homeRecomandMatchWithresponse:^(id dict, ESError *error) {
        WTCLog(@"loadImportantMatch");
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* list = data[@"matchList"];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.importantArr removeAllObjects];
                if (!QM_IS_ARRAY_NIL(list)) {
                    for (NSDictionary *dic in list) {
                        if (!QM_IS_DICT_NIL(dic)) {
                            HomeMatchResultModel *model = [HomeMatchResultModel mj_objectWithKeyValues:dic];
                            [self.importantArr addObject:model];
                        }
                    }
                }
            });
        }
        dispatch_group_leave(group);
    }];
}

#pragma mark - action
-(void)didSelectHeadV:(id)cell {
    NSIndexPath*indexPath = [self.plainTableView indexPathForCell:cell];
    PlanModel *model  = self.dataSource[indexPath.row];
    ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",model.userId];
    vc.sourcePage = @"首页方案列表";
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}


-(void)goEdit:(UIButton*)button{
    [MobClick event:@"expert8"];
    
    [self.navigationController pushViewController:[SelectPlanViewController new] animated:YES];
}

#pragma mark 类型选择条的处理
-(void)changeView:(UIButton *)sender {
    int onChanging = (int)sender.tag-1000;
//    if (onChanging == 1 && !self.leagueList.count) {/// 足球
//        return;
//    }
//    if (onChanging == 2 && !self.leagueBasketList.count) {
//        return;
//    }
    /**模拟数据*/
    //全部
//    //足球联事
//    NSArray*arr1 = @[@"全部足球",@"英超",@"德甲",@"法甲",@"意甲",@"欧洲杯",@"世界杯"];
//    //篮球联赛
//    NSArray*arr2 = @[@"全部篮球",@"NBA",@"CBA",@"WNBA",@"欧洲杯",@"世界杯"];
    //方案类型
//    NSArray *arrayT = @[@"全部",@"单关",@"二串一",@"免费"];

    NSMutableArray *footerLists = [NSMutableArray new];
    [footerLists addObject:@"全部足球"];
    [footerLists addObjectsFromArray:self.leagueList.copy];
    
    NSMutableArray *basketLists = [NSMutableArray new];
    [basketLists addObject:@"全部篮球"];
    [basketLists addObjectsFromArray:self.leagueBasketList.copy];
    

    NSArray*dataArr = @[@[],footerLists.copy, basketLists.copy, self.leagueCategatyList.copy];
    NSArray*buttonA = @[allB, footballB, basketballB, typeB];
    
    NSArray*nowTpyeA = @[@"全部",self.footballType,self.basketballType,self.planType];
    
    CGRect rect = [self.muiltClickView convertRect:self.muiltClickView.bounds toView:self.muiltClickView.window];
    CGFloat originY = rect.origin.y + rect.size.height;
    self.typeChooseView.frame = CGRectMake(0, originY, kScreen_Width, kScreen_Height - originY);
    
    if (onChanging != _changingType) {//和之前选的不一样
        if (onChanging == 0) {
            [self.typeChooseView hidden];
            
            //全部
            [allB setTitleColor:ColorBallRed forState:UIControlStateNormal];
            
            self.footballType = @"";
            [footballB setTitle:@"足球" forState:UIControlStateNormal];
            [footballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
            [footballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];
            
            self.basketballType = @"";
            [basketballB setTitle:@"篮球" forState:UIControlStateNormal];
            [basketballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
            [basketballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];
            
            self.planType = @"";
            [typeB setTitle:@"分类" forState:UIControlStateNormal];
            [typeB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
            [typeB setImage:[UIImage imageNamed:@"filter-fill"] forState:UIControlStateNormal];
            //更新筛选之后数据 -- 全部
//            [CMMUtility showNote:@"self.basketballType\nself.footballType\nself.planType\n更新数据"];
            
            [self loadPlanList:nil];
            
        }else if(_changingType == 0) {
            
            [allB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
            
            UIButton*certainB = buttonA[onChanging];
            NSString*certainTyep = nowTpyeA[onChanging];
            NSArray*certainA = dataArr[onChanging];
    
            [certainB setTitleColor:ColorBallRed forState:UIControlStateNormal];
            NSInteger selectedIndex = [certainA indexOfObject:certainTyep];
            [certainB setImage:[UIImage imageNamed:@"data_pullup_green"] forState:UIControlStateNormal];
            
            [self.typeChooseView showWithdataSource:certainA index:selectedIndex];
            
            
        }else if (_changingType == 3 || onChanging == 3){
            if (_changingType == 3 && onChanging == 1) {
                self.basketballType = @"全部篮球";
                [basketballB setTitle:@"篮球" forState:UIControlStateNormal];
                [basketballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
                [basketballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];

            }else  if (_changingType == 3 && onChanging == 2) {
                self.footballType = @"全部足球";
                [footballB setTitle:@"足球" forState:UIControlStateNormal];
                [footballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
                [footballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];

            }
            UIButton*oldB = buttonA[_changingType];
            [oldB setImage:[UIImage imageNamed:@"data_pulldown_red"] forState:UIControlStateNormal];
            UIButton*certainB = buttonA[onChanging];
            NSString*certainTyep = nowTpyeA[onChanging];
            NSArray*certainA = dataArr[onChanging];
    
            [certainB setTitleColor:ColorBallRed forState:UIControlStateNormal];
            NSInteger selectedIndex = [certainA indexOfObject:certainTyep];
            [certainB setImage:[UIImage imageNamed:@"data_pullup_green"] forState:UIControlStateNormal];

            [self.typeChooseView showWithdataSource:certainA index:selectedIndex];
            
        }else {
            if (_changingType == 1) {
                self.footballType = @"";
                [footballB setTitle:@"足球" forState:UIControlStateNormal];
                [footballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
                [footballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];

            }else{
                //_changingType == 2
                self.basketballType = @"";
                [basketballB setTitle:@"篮球" forState:UIControlStateNormal];
                [basketballB setTitleColor:ColorAppBlack forState:UIControlStateNormal];
                [basketballB setImage:[UIImage imageNamed:@"data_pulldown_icon"] forState:UIControlStateNormal];

            }
            UIButton*certainB = buttonA[onChanging];
            NSString*certainTyep = nowTpyeA[onChanging];
            NSArray*certainA = dataArr[onChanging];
    
            [certainB setTitleColor:ColorBallRed forState:UIControlStateNormal];
            NSInteger selectedIndex = [certainA indexOfObject:certainTyep];
            [certainB setImage:[UIImage imageNamed:@"data_pullup_green"] forState:UIControlStateNormal];

            [self.typeChooseView showWithdataSource:certainA index:selectedIndex];
        }
        _changingType = onChanging;
    }else {
        //相同
        if (self.typeChooseView.hidden == YES) {
            switch (onChanging) {
                case 0:
                {
//                    //更新筛选之后数据 -- 全部
//                    [CMMUtility showNote:@"self.basketballType\nself.footballType\nself.planType\n更新数据"];
                    self.basketballType = @"";
                    self.footballType = @"";
                    self.planType = @"";
                    
                    [self loadPlanList:nil];
                }
                    break;
                case 1:
                {
                    UIButton*certainB = buttonA[onChanging];
                    [certainB setImage:[UIImage imageNamed:@"data_pullup_green"] forState:UIControlStateNormal];
                    NSInteger selectedIndex = [footerLists indexOfObject:self.footballType];
                    [self.typeChooseView showWithdataSource:footerLists index:selectedIndex];
                }
                    break;
                case 2:
                {
                    UIButton*certainB = buttonA[onChanging];
                    [certainB setImage:[UIImage imageNamed:@"data_pullup_green"] forState:UIControlStateNormal];
                    NSInteger selectedIndex = [basketLists indexOfObject:self.basketballType];
                    [self.typeChooseView showWithdataSource:basketLists index:selectedIndex];
                }
                    break;
                case 3:
                {
                    UIButton*certainB = buttonA[onChanging];
                    [certainB setImage:[UIImage imageNamed:@"filter-filled"] forState:UIControlStateNormal];
                    NSInteger selectedIndex = [self.leagueCategatyList indexOfObject:self.planType];
                    [self.typeChooseView showWithdataSource:self.leagueCategatyList index:selectedIndex];
                }
                    break;
                    
                default:
                    break;
            }
        }
    }
}

#pragma mark 布局页面
-(void)setupViews {
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    [self.view addSubview:self.plainTableView];
    
    self.plainTableView.scrollsToTop = NO;
    self.plainTableView.backgroundColor = ColorDefaultGrayBackground;
    self.plainTableView.tag = 9999;
    self.plainTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.plainTableView.separatorColor = RGBCOLORV(0xEDEDED);
    self.plainTableView.estimatedSectionHeaderHeight = 0;
    self.plainTableView.estimatedSectionFooterHeight = 0;
    self.plainTableView.contentInset = kTableViewDetailtContentInset;
    self.plainTableView.placeHolderView = nil;
    
    [self.plainTableView registerNibCell:[ExpertPlansListTableViewCell class]];
    
    [self fillTableHeadSubViews];

    if (@available(iOS 11.0, *)) {
        self.plainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    
    [self.plainTableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.plainTableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
    
//    self.barView = [UIView new];
//    [self.barView setFrame:CGRectMake(0, 0, kScreen_Width, kStatusBarHeight)];
//    self.barView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0];
//    [self.view addSubview:self.barView];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.view addSubview:self.barWindow];
        self.barWindow.hidden = NO;
    });
}

- (void)fillTableHeadSubViews {
    //轮播图
    self.mainScrollView = [[ESNewMainScrollView alloc] initWithFrame:CGRectZero withDelegate:self];
    self.mainScrollView.insets = UIEdgeInsetsMake(0, 0, 8.0, 0);
    [self.tableHeadView addSubview:self.mainScrollView];
    [self.mainScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.equalTo(self.tableHeadView);
        make.height.offset(kheadViewHight);
    }];
    
    // 推荐大神
//    [self.tableHeadView addSubview:self.titleBarView];
    [self.tableHeadView insertSubview:self.titleBarView aboveSubview:self.mainScrollView];
    self.titleBarView.sliderColor = ColorMainAppRed;
    self.titleBarView.normalItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCRegular:16],
                                                         NSForegroundColorAttributeName:ColorMainNormalBlack};
    self.titleBarView.selectedItemTextAttributes = @{NSFontAttributeName: [UIFont addPingFangSCBold:16],
                                                         NSForegroundColorAttributeName:ColorMainAppRed};
    self.titleBarView.dataArray = self.titleBarArray.copy;
    self.titleBarView.insets = UIEdgeInsetsMake(0.0, 44.0, 0.0, 44.0);
    [self.titleBarView addRoundedCorners:(UIRectCornerTopLeft | UIRectCornerTopRight) withRadii:8.0];
    [self.titleBarView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mainScrollView.mas_bottom);
        make.width.centerX.equalTo(self.tableHeadView);
        make.height.offset(kTitleBarHeight);
    }];
    
    CYButton *moreExpertB = [CYButton buttonWithType:UIButtonTypeCustom];
    [self.tableHeadView addSubview:moreExpertB];
    [moreExpertB mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.height.equalTo(self.titleBarView);
        make.right.equalTo(self.tableHeadView.mas_right).offset(-10);
        make.width.equalTo(moreExpertB.mas_height);
    }];
    [moreExpertB setImage:GetImage(@"expert-more") forState:UIControlStateNormal];
    moreExpertB.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [moreExpertB addTarget:self action:@selector(moreExpert:) forControlEvents:UIControlEventTouchUpInside];
    
    //滚动字幕
//    [self.tableHeadView addSubview:self.headLineView];
    [self.tableHeadView insertSubview:self.headLineView belowSubview:self.titleBarView];
    [self.headLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.titleBarView);
        make.centerX.equalTo(self.tableHeadView);
        make.size.sizeOffset(self.headLineView.size);
    }];
    
    // 推荐大神列表
    [self addChildViewController:self.titleBarController];
    [self.tableHeadView addSubview:self.titleBarController.view];
    [self.titleBarController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleBarView.mas_bottom);
        make.centerX.width.equalTo(self.tableHeadView);
        make.bottom.equalTo(self.tableHeadView.mas_bottom).offset(-kMarginHeight);
        make.height.offset(kTitleBarListHeight);
    }];
    
    [self creatClickViewItems];
}

- (void)creatClickViewItems {
    NSArray *nameArray = @[@"全部",@"足球",@"篮球",@"分类"];
    CGFloat _allWidth, _btnWidth, _cateWidth, _allHeight;
    _allWidth = self.muiltClickView.width - 1.0;
//    _allHeight = kswitchTabHight - 1.0;
    _allHeight = kswitchTabHight;
    _cateWidth = _allWidth/5;
    _btnWidth = (_allWidth - _cateWidth - 1.0)/3;
    
    for (int i = 0; i < nameArray.count; i ++) {
        GallopSwitchButton *button = [GallopSwitchButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(_btnWidth *i, 0, (i == (nameArray.count -1))?_cateWidth:_btnWidth, _allHeight);
        button.tag = 1000+i;
        switch (i) {
            case 0:
                allB = button;
                break;
            case 1:
                footballB = button;
                break;
            case 2:
                basketballB = button;
                break;
            case 3:
                typeB = button;
                break;

            default:
                break;
        }
        [button setTitle:[nameArray objectAtIndex:i] forState:UIControlStateNormal];
        button.titleLabel.font= [UIFont addPingFangSCRegular:13];
        [button addTarget:self action:@selector(changeView:) forControlEvents:UIControlEventTouchUpInside];

        if (i != 0) {
            NSString *imageStr = @"data_pulldown_icon" ,*selectedImageStr = @"data_pulldown_red";
            if (i == (nameArray.count - 1)) {
                imageStr = @"filter-fill";
                selectedImageStr = @"filter-fill";

                UIView*lineV = [UIView new];
                lineV.backgroundColor = RGBCOLORV(0xEDEDED);
                [self.muiltClickView addSubview:lineV];
                [lineV setFrame:CGRectMake(_btnWidth *i, self.muiltClickView.height *0.1, 1.0, _allHeight *0.8)];
            }
            [button setTitleColor:ColorAppBlack forState:UIControlStateNormal];
            [button setTitleColor:ColorAppBlack forState:UIControlStateSelected];
            [button setImage:[UIImage imageNamed:imageStr] forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:selectedImageStr] forState:UIControlStateSelected];
        }else {
            [button setTitleColor:ColorAppRed forState:UIControlStateNormal];
        }
        [self.muiltClickView addSubview:button];
    }
    
    UIView *line = [[UIView alloc] initWithFrame:CGRectMake(0, _allHeight - 1, self.muiltClickView.width, 1)];
    [self.muiltClickView addSubview:line];
    line.backgroundColor = RGBCOLORV(0xEDEDED);
//    line.backgroundColor = UIColor.redColor;
}

//- (void)defaultCell:(NSArray*)listArray CellView:(MLMOptionSelectView*)cellView{
//    WEAK(weakCellView, cellView);
//    cellView.canEdit = NO;
//    cellView.showsVerticalScrollIndicator = YES;
//    if (listArray.count > 5) {
//        //暂时显示滚动条
//        [cellView flashScrollIndicators];
//    }
//    [cellView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"DefaultCell"];
//
//    cellView.cell = ^(NSIndexPath *indexPath){
//
//        UITableViewCell *cell = [weakCellView dequeueReusableCellWithIdentifier:@"DefaultCell"];
//
//        cell.backgroundColor =[UIColor whiteColor];
//        cell.textLabel.textColor = ColorSubTitle;
//        cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@",listArray[indexPath.row]]];
//        cell.textLabel.textAlignment = NSTextAlignmentCenter;
//
//
//        cell.textLabel.font = GetFont(13.0f);
//        return cell;
//    };
//    cellView.optionCellHeight = ^{
//
//        return 40.f;
//    };
//    cellView.rowNumber = ^(){
//
//        return (NSInteger)listArray.count;
//    };
//}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }
    return  self.dataSource.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    if (indexPath.section == 0) {
        return [UITableViewCell new];
    }
    
    ExpertPlansListTableViewCell *cell = [tableView dequeueReusableCell:[ExpertPlansListTableViewCell class]];
    cell.delegate = self;
    cell.cellType = 0;
    cell.model = [self.dataSource objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) return;
    
    ExpertPlansListTableViewCell *cell = (ExpertPlansListTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
    
    CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
    vc.planId = cell.model.planId.integerValue;
    [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return CGFLOAT_MIN;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return (kheadViewHight+kTitleBarHeight+kTitleBarListHeight+kMarginHeight);
    }
    return kswitchTabHight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return self.tableHeadView;
    }
    return self.muiltClickView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return self.importantArr.count?self.footerView.height:CGFLOAT_MIN;
    }
    if (section == 1 && !self.dataSource.count) {
        CGRect rect = [self.muiltClickView convertRect:self.muiltClickView.bounds toView:tableView];
        CGFloat difference = tableView.height - rect.origin.y - TabBarHeight;
        
        return (difference > 200.0)?difference:200.0;
    }
    return CGFLOAT_MIN;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == 0 && self.importantArr.count) {
        self.footerView.dataArray = self.importantArr.copy;
        return self.footerView;
    }
    if (section == 1 && !self.dataSource.count) {
        UIView *footer = [[UIView alloc] init];
        UIImageView *imageView = [UIImageView new];
        imageView.image = GetImage(@"no_data");
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        [footer addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(footer);
            make.size.mas_equalTo([UIImage sizeForNoDataImageWithWidth:tableView.width/2]);
        }];
        return footer;
    }
    
    return [UIView new];
}

#pragma mark 滑动隐藏bar处理
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    _offsetY = scrollView.contentOffset.y;
    
    if (_offsetY > 0) {
        self.plainTableView.contentInset = UIEdgeInsetsMake(kStatusBarHeight, 0, kBottomSafeArea, 0);
    }else {
        self.plainTableView.contentInset = kTableViewDetailtContentInset;
    }
    
    [self updateSwitchBar];
}

- (void)updateSwitchBar {

    CGFloat limitHeight = kheadViewHight + kTitleBarListHeight + kMarginHeight + (self.importantArr.count? kMatchBlockHeight:0.0) - kStatusBarHeight -10;
    CGFloat differenceHegiht =  _offsetY - limitHeight;
    
    CGFloat alpha = (differenceHegiht + kStatusBarHeight)/kStatusBarHeight;
    alpha = (alpha < 0)?0:alpha;
    alpha = (alpha >= 1)?1:alpha;
    
    WTCLog(@"scrollViewDidScroll = %.2f - %.2f - %.2f",_offsetY, differenceHegiht, alpha);
    
    self.barStyle = alpha?UIStatusBarStyleDefault:UIStatusBarStyleLightContent;
    
    self.barWindow.hidden = NO;
    self.barWindow.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:alpha];

    CGRect rect = [self.muiltClickView convertRect:self.muiltClickView.bounds toView:self.muiltClickView.window];
    CGFloat originY = rect.origin.y + rect.size.height;
    self.typeChooseView.frame = CGRectMake(0, originY, kScreen_Width, kScreen_Height - originY);
}

#pragma mark 轮播图代理
- (NSArray<ESBannerModel *> *)imagesInMainScrollView:(ESNewMainScrollView *)mainScrollView {
    NSMutableArray <ESBannerModel *>*banners = @[].mutableCopy;
    [self.banners enumerateObjectsUsingBlock:^(GallopBannerItemModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        ESBannerModel *model = [ESBannerModel new];
        model.img = obj.content;
        [banners addObject:model];
    }];
    return banners.copy;
}

- (void)mainScrollView:(ESNewMainScrollView *)mainScrollView atIndex:(NSInteger)index {
    GallopBannerItemModel *banner = [self.banners objectAtIndex:index];
    [self clickToBannerOrHeadlinesWithModel:banner withSource:@"飞驰Banner"];
}

- (void)segementSeletedChange:(NSInteger)index {
    
}

#pragma mark 按钮点击事件
- (void)moreExpert:(id)sender {
//    [CMMUtility showNote:@"更多专家"];
    
    WTCTabBarViewController *tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
    tabBarVC.selectedIndex = 1;
    ESNavigationViewController *navi = [tabBarVC.childViewControllers objectAtIndex:1];
    GallopExpertViewController *expertVC = navi.viewControllers.firstObject;
    expertVC.defaultIndex = self.currentBarIndex + 1;
}

-(void)allResultMatch{
    //跳转比赛赛果
    WTCTabBarViewController *tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
    tabBarVC.selectedIndex = 2;
    
    ESNavigationViewController *navi = tabBarVC.childViewControllers[2];
    MatchHomeViewController *matchVC = navi.viewControllers.firstObject;
    [matchVC switchViewControllerWithField:0];
}

#pragma mark HeadLineDelegate
- (void)parseClick:(GallopBannerItemModel *)model {
    [self clickToBannerOrHeadlinesWithModel:model withSource:@"飞驰头条"];
}

- (void)clickToBannerOrHeadlinesWithModel:(GallopBannerItemModel *)model withSource:(NSString *)source {
    if (QM_IS_STR_NIL(model.type)) {
        return;
    }
    /// NOT_LINKED：纯图
    if ([model.type isEqualToString:@"NOT_LINKED"]) {
        return;
    }else if ([model.type isEqualToString:@"URL"]) {
        /// 跳转网页
        if (![CommonUtils isEqualToNonNull:model.linkTo]) {
            return;
        }
        WTCContentViewController *vc = [WTCContentViewController new];
        vc.url = model.linkTo;
        vc.contentType = WTCContentTypeNav;
        [self.navigationController pushViewController:vc animated:YES];
    }else if ([model.type isEqualToString:@"ARTICLE"]) {
        if (![CommonUtils isEqualToNonNull:model.linkTo]) {
            return;
        }
        ESBanner *banner = [ESBanner mj_objectWithKeyValues:[model.linkTo mj_JSONObject]];
        /// 跳转文章
        PaperContentViewController *vc = [PaperContentViewController new];
        banner.textFormat = @"1";
        vc.banerModel = banner;
        [self.navigationController pushViewController:vc animated:YES];
    }else if ([model.type isEqualToString:@"APP_PAGE"]) {
        if ([model.businessType isEqualToString:@"POST"]) {
            /// 跳转帖子
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
            vc.postId = [[linkTo objectForKey:@"postId"] integerValue];
            [self.navigationController pushViewController:vc animated:YES];
        }else if ([model.businessType isEqualToString:@"PLAN"]) {
            /// 跳转方案详情
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
            vc.planId = [[linkTo objectForKey:@"planId"] integerValue];
            vc.sourcePage = source;
            [self.navigationController pushViewController:vc animated:YES];
        }else if ([model.businessType isEqualToString:@"EXPERT"]) {
            /// 专家主页
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            ExpertDetailViewController*vc = [ExpertDetailViewController new];
            vc.expertId = [linkTo objectForKey:@"expertId"];
            vc.sourcePage = source;
            vc.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
        }else if ([model.businessType isEqualToString:@"RECHARGE_PAGE"]) {
            //充值
            if (![App_Utility checkCurrentUser]) {
                [App_Utility showLoginViewController];
            }else{
                [self.navigationController pushViewController:[[PayViewController alloc] init] animated:YES];
            }
        }else if ([model.businessType isEqualToString:@"MATCH"]) {
            /// 比赛页面
            if (![CommonUtils isEqualToNonNull:model.linkTo]) {
                return;
            }
            NSDictionary *linkTo = [model.linkTo mj_JSONObject];
            NSString *field = [linkTo objectForKey:@"field"];
            if (![CommonUtils isEqualToNonNull:field]) {
                return;
            }
            if (![CommonUtils isEqualToNonNull:[linkTo objectForKey:@"matchId"]]) {
                return;
            }
            MatchDetailViewController *matchVC = [[MatchDetailViewController alloc] init];
            matchVC.field = field.integerValue;
            matchVC.matchId = [[linkTo objectForKey:@"matchId"] integerValue];
            matchVC.sourcePage = source;
            [self.navigationController pushViewController:matchVC animated:YES];
        }
    }
}

#pragma mark - ExpertPlansListTableCellDelegate
- (void)listCell:(ExpertPlansListTableViewCell *)listCell didClickToAvatar:(id)sender {
//    if (![App_Utility checkCurrentUser]) {
//        [App_Utility showLoginViewController];
//        return;
//    }
    ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",listCell.model.userId];
    vc.sourcePage = @"首页方案列表";
    [self.navigationController pushViewController:vc animated:YES];
}

//- (void)listCell:(ExpertPlansListTableViewCell *)listCell didClickToMatch:(MatchTag *)model {
//    [ESNetworkService getMatchId:model.matchId response:^(id dict, ESError *error) {
//        @strongify(self)
//        if (dict&&[dict[@"code"] integerValue] == 0) {
//            NSUInteger matchId = [dict[@"data"] integerValue];
//            dispatch_main_async_safe(^{
//                if (matchId == 0) {
//                    [[LPUnitily sharedManager] showToastWithText:@"暂无比赛信息"];
//                    return;
//                }
//            });
//        }
//    }];
//}

#pragma mark - CYHomeMatchFooterViewDelegate
- (void)footerView:(CYHomeMatchFooterView *)footerView didClickToMore:(id)sender {
    [self allResultMatch];
}

- (void)footerView:(CYHomeMatchFooterView *)footerView didClickToMatchItemWithModel:(HomeMatchResultModel *)model atIndexPath:(NSIndexPath *)indexPath {
    if (model.matchId <= 0) {
        return;
    }
    MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
//    liveVC.field = model.;

    liveVC.matchId = model.matchId;
    liveVC.sourcePage = @"首页推荐比赛";
    
    [self.navigationController pushViewController:liveVC animated:YES];
}

#pragma mark -
-(void)viewHide {
    self.iconImageUp = NO;
    switch (_changingType) {
        case 1:
        {
            [footballB setImage:[UIImage imageNamed:@"data_pulldown_red"] forState:UIControlStateNormal];
            footballB.imageView.contentMode = UIViewContentModeScaleAspectFit;
            CGFloat imageWidth = footballB.imageView.bounds.size.width;
            CGFloat labelWidth = footballB.titleLabel.bounds.size.width + 7;
            footballB.imageEdgeInsets = UIEdgeInsetsMake(5, labelWidth, 5, -labelWidth);
            footballB.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
        }
            break;
        case 2:
        {
            [basketballB setImage:[UIImage imageNamed:@"data_pulldown_red"] forState:UIControlStateNormal];
            basketballB.imageView.contentMode = UIViewContentModeScaleAspectFit;
            CGFloat imageWidth = basketballB.imageView.bounds.size.width;
            CGFloat labelWidth = basketballB.titleLabel.bounds.size.width + 7;
            basketballB.imageEdgeInsets = UIEdgeInsetsMake(5, labelWidth, 5, -labelWidth);
            basketballB.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
        }
            break;
        case 3:
        {
            [typeB setImage:[UIImage imageNamed:@"filter-filled"] forState:UIControlStateNormal];
            typeB.imageView.contentMode = UIViewContentModeScaleAspectFit;
            CGFloat imageWidth = typeB.imageView.bounds.size.width;
            CGFloat labelWidth = typeB.titleLabel.bounds.size.width + 7;
            typeB.imageEdgeInsets = UIEdgeInsetsMake(5, labelWidth, 5, -labelWidth);
            typeB.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
        }
            break;
            
        default:
            break;
    }
}
-(void)chooseTypeWithTypeStr:(NSString *)typeStr index:(NSInteger)index {
    
    [self.typeChooseView hidden];
    switch (_changingType) {
        case 1:
        {
            self.footballType = typeStr;
            if (index == 0) {
                [footballB setTitle:@"足球" forState:UIControlStateNormal];
                [footballB setTitleColor:ColorAppRed forState:UIControlStateNormal];
                
                
            }else{
                [footballB setTitle:self.footballType forState:UIControlStateNormal];
                [footballB setTitleColor:ColorAppRed forState:UIControlStateNormal];
            }
            
        }
            break;
        case 2:
        {
            self.basketballType = typeStr;
            if (index == 0) {
                [basketballB setTitle:@"篮球" forState:UIControlStateNormal];
                [basketballB setTitleColor:ColorAppRed forState:UIControlStateNormal];
            }else{
                [basketballB setTitle:self.basketballType forState:UIControlStateNormal];
                [basketballB setTitleColor:ColorAppRed forState:UIControlStateNormal];
            }
            
        }
            break;
        case 3:
        {
            self.planType = typeStr;
            if (index == 0) {
                [typeB setTitle:@"分类" forState:UIControlStateNormal];
                [typeB setTitleColor:ColorAppRed forState:UIControlStateNormal];
                
            }else{
                [typeB setTitle:self.planType forState:UIControlStateNormal];
                [typeB setTitleColor:ColorAppRed forState:UIControlStateNormal];
            }
            
        }
            break;
            
        default:
            break;
    }
//    [CMMUtility showNote:@"self.basketballType\nself.footballType\nself.planType\n更新数据"];
    
    [self loadPlanList:nil];
}

#pragma mark -
- (NSInteger)numberOfControllersInPagerController {
    return self.titleBarArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return self.titleBarArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return self.titleBarControllerArray[index];
}

- (void)pagerController:(TYTabPagerController *)pagerController didScrollToTabPageIndex:(NSInteger)index {
    NSLog(@"didScrollToTabPageIndex - %@",@(index));
    if (self.currentBarIndex != index) {
        self.currentBarIndex = index;
        _titleBarView.currentIndex = self.currentBarIndex;
    }
}

#pragma mark -
- (NSArray <HomeDaShenViewController *>*)getTitleControllerArray {
    NSMutableArray <HomeDaShenViewController *>*controllers = [NSMutableArray arrayWithCapacity:self.titleBarArray.count];
    
    for (int i = 0; i < self.titleBarArray.count; i ++) {
        HomeDaShenViewController *barController = [[HomeDaShenViewController alloc] init];
        barController.field = (i + 1);
        barController.hideBarSetting = YES;
        [controllers addObject:barController];
    }
    
    return controllers.copy;
}

//- (void)setCurrentBarIndex:(NSInteger)currentBarIndex {
//    _currentBarIndex = currentBarIndex;
////    self.field = [NSString stringWithFormat:@"%@",@(_currentBarIndex + 1)];
//}

#pragma mark - lazy init
- (TYTabButtonPagerController *)titleBarController {
    if (!_titleBarController) {
        _titleBarController = [[TYTabButtonPagerController alloc] init];
        _titleBarController.contentTopEdging = 0.0f;
        _titleBarController.delegate = self;
        _titleBarController.dataSource = self;
    }return _titleBarController;
}

- (CYTabTitleBar *)titleBarView {
    if (!_titleBarView) {
        _titleBarView = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([CYTabTitleBar class]) owner:self options:nil].lastObject;
        _titleBarView.frame = CGRectMake(0, 0, SCREEN_WIDTH, kTitleBarHeight);
        @weakify(self);
        _titleBarView.clickIndexBlock = ^(NSInteger index) {
            @strongify(self);
            if (self.currentBarIndex != index) {
                self.currentBarIndex = index;
                [self.titleBarController moveToControllerAtIndex:self.currentBarIndex animated:YES];
            }
        };
    } return _titleBarView;
}

- (UIView *)tableHeadView {
    if (!_tableHeadView) {
        _tableHeadView = [UIView new];
        _tableHeadView.backgroundColor = ColorDefaultGrayBackground;
        _tableHeadView.clipsToBounds = YES;
    }
    return _tableHeadView;
}


- (UIView*)muiltClickView
{
    if (!_muiltClickView) {
        _muiltClickView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, kswitchTabHight)];
        _muiltClickView.backgroundColor = [UIColor whiteColor];
    }
    return _muiltClickView;
}

- (NSMutableArray *)banners{
    if (!_banners) {
        _banners = [NSMutableArray array];
    }
    
    return _banners;
}

- (NSMutableArray *)dashens{
    if (!_dashens) {
        _dashens = [NSMutableArray array];
    }
    
    return _dashens;
}
- (NSMutableArray *)basketDashens{
    if (!_basketDashens) {
        _basketDashens = [NSMutableArray array];
    }
    
    return _basketDashens;
}

- (DiscoverHeadLineView *)headLineView {
    if (!_headLineView) {
        _headLineView = [[DiscoverHeadLineView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, kmiddleViewHight+kTitleBarHeight)];
        _headLineView.delegateVC = self;
    }
    return _headLineView;
}

- (TypeChooseView *)typeChooseView {
    if (!_typeChooseView) {
        _typeChooseView = [[TypeChooseView alloc] initWithView:self.view];
        _typeChooseView.delegate = self;
        _typeChooseView.hidden = YES;
    }
    return _typeChooseView;
}

- (CYHomeMatchFooterView *)footerView {
    if (!_footerView) {
        _footerView = [CYHomeMatchFooterView shareInstance];
        _footerView.frame = CGRectMake(0, 0, kScreen_Width, kMatchBlockHeight);
        _footerView.delegate = self;
    }return _footerView;
}

- (UIWindow *)barWindow {
    if (!_barWindow) {
        _barWindow = [[UIWindow alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, kStatusBarHeight)];
        _barWindow.backgroundColor = [UIColor.whiteColor colorWithAlphaComponent:0.0];
        _barWindow.windowLevel = UIWindowLevelAlert;
        _barWindow.hidden = NO;
    }return _barWindow;
}

@end



