//
//  PlanDetailViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlanDetailViewController : ESViewController
@property (nonatomic, assign) NSInteger planId;
@property (nonatomic,assign) BOOL back;
@property (nonatomic,assign) BOOL isBasket;//YES-篮球 NO-足球
@property (nonatomic, strong) NSString *sourcePage; //埋点用字段
@end

NS_ASSUME_NONNULL_END
