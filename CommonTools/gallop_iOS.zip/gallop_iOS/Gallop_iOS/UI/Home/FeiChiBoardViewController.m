//
//  FeiChiBoardViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/5.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "FeiChiBoardViewController.h"
#import "ProfitRankViewController.h"
#import "RedRankViewController.h"
#import "HitRankViewController.h"

#define kHHeight 35
#define kLHeight 4
#define kPageCount 3  //一页显示几个tag

@interface FeiChiBoardViewController ()<UIScrollViewDelegate>
{
    CGFloat _Hwidth;
    UIButton *_markButton;
    UIButton *allButton;
    UIViewController*_markController;
}
@property (nonatomic, strong) UIView *switchView;
@property (nonatomic, strong) UIScrollView *titleScrollView;
@property (nonatomic, strong) UIScrollView *mainScrollView;
@property (nonatomic,strong) ProfitRankViewController*profitVC;
@property (nonatomic,strong) RedRankViewController*redVC;
@property (nonatomic,strong) HitRankViewController*hitVC;

@end

@implementation FeiChiBoardViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self initWithSubViews];
    // Do any additional setup after loading the view.
}
- (void)initWithSubViews{
	self.navigationItem.titleView = self.switchView;
    _Hwidth=SCREEN_WIDTH/kPageCount;
    
    [self setupTitleScrollView];
    [self setupMainScrollView];
}
- (void)setupTitleScrollView
{
    NSArray *arr=@[@"7天返奖榜",@"连红榜",@"命中榜"];
    
    for (int i=0; i<[arr count]; i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame=CGRectMake(_Hwidth*i, 0, _Hwidth, kHHeight);
        button.tag=1000+i;
        [button setTitle:[arr objectAtIndex:i] forState:UIControlStateNormal];
        button.titleLabel.font=GetFont(14);
        [button setTitleColor:ColorTitle forState:UIControlStateNormal];
        [button addTarget:self action:@selector(changeView:) forControlEvents:UIControlEventTouchUpInside];
        [self.titleScrollView addSubview:button];
        if (i==0) {
            [button setTitleColor:ColorAppRed forState:UIControlStateNormal];
            allButton = button;
            
        }
    }
	
	UIView *seperatorLine = [[UIView alloc] initWithFrame:CGRectMake(0, kHHeight, SCREEN_WIDTH, 1)];
	seperatorLine.backgroundColor = RGBCOLOR(231, 231, 231);
	[self.titleScrollView addSubview:seperatorLine];
    
	//seletedLine
    UIView *lineView=[[UIView alloc] initWithFrame:CGRectMake(10, kHHeight, _Hwidth - 20, kLHeight)];
    lineView.backgroundColor=ColorAppRed;
	lineView.layer.cornerRadius = 2;
	lineView.clipsToBounds = YES;
    [self.titleScrollView addSubview:lineView];
    lineView.tag=1111;
}
- (void)setupMainScrollView
{
    self.profitVC = [[ProfitRankViewController alloc] init];
	self.redVC = [[RedRankViewController alloc] init];
	self.hitVC = [[HitRankViewController alloc] init];
	self.profitVC.field = self.field;
	self.redVC.field = self.field;
	self.hitVC.field = self.field;
    
    
    _profitVC.view.frame=CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - (NavBarHeight+kHHeight+kLHeight));
   
    _redVC.view.frame = CGRectMake(SCREEN_WIDTH, 0, SCREEN_WIDTH, SCREEN_HEIGHT - (NavBarHeight+kHHeight+kLHeight));

	_hitVC.view.frame=CGRectMake(SCREEN_WIDTH*2, 0, SCREEN_WIDTH, SCREEN_HEIGHT - (NavBarHeight+kHHeight+kLHeight));
    
    [self.mainScrollView addSubview:_profitVC.view];
    [self.mainScrollView addSubview:_redVC.view];
	[self.mainScrollView addSubview:_hitVC.view];
    
    [self addChildViewController:_profitVC];
    [self addChildViewController:_redVC];
	[self addChildViewController:_hitVC];
    
    _markController = _profitVC;
    
}

#pragma mark - action
//切换足球/篮球
- (void)swithBtnClick:(UIButton *)btn {
	if (btn.selected) {
		return;
	} else {
		btn.selected = YES;
	}
	self.field = @(btn.tag - 10000).stringValue;
	
	if ([self.field isEqualToString:(@"1")]) {
		//足球
		UIButton *btn = [self.switchView viewWithTag:10002];
		btn.selected = NO;
	} else {
		//篮球
		UIButton *btn = [self.switchView viewWithTag:10001];
		btn.selected = NO;
	}
	//刷新数据
	self.profitVC.field = self.field;
	self.redVC.field = self.field;
	self.hitVC.field = self.field;
	[self.redVC loadData];
	[self.profitVC loadData];
	[self.hitVC loadData];
}

//被划到的时候做什么
-(void)buttonDrag:(UIButton*)button
{
    //上一个点击的button做什么<要写在被点击的button上面,_markButton是上一个标记的>
    [self buttonUnclickState:_markButton];
    //被点击的button做什么
    [self buttonClickState:button];
    //改变mainScrollView的偏移量
    _mainScrollView.contentOffset=CGPointMake(SCREEN_WIDTH*(button.tag-1000), 0);
}
//被点击的button做什么事
- (void)buttonClickState:(UIButton *)button
{
    //这里不将第一个button的颜色变回未选中
    if (button.tag!=1000) {
        UIButton *button=(UIButton *)[_titleScrollView viewWithTag:1000];
        
        
        UIView *mView=[_titleScrollView viewWithTag:1000+100];
        [button setTitleColor:ColorTitle forState:UIControlStateNormal];
        mView.backgroundColor=[UIColor whiteColor];
    }
    //标记被点击的button
    _markButton=button;
    //变颜色
    [button setTitleColor:ColorAppRed forState:UIControlStateNormal];
    
    //找出划线的view
    UIView *lineView=[_titleScrollView viewWithTag:1111];
    [UIView animateWithDuration:0.2 animations:^{
        lineView.frame = CGRectMake((button.tag - 1000)*_Hwidth - 10, kHHeight, _Hwidth - 20, kLHeight);
    }];
	
	//埋点
	if (self.field.integerValue == 1) {
		[ESNetworkService customPostionCode:[NSString stringWithFormat:@"00200100400%@",@(button.tag - 999)]];
	} else {
		[ESNetworkService customPostionCode:[NSString stringWithFormat:@"00200200400%@",@(button.tag - 999)]];
	}
    
}
//上一个点击的button做什么
- (void)buttonUnclickState:(UIButton *)button
{
    [button setTitleColor:ColorTitle forState:UIControlStateNormal];
}
//button点击事件
- (void)changeView:(UIButton *)button
{
    //上一个点击的button做什么<要写在被点击的button上面,_markButton是上一个标记的>
    [self buttonUnclickState:_markButton];
    //被点击的button做什么
    
    [self buttonClickState:button];
    //改变mainScrollView的偏移量
    _mainScrollView.contentOffset=CGPointMake(SCREEN_WIDTH*(button.tag-1000), 0);
}
//没有减速状态会不执行(执行时只执行一次) "结束减速时"
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    //因为是2个ScrollView,所以这里需要判断一下到底是哪一个
    if (scrollView == _mainScrollView) {
        CGFloat offsetX = scrollView.contentOffset.x;
        //得出_ScrollView的偏移量,来判断用哪个button来执行它的方法
        [self changeButtonPostion:offsetX];
    }
}
- (void)changeButtonPostion:(CGFloat)offsetX
{
    if (offsetX<SCREEN_WIDTH/2) {//小于屏幕的一半 就用第一个button
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1000]];
    }else if(offsetX<SCREEN_WIDTH*3/2){//小于一个半屏幕 就用第二个button
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1001]];
    }else if (offsetX<SCREEN_WIDTH*5/2){//小于2个半屏幕 就用第三个button.....
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1002]];
    }else if (offsetX<SCREEN_WIDTH*7/2){
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1003]];
    }else if (offsetX<SCREEN_WIDTH*9/2){
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1004]];
    }else if (offsetX<SCREEN_WIDTH*11/2){
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1005]];
    }else if (offsetX<SCREEN_WIDTH*13/2){
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1006]];
    }else if (offsetX<SCREEN_WIDTH*15/2){
        [self buttonDrag:(UIButton *)[_titleScrollView viewWithTag:1007]];
    }
}
- (UIScrollView *)titleScrollView
{
    if (!_titleScrollView) {
        _titleScrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, NavBarHeight, SCREEN_WIDTH, kHHeight+kLHeight)];
        _titleScrollView.delegate=self;
        //隐藏2个滚动条
        //以下2个属性必须设成NO;<去掉滚动时候的滚动条,否则子视图中会多2个UIImageView>
        _titleScrollView.showsVerticalScrollIndicator=NO;
        _titleScrollView.showsHorizontalScrollIndicator=NO;
        _titleScrollView.backgroundColor = [UIColor whiteColor];
        _titleScrollView.contentSize=CGSizeMake(kPageCount*_Hwidth, kHHeight+kLHeight);
        _titleScrollView.bounces=NO;
        [self.view addSubview:_titleScrollView];
    }
    return _titleScrollView;
}
- (UIScrollView *)mainScrollView
{
    if (!_mainScrollView) {
        _mainScrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, NavBarHeight+kHHeight+kLHeight, SCREEN_WIDTH, SCREEN_HEIGHT - (NavBarHeight+kHHeight+kLHeight))];
        _mainScrollView.delegate=self;
        _mainScrollView.showsVerticalScrollIndicator=NO;
        _mainScrollView.showsHorizontalScrollIndicator=NO;
        _mainScrollView.contentSize=CGSizeMake(kPageCount*SCREEN_WIDTH, SCREEN_HEIGHT - (NavBarHeight+kHHeight+kLHeight));
        _mainScrollView.pagingEnabled=YES;
        [self.view addSubview:_mainScrollView];
    }
    return _mainScrollView;
}

- (UIView *)switchView {
	if (!_switchView) {
		_switchView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 150, 30)];
		UIButton *footBallBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 70, 30)];
		[footBallBtn setTitle:@"足球" forState:UIControlStateNormal];
		[footBallBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
		[footBallBtn setTitleColor:ColorAppBlack forState:UIControlStateNormal];
		[footBallBtn setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal];
		[footBallBtn setBackgroundImage:[UIImage imageWithColor:ColorAppRed] forState:UIControlStateSelected];
		footBallBtn.tag = 10001;
		footBallBtn.layer.cornerRadius = 14;
		footBallBtn.clipsToBounds = YES;
		footBallBtn.titleLabel.font = GetFont(15);
		[footBallBtn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		[_switchView addSubview:footBallBtn];
		
		UIButton *basketBtn = [[UIButton alloc] initWithFrame:CGRectMake(80, 0, 70, 30)];
		[basketBtn setTitle:@"篮球" forState:UIControlStateNormal];
		basketBtn.titleLabel.font = GetFont(15);
		[basketBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
		[basketBtn setTitleColor:ColorAppRed forState:UIControlStateNormal];
		[basketBtn setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal];
		[basketBtn setBackgroundImage:[UIImage imageWithColor:ColorAppRed] forState:UIControlStateSelected];
		basketBtn.tag = 10002;
		basketBtn.layer.cornerRadius = 14;
		basketBtn.clipsToBounds = YES;
		[basketBtn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		
		basketBtn.selected = self.field.intValue == 2;
		footBallBtn.selected = self.field.intValue == 1;
		[_switchView addSubview:basketBtn];
	}
	return _switchView;
}
@end
