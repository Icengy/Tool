//
//  ESContentNavigationView.m
//  ESTicket
//
//  Created by 王帅 on 16/3/11.
//  Copyright © 2016年 鹏 刘. All rights reserved.
//

#import "ESContentNavigationView.h"

@interface ESContentNavigationView ()

@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UILabel *titleLabel;

@end

@implementation ESContentNavigationView


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self setupView];
    }
    return self;
}

- (UIButton *)backButton
{
    if (!_backButton) {
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backButton setImage:[UIImage imageNamed:@"nav_return_black"] forState:UIControlStateNormal];
        [_backButton setImage:[UIImage imageNamed:@"nav_return_black"] forState:UIControlStateHighlighted];
        [_backButton setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, -8)];
		_backButton.contentMode = UIViewContentModeScaleAspectFit;
        [_backButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_backButton addTarget:self action:@selector(toBack:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_backButton];
    }
    return _backButton;
}

- (UIButton *)closeButton
{
    if (!_closeButton) {
        _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        [_closeButton setImage:[UIImage imageNamed:@"top_icon_close"] forState:UIControlStateNormal];
        [_closeButton setTitle:@"关闭" forState:UIControlStateNormal];
        [_closeButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _closeButton.titleLabel.font = GetFont(16.0f);
        [_closeButton addTarget:self action:@selector(toClose:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_closeButton];
    }
    return _closeButton;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [[UILabel alloc] init];
        _titleLabel.textColor = [UIColor blackColor];//[UIColor blackColor];
        _titleLabel.font = GetFont(18.0f);
        [self addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (void)setupView
{
    __weak ESContentNavigationView *weakSelf = self;
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.mas_left).offset(16);
        make.top.mas_equalTo(weakSelf.mas_top).offset(20);
        make.height.equalTo(@(22));
    }];
    [self.closeButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(_backButton.mas_right).offset(10);
        make.top.mas_equalTo(weakSelf.mas_top).offset(20);
        make.height.equalTo(@(NavBarHeight-20));
    }];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakSelf);
        make.top.mas_equalTo(weakSelf.mas_top).offset(20);
        make.height.equalTo(@(NavBarHeight-20));
        make.width.lessThanOrEqualTo(@((SCREEN_WIDTH/3 - 10)*kScreenRate));
    }];
}

- (void)setTitle:(NSString *)title
{
    _title = title;
    self.titleLabel.text = title;
}

- (void)setHiddenCloseButton:(BOOL)hiddenCloseButton
{
    _hiddenCloseButton = hiddenCloseButton;
    if (_hiddenCloseButton) {
        self.closeButton.hidden = YES;
    }else{
        self.closeButton.hidden = NO;
    }
}

- (void)setShowBackButton:(BOOL)showBackButton
{
    _showBackButton = showBackButton;
    if (_showBackButton) {
        self.backButton.hidden = NO;
    }else{
        self.backButton.hidden = YES;
    }
}

- (void)toBack:(UIButton *)button
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(toBackLastView)]) {
        [self.delegate toBackLastView];
    }
}

- (void)toClose:(UIButton *)button
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(toCloseCurrentView)]) {
        [self.delegate toCloseCurrentView];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
