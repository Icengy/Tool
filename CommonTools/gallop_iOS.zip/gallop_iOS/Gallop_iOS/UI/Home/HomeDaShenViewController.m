//
//  HomeDaShenViewController.m
//  Gallop_iOS
//
//  Created by lcy on 2021/5/20.
//  Copyright © 2021 homosum. All rights reserved.
//

#import "HomeDaShenViewController.h"

#import "HomeExpertCollectionViewCell.h"

#import "GallopExpertModel.h"

#import "ExpertDetailViewController.h"

@interface HomeDaShenViewController () <UICollectionViewDelegate, UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
/// 数据源
@property (nonatomic ,strong) NSMutableArray *dataArray;
@end

@implementation HomeDaShenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.dataArray = [NSMutableArray new];
    
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(SCREEN_WIDTH / 4 - 0.1, kTitleBarListHeight/2);
    layout.minimumLineSpacing = CGFLOAT_MIN;
    layout.minimumInteritemSpacing = CGFLOAT_MIN;

    self.collectionView.collectionViewLayout = layout;
    
    self.collectionView.backgroundColor = UIColor.whiteColor;
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    self.collectionView.scrollEnabled = NO;
    self.collectionView.bounces = NO;
    self.collectionView.bouncesZoom = NO;
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([HomeExpertCollectionViewCell class]) bundle:nil] forCellWithReuseIdentifier:NSStringFromClass([HomeExpertCollectionViewCell class])];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];
    
    if (!self.dataArray.count) {
        [self loadData:nil];
    }
}

#pragma mark UICollectionView代理
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return  self.dataArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    HomeExpertCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([HomeExpertCollectionViewCell class]) forIndexPath:indexPath];
    //热门大神
    cell.model = [self.dataArray objectAtIndex:indexPath.item];
    
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    [MobClick event:@"expert7"];
    GallopExpertModel *model = [self.dataArray objectAtIndex:indexPath.row];
     
    ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",@(model.expertId)];
    vc.sourcePage = (2 - self.field) ? @"足球大神" : @"篮球大神";
    vc.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -
- (void)loadData:(id _Nullable)sender {
    @weakify(self);
    [ESNetworkService getDaShenWithField:self.field Response:^(id dict, ESError *error) {
        WTCLog(@"%@",(self.field - 1)?@"loadBasketballDaShen":@"loadfootballDaShen");
        @strongify(self)
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id data = dict[@"data"];
            NSArray* dsList = [data objectForKey:@"doyenList"];
            if (self.dataArray.count) [self.dataArray removeAllObjects];
            if (dsList && dsList.count) {
                for (NSDictionary *dic in dsList) {
                    GallopExpertModel *model = [GallopExpertModel mj_objectWithKeyValues:dic];
                    [self.dataArray addObject:model];
                }
            }
        }
        [self.collectionView reloadData];
//        dispatch_main_async_safe(^{
//
//        });
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
