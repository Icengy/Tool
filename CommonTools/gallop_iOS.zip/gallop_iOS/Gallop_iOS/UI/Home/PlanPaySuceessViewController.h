//
//  PlanPaySuceessViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PlanPaySuceessViewController : ESViewController
@property (nonatomic,strong)NSString*pTitle;
@property (nonatomic,strong) NSString *avatar;
@property (nonatomic,strong) NSString *expertName;
@property (nonatomic,strong) NSString *price;
@property (nonatomic,strong) NSString *accountM;
@property (nonatomic,strong) NSNumber *planId;
-(void)refreshView;
@end

NS_ASSUME_NONNULL_END
