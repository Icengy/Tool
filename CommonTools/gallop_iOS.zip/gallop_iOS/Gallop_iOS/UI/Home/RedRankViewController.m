//
//  RedRankViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "RedRankViewController.h"
#import "BoardManager.h"
#import "YinLi.h"
#import "YinLiTableViewCell.h"
#import "ExpertDetailViewController.h"
@interface RedRankViewController ()<BoardManagerDelegate>
@property (nonatomic, strong) BoardManager *manager;

@end

@implementation RedRankViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self initWithSubViews];
	// Do any additional setup after loading the view.
}
-(void)BoardManager:(BoardManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
	dispatch_main_async_safe(^{
		[self.tableView.mj_header endRefreshing];
		[self.tableView.mj_footer endRefreshing];
		
		if (self.manager.dataSource.count == 0) {
		}
		
		if (!isRefresh && self.manager.dataSource.count >= 20) {
			self.tableView.mj_footer.hidden = NO;
		}else{
			self.tableView.mj_footer.hidden = YES;
		}
		
		[self.tableView reloadData];
	});
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.manager.dataSource.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	RedRank*model = self.manager.dataSource[indexPath.row];
	NSString *identifier=@"YinLiTableViewCell";
	YinLiTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
	cell.selectionStyle = UITableViewCellSelectionStyleDefault;
	if (cell==nil) {
		cell= [[[NSBundle mainBundle]loadNibNamed:@"YinLiTableViewCell" owner:nil options:nil] firstObject];
		
	}
	[cell configCell:model index:indexPath.row];
	
	return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	YinLi*model = self.manager.dataSource[indexPath.row];
	ExpertDetailViewController*vc = [ExpertDetailViewController new];
	vc.sourcePage = @"飞驰榜-15天返奖";
    vc.expertId = [NSString stringWithFormat:@"%@",model.userId];
	[self.navigationController pushViewController:vc animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 55.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	return 0.01f;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 0.01f;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	return nil;
}

-(void)initWithSubViews
{
	self.navigationItem.title = @"3日返奖";
	self.tableView.frame = CGRectMake(0, 0, kScreen_Width, kScreen_Height-NavBarHeight-40);
	self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
	self.tableView.separatorColor = ColorGrayBack;
	if (@available(iOS 11.0, *)){
		self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
	}
	[self.tableView registerNib:[UINib nibWithNibName:@"YinLiTableViewCell" bundle:nil] forCellReuseIdentifier:@"YinLiTableViewCell"];
	[self.view addSubview:self.tableView];
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self loadData];
}

- (void)loadData{
	self.manager.field = self.field;
	[self.manager refreshData];
}

- (void)loadMoreData{
	[self.manager loadData];
}

- (BoardManager *)manager{
	if (!_manager) {
		_manager = [[BoardManager alloc]init];
		_manager.rank = @"CONTINUERED";
		_manager.delegate = self;
	}
	
	return _manager;
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	//    [AVAnalytics beginLogPageView:self.title];
	//    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
	//    self.navigationController.navigationBarHidden = NO;
	//    [AVAnalytics endLogPageView:self.title];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
