//
//  ExpertDetailViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/14.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ExpertDetailViewController.h"

#import "CYPlanDetailViewController.h"
#import "FootBallExpertDetailController.h"
#import "BaketExpertDetailController.h"

#import "LeagueCountViewController.h"

#import "ExpertDetail.h"
#import "PlanModel.h"
//分享
#import "ESShareViewController.h"
#import "NavButton.h"

#import "ExpertDetailHeaderView.h"
#import "ExpertDetailRecordTableViewCell.h"
#import "ExpertDetailStatisticsTableViewCell.h"
#import "ExpertDetailHistoryPlanTableViewCell.h"

#import "CYCommonListHeaderView.h"
#import "UIBarButtonItem+CreateExt.h"

@interface ExpertDetailViewController () <ExpertDetailHeaderDelegate>
/**导航条**/
@property (nonatomic,strong) UILabel*labelL;
@property (nonatomic,strong) CYButton*followB;
@property (nonatomic,strong) CYButton*backB;
@property (nonatomic,strong) CYButton*shareB;

@property (nonatomic, copy) NSDictionary *expertData;
//@property (nonatomic, strong) PersonManager *manager;
@property (nonatomic ,strong) NSMutableArray <PlanModel *>*dataArray;
@property (nonatomic, strong) ExpertPrize *prizeModel;
@property (nonatomic, strong) ExpertLeagueCountModel *leagueCountModel;

@property (nonatomic, strong) NSString *field;

@property (nonatomic ,assign) CGFloat offsetY;

@property (nonatomic ,strong) ExpertDetailHeaderView *headView;

@end

@implementation ExpertDetailViewController {
    int _page;
    CGFloat _introHeight, _headerViewHeight;
    NSArray *_transitionArray;
}

- (void)viewDidLoad {
	[super viewDidLoad];
    
//	self.field = self.isBasket ? @"2" : @"1";
    self.offsetY = 0;
    _page = 1;
    self.dataArray = [NSMutableArray new];
    _introHeight = 40.0;
    _headerViewHeight = kNavBarHeight + 16*2 + 25 + kScreen_Width *(60.0/375) + 40.0*2;
	
	[self setupViews];
    
	__weak __typeof(self)weakSelf = self;
	[[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification  object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf loadTotalData:nil];
	}];
	
	[MobClick event:@"expert9" attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage}];
    
    [self loadTotalData:nil];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleImageContent;
    //设置导航栏背景图片为一个空的image，这样就透明了
    [self showNavi];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

-(void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setupViews {

	[self navLayout];
    [self tableViewLayout];
    
    [self.view addSubview:self.tableView];

    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.equalTo(self.view);
        make.top.equalTo(self.view).offset(0);
    }];
}

-(void)navLayout {
    
    self.navigationItem.titleView = self.labelL;
    
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem createBackBarItemWithImage:@"expert_detail_back" withHightImg:nil target:self action:@selector(back)];
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem createPostionBarItemWithImage:@"expert_detail_share" withHightImg:nil horizontalAlignment:(CYBarButtonItemPositionRight) target:self action:@selector(share)];
}


- (void)tableViewLayout {
//    self.tableView.tableFooterView = [UIView new];
//    self.tableView.pagingEnabled = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = UIColor.clearColor;
    self.tableView.contentInset = kTableViewDetailtContentInset;

    [self.tableView registerNibCell:[ExpertDetailRecordTableViewCell class]];
    [self.tableView registerNibCell:[ExpertDetailStatisticsTableViewCell class]];
    [self.tableView registerNibCell:[ExpertDetailHistoryPlanTableViewCell class]];
    
    if (@available(iOS 11.0, *)) {
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    
    [self.tableView addRefreshHeaderWithTarget:self textColor:UIColor.whiteColor action:@selector(loadTotalData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadTotalData:)];
    
    /// 背景图
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImageView *bgView = [[UIImageView alloc] initWithFrame:CGRectOffset(self.tableView.bounds, 0, -self.tableView.bounds.size.height)];
        bgView.contentMode = UIViewContentModeScaleAspectFill;
        bgView.image = [[UIImage imageNamed:@"head_bg_single"] resizableImageWithCapInsets:UIEdgeInsetsZero];
        [self.tableView insertSubview:bgView atIndex:0];
    });
}


#pragma mark - data
- (void)loadTotalData:(id)sender {
    [ES_HttpService showLoading:!sender];
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        _page ++;
    }else {
        _page = 1;
    }
    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    dispatch_group_t group = dispatch_group_create();
    
    if (![sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        dispatch_group_enter(group);
        [ESNetworkService expertViewWithoutHUDWithExpertId:self.expertId.integerValue Response:^(id dict, ESError *error) {
    
            if (dict && [dict[@"code"] integerValue] == 0) {
                self.expertData = [dict objectForKey:@"data"];
                NSDictionary*info = [self.expertData objectForKey:@"info"];
                NSDictionary *expertBase = [info objectForKey:@"expertBase"];
                self.field = [expertBase objectForKey:@"field"];
                
                if (![sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
                    dispatch_group_async(group, queue, ^{
                        [self loadLeagueCount:sender withGroup:group];
                    });
                }
                dispatch_group_async(group, queue, ^{
                    [self loadData:sender withGroup:group];
                });
            }
            dispatch_group_leave(group);
        }];
    }else {
        dispatch_group_async(group, queue, ^{
            [self loadData:sender withGroup:group];
        });
    }

    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
//        dispatch_main_async_safe(^{
        WTCLog(@"expertDetailController dispatch_group_notify");
        [self endAllFreshing:self.tableView];
    
        BOOL isSubscribed = [[self.expertData objectForKey:@"isSubscribed"] boolValue];
        self.followB.selected = isSubscribed;
        
        //专家信息
        NSDictionary*info = [self.expertData objectForKey:@"info"];
        ExpertDetail *detailModel = [ExpertDetail mj_objectWithKeyValues:info[@"expertBase"]];
        self.labelL.text  = [CommonUtils isEqualToNonNull:detailModel.expertName replace:@"专家号"];
        [self.labelL sizeToFit];
        if (self.labelL.width > (SCREEN_WIDTH - 200)) {
            self.labelL.width = SCREEN_WIDTH - 200;
        }
        
        self.headView.data = self.expertData;
        
        //专家战绩
        if (self.field.integerValue == 1) {
            /// 足球
            self.prizeModel = [ExpertPrize mj_objectWithKeyValues:[info objectForKey:@"footballPrize"]];
            self.prizeModel.sevenRedList = [self.prizeModel.sevenRedList reverseObjectEnumerator].allObjects;
        }else {
            
            self.prizeModel = [ExpertPrize mj_objectWithKeyValues:[info objectForKey:@"basketballPrize"]];
            self.prizeModel.sevenRedList = [self.prizeModel.sevenRedList reverseObjectEnumerator].allObjects;
        }
        
        [self.tableView updataFreshFooter:(self.dataArray.count && _transitionArray.count < 20)];
        self.tableView.mj_footer.hidden = !_dataArray.count;

        [self.tableView reloadData];
    });
}

/// 获取列表信息
- (void)loadData:(id)sender withGroup:(dispatch_group_t)group {
    WTCLog(@"expertDetailController loadData");
    dispatch_group_enter(group);
    [ESNetworkService expertPlanListWithHUD:NO
                                   withPage:_page
                                   PageSize:20
                                      Field:self.field
                                       Type:@""
                                   ExpertId:self.expertId.integerValue
                                  ForExpert:0
                                   Response:^(id dict, ESError *error) {
        
        if (dict && [dict[@"code"] integerValue] == 0) {
            id da = dict[@"data"];
            id data = da[@"data"];
            if ([data isKindOfClass:[NSString class]]) {
                _transitionArray = [data objectFromJSONString];
            }
            if ([data isKindOfClass:[NSArray class]]) {
                _transitionArray = data;
            }
            
            if (_page == 1) {
                [self.dataArray removeAllObjects];
            }
            
            for (NSDictionary *dic in _transitionArray) {
                PlanModel *model = [PlanModel mj_objectWithKeyValues:dic];
                NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
                NSArray*matchInfo = [[dic objectForKey:@"matchInfo"] objectFromJSONString];
                for (NSDictionary*dic_info in matchInfo) {
                    MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
                    [arrM addObject:tag];
                }
                model.matchInfoArr = [arrM copy];
                [self.dataArray addObject:model];
            }
        }
        WTCLog(@"expertDetailController loadData leave");
        dispatch_group_leave(group);
    }];
}

-(void)loadLeagueCount:(id)sender withGroup:(dispatch_group_t)group {
    WTCLog(@"expertDetailController loadLeagueCount");
    //获取联赛统计
    dispatch_group_enter(group);
//    @weakify(self);
    [ESNetworkService expertLeagueCountWithHUD:NO
                                  withExpertId:self.expertId.integerValue
                                         field:self.field.integerValue
                                          page:1
                                      pageSize:3
                                      Response:^(id dict, ESError *error) {
//        @strongify(self);
        if (dict&&[dict[@"code"] integerValue] == 0) {
            self.leagueCountModel = [ExpertLeagueCountModel mj_objectWithKeyValues:[dict objectForKey:@"data"]];
        }
        WTCLog(@"expertDetailController loadLeagueCount leave");
        dispatch_group_leave(group);
    }];
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.leagueCountModel.expertLeagueList.count?4:3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 0;
    }else if (section == 1) {
        return 1;
    } else {
        if (section == 2 && self.leagueCountModel.expertLeagueList.count) {
            return (self.leagueCountModel.expertLeagueList.count < 3)?self.leagueCountModel.expertLeagueList.count:3;
        }
        return  self.dataArray.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return [UITableViewCell new];
    }else if (indexPath.section == 1) {
        //战绩统计
        ExpertDetailRecordTableViewCell *recordCell = [tableView dequeueReusableCell:[ExpertDetailRecordTableViewCell class]];
        recordCell.model = self.prizeModel;
        return recordCell;
    }else {
        if (indexPath.section == 2 && self.leagueCountModel.expertLeagueList.count) {
            //联赛统计
            ExpertDetailStatisticsTableViewCell *cell = [tableView dequeueReusableCell:[ExpertDetailStatisticsTableViewCell class]];
            cell.indexPath = indexPath;
            if (self.leagueCountModel.expertLeagueList.count) {
                cell.model = [self.leagueCountModel.expertLeagueList objectAtIndex:indexPath.row];
            }
            return cell;
        }
        /// 历史解读
        ExpertDetailHistoryPlanTableViewCell *cell = [tableView dequeueReusableCell:[ExpertDetailHistoryPlanTableViewCell class]];
        cell.cellType = 1;
        cell.separatedLine.hidden = (indexPath.row == self.dataArray.count - 1)?YES:NO;
        if (self.dataArray.count) {
            cell.model = [self.dataArray objectAtIndex:indexPath.row];
        }
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([[tableView cellForRowAtIndexPath:indexPath] isKindOfClass:[ExpertDetailHistoryPlanTableViewCell class]]) {
        if (indexPath.row >= self.dataArray.count) return;
        PlanModel *model  = self.dataArray[indexPath.row];
        CYPlanDetailViewController *vc = [CYPlanDetailViewController new];
        vc.back = YES;
        vc.planId = [model.planId integerValue];
        vc.sourcePage = @"专家主页页面";
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (!QM_IS_ARRAY_NIL(self.leagueCountModel.expertLeagueList) && indexPath.section == 2) {
        return 40.0;
    }
    return UITableViewAutomaticDimension;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return UITableViewAutomaticDimension;
    }
    return 40.0;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        UIView *wrapView = [UIView new];
        [wrapView addSubview:self.headView];
        [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.offset(0);
        }];
        return wrapView;
    }
    NSArray *titleArr = @[@"战绩统计",@"联赛统计",@"历史解读"];
    if (QM_IS_ARRAY_NIL(self.leagueCountModel.expertLeagueList) && section == 2) {
        titleArr = @[@"战绩统计", @"历史解读"];
    }
    
    CYCommonListHeaderView *header = [CYCommonListHeaderView shareInstance];
    header.frame = CGRectMake(0, 0, tableView.width, 40);
    header.titleLabel.text = [titleArr objectAtIndex:section - 1];
    
    if (section == 1) {
        [header setCorner:UIRectCornerTopRight | UIRectCornerTopLeft withRadiu:8.0];
    }else if (section == 2) {
        if (!QM_IS_ARRAY_NIL(self.leagueCountModel.expertLeagueList)) {
            CYReverseButton *moreBtn = (CYReverseButton *)[CYReverseButton buttonWithType:UIButtonTypeCustom]
            .titlePrams(@"更多",
                        [UIFont addPingFangSCRegular:13.0],
                        RGBCOLORV(0xA8A8A8),
                        UIControlStateNormal)
            .imagePrams(GetImage(@"expert_detail_more"),
                        UIControlStateNormal)
            .actionPrams(self,
                         @selector(moreBtnClick),
                         UIControlEventTouchUpInside);
            [header.contentView addSubview:moreBtn];
            [moreBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.left.lessThanOrEqualTo(header.titleLabel.mas_right).offset(8.0);
                make.right.equalTo(header.contentView).offset(-15.0);
                make.height.centerY.equalTo(header.contentView);
                make.width.equalTo(moreBtn.mas_height).multipliedBy(1.5);
            }];
        }
    }
    return header;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return CGFLOAT_MIN;
    }
    if (section == ([tableView numberOfSections] - 1)) {
        return self.dataArray.count?CGFLOAT_MIN:200.0;
    }
    return 10;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section == 0) {
        return [UIView new];
    }
    if (section == ([tableView numberOfSections] - 1)) {
        if (!self.dataArray.count) {
            UIView *footer = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 200.0)];
            UIImageView *imageView = [UIImageView new];
            imageView.image = GetImage(@"no_data");
            imageView.contentMode = UIViewContentModeScaleAspectFit;
            [footer addSubview:imageView];
            [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.center.equalTo(footer);
                make.size.mas_equalTo(CGSizeMake(200, 200));
            }];
            return footer;
        }
        return [UIView new];
    }
    UIView *wrapView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.width, 10)];
    wrapView.backgroundColor = ColorDefaultGrayBackground;
    return wrapView;
}

#pragma mark - scorllerDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    self.offsetY = scrollView.contentOffset.y;
    [self showNavi];
}

- (void)showNavi {
    CGFloat alpha = self.offsetY /  NavBarHeight;

    self.labelL.alpha = alpha;
    self.followB.alpha = alpha;
    self.labelL.hidden = (alpha > 1)?NO:YES;
    self.followB.hidden = (alpha > 1)?NO:YES;
    
    self.navigationController.navigationBar.translucent = (alpha >= 1.0f) ? NO : YES;
    UIImage *image = [UIImage imageNamed:@"head_bg_single"];
    [self.navigationController.navigationBar setBackgroundImage:[UIImage changeAlphaOfImageWith:alpha withImage:image] forBarMetrics:UIBarMetricsDefault];
}


#pragma mark - ExpertDetailHeaderDelegate
- (void)headerView:(ExpertDetailHeaderView *)cell didClickToFollow:(NSInteger)state withBtns:(NSArray<UIButton *> *)btns {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    @weakify(self);
    if ([CommonUtils isEqualToNonNull:self.expertId]) {
        if (state) {
            /// 取关
            [ESNetworkService unfollowExpert:self.expertId.integerValue  Response:^(id dict, ESError *error) {
                @strongify(self);
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        self.followB.selected = NO;
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }else{
            /// 关注
            [ESNetworkService followExpert:self.expertId.integerValue  Response:^(id dict, ESError *error) {
                if (dict&&[dict[@"code"] integerValue] == 0) {
                    dispatch_main_async_safe(^{
                        self.followB.selected = YES;
                        [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                            obj.hidden = !obj.hidden;
                        }];
                    });
                }
            }];
        }
    }
}

- (void)headerView:(ExpertDetailHeaderView *)cell didClickToWarning:(NSInteger)state withBtns:(NSArray<UIButton *> *)btns {
    if (![App_Utility checkCurrentUser]) {
        [App_Utility showLoginViewController];
        return;
    }
    [ESNetworkService ocWithExpertId:[self.expertId integerValue]
                        andOpenClose:!state
                            Response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            dispatch_main_async_safe(^{
                [btns enumerateObjectsUsingBlock:^(UIButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    obj.hidden = !obj.hidden;
                }];
            });
            
        }
    }];
}


#pragma mark - action
-(void)back{
	[self.navigationController popViewControllerAnimated:YES];
}
-(void)share{
    [ESNetworkService expertIdShareWithExpertId:self.expertId Field:self.field Response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            //分享出去
            NSDictionary*model = dict[@"data"];
            [self shareWithModel:model];
        }
    }];
}
- (void)moreBtnClick {
    //跳转更多联赛战绩
    LeagueCountViewController *vc = [[LeagueCountViewController alloc] init];
    vc.expertId = self.expertId.integerValue;
    vc.field = self.field.integerValue;
    [self.navigationController pushViewController:vc animated:YES];
}
#pragma mark - 微信分享
- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

- (void)follow:(UIButton *)button {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
    button.selected = !button.selected;
    @weakify(self);
	if (self.expertId) {
		if (!button.selected) {
            /// 取关
			[ESNetworkService unfollowExpert:self.expertId.integerValue  Response:^(id dict, ESError *error) {
                @strongify(self);
				if (dict&&[dict[@"code"] integerValue] == 0) {
					dispatch_main_async_safe(^{
                        self.followB.selected = NO;
                        [self.headView changeFollowState:NO];
					});
				}
			}];
		}else{
            /// 关注
			[ESNetworkService followExpert:self.expertId.integerValue  Response:^(id dict, ESError *error) {
				if (dict&&[dict[@"code"] integerValue] == 0) {
					dispatch_main_async_safe(^{
                        self.followB.selected = YES;
                        [self.headView changeFollowState:YES];
					});
				}
			}];
		}
	}
}
#pragma mark - lazy init
-(UILabel*)labelL
{
	if (!_labelL) {
		_labelL = [UILabel new];
		_labelL.textColor = UIColor.whiteColor;
		_labelL.font = [UIFont addPingFangSCRegular:15];
        _labelL.text = @"专家名";
        _labelL.hidden = YES;
//        _labelL.frame = CGRectMake(0, 0, 80, 30);
	}
	return _labelL;
}
-(CYButton*)followB
{
    if(!_followB){
        _followB = [CYButton buttonWithType:UIButtonTypeCustom];
        _followB.frame = CGRectMake(0, 0, 50, 44);
        
        [_followB setTitle:@"+ 关注" forState:UIControlStateNormal];
        [_followB setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
        [_followB setTitle:@"已关注" forState:UIControlStateSelected];
        [_followB setTitleColor:UIColor.whiteColor forState:UIControlStateSelected];
        _followB.titleLabel.font = [UIFont addPingFangSCBold:13];
        
        _followB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [_followB addTarget:self action:@selector(follow:) forControlEvents:UIControlEventTouchUpInside];
        _followB.hidden = YES;
    }
    return _followB;
}

-(CYButton*)backB {
	if(!_backB){
		_backB = [CYButton buttonWithType:UIButtonTypeCustom];
        _backB.frame = CGRectMake(0, 0, 44, 44);
        [_backB setImage:[[UIImage imageNamed:@"expert_detail_back"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _backB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_backB addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
	}
	return _backB;
}

-(CYButton*)shareB {
    if(!_shareB){
        _shareB = [CYButton buttonWithType:UIButtonTypeCustom];
        _shareB.frame = CGRectMake(0, 0, 44, 44);
        [_shareB setImage:[[UIImage imageNamed:@"expert_detail_share"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _shareB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [_shareB addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
    }
    return _shareB;
}

- (ExpertDetailHeaderView *)headView {
    if (!_headView) {
        _headView = [ExpertDetailHeaderView shareInstance];
        _headView.delegate = self;
    }return _headView;
}

@end
