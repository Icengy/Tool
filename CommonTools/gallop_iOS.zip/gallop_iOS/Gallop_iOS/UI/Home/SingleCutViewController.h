//
//  SingleCutViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface SingleCutViewController : ESViewController
@property (nonatomic,strong) NSString *field;
@end
