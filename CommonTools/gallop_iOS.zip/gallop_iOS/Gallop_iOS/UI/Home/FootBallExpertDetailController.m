//
//  FootBallExpertDetailController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/12/30.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "FootBallExpertDetailController.h"
#import "CYPlanDetailViewController.h"
#import "LeagueCountViewController.h"
#import "ExpertDetailTableViewCell.h"

#import "PersonManager.h"
#import "ExpertDetail.h"

#import "NavButton.h"
#import "ExpertZhanjiCell.h"
#import "ExpertLeagueCountCell.h"

#define kExpertZhanjiCellIdentifier @"kExpertZhanjiCellIdentifier"
#define kExpertLeagueCountCellIdentifier @"kExpertLeagueCountCellIdentifier"
#define kExpertDetailTableViewCellIdentifier @"kExpertDetailTableViewCellIdentifier"

@interface FootBallExpertDetailController ()<PersonManagerDelegate>
@property (nonatomic, strong) PersonManager *manager;
@property (nonatomic, strong) ExpertPrize *prizeModel;
@property (nonatomic, strong) ExpertLeagueCountModel *leagueCountModel;

@end

@implementation FootBallExpertDetailController
- (void)viewWillAppear:(BOOL)animated{
	[super viewWillAppear:animated];
}
- (void)viewWillDisappear:(BOOL)animated{
	[super viewWillDisappear:animated];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupViews];
	[self loadData];
}

-(void)dealloc
{
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setupViews {
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.top.bottom.equalTo(self.view);
	}];
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	[self.tableView registerClass:[ExpertZhanjiCell class] forCellReuseIdentifier:kExpertZhanjiCellIdentifier];
	[self.tableView registerClass:[ExpertLeagueCountCell class] forCellReuseIdentifier:kExpertLeagueCountCellIdentifier];
	[self.tableView registerClass:[ExpertDetailTableViewCell class] forCellReuseIdentifier:kExpertDetailTableViewCellIdentifier];
	
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
}

#pragma mark - data && manager
//加载战绩信息
- (void)loadZhanjiWithModel:(ExpertPrize *)model {
	self.prizeModel = model;
	[self.tableView reloadData];
}

-(PersonManager*)manager
{
	if (!_manager) {
		_manager = [PersonManager new];
		_manager.expertId = self.expertId;
		_manager.forExpert = 0;
		_manager.delegate = self;
	}
	return _manager;
}

-(void)PersonManager:(PersonManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload
{
	
	dispatch_main_async_safe(^{
		[self.tableView.mj_header endRefreshing];
		[self.tableView.mj_footer endRefreshing];
		
		if (self.manager.dataSource.count == 0) {
		}
		
		if (!isRefresh && self.manager.dataSource.count >= 20) {
			self.tableView.mj_footer.hidden = NO;
		}else{
			self.tableView.mj_footer.hidden = YES;
		}
		
		[self.tableView reloadData];
		
	});
}

-(void)loadData {
	[self.manager refreshDataWithType:@"" andField:@"1"];
	[self loadLeagueCount];
}

-(void)loadMoreData{
	[self.manager loadDataWithType:@"" andField:@"1"];
}

-(void)loadLeagueCount {
	//获取联赛统计
	[ESNetworkService expertLeagueCountWithExpertId:self.expertId.integerValue field:1 page:1 pageSize:3 Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				self.leagueCountModel = [ExpertLeagueCountModel mj_objectWithKeyValues:dict[@"data"]];
				[self.tableView reloadData];
			});
		}
	}];
}

#pragma mark - action
- (void)moreBtnClick {
	//跳转更多联赛战绩
	LeagueCountViewController *vc = [[LeagueCountViewController alloc] init];
	vc.expertId = self.expertId.integerValue;
	vc.field = 1;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark tableView代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (section == 0) {
		return 1;
	} else if (section == 1) {
		if (self.leagueCountModel.expertLeagueList.count > 3) {
			return 3;
		} else {
			return self.leagueCountModel.expertLeagueList.count;
		}
	} else {
		if (QM_IS_ARRAY_NIL(self.manager.dataSource)) {
			self.tableView.placeHolderText = @"暂无内容";
			[self.tableView addSubview:self.tableView.placeHolderView];
			[self.tableView addSubview:self.tableView.placeHolderLabel];
			//调整布局
			[self.tableView.placeHolderView mas_makeConstraints:^(MASConstraintMaker *make) {
				make.centerX.equalTo(self.tableView);
				make.centerY.equalTo(self.tableView).offset(40);
				make.size.mas_equalTo(CGSizeMake(70, 70));
			}];
			[self.tableView.placeHolderLabel mas_makeConstraints:^(MASConstraintMaker *make) {
				make.centerX.equalTo(self.tableView);
				make.top.equalTo(self.tableView.placeHolderView.mas_bottom).offset(5);
				make.width.mas_equalTo(SCREEN_WIDTH - 50);
			}];
		} else {
			[self.tableView.placeHolderLabel removeFromSuperview];
			[self.tableView.placeHolderView removeFromSuperview];
		}
		return  self.manager.dataSource.count;
	}
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		//战绩统计
		ExpertZhanjiCell *cell = [tableView dequeueReusableCellWithIdentifier:kExpertZhanjiCellIdentifier];
		[cell configCellWithModel:self.prizeModel];
		return cell;
	} else if (indexPath.section == 1) {
		//联赛统计
		ExpertLeagueCountCell *cell = [tableView dequeueReusableCellWithIdentifier:kExpertLeagueCountCellIdentifier];
		[cell configCellWithModel:self.leagueCountModel.expertLeagueList[indexPath.row] row:indexPath.row];
		return cell;
	} else {
		PlanModel*model  = self.manager.dataSource[indexPath.row];
		ExpertDetailTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:kExpertDetailTableViewCellIdentifier];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		cell.model = model;
		return cell;
	}
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 2) {
		PlanModel*model  = self.manager.dataSource[indexPath.row];
        CYPlanDetailViewController*vc = [CYPlanDetailViewController new];
		vc.back = YES;
		vc.planId = [model.planId integerValue];
		vc.sourcePage = @"专家主页页面";
//		vc.hidesBottomBarWhenPushed = YES;
//        vc.isBasket = (model.field.integerValue == 2);
		[self.navigationController pushViewController:vc animated:YES];
	}
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		return 105;
	} else if (indexPath.section == 1) {
		return 35;
	} else {
		tableView.rowHeight = UITableViewAutomaticDimension;
		tableView.estimatedRowHeight = 150;
		return tableView.rowHeight;
	}
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	if (QM_IS_ARRAY_NIL(self.leagueCountModel.expertLeagueList) && section == 1) {
		return 0.01;
	}
	return 35;
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if (QM_IS_ARRAY_NIL(self.leagueCountModel.expertLeagueList) && section == 1) {
		return nil;
	}
	
	UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
	UILabel*label = [UILabel new];
	[view addSubview:label];
	view.backgroundColor = RGBCOLOR(244, 244, 244);
	[label mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(view).offset(15);
		make.centerY.mas_equalTo(view);
	}];
	[label sizeToFit];
	label.textColor = ColorAppBlack;
	label.font = fcFont(14);
	NSArray *titleArr = @[@"战绩统计",@"联赛统计",@"历史解读"];
	label.text  = titleArr[section];
	
	if (section == 1) {
		//联赛统计
		UIButton *btn = [UIButton new];
		[btn setImage:GetImage(@"scheme_detail_arrow_icon") forState:UIControlStateNormal];
		[btn setTitle:@"更多联赛战绩" forState:UIControlStateNormal];
		btn.titleLabel.font = fcFont(13);
		[btn setTitleColor:RGBCOLOR(58, 58, 58) forState:UIControlStateNormal];
		[btn addTarget:self action:@selector(moreBtnClick) forControlEvents:UIControlEventTouchUpInside];
		btn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[view addSubview:btn];
		[btn mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.equalTo(view).offset(-15);
			make.centerY.equalTo(view);
			make.height.mas_equalTo(19);
		}];
		
		CGFloat imageWidth = btn.imageView.bounds.size.width;
		CGFloat labelWidth = btn.titleLabel.bounds.size.width;
		btn.imageEdgeInsets = UIEdgeInsetsMake(3.5, labelWidth, 3.5, -labelWidth);
		btn.titleEdgeInsets = UIEdgeInsetsMake(0, -imageWidth, 0, imageWidth);
	}
	return view;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	return 0.01;
}

#pragma mark - scorllerDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
	scrollView.tag = 1;
	[self.delegate scrollViewOffsetChanged:scrollView isDataEmpty:QM_IS_ARRAY_NIL(self.manager.dataSource)];
}

@end

