//
//  PlanConfirmViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PlanConfirmViewController.h"
#import "PlanPaySuceessViewController.h"
#import "PayViewController.h"
#import "CaiJinQuanUseListViewController.h"
#import "CaiJinQuan.h"

#import "WXApi.h"
#import "PlanModel.h"

#import "PlanConfirmHeaderView.h"

@interface PlanConfirmViewController ()

@property (weak, nonatomic) IBOutlet CYBaseTableView *contentView;

@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (nonatomic, weak) IBOutlet CYButton*payButton;

@property (nonatomic, strong) NSString*currentM;

//代金券
@property (nonatomic,strong) CaiJinQuan *quanModel;

@property (nonatomic,strong) NSString*myAmount;

@end

@implementation PlanConfirmViewController {
    BOOL _isWXAppInstalled;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _isWXAppInstalled = [CommonUtils canShowWXAbout];
    
    [self initWithSubViews];
    
    self.currentM = @"0";
    
    // Do any additional setup after loading the view.
}

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshMoney];
}

- (void)initWithSubViews{
    self.navigationItem.title = @"支付";
    
    self.contentView.delegate = self;
    self.contentView.dataSource = self;
    self.contentView.backgroundColor = ColorDefaultGrayBackground;
    self.contentView.estimatedSectionHeaderHeight = 150.0;
    self.contentView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.contentView.rowHeight = 40.0;
    
    if (@available(iOS 11.0, *)) {
        self.contentView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
}

-(IBAction)pay:(UIButton*)button {
    @weakify(self);
//    if (self.model.price.integerValue > self.currentM.integerValue) {
//        [CMMUtility showToastWithText:@"余额不足，请充值"];
//        return;
//    }
    NSInteger couponId = QM_IS_STR_NIL(self.quanModel.userCouponId) ? -1 : self.quanModel.userCouponId.integerValue;
    [ESNetworkService payOrderWithPlanId:self.model.planId.integerValue userCouponId:couponId Response:^(id dict, ESError *error) {
        @strongify(self);
        if (dict&&[dict[@"code"] integerValue] == 0) {
            [[NSNotificationCenter defaultCenter] postNotificationName:kBuyPlanSuccess object:nil];
            
            dispatch_main_async_safe((^{
                PlanPaySuceessViewController *vc = [PlanPaySuceessViewController new];
                vc.expertName = self.model.expertName;
                vc.pTitle = self.model.title;
                vc.avatar = self.model.expertAvatar;
                vc.price = [NSString stringWithFormat:@"%@",self.model.price];
                vc.planId = self.model.planId;
                
                [self.navigationController pushViewController:vc animated:YES];
            }));
        }
    }];
}

#pragma mark -
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_isWXAppInstalled) {
        return 2;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.layoutMargins = UIEdgeInsetsZero;
    }
    
    if (indexPath.row == 0 && _isWXAppInstalled) {
        //代金券
        cell.textLabel.text = @"代金券选择";
        cell.textLabel.font = [UIFont addPingFangSCRegular:12.0];
        cell.textLabel.textColor = RGBCOLORV(0x282828);
        UILabel*label = [UILabel new];
        label.textColor = ColorMainAppRed;
        //缺少字段
        if (_quanModel.couponType.integerValue == 2) {
            label.text = [NSString stringWithFormat:@"已选择 抵扣%@",self.quanModel.num];
        }
        
        if (_quanModel.couponType.integerValue == 4) {
            label.text = @"已选择 免费优惠券";
        }
        
        if (!_quanModel) {
            label.text = @"";
        }
        
        label.font = [UIFont addPingFangSCRegular:12.0];
        [cell.contentView addSubview:label];
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(cell.contentView);
            make.right.mas_equalTo(cell.contentView).offset(-30);
        }];
        UIImageView *imageview = [UIImageView new];
        imageview.image = GetImage(@"go_arrow");
        [cell.contentView addSubview:imageview];
        [imageview mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(cell.contentView).offset(0);
            make.right.mas_equalTo(cell.contentView).offset(-15);
            make.size.mas_equalTo(CGSizeMake(6, 12));
        }];
        return cell;
    }else {
    
        //充值
        cell.textLabel.text = QM_IS_STR_NIL(self.myAmount)?@"账户飞驰币：":[NSString stringWithFormat: @"账户飞驰币：%@",self.myAmount];
        cell.textLabel.font = [UIFont addPingFangSCRegular:12.0];
        cell.textLabel.textColor = RGBCOLORV(0x282828);
        
        UILabel*chongzhi = [UILabel new];
        chongzhi.backgroundColor = ColorMainAppRed;
        chongzhi.text = @"充值";
        chongzhi.textAlignment = NSTextAlignmentCenter;
        chongzhi.textColor = [UIColor whiteColor];
        chongzhi.layer.cornerRadius = 2;
        chongzhi.clipsToBounds = YES;
        chongzhi.font = [UIFont addPingFangSCRegular:12.0];
        [cell.contentView addSubview:chongzhi];
        [chongzhi mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(cell.contentView).offset(0);
            make.right.mas_equalTo(cell.contentView).offset(-15);
            make.width.offset(60.0);
            make.height.mas_equalTo(25);
        }];
        
        return cell;
    }
//    switch (indexPath.row) {
//        case 1: {
//            //代金券
//            cell.selectionStyle = UITableViewCellSelectionStyleNone;
//            cell.layoutMargins = UIEdgeInsetsZero;
//            cell.textLabel.text = @"代金券选择";
//            cell.textLabel.font = [UIFont addPingFangSCRegular:12.0];
//            cell.textLabel.textColor = RGBCOLORV(0x282828);
//            UILabel*label = [UILabel new];
//            label.textColor = ColorMainAppRed;
//            //缺少字段
//            if (_quanModel.couponType.integerValue == 2) {
//                label.text = [NSString stringWithFormat:@"已选择 抵扣%@",self.quanModel.num];
//            }
//
//            if (_quanModel.couponType.integerValue == 4) {
//                label.text = @"已选择 免费优惠券";
//            }
//
//            if (!_quanModel) {
//                label.text = @"";
//            }
//
//            label.font = [UIFont addPingFangSCRegular:12.0];
//            [cell.contentView addSubview:label];
//            [label mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.centerY.mas_equalTo(cell.contentView);
//                make.right.mas_equalTo(cell.contentView).offset(-30);
//            }];
//            UIImageView *imageview = [UIImageView new];
//            imageview.image = GetImage(@"go_arrow");
//            [cell.contentView addSubview:imageview];
//            [imageview mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.centerY.mas_equalTo(cell.contentView).offset(0);
//                make.right.mas_equalTo(cell.contentView).offset(-15);
//                make.size.mas_equalTo(CGSizeMake(6, 12));
//            }];
//        }
//            break;
//        case 0: {
//            //充值
//            cell.selectionStyle = UITableViewCellSelectionStyleNone;
//            cell.layoutMargins = UIEdgeInsetsZero;
//
//            cell.textLabel.text = QM_IS_STR_NIL(self.myAmount)?@"账户飞驰币：":[NSString stringWithFormat: @"账户飞驰币：%@",self.myAmount];
//            cell.textLabel.font = [UIFont addPingFangSCRegular:12.0];
//            cell.textLabel.textColor = RGBCOLORV(0x282828);
//            UILabel*chongzhi = [UILabel new];
//            chongzhi.backgroundColor = ColorMainAppRed;
//            chongzhi.text = @"  充值  ";
//            chongzhi.textColor = [UIColor whiteColor];
//            chongzhi.layer.cornerRadius = 2;
//            chongzhi.clipsToBounds = YES;
//            chongzhi.font = [UIFont addPingFangSCRegular:12.0];
//            [cell.contentView addSubview:chongzhi];
//            [chongzhi mas_makeConstraints:^(MASConstraintMaker *make) {
//                make.centerY.mas_equalTo(cell.contentView).offset(0);
//                make.right.mas_equalTo(cell.contentView).offset(-15);
//                make.height.mas_equalTo(25);
//            }];
//        }
//            break;
//        default:
//            break;
//    }
    
//    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0 && _isWXAppInstalled) {
        //代金券
        CaiJinQuanUseListViewController *vc = [CaiJinQuanUseListViewController new];
        vc.clickBlock = ^(CaiJinQuan * _Nonnull model) {
            dispatch_main_async_safe(^{
                self.quanModel = model;
                [self.contentView reloadData];
            });
        };
        [self.navigationController pushViewController:vc animated:YES];
        return;
    }
    PayViewController *vc = [PayViewController new];
      [self.navigationController pushViewController:vc animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return UITableViewAutomaticDimension;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *wrapView = [UIView new];
    wrapView.backgroundColor = tableView.backgroundColor;
    
    PlanConfirmHeaderView *header = [PlanConfirmHeaderView shareInstance];
    header.model = self.model;
    [wrapView addSubview:header];
    [header mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
    }];
    
    return wrapView;
}

#pragma mark -
- (void)refreshMoney {
//    __weak PlanConfirmViewController*weakSelf = self;
    [ESNetworkService getSelfMessageResponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSString *gallopAccountAmount = [NSString stringWithFormat:@"%ld",[[dict[@"data"] objectForKey:@"gallopAccountAmount"] integerValue]];
            self.myAmount = gallopAccountAmount;

            dispatch_main_async_safe((^{
                
//                UITableViewCell*cell = [weakSelf.contentView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
//                weakSelf.currentM = gallopAccountAmount;
//                cell.textLabel.text = [NSString stringWithFormat: @"账户飞驰币：%@",gallopAccountAmount];
                [self.contentView reloadData];
            }));
        }
    }];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
