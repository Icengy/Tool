//
//  PlanPaySuceessViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PlanPaySuceessViewController.h"
#import "WTCTabBarViewController.h"
@interface PlanPaySuceessViewController ()
@property (nonatomic,strong) UIView*buyV;
@property (nonatomic,strong)UILabel*buyL;
@property (nonatomic, strong)UIView*headerView;
@property (nonatomic,strong) UIImageView*headV;
@property (nonatomic,strong) UILabel*titleL;
@property (nonatomic,strong) UILabel*nameL;
@property (nonatomic,strong) UILabel*moneyL;

@property (nonatomic,strong) UIView*underView;
@property (nonatomic, strong) UILabel*msgLabel;
@property (nonatomic,strong) UIButton*backButton;
@property (nonatomic,strong) UIButton*watchButton;
@end

@implementation PlanPaySuceessViewController
-(UIButton*)backButton
{
    if(!_backButton){
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backButton setBackgroundColor:[UIColor whiteColor]];
        [_backButton setTitle:@"返回首页" forState:UIControlStateNormal];
        [_backButton setTitleColor:ColorTitle forState:UIControlStateNormal];
        _backButton.layer.borderColor = ColorSubTitle.CGColor;
        [_backButton addTarget:self action:@selector(goHome) forControlEvents:UIControlEventTouchUpInside];
        _backButton.layer.borderWidth = 1;
        _backButton.titleLabel.font = GetFont(15.0f);
        
        [self.underView addSubview:_backButton];
        
    }
    return _backButton;
}
-(UIButton*)watchButton
{
    if(!_watchButton){
        _watchButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_watchButton setBackgroundColor:ColorAppRed];
        [_watchButton setTitle:@"立即查看" forState:UIControlStateNormal];
        [_watchButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_watchButton addTarget:self action:@selector(goWatch) forControlEvents:UIControlEventTouchUpInside];
        _watchButton.titleLabel.font = GetFont(15.0f);
        [self.underView addSubview:_watchButton];
    }
    return _watchButton;
}
-(UILabel*)msgLabel
{
    if (!_msgLabel) {
        _msgLabel = [UILabel new];
        _msgLabel.textColor = ColorTitle;
        _msgLabel.font = GetFont(12.0f);
        _msgLabel.numberOfLines = 2;
        _msgLabel.textAlignment = NSTextAlignmentCenter;
        [self.underView addSubview:_msgLabel];
    }
    return _msgLabel;
}
-(UIView*)underView
{
    if (!_underView) {
        _underView = [[UIView alloc] init];
        _underView.backgroundColor = ColorGrayBack;
        [self.headerView addSubview:_underView];
    }
    return _underView;
}
-(UILabel*)moneyL
{
    if (!_moneyL) {
        _moneyL = [UILabel new];
        _moneyL.textColor = [UIColor colorWithHexString:@"#F04844"];
        _moneyL.font = GetFont(10.0f);
        [self.headerView addSubview:_moneyL];
    }
    return _moneyL;
}
-(UILabel*)nameL
{
    if (!_nameL) {
        _nameL = [UILabel new];
        _nameL.textColor = ColorTitle;
        _nameL.font = GetFont(10.0f);
        [self.headerView addSubview:_nameL];
    }
    return _nameL;
}
-(UILabel*)titleL
{
    if (!_titleL) {
        _titleL = [UILabel new];
        _titleL.textColor = ColorTitle;
        _titleL.font = GetFont(12.0f);
        _titleL.numberOfLines = 2;
        [self.headerView addSubview:_titleL];
    }
    return _titleL;
}
-(UIImageView*)headV
{
    if (!_headV) {
        _headV = [UIImageView new];
        _headV.layer.cornerRadius = 20;
        _headV.clipsToBounds = YES;
        [self.headerView addSubview:_headV];
    }
    return _headV;
}
-(UILabel*)buyL
{
    if (!_buyL) {
        _buyL = [UILabel new];
        _buyL.backgroundColor = ColorGrayBack;
        _buyL.textColor = ColorTitle;
        _buyL.font = GetFont(14.0f);
        [self.buyV addSubview:_buyL];
    }
    return _buyL;
}

-(UIView*)headerView
{
    if (!_headerView) {
        _headerView = [[UIView alloc] init];
        _headerView.backgroundColor = [UIColor whiteColor];
    }
    return _headerView;
}
-(UIView*)buyV
{
    if (!_buyV) {
        _buyV = [[UIView alloc] init];
        _buyV.backgroundColor = ColorGrayBack;
        [self.headerView addSubview:_buyV];
    }
    return _buyV;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initViews];
    [self refreshView];
    
    // Do any additional setup after loading the view.
}
-(void)goHome
{
    WTCTabBarViewController*rootVC = APP_DELEGATE.window.rootViewController;
    UINavigationController*nai = rootVC.selectedViewController;
    NSArray*arr = [NSArray arrayWithObjects:nai.viewControllers[0],self, nil];
    [nai setViewControllers:arr];
//    [rootVC setSelectedIndex:0];
    [nai popToRootViewControllerAnimated:YES];
}
-(void)goWatch {
    NSMutableArray*mArr = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    [mArr removeObjectAtIndex:mArr.count -1];
    [mArr removeObjectAtIndex:mArr.count -1];
    [self.navigationController setViewControllers:[mArr copy] animated:YES];
}
-(void)initViews{
    self.navigationItem.title = @"支付成功";
    
    
    self.tableView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 67, 0);
    self.tableView.separatorInset = UIEdgeInsetsZero;
    self.tableView.layoutMargins = UIEdgeInsetsZero;
    self.tableView.placeHolderView = nil;
    self.tableView.backgroundColor = ColorGrayBack;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"PlanConfirmTabelCell"];
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.tableView];
    
    [self.headerView setFrame:CGRectMake(0, 0, kScreen_Width, 90+95)];
    [self.underView setFrame:CGRectMake(0, 90, kScreen_Width, 95)];
    [self.buyV setFrame:CGRectMake(0, 0, kScreen_Width, 30)];
    [self.buyL setFrame:CGRectMake(15, 0, kScreen_Width, 30)];
    __weak PlanPaySuceessViewController*weakSelf = self;
    [self.headV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.buyV.mas_bottom).offset(8);
        make.left.mas_equalTo(weakSelf.headerView).offset(15);
        make.size.mas_equalTo(CGSizeMake(40, 40));
    }];
    [self.titleL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.headV).offset(0);
        make.left.mas_equalTo(weakSelf.headV.mas_right).offset(12);
        make.right.mas_equalTo(weakSelf.headerView).offset(-15);
        make.height.mas_equalTo(30);
    }];
    [self.nameL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.titleL.mas_bottom).offset(3);
        make.left.mas_equalTo(weakSelf.titleL).offset(0);
        make.height.mas_equalTo(15);
    }];
    [self.moneyL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.nameL).offset(3);
        make.left.mas_equalTo(weakSelf.nameL.mas_right).offset(30);
        make.height.mas_equalTo(weakSelf.moneyL);
    }];
    
    [self.msgLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(weakSelf.underView).offset(10);
        make.left.mas_equalTo(weakSelf.underView).offset(15);
        make.right.mas_equalTo(weakSelf.underView).offset(-15);
        make.height.mas_equalTo(30);
    }];
    CGFloat width = (kScreen_Width-50)*0.25;
    [self.backButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.underView).offset(width);
        make.top.mas_equalTo(weakSelf.msgLabel.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(width, 40));
    }];
    [self.watchButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(weakSelf.underView).offset(-width);
        make.top.mas_equalTo(weakSelf.msgLabel.mas_bottom).offset(10);
        make.size.mas_equalTo(CGSizeMake(width, 40));
    }];
    self.tableView.tableHeaderView = self.headerView;

}
-(void)refreshView
{
    self.titleL.text = self.pTitle;
    [self.headV sd_setImageWithURL:[NSURL URLWithString:self.avatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
    self.nameL.text = [NSString stringWithFormat:@"专家：%@",self.expertName];
    self.moneyL.text = [NSString stringWithFormat:@"%@飞驰币",self.price];
    self.buyL.text = @"购买内容";
    self.msgLabel.text = @"你已经成功购买了此方案，可在方案查看分析详情";
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
