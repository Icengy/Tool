//
//  SaleCountViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SaleCountViewController.h"
#import "ReleaseRecordTableViewCell.h"
#import "SaleCntTableViewCell.h"
#import "SaleDetailManager.h"
#import "SaleDetail.h"
@interface SaleCountViewController ()<SaleDetailManagerDelegate>
@property (nonatomic, strong) SaleDetailManager *manager;
@end

@implementation SaleCountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     [self initWithSubViews];
    // Do any additional setup after loading the view.
}
- (void)initWithSubViews{
    self.navigationItem.title = @"销量详情";
    self.plainTableView.frame = CGRectMake(0, NavBarHeight, kScreen_Width, kScreen_Height-NavBarHeight);
    self.plainTableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 0);
    self.plainTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.plainTableView.separatorColor = ColorGrayBack;
    if (@available(iOS 11.0, *)){
        self.plainTableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.plainTableView];
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
    
    //    [self.plainTableView.mj_header beginRefreshing];
    [self loadData];
    
}
-(SaleDetailManager*)manager
{
    if (!_manager) {
        _manager = [SaleDetailManager new];
        _manager.planId = self.model.planId;
        _manager.delegate = self;
    }
    return _manager;
}
-(void)loadData{
    [ES_HttpService showLoading:YES];
    [self.manager refreshData];
}
-(void)loadMoreData{
    [self.manager loadData];
}
-(void)SaleDetailManager:(SaleDetailManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload {
    [self endAllFreshing:self.plainTableView];
    
    dispatch_main_async_safe(^{
        
        if (self.manager.dataSource.count == 0) {
        }
        
        if (!isRefresh && self.manager.dataSource.count >= 20) {
            self.plainTableView.mj_footer.hidden = NO;
        }else{
            self.plainTableView.mj_footer.hidden = YES;
        }
        
        [self.plainTableView reloadData];
        
    });
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        BuyRecord*model  = self.model;
        static NSString *identifier=@"ReleaseRecordTableViewCell";
        ReleaseRecordTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell==nil) {
            cell=[[ReleaseRecordTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        cell.fromSale = YES;
        //cell贴边
        UIEdgeInsets inset;
        inset.bottom=0;
        inset.top=0;
        inset.left=0;
        inset.right=0;
        if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
            [cell setLayoutMargins:inset];
        }
        if ([cell respondsToSelector:@selector(setSeparatorInset:)]){
            [cell setSeparatorInset:inset];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.model = model;
        
        return cell;
    }else{
        SaleDetail*model = self.manager.dataSource[indexPath.row];
        static NSString *identifier=@"SaleCntTableViewCell";
        SaleCntTableViewCell*cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"SaleCntTableViewCell" owner:nil options:nil] firstObject];
            
        }
        
        [cell.headV sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
        cell.headV.layer.cornerRadius = 15;
        cell.clipsToBounds = YES;
        cell.detailL.text =  [model.buyTime substringFromIndex:5];
        cell.nameL.text = model.userName;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }else{
        return self.manager.dataSource.count;
    }
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
         tableView.rowHeight = UITableViewAutomaticDimension;
           tableView.estimatedRowHeight = 165;
           return tableView.rowHeight;
    }else{
    return 50;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 1) {
        return 30;
    }else{
    return 0.01;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 1) {
        UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 30)];
        UILabel*l1 = [UILabel new];
        UILabel*l2 = [UILabel new];
        [view addSubview:l1];
        [view addSubview:l2];
        [l1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(view).offset(0);
            make.left.mas_equalTo(view).offset(15);
        }];
        [l2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.mas_equalTo(view).offset(0);
            make.right.mas_equalTo(view).offset(-15);
        }];
        l1.text = @"用户购买列表";
        l2.text = @"消费时间";
        view.backgroundColor = ColorGrayBack;
        [l1 setFont:GetFont(12.0f)];
        [l2 setFont:GetFont(12.0f)];
        return view;
    }else{
        return nil;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 0.01;
}
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
