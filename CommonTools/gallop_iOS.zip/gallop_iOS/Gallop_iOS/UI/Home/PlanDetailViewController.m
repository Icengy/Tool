//
//  PlanDetailViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/12.
//  Copyright © 2019 homosum. All rights reserved.

#import "PlanDetailViewController.h"
#import "PlanModel.h"
#import "SelectedMatchModel.h"
#import "MyLabel.h"
#import "PlanDetailGameInfoView.h"
#import "PlanBasketDetailGameInfoView.h"
#import "PlanConfirmViewController.h"
#import "PlanConfirmViewController.h"
#import "ExpertDetailViewController.h"
#import "MatchDetailViewController.h"
#import "ImageDeliverManager.h"
#import <SDWebImage/SDWebImageManager.h>
#import "HZPhotoBrowser.h"
#import "pointExtenButton.h"
#import "ExpertDetailTableViewCell.h"
#import "PlanCommentCell.h"
#import "PaperCommentView.h"
//分享
#import "ESShareViewController.h"

#define kPageSize 20

@interface PlanDetailViewController ()<PlanDetailGameInfoViewDelegate,PlanBasketDetailGameInfoViewDelegate,UITableViewDelegate,UITableViewDataSource,PaperCommentViewDelegate>
{
	NSArray<SelectResult *> *selectArr;
	HZPhotoBrowser *browserVc;
}
@property (nonatomic, strong) UIScrollView*customScrollerView;
@property (nonatomic, strong) UIView*titleV;
@property (nonatomic, strong) UIView*personView;
@property (nonatomic, strong) UIView*gameView;
@property (nonatomic, strong) UIView*analyseView;
@property (nonatomic, strong) UIImageView*limitView;
@property (nonatomic, strong) UIView*payView;
/**titleV**/
@property (nonatomic, strong) UILabel*titleL;
@property (nonatomic, strong) UILabel*timeLabel;
@property (nonatomic,strong) UILabel*specailStatusL;
@property (nonatomic, strong) UIView*seperatorLine;
/**personView**/
@property (nonatomic, strong) UIImageView*headV;
@property (nonatomic, strong) UILabel*nameL;
@property (nonatomic, strong) UILabel *recentLabel;
@property (nonatomic, strong) UILabel *redLabel;
@property (nonatomic, strong) UILabel *percentL;
@property (nonatomic, strong) UILabel *bounsLabel;
@property (nonatomic, strong) UILabel *sevenDaysLabel;
/**宣言view*/
@property (nonatomic,strong) UIView*xuanyanV;
@property (nonatomic,strong) UILabel*xuanyanL;
@property (nonatomic,strong) UILabel*declarationL;
@property (nonatomic,strong) UIImageView*declarationImageView;
/**gameView**/
@property (nonatomic, strong) PlanDetailGameInfoView *gameInfoView;
@property (nonatomic,strong) PlanBasketDetailGameInfoView*gameInfoBasketView;
/**analyseView**/
@property (nonatomic, strong) MyLabel*analyseL;
@property (nonatomic, strong) UILabel*tuijianL;
@property (nonatomic, strong) NSMutableArray*imgArr;
@property (nonatomic, strong) NSMutableArray*heighArr;
@property (nonatomic, strong) NSMutableArray*shunxuArr;
/*limitView**/
@property (nonatomic, strong)UIImageView*lockImageView;
@property (nonatomic, strong)UILabel*limitTipL;
@property (nonatomic, strong)UILabel*onlyL;
@property (nonatomic, strong) PointExtenButton*addReadB;
/*payView**/
@property (nonatomic, strong) UILabel*needPayL;
@property (nonatomic, strong) UIButton*payB;
@property (nonatomic, strong) PlanModel*model;

@property (nonatomic, strong) PaperCommentView *commentView; //评论输入框

@property (nonatomic, strong) NSMutableArray*browerArr;
@property (nonatomic, strong) NSMutableArray*imageVArr;

@property (nonatomic,strong) NSMutableArray *commentArr;

@property (nonatomic,assign) NSUInteger currentPage;

@end

@implementation PlanDetailViewController

#pragma mark - life cycle
- (void)viewDidLoad {
	[super viewDidLoad];
	self.commentArr = [NSMutableArray array];
	self.imgArr = [NSMutableArray arrayWithCapacity:3];
	self.heighArr = [NSMutableArray arrayWithObjects:@200,@200,@200, nil];
	self.browerArr = [NSMutableArray arrayWithCapacity:3];
	self.imageVArr = [NSMutableArray arrayWithCapacity:3];
	self.shunxuArr = [NSMutableArray arrayWithObjects:[UIImage imageNamed:@"无内容"],[UIImage imageNamed:@"无内容"],[UIImage imageNamed:@"无内容"], nil];
	[self setupViews];
	
	[self loadData];
	[[NSNotificationCenter defaultCenter] addObserverForName:kBuyPlanSuccess object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
		dispatch_main_async_safe(^{
			[self clearAndRefresh];
		});
	}];
	[[NSNotificationCenter defaultCenter] addObserverForName:kESDidLoginNotification  object:nil queue:nil usingBlock:^(NSNotification * _Nonnull note) {
		dispatch_main_async_safe(^{
			[self clearAndRefresh];
		});
	}];
	
	[MobClick event:@"expert10" attributes:@{@"source":QM_IS_STR_NIL(self.sourcePage) ? @"" : self.sourcePage}];
}


-(void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
}

-(void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self.tableView removeObserver:self forKeyPath:@"contentSize"];
}
#pragma  mark - action
-(void)share {
    [ESNetworkService planShareWithPlanId:@(self.planId).stringValue Response:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
             NSDictionary*model = dict[@"data"];
                       [self shareWithModel:model];
        }
    }];
}
#pragma mark - 微信分享
- (void)shareWithModel:(NSDictionary *)model {
    ESShareViewController *shareVC = [[ESShareViewController alloc] initWithModel:model];
    AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [delegate.window.rootViewController presentViewController:shareVC animated:YES completion:nil];
}

-(void)goToPersion
{
	ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",self.model.userId];
	vc.sourcePage = @"方案详情页";
	vc.hidesBottomBarWhenPushed = YES;
	
	[self.navigationController pushViewController:vc animated:YES];
}


-(void)toPhotoBrower:(UITapGestureRecognizer*)tap
{
	dispatch_main_async_safe(^{
		UIImageView*imgV = (UIImageView *)tap.view;
		int i = (int)imgV.tag - 2000;
		
		if (i == -1) {
			//宣言图片
			self->browserVc = [[HZPhotoBrowser alloc] init];
			self->browserVc.imageArray = @[self.model.declarationPic];
			self->browserVc.imageCount = 1;
			self->browserVc.currentImageIndex = 0;
			[self->browserVc show:self];
		} else {
			//方案内容图片
			self->browserVc = [[HZPhotoBrowser alloc] init];
			self->browserVc.imageArray = self.browerArr;
			self->browserVc.imageCount = self.browerArr.count;
			self->browserVc.currentImageIndex = i;
			[self->browserVc show:self];
		}
	});
}

-(void)dingyue:(UIButton*)button{
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	__weak PlanDetailViewController*weakSelf = self;
	[ESNetworkService followExpert:self.model.userId.integerValue  Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				[weakSelf loadData];
			});
		}
	}];
}

#pragma mark - private method
-(void)loadData
{
	[ESNetworkService planDetailWithPlanId:self.planId Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			id data = dict[@"data"];
			NSDictionary*match = data[@"info"];
			PlanModel*planModel = [PlanModel mj_objectWithKeyValues:match];
			self.isBasket = (planModel.field.integerValue == 2);
			if (self.isBasket) {
				[self configBasketBallData:planModel];
			}else{
				[self configFootBallData:planModel];
			}
		}
	}];
}

- (void)configBasketBallData:(PlanModel *)planModel {
	for (MatchModel *matchModel in planModel.matches) {
		NSString*winLose = matchModel.odds[@"sf"];
		NSString*concedeWinLose = matchModel.odds[@"rf"];
		NSString*dxfWinLose = matchModel.odds[@"dxf"];
		
		//专家方案选择结果(因2串1方案存在目前结构为数组)
		self->selectArr = matchModel.selects;
		//                       if (!QM_IS_STR_NIL(winLose)) {
		matchModel.winLose = [winLose objectFromJSONString];
		NSString*p_status = matchModel.winLose[@"p_status"];
		matchModel.sfAllow = [p_status isEqualToString:@"Selling"];
		for (int i = 0; i<2; i++) {
			SelectedMatchModel*modelS = [SelectedMatchModel new];
			modelS.selected = NO;
			modelS.matchDateNum = matchModel.matchDateNum;
			modelS.selectType = @"sf";
			switch (i) {
				case 0:
				{
				modelS.title = @"客胜";
				modelS.odds = matchModel.winLose[@"a"];
				modelS.selectOdds = @"a";
				
				}
					break;
				case 1:
				{
				modelS.title = @"主胜";
				modelS.odds = matchModel.winLose[@"h"];
				modelS.selectOdds = @"h";
				}
					break;
					
				default:
					break;
			}
			for (SelectResult*res in self->selectArr) {
				if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
					modelS.selected = YES;
				}
			}
			[matchModel.sfArray addObject:modelS];
			
		}
		
		matchModel.concedeWinLose = [concedeWinLose objectFromJSONString];
		matchModel.rangNumStr = matchModel.concedeWinLose[@"fixedodds"];
		NSString*p_status_rq = matchModel.concedeWinLose[@"p_status"];
		matchModel.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
		for (int i = 0; i<3; i++) {
			SelectedMatchModel*modelS = [SelectedMatchModel new];
			modelS.selected = NO;
			modelS.matchDateNum = matchModel.matchDateNum;
			modelS.selectType = @"rf";
			switch (i) {
				case 0:
				{
				modelS.title = @"让分客胜";
				modelS.odds = matchModel.concedeWinLose[@"a"];
				modelS.selectOdds = @"a";
				}
					break;
				case 1:
				{
				modelS.title = @"让分主胜";
				modelS.odds = matchModel.concedeWinLose[@"h"];
				modelS.selectOdds = @"h";
				}
					break;
					
				default:
					break;
			}
			for (SelectResult*res in self->selectArr) {
				if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
					modelS.selected = YES;
				}
			}
			[matchModel.rqsfArray addObject:modelS];
		}
		
		matchModel.dxfWinLose = [dxfWinLose objectFromJSONString];
		matchModel.dxfNumStr = matchModel.dxfWinLose[@"fixedodds"];
		NSString*p_status_dxf = matchModel.dxfWinLose[@"p_status"];
		matchModel.dxfAllow = [p_status_dxf isEqualToString:@"Selling"];
		for (int i = 0; i<3; i++) {
			SelectedMatchModel*modelS = [SelectedMatchModel new];
			modelS.selected = NO;
			modelS.matchDateNum = matchModel.matchDateNum;
			modelS.selectType = @"dxf";
			switch (i) {
				case 0:
				{
				modelS.title = @"大分";
				modelS.odds = matchModel.dxfWinLose[@"h"];
				modelS.selectOdds = @"h";
				}
					break;
				case 1:
				{
				modelS.title = @"小分";
				modelS.odds = matchModel.dxfWinLose[@"l"];
				modelS.selectOdds = @"l";
				}
					break;
					
				default:
					break;
			}
			for (SelectResult*res in self->selectArr) {
				if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
					modelS.selected = YES;
				}
			}
			[matchModel.dxfArray addObject:modelS];
		}
	}
	//                   }
	
	self.model = planModel;
	dispatch_main_async_safe(^{
		self.customScrollerView.hidden = NO;
		[self refreshViews];
	});
	[ESNetworkService expertPlanListWithPage:1 PageSize:4 Field:@(@(self.isBasket).intValue+1).stringValue Type:@"" ExpertId:planModel.userId.longLongValue ForExpert:0 Response:^(id dict, ESError *error) {
		NSArray*array = nil;
		if (dict&&[dict[@"code"] integerValue] == 0) {
			id da = dict[@"data"];
			id data = da[@"data"];
			if ([data isKindOfClass:[NSString class]]) {
				array = [data objectFromJSONString];
			}
			
			if ([data isKindOfClass:[NSArray class]]) {
				array = data;
			}
			
			
			[self.dataSource removeAllObjects];
			
			for (NSDictionary *dic in array) {
				PlanModel*model = [PlanModel mj_objectWithKeyValues:dic];
				NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
				NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
				for (NSDictionary*dic_info in matchInfo) {
					MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
					[arrM addObject:tag];
				}
				model.matchInfoArr = [arrM copy];
				
				if (self.dataSource.count<3&&model.planId.longLongValue!=self.planId) {
					[self.dataSource addObject:model];
				}
			}
			dispatch_main_async_safe(^{
				[self.tableView reloadData];
				
				if (self.model.commentAreaType != 0) {
					[self loadCommentList];
				}
			});
		}
	}];
}

- (void)configFootBallData:(PlanModel *)planModel {
	for (MatchModel *matchModel in planModel.matches) {
		NSString*winLose = matchModel.odds[@"winLose"];
		NSString*concedeWinLose = matchModel.odds[@"concedeWinLose"];
		//专家方案选择结果(因2串1方案存在目前结构为数组)
		self->selectArr = matchModel.selects;
		//                if (!QM_IS_STR_NIL(winLose)) {
		matchModel.winLose = [winLose objectFromJSONString];
		NSString*p_status = matchModel.winLose[@"p_status"];
		matchModel.sfAllow = [p_status isEqualToString:@"Selling"];
		for (int i = 0; i<3; i++) {
			SelectedMatchModel*modelS = [SelectedMatchModel new];
			modelS.selected = NO;
			modelS.matchDateNum = matchModel.matchDateNum;
			modelS.selectType = @"winLose";
			switch (i) {
				case 0:
				{
				modelS.title = @"胜";
				modelS.odds = matchModel.winLose[@"h"];
				modelS.selectOdds = @"h";
				}
					break;
				case 1:
				{
				modelS.title = @"平";
				modelS.odds = matchModel.winLose[@"d"];
				modelS.selectOdds = @"d";
				}
					break;
				case 2:
				{
				modelS.title = @"负";
				modelS.odds = matchModel.winLose[@"a"];
				modelS.selectOdds = @"a";
				}
					break;
					
				default:
					break;
			}
			for (SelectResult*res in self->selectArr) {
				if ([res.type isEqualToString:modelS.selectType] &&
                    [res.result isEqualToString:modelS.selectOdds]) {
					modelS.selected = YES;
				}
			}
			[matchModel.sfArray addObject:modelS];
			
		}
		
		matchModel.concedeWinLose = [concedeWinLose objectFromJSONString];
		matchModel.rangNumStr = matchModel.concedeWinLose[@"fixedodds"];
		NSString*p_status_rq = matchModel.concedeWinLose[@"p_status"];
		matchModel.rqsfAllow = [p_status_rq isEqualToString:@"Selling"];
		for (int i = 0; i<3; i++) {
			SelectedMatchModel*modelS = [SelectedMatchModel new];
			modelS.selected = NO;
			modelS.matchDateNum = matchModel.matchDateNum;
			modelS.selectType = @"concedeWinLose";
			switch (i) {
				case 0:
				{
				modelS.title = @"胜";
				modelS.odds = matchModel.concedeWinLose[@"h"];
				modelS.selectOdds = @"h";
				}
					break;
				case 1:
				{
				modelS.title = @"平";
				modelS.odds = matchModel.concedeWinLose[@"d"];
				modelS.selectOdds = @"d";
				}
					break;
				case 2:
				{
				modelS.title = @"负";
				modelS.odds = matchModel.concedeWinLose[@"a"];
				modelS.selectOdds = @"a";
				}
					break;
					
				default:
					break;
			}
			for (SelectResult*res in self->selectArr) {
				if ([res.type isEqualToString:modelS.selectType]&&[res.result isEqualToString:modelS.selectOdds]) {
					modelS.selected = YES;
				}
			}
			[matchModel.rqsfArray addObject:modelS];
		}
	}
	//            }
	
	self.model = planModel;
	dispatch_main_async_safe(^{
		self.customScrollerView.hidden = NO;
		[self refreshViews];
	});
	[ESNetworkService expertPlanListWithPage:1 PageSize:4 Field:@(@(self.isBasket).intValue+1).stringValue Type:@"" ExpertId:planModel.userId.longLongValue ForExpert:0 Response:^(id dict, ESError *error) {
		NSArray*array = nil;
		if (dict&&[dict[@"code"] integerValue] == 0) {
			id da = dict[@"data"];
			id data = da[@"data"];
			if ([data isKindOfClass:[NSString class]]) {
				array = [data objectFromJSONString];
			}
			
			if ([data isKindOfClass:[NSArray class]]) {
				array = data;
			}
			
			
			[self.dataSource removeAllObjects];
			
			for (NSDictionary *dic in array) {
				PlanModel*model = [PlanModel mj_objectWithKeyValues:dic];
				NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
				NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
				for (NSDictionary*dic_info in matchInfo) {
					MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
					[arrM addObject:tag];
				}
				model.matchInfoArr = [arrM copy];
				if (self.dataSource.count<3&&model.planId.longLongValue!=self.planId) {
					[self.dataSource addObject:model];
				}
			}
			dispatch_main_async_safe(^{
				[self.tableView reloadData];
				if (self.model.commentAreaType != 0) {
					[self loadCommentList];
				}
			});
		}
	}];
}

- (void)loadCommentList {
	self.currentPage = 1;
	@weakify(self)
	[ESNetworkService planDetailCommentList:self.model.planId.intValue Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.customScrollerView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				PlanCommentModel *model = [PlanCommentModel mj_objectWithKeyValues:dict[@"data"]];
				if (model.totalPages > self.currentPage) {
					[self.customScrollerView.mj_footer resetNoMoreData];
					self.customScrollerView.mj_footer.hidden = NO;
				}
				
				[self.commentArr removeAllObjects];
				[self.commentArr addObjectsFromArray:model.content];
				
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	@weakify(self)
	[ESNetworkService planDetailCommentList:self.model.planId.intValue Page:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				PlanCommentModel *model = [PlanCommentModel mj_objectWithKeyValues:dict[@"data"]];
				
				if (model.totalPages >= self.currentPage) {
					[self.customScrollerView.mj_footer endRefreshingWithNoMoreData];
					self.customScrollerView.mj_footer.hidden = YES;
				} else {
					[self.customScrollerView.mj_footer endRefreshing];
				}
				[self.commentArr addObjectsFromArray:model.content];
				
				[self.tableView reloadData];
			});
		} else {
			dispatch_main_async_safe(^{
				[self.customScrollerView.mj_footer endRefreshing];
			});
		}
	}];
}

- (void)clearAndRefresh {
	if (self.isBasket) {
		self.gameInfoBasketView = nil;
		self.gameInfoBasketView.hidden = NO;
		[self.gameInfoBasketView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.gameView);
			make.left.equalTo(self.view).offset(15);
			make.right.equalTo(self.view).offset(-15);
			make.bottom.equalTo(self.gameView).offset(-16.5);
		}];
	}else{
		self.gameInfoView = nil;
		self.gameInfoView.hidden = NO;
		[self.gameInfoView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.gameView);
			make.left.equalTo(self.view).offset(15);
			make.right.equalTo(self.view).offset(-15);
			make.bottom.equalTo(self.gameView).offset(-16.5);
		}];
	}
	
	[self loadData];
}

-(void)refreshViews{
	self.titleL.text = self.model.title;
	[self.titleL setLabelSpace:5 withFont:self.titleL.font];
	self.timeLabel.text = [NSString stringWithFormat:@"%@ 发布",self.model.releaseTime];
	if (!QM_IS_STR_NIL(self.model.specialStatus)) {
		self.specailStatusL.text = self.model.specialStatus;
	}else{
		self.specailStatusL.text = @"";
	}
	if ([self.model.redCnt intValue] != 0) {
		self.recentLabel.text = [NSString stringWithFormat:@" %@ 近%d中%d %@ ",@"\U0000200C",[self.model.planCnt intValue],[self.model.redCnt intValue],@"\U0000200C"];
		self.recentLabel.hidden = NO;
	}else{
		self.recentLabel.text = @"";
		self.recentLabel.hidden = YES;
	}
	if ([self.model.lastContinueCnt intValue]>=2) {
		self.redLabel.text = [NSString stringWithFormat:@" %@ %d连红 %@ ",@"\U0000200C",[self.model.lastContinueCnt intValue],@"\U0000200C"];
		self.redLabel.hidden = NO;
	}else{
		self.redLabel.text = @"";
		self.redLabel.hidden = YES;
	}
	self.nameL.text = self.model.expertName;
	
	self.bounsLabel.text = [NSString stringWithFormat:@"%.0f",[self.model.profitOfMinDays doubleValue] * 100];
	if ([self.model.profitOfMinDays doubleValue] > 0.0) {
		self.bounsLabel.hidden = NO;
		self.sevenDaysLabel.hidden = NO;
		self.percentL.hidden = NO;
        [self.recentLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.bounsLabel.mas_left).offset(-20);
        }];
	}else{
		self.bounsLabel.hidden = YES;
		self.sevenDaysLabel.hidden = YES;
		self.percentL.hidden = YES;
        
        [self.recentLabel mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.bounsLabel.mas_left).offset((self.bounsLabel.frame.size.width+20));
        }];
	}
	
	if (QM_IS_STR_NIL(self.model.expertAvatar)) {
		self.headV.image = [UIImage imageNamed:@"avatar"];
	}else{
		[self.headV sd_setImageWithURL:[NSURL URLWithString:self.model.expertAvatar] placeholderImage:[UIImage imageNamed:@"avatar"]];
	}
	
	if (!QM_IS_STR_NIL(self.model.declaration) || !QM_IS_STR_NIL(self.model.declarationPic)) {
		self.xuanyanV.hidden = NO;
		self.xuanyanL.text = @"专家宣言";
		self.declarationL.text = self.model.declaration;
		[self.declarationImageView sd_setImageWithURL:[NSURL URLWithString:self.model.declarationPic] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
			CGFloat imageW = kScreen_Width - 30;
			CGFloat imageYW = CGImageGetWidth(image.CGImage);
			CGFloat imageH = imageW / (imageYW / CGImageGetHeight(image.CGImage));
			if (imageH > 0) {
				[self.declarationImageView mas_updateConstraints:^(MASConstraintMaker *make) {
					make.height.mas_equalTo(imageH);
				}];
				[self.xuanyanV layoutSubviews];
			}
		}];
		[self.gameView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.top.mas_equalTo(self.xuanyanV.mas_bottom).offset(6);
		}];
	}else{
		self.xuanyanV.hidden = YES;
		[self.gameView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.top.mas_equalTo(self.xuanyanV.mas_bottom).offset(-20);
		}];
	}
	if (self.isBasket) {
		//比赛信息
		self.gameInfoBasketView.hidden = NO;
		[self.gameInfoBasketView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.gameView);
			make.left.equalTo(self.view).offset(15);
			make.right.equalTo(self.view).offset(-15);
			make.bottom.equalTo(self.gameView).offset(-16.5);
		}];
		[self.gameInfoBasketView configPlanBasketDetailGameInfoView:self.model];
	}else{
		//比赛信息
		self.gameInfoView.hidden = NO;
		[self.gameInfoView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.gameView);
			make.left.equalTo(self.view).offset(15);
			make.right.equalTo(self.view).offset(-15);
			make.bottom.equalTo(self.gameView).offset(-16.5);
		}];
		[self.gameInfoView configPlanDetailGameInfoView:self.model];
	}
	
	//仅未开赛时需要判断是否展示支付
	BOOL needShowPay = [self.model.guessStatus integerValue] == 9 && [self.model.buyFlag boolValue];
	
	if ([self.model.type isEqualToString:@"4"]) {
		needShowPay = NO;
	}
	
	if (needShowPay) {
		self.payView.hidden = NO;
		self.needPayL.text  = [NSString stringWithFormat:@"需支付%@飞驰币",[self.model.price stringValue]];
		[self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.bottom.equalTo(self.customScrollerView).offset(-21);
		}];
	}else{
		self.payView.hidden = YES;
		[self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.bottom.equalTo(self.customScrollerView).offset(20);
		}];
	}
	[self.payB setTitle:@"立即支付" forState:UIControlStateNormal];
	
	//专家分析
	if ([self.model.showContentFlag boolValue]) {
		self.limitView.hidden = YES;
		self.analyseView.hidden = NO;
		self.tuijianL.text = @"专家分析";
		self.analyseL.text = self.model.content;
		[self loadImageWithStr:self.model.pic];
	}else{
		if (!needShowPay) {
			if (self.model.type.intValue == 4) {
				self.limitTipL.text = @"订阅专家后查看推荐选项和分析";
				self.addReadB.hidden = NO;
			} else {
				self.limitTipL.text = @"已开赛停止购买";
				self.addReadB.hidden = YES;
			}
		} else {
			self.addReadB.hidden = YES;
		}
		self.limitView.hidden = NO;
		self.analyseView.hidden = YES;
	}
}

-(void)loadImageWithStr:(NSString*)imgStr{
	if (QM_IS_STR_NIL(imgStr)) {
		[self changeFrames];
		return;
	}
	if (!QM_IS_STR_NIL(imgStr)) {
		
		NSArray*conditionImageArr = [imgStr componentsSeparatedByString:@","];
		NSInteger count = conditionImageArr.count;
		[self.imgArr removeAllObjects];
		self.shunxuArr = [NSMutableArray arrayWithObjects:[UIImage imageNamed:@"无内容"],[UIImage imageNamed:@"无内容"],[UIImage imageNamed:@"无内容"], nil];
		self.heighArr = [NSMutableArray arrayWithObjects:@200,@200,@200, nil];
        
		
		CGFloat height = [LPUnitily getHeightFromString:self.model.content font:GetFont(14.0) width:kScreen_Width-30];
		[self.analyseL mas_updateConstraints:^(MASConstraintMaker *make) {
			make.height.mas_equalTo(height+14);
		}];
		__block CGFloat mH = height + 36;
		
		for (int i = 0;  i< count; i++) {
			
			dispatch_main_async_safe(^{
				CGFloat imageH = 200;
				UIImageView*imgV = [[UIImageView alloc] initWithFrame:CGRectMake(Adapt(15), mH, kScreen_Width-Adapt(30), imageH)];
				[self.analyseView addSubview:imgV];
				imgV.userInteractionEnabled = NO;
				
				imgV.backgroundColor = ColorGrayBack;
				imgV.contentMode = UIViewContentModeScaleAspectFill;
				[self.imageVArr addObject:imgV];
				mH = mH + imageH + Adapt(5);
				if (i == count -1) {
					[self.analyseView mas_updateConstraints:^(MASConstraintMaker *make) {
						make.height.mas_equalTo(mH+20);
					}];
				}
			});
			
			NSString*url =  [[ImageDeliverManager sharedInstance] privateImageUrlWithImageName:[NSString stringWithFormat:@"plan/image/%@",conditionImageArr[i]]];
			[self.browerArr addObject:url];
			@weakify(self)
			[[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:url] options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize, NSURL * _Nullable targetURL) {
				
			} completed:^(UIImage * _Nullable image, NSData * _Nullable data, NSError * _Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL * _Nullable imageURL) {
				@strongify(self)
				if (image) {
					[self.imgArr addObject:image];
					[self.shunxuArr replaceObjectAtIndex:i withObject:image];
					CGFloat imageW = kScreen_Width - 30.0;
					CGFloat imageYW = CGImageGetWidth(image.CGImage);
					CGFloat imageH = imageW / (imageYW / CGImageGetHeight(image.CGImage));
					[self.heighArr replaceObjectAtIndex:i withObject:@(imageH)];
				}
				if (self.imgArr.count == count) {
					[self changeFrames];
				}
			}];
		}
	}
}

-(void)changeFrames{
	dispatch_main_async_safe(^{
		CGFloat height = [LPUnitily getHeightFromString:self.model.content font:GetFont(14.0) width:kScreen_Width-30];
		[self.analyseL mas_updateConstraints:^(MASConstraintMaker *make) {
			make.height.mas_equalTo(height+14);
		}];
		CGFloat mH = height + 36;
		if (!QM_IS_ARRAY_NIL(self.imgArr)) {
			mH = mH + Adapt(10);
			for (int i = 0; i<self.imgArr.count; i++) {
				
				CGFloat imageH = [self.heighArr[i] floatValue];
				UIImageView*imgV = self.imageVArr[i];
				imgV.backgroundColor = [UIColor whiteColor];
				[imgV setFrame:CGRectMake(Adapt(15), mH, kScreen_Width-Adapt(30), imageH)];
				UITapGestureRecognizer*tap  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toPhotoBrower:)];
				[imgV addGestureRecognizer:tap];
				imgV.userInteractionEnabled = YES;
				imgV.tag = 2000+i;
				[self.analyseView addSubview:imgV];
				imgV.image= self.shunxuArr[i];
				imgV.contentMode = UIViewContentModeScaleToFill;
				mH = mH + imageH + Adapt(5);
			}
		}
		[self.analyseView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.height.mas_equalTo(mH + 20);
		}];
	});
}

#pragma mark - PlanDetailGameInfoViewDelegate & PlanBasketDetailGameInfoViewDelegate
- (void)matchCardClick:(MatchModel *)model {
	@weakify(self)
	if (self.model.field.integerValue == 2) {
		return;
	}
	[ESNetworkService getMatchId:model.matchId response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSUInteger matchId = [dict[@"data"] integerValue];
			dispatch_main_async_safe(^{
				if (matchId == 0) {
					[[LPUnitily sharedManager] showToastWithText:@"暂无比赛信息"];
					return;
				}
                
                MatchDetailViewController *liveVC = [[MatchDetailViewController alloc] init];
                liveVC.field = self.model.field.integerValue;

                liveVC.matchId = matchId;
                liveVC.sourcePage = @"方案详情页";
                
                [self.navigationController pushViewController:liveVC animated:YES];
			});
		}
	}];
}

#pragma mark - view layout
-(void)setupViews
{
	self.navigationItem.title = @"方案详情";
	self.view.backgroundColor = RGBCOLOR(244, 244, 244);
	
	//分享按钮
	UIButton *navShareBtn = [UIButton buttonWithType:UIButtonTypeCustom];
	navShareBtn.frame = CGRectMake(0, 0, 20, 20);
	[navShareBtn setImage:GetImage(@"nav_share_btn") forState:UIControlStateNormal];
	[navShareBtn setImage:GetImage(@"nav_share_btn") forState:UIControlStateHighlighted];
	[navShareBtn addTarget:self action:@selector(share) forControlEvents:UIControlEventTouchUpInside];
	UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
	[view addSubview:navShareBtn];
	navShareBtn.frame = CGRectMake(0, 0, 20, 20);
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:view];
	
	self.customScrollerView.hidden = YES;
	[self.customScrollerView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.top.bottom.equalTo(self.view);
	}];
    [self.customScrollerView addRefreshHeaderWithTarget:self action:@selector(loadCommentList)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	//headView
	[self.titleV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.customScrollerView);
		make.left.right.equalTo(self.view);
	}];
	[self.titleL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.titleV).offset(15);
		make.top.mas_equalTo(self.titleV).offset(6);
		make.right.mas_equalTo(self.titleV).offset(-15);
	}];
	[self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.titleL.mas_bottom).offset(5);
		make.left.mas_equalTo(self.titleV).offset(15);
		make.bottom.mas_equalTo(self.titleV).offset(-7);
		make.right.mas_equalTo(self.titleV).offset(-15);
	}];
	[self.specailStatusL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.titleL.mas_bottom).offset(5);
		make.right.mas_equalTo(self.titleV).offset(-15);
		make.bottom.mas_equalTo(self.titleV).offset(-7);
	}];
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.left.right.equalTo(self.titleV);
		make.height.mas_equalTo(1);
	}];
	
	//personView
	[self.personView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.titleV.mas_bottom);
		make.height.mas_equalTo(82);
		make.left.right.equalTo(self.view);
	}];
	[self.headV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.personView).offset(18);
		make.left.mas_equalTo(self.personView).offset(15);
		make.size.mas_equalTo(CGSizeMake(50, 50));
	}];
	
	
	
	[self.bounsLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.personView).offset(-25);
		make.centerY.equalTo(self.headV);
		make.height.mas_equalTo(22);
	}];
	[self.percentL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.personView).offset(-15);
		make.bottom.equalTo(self.bounsLabel).offset(-2);
	}];
	
	[self.sevenDaysLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.bounsLabel);
		make.top.equalTo(self.bounsLabel.mas_bottom).offset(3);
		make.height.mas_equalTo(12);
	}];
	
	[self.recentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.bounsLabel.mas_left).offset(-20);
		make.height.mas_equalTo(20);
		make.centerY.equalTo(self.headV);
	}];
	
	[self.redLabel mas_updateConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.headV);
//		make.right.equalTo(self.recentLabel.mas_left).offset(-12).priority(1000);
        make.right.mas_equalTo(self.recentLabel.mas_left).offset(-8);
//		make.right.equalTo(self.bounsLabel.mas_left).offset(-12).priority(900);
		make.height.mas_equalTo(20);
	}];
    [self.nameL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.headV);
        make.left.mas_equalTo(self.headV.mas_right).offset(12);
        make.right.mas_lessThanOrEqualTo(self.redLabel.mas_left).offset(-15);
    }];
	
	
	//xuanyanView
	self.xuanyanV.backgroundColor = [UIColor whiteColor];
	[self.xuanyanV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.personView.mas_bottom).offset(1);
		make.left.right.mas_equalTo(self.view);
	}];
	[self.xuanyanL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.xuanyanV).offset(10);
		make.left.mas_equalTo(self.xuanyanV).offset(15);
	}];
	[self.declarationL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.xuanyanL.mas_bottom).offset(5);
		make.left.mas_equalTo(self.xuanyanV).offset(15);
		make.right.mas_equalTo(self.xuanyanV).offset(-15);
	}];
	[self.declarationImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.declarationL.mas_bottom).offset(10);
		make.bottom.equalTo(self.xuanyanV).offset(-10);
		make.width.mas_equalTo(SCREEN_WIDTH - 30);
		make.centerX.equalTo(self.xuanyanV);
	}];
		
	//gameView
	[self.gameView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.xuanyanV.mas_bottom).offset(6);
	}];
	
	self.gameInfoBasketView.hidden = YES;
	self.gameInfoView.hidden = YES;

	[self.limitView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.gameView.mas_bottom);
		make.left.right.equalTo(self.view);
		make.height.mas_equalTo(165);
	}];
	[self.lockImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.view);
		make.top.equalTo(self.limitView).offset(42);
		make.size.mas_equalTo(CGSizeMake(40, 40));
	}];
	[self.limitTipL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.view);
		make.top.equalTo(self.lockImageView.mas_bottom).offset(15);
	}];
	[self.addReadB mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.limitTipL.mas_bottom).offset(15);
		make.centerX.equalTo(self.view);
		make.size.mas_equalTo(CGSizeMake(54, 24));
	}];
	//analyseView
	[self.analyseView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.gameView.mas_bottom);
		make.height.mas_equalTo(165);
	}];
	[self.tuijianL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.analyseView).offset(15);
		make.right.mas_equalTo(self.analyseView).offset(-15);
		make.top.mas_equalTo(self.analyseView).offset(0);
		make.height.mas_equalTo(30);
	}];
	[self.analyseL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.tuijianL.mas_bottom).offset(5);
		make.left.mas_equalTo(self.analyseView).offset(15);
		make.right.mas_equalTo(self.analyseView).offset(-15);
		make.height.mas_equalTo(25);
	}];
	//tipLabel
	[self.onlyL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.mas_equalTo(self.limitView);
		make.top.mas_equalTo(self.analyseView.mas_bottom).offset(10);
	}];
	
	CGFloat h;
	if (IsIphoneX) {
		h = 64;
	}else{
		h = 40;
	}
	
	[self.payView setFrame:CGRectMake(0, kScreen_Height-h, kScreen_Width, h)];
	
	[self.needPayL mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.mas_equalTo(self.payView).offset(15);
		make.centerY.mas_equalTo(self.payView);
	}];
	[self.payB mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.top.bottom.mas_equalTo(self.payView);
		make.width.mas_equalTo(85);
	}];
	self.analyseView.hidden = YES;
	self.payView.hidden = YES;
	
	UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(goToPersion)];
	
	[self.headV addGestureRecognizer:tap];
	self.headV.userInteractionEnabled = YES;
	
	[self.customScrollerView addSubview:self.tableView];
	self.tableView.estimatedSectionFooterHeight = 0;
	self.tableView.estimatedSectionHeaderHeight = 0;
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.mas_equalTo(self.onlyL.mas_bottom).offset(10);
		make.left.right.mas_equalTo(self.view);
		make.height.mas_equalTo(100);
		make.bottom.equalTo(self.customScrollerView).offset(20);
	}];
	self.tableView.scrollEnabled = NO;
	self.tableView.backgroundColor  = ColorGrayBack;
	self.tableView.placeHolderView = nil;
	[self.tableView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
	
}
#pragma mark - uitableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	if (QM_IS_ARRAY_NIL(self.dataSource) && QM_IS_ARRAY_NIL(self.commentArr)) {
		return 0;
	}
	if (self.model.commentAreaType == 0) {
		return 1;
	} else {
		return 2;
	}
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	if (section == 0) {
		return  self.dataSource.count;
	} else {
		return self.commentArr.count;
	}
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == 0) {
		PlanModel*model  = self.dataSource[indexPath.row];
		NSString *identifier=@"ExpertDetailTableViewCell";
		ExpertDetailTableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
		if (cell==nil) {
			cell=[[ExpertDetailTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
		}
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		cell.model = model;
		return cell;
	} else {
		PlanCommentItem*model  = self.commentArr[indexPath.row];
		NSString *identifier=@"PlanCommentCell";
		PlanCommentCell*cell=[tableView dequeueReusableCellWithIdentifier:identifier];
		if (cell==nil) {
			cell=[[PlanCommentCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
		}
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		[cell configCellWithModel:model];
		return cell;
	}
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	if (indexPath.section == 0) {
		PlanModel*model  = self.dataSource[indexPath.row];
		PlanDetailViewController*vc = [PlanDetailViewController new];
		vc.back = YES;
		vc.isBasket = self.isBasket;
		vc.planId = [model.planId integerValue];
		vc.sourcePage = @"专家主页页面";
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	}
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	tableView.rowHeight = UITableViewAutomaticDimension;
	tableView.estimatedRowHeight = 150;
	return tableView.rowHeight;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
	if (section == 0 && QM_IS_ARRAY_NIL(self.dataSource)) {
		return 0;
	}
	return 40;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if (section == 0) {
		if (QM_IS_ARRAY_NIL(self.dataSource)) {
			return nil;
		}
		UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 40)];
		UILabel*label = [UILabel new];
		[view addSubview:label];
		view.backgroundColor = [UIColor whiteColor];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(view).offset(15);
			make.centerY.mas_equalTo(view).offset(0);
		}];
		[label sizeToFit];
		label.textColor = ColorSubTitle;
		label.font = fcFont(14);
		label.text  =@"该专家近期其他方案";
		UIView*line = [UIView new];
		line.backgroundColor = RGBCOLOR(244, 244, 244);
		[view addSubview:line];
		[line mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.bottom.mas_equalTo(view);
			make.height.mas_equalTo(1);
		}];
		
		
		UILabel*moreLabel = [UILabel new];
		[view addSubview:moreLabel];
		[moreLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.mas_equalTo(view).offset(-15);
			make.centerY.mas_equalTo(view);
		}];
		[moreLabel sizeToFit];
		moreLabel.textColor = ColorSubTitle;
		moreLabel.font = fcFont(12);
		moreLabel.text  =@"查看更多";
		
		moreLabel.userInteractionEnabled = YES;
		UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toTheMore)];
		[moreLabel addGestureRecognizer:tap];
		return view;
	} else {
		UIView*view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 40)];
		UILabel*label = [UILabel new];
		[view addSubview:label];
		view.backgroundColor = [UIColor whiteColor];
		[label mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.mas_equalTo(view).offset(15);
			make.centerY.mas_equalTo(view).offset(0);
		}];
		[label sizeToFit];
		label.textColor = ColorAppBlack;
		label.font = fcFont(16);
		label.text  =@"全部评论";
		UIView*line = [UIView new];
		line.backgroundColor = RGBCOLOR(244, 244, 244);
		[view addSubview:line];
		[line mas_makeConstraints:^(MASConstraintMaker *make) {
			make.left.right.bottom.mas_equalTo(view);
			make.height.mas_equalTo(1);
		}];
		
		
		UILabel*commentLabel = [UILabel new];
		[view addSubview:commentLabel];
		[commentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.right.mas_equalTo(view).offset(-15);
			make.centerY.mas_equalTo(view);
			make.size.mas_equalTo(CGSizeMake(140, 32));
		}];
		commentLabel.textColor = RGBCOLOR(168, 168, 168);
		commentLabel.font = fcFont(12);
		commentLabel.backgroundColor = RGBCOLOR(244, 244, 244);
		commentLabel.text  = @"   我也来评论";
		commentLabel.hidden = self.model.forbidComment == 1 ? YES : NO;
		
		commentLabel.userInteractionEnabled = YES;
		UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(commentClick)];
		[commentLabel addGestureRecognizer:tap];
		return view;
	}
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	if (section == 1 && self.model.commentAreaType != 0 && QM_IS_ARRAY_NIL(self.commentArr)) {
		return 100;
	} else {
		return 0;
	}
}
-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
	if (section == 1 && self.model.commentAreaType != 0 && QM_IS_ARRAY_NIL(self.commentArr)) {
		UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
		contentView.backgroundColor = RGBCOLOR(244, 244, 244);
		UIView *noneCommentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
		[contentView addSubview:noneCommentView];
		noneCommentView.backgroundColor = [UIColor whiteColor];
		UILabel *noneCommentLabel = [UILabel new];
		noneCommentLabel.text = @"沙发尚无人坐,首评等你来写";
		noneCommentLabel.textColor = RGBCOLOR(136, 136, 136);
		noneCommentLabel.font = fcFont(16);
		[noneCommentView addSubview:noneCommentLabel];
		[noneCommentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.center.equalTo(noneCommentView);
		}];
		return contentView;
	} else {
		return nil;
	}
}

-(void)toTheMore
{
	ExpertDetailViewController*vc = [ExpertDetailViewController new];
    vc.expertId = [NSString stringWithFormat:@"%@",self.model.userId];
	vc.sourcePage = self.title;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)commentClick {
	//弹出评论框
	[self.commentView showPaperCommentView];
}

#pragma mark - KVO
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(nullable void *)context{
	if ([keyPath isEqualToString:@"contentSize"]) {
		CGSize oldSize = [change[NSKeyValueChangeOldKey] CGSizeValue];
		CGSize newSize = [change[NSKeyValueChangeNewKey] CGSizeValue];
		if (oldSize.height == newSize.height) {
			return;
		}
		//自动适应网页高度
		[self.tableView removeObserver:self forKeyPath:@"contentSize"];
		[self.tableView mas_updateConstraints:^(MASConstraintMaker *make) {
			make.height.mas_equalTo(newSize.height);
		}];
		//添加监听
		[self.tableView addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:nil];
	}
}


#pragma mark - PaperCommentViewDelegate
- (void)sendBtnClick:(NSString *)content {
	//调用文章评论接口
	@weakify(self)
	[ESNetworkService planDetailComment:self.model.planId.integerValue content:content Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe((^{
				self.commentView.textView.text = @"";
				[self.commentView hidePaperCommentView];
				[self loadCommentList];
			}));
		} else {
			dispatch_main_async_safe((^{
				[self.commentView hidePaperCommentView];
			}));
		}
	}];
}

#pragma mark - lazy init
-(UILabel*)needPayL
{
	if (!_needPayL) {
		_needPayL = [UILabel new];
		_needPayL.textColor = [UIColor colorWithHexString:@"#F04844"];
		_needPayL.font = GetFont(12.0f);
		[self.payView addSubview:_needPayL];
	}
	return _needPayL;
}

-(UIButton*)payB
{
	if(!_payB){
		_payB = [UIButton buttonWithType:UIButtonTypeCustom];
		[_payB setBackgroundColor:ColorAppRed];
		[_payB setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_payB.titleLabel.font = GetFont(12.0f);
		[_payB addTarget:self action:@selector(payPlan:) forControlEvents:UIControlEventTouchUpInside];
		[self.payView addSubview:_payB];
	}
	return _payB;
}

-(void)payPlan:(UIButton*)button{
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
	}else{
		PlanConfirmViewController*vc = [PlanConfirmViewController new];
//		vc.avatar = self.model.expertAvatar;
//		vc.pTitle = self.model.title;
//		vc.price = [NSString stringWithFormat:@"%d",self.model.price.intValue];
//		vc.expertName = self.model.expertName;
//		vc.planId = self.model.planId;
//		[vc refreshViews];
		[self.navigationController pushViewController:vc animated:YES];
	}
}

-(UILabel*)tuijianL
{
	if (!_tuijianL) {
		_tuijianL = [UILabel new];
		_tuijianL.textColor = ColorAppBlack;
		_tuijianL.backgroundColor = [UIColor whiteColor];
		_tuijianL.font = GetFont(14.0f);
		[self.analyseView addSubview:_tuijianL];
	}
	return _tuijianL;
}

-(MyLabel*)analyseL
{
	if (!_analyseL) {
		_analyseL = [MyLabel new];
		_analyseL.backgroundColor = [UIColor whiteColor];
		_analyseL.textColor = ColorSubTitle;
		_analyseL.font = GetFont(14.0f);
		_analyseL.numberOfLines = 0;
		_analyseL.verticalAlignment = VerticalAlignmentTop;
		[self.analyseView addSubview:_analyseL];
	}
	return _analyseL;
}

- (UIImageView *)lockImageView {
	if (!_lockImageView) {
		_lockImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"scheme_detail_limit_lock"]];
		[self.limitView addSubview:_lockImageView];
	}
	return _lockImageView;
}

- (UILabel *)limitTipL {
	if (!_limitTipL) {
		_limitTipL = [[UILabel alloc] init];
		_limitTipL.text = @"购买后可查看专业分析和选项";
		_limitTipL.font = GetFont(10);
		_limitTipL.textColor = RGBACOLOR(255, 168, 71, 1);
		[self.limitView addSubview:_limitTipL];
	}
	return _limitTipL;
}

-(UILabel*)onlyL
{
	if (!_onlyL) {
		_onlyL = [UILabel new];
		_onlyL.textColor = [UIColor colorWithHexString:@"#A8A8A8"];
		_onlyL.font = GetFont(10.0f);
		_onlyL.textAlignment = NSTextAlignmentCenter;
		_onlyL.backgroundColor = ColorGrayBack;
		_onlyL.text = @"分析仅供参考，如需购彩请前往彩票店";
		[self.customScrollerView addSubview:_onlyL];
	}
	return _onlyL;
}

-(PointExtenButton*)addReadB
{
	if(!_addReadB){
		_addReadB = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_addReadB addTarget:self action:@selector(dingyue:) forControlEvents:UIControlEventTouchUpInside];
		[_addReadB setTitle:@" +订阅 " forState:UIControlStateNormal];
		[_addReadB setBackgroundColor:ColorAppRed];
		[_addReadB setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_addReadB.titleLabel.font = fcFont(12);
		_addReadB.layer.cornerRadius = 2;
		_addReadB.clipsToBounds = YES;
		[self.limitView addSubview:_addReadB];
	}
	return _addReadB;
}

-(UILabel*)recentLabel
{
	if (!_recentLabel) {
		_recentLabel = [UILabel new];
		_recentLabel.textColor = ColorAppGreen;
		_recentLabel.layer.borderColor = ColorAppGreen.CGColor;
		_recentLabel.layer.cornerRadius =3;
		_recentLabel.layer.borderWidth = 1;
		_recentLabel.clipsToBounds = YES;
		_recentLabel.font = GetFont(10.0f);
		
		[self.personView addSubview:_recentLabel];
	}
	return _recentLabel;
}

-(UILabel*)redLabel
{
	if (!_redLabel) {
		_redLabel = [UILabel new];
		_redLabel.textColor = [UIColor colorWithHexString:@"#F04844"];
		_redLabel.layer.borderColor = [UIColor colorWithHexString:@"#F04844"].CGColor;
		_redLabel.layer.cornerRadius =3;
		_redLabel.layer.borderWidth = 1;
		_redLabel.clipsToBounds = YES;
		_redLabel.font = GetFont(10.0f);
		[self.personView addSubview:_redLabel];
	}
	return _redLabel;
}

-(UILabel*)bounsLabel
{
	if (!_bounsLabel) {
		_bounsLabel = [UILabel new];
		_bounsLabel.textColor = [UIColor colorWithHexString:@"#F04844"];
		_bounsLabel.font = fcBoldFont(19.0f);
		[self.personView addSubview:_bounsLabel];
	}
	return _bounsLabel;
}

-(UILabel*)sevenDaysLabel
{
	if (!_sevenDaysLabel) {
		_sevenDaysLabel = [UILabel new];
		_sevenDaysLabel.textColor = ColorSubTitle;
		_sevenDaysLabel.font = fcFont(10.0f);
		_sevenDaysLabel.text = @"7日返奖";
		[self.personView addSubview:_sevenDaysLabel];
	}
	return _sevenDaysLabel;
}

-(UILabel*)percentL
{
	if (!_percentL) {
		_percentL = [[UILabel alloc] init];
		_percentL.textColor = [UIColor colorWithHexString:@"#f04844"];
		_percentL.font = fcBoldFont(10.0f);
		_percentL.text = @"%";
		[self.personView addSubview:_percentL];
	}
	return _percentL;
}

-(UIView*)xuanyanV
{
	if (!_xuanyanV) {
		_xuanyanV = [[UIView alloc] init];
		[self.customScrollerView addSubview:_xuanyanV];
	}
	return _xuanyanV;
}
-(UILabel*)xuanyanL
{
	if (!_xuanyanL) {
		_xuanyanL = [UILabel new];
		_xuanyanL.textColor = ColorTitle;
		_xuanyanL.font = fcFont(14.0f);
		_xuanyanL.textAlignment = NSTextAlignmentLeft;
		[self.xuanyanV addSubview:_xuanyanL];
	}
	return _xuanyanL;
}
-(UILabel*)declarationL
{
	if (!_declarationL) {
		_declarationL = [UILabel new];
		_declarationL.textColor = ColorSubTitle;
		_declarationL.numberOfLines = 0;
		_declarationL.font = fcFont(12.0f);
		_declarationL.textAlignment = NSTextAlignmentLeft;
		[self.xuanyanV addSubview:_declarationL];
	}
	return _declarationL;
}

-(UIImageView*)declarationImageView
{
	if (!_declarationImageView) {
		_declarationImageView = [UIImageView new];
		UITapGestureRecognizer*tap  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toPhotoBrower:)];
		[_declarationImageView addGestureRecognizer:tap];
		_declarationImageView.userInteractionEnabled = YES;
		_declarationImageView.tag = 1999;
		[self.xuanyanV addSubview:_declarationImageView];
	}
	return _declarationImageView;
}

-(UIImageView*)headV
{
	if (!_headV) {
		_headV = [UIImageView new];
		_headV.layer.cornerRadius = 25;
		_headV.clipsToBounds = YES;
		[self.personView addSubview:_headV];
	}
	return _headV;
}

-(UILabel*)nameL
{
	if (!_nameL) {
		_nameL = [UILabel new];
		_nameL.textColor = RGBCOLOR(58, 58, 58);
		_nameL.font = fcBoldFont(14);
		[self.personView addSubview:_nameL];
	}
	return _nameL;
}

-(UILabel*)titleL
{
	if (!_titleL) {
		_titleL = [UILabel new];
		_titleL.textColor = ColorAppBlack;
		_titleL.font = GetBoldFont(15.0f);
		_titleL.numberOfLines = 0;
		[self.titleV addSubview:_titleL];
	}
	return _titleL;
}

-(UILabel*)timeLabel
{
	if (!_timeLabel) {
		_timeLabel = [UILabel new];
		_timeLabel.textColor = ColorSubTitle;
		_timeLabel.font = GetFont(10.0f);
		[self.titleV addSubview:_timeLabel];
	}
	return _timeLabel;
}
-(UILabel*)specailStatusL
{
	if (!_specailStatusL) {
		_specailStatusL = [UILabel new];
		_specailStatusL.textColor = [UIColor colorWithHexString:@"#F98131"];
		_specailStatusL.font = GetFont(10.0f);
		[self.titleV addSubview:_specailStatusL];
	}
	return _specailStatusL;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [[UIView alloc] init];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.titleV addSubview:_seperatorLine];
	}
	return _seperatorLine;
}

-(UIView*)payView
{
	if (!_payView) {
		_payView = [[UIView alloc] init];
		_payView.backgroundColor = [UIColor whiteColor];
		[self.view addSubview:_payView];
	}
	return _payView;
}

-(UIImageView*)limitView
{
	if (!_limitView) {
		_limitView = [[UIImageView alloc] init];
		_limitView.image = [UIImage imageNamed:@"scheme_detail_limit_bg"];
		_limitView.userInteractionEnabled = YES;
		[self.customScrollerView addSubview:_limitView];
	}
	return _limitView;
}

-(UIView*)analyseView
{
	if (!_analyseView) {
		_analyseView = [[UIView alloc] init];
		_analyseView.backgroundColor = [UIColor whiteColor];
		[self.customScrollerView addSubview:_analyseView];
	}
	return _analyseView;
}

/**gameView**/
-(UIView*)gameView
{
	if (!_gameView) {
		_gameView = [[UIView alloc] init];
		_gameView.backgroundColor = [UIColor whiteColor];
		[self.customScrollerView addSubview:_gameView];
	}
	return _gameView;
}

- (PlanDetailGameInfoView *)gameInfoView {
	if (!_gameInfoView) {
		_gameInfoView = [[PlanDetailGameInfoView alloc] init];
		_gameInfoView.delegate = self;
		[self.gameView addSubview:_gameInfoView];
	}
	return _gameInfoView;
}
-(PlanBasketDetailGameInfoView*)gameInfoBasketView
{
	if (!_gameInfoBasketView) {
		_gameInfoBasketView = [[PlanBasketDetailGameInfoView alloc]init];
		_gameInfoBasketView.delegate = self;
		[self.gameView addSubview:_gameInfoBasketView];
	}
	return _gameInfoBasketView;
}
//
-(UIView*)personView
{
	if (!_personView) {
		_personView = [[UIView alloc] init];
		_personView.backgroundColor = [UIColor whiteColor];
		[self.customScrollerView addSubview:_personView];
	}
	return _personView;
}

-(UIView*)titleV
{
	if (!_titleV) {
		_titleV = [[UIView alloc] init];
		_titleV.backgroundColor = [UIColor whiteColor];
		[self.customScrollerView addSubview:_titleV];
	}
	return _titleV;
}

-(UIScrollView*)customScrollerView
{
	if (!_customScrollerView) {
		_customScrollerView = [[UIScrollView alloc] init];
		_customScrollerView.backgroundColor = ColorGrayBack;
		_customScrollerView.scrollEnabled = YES;
		[self.view addSubview:_customScrollerView];
	}
	return _customScrollerView;
}

- (PaperCommentView *)commentView {
	if (!_commentView) {
		_commentView = [[PaperCommentView alloc] init];
		_commentView.hidden = YES;
		_commentView.delegate = self;
		_commentView.placeHolderLabel.text = @"说说你的看法";
		_commentView.fullScreenBtn.hidden = YES;
		[self.view addSubview:_commentView];
		[_commentView mas_makeConstraints:^(MASConstraintMaker *make) {
			make.bottom.left.right.top.equalTo(self.view);
		}];
	}
	return _commentView;
}

@end
