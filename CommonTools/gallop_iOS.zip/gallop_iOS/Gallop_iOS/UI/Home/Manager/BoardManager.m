//
//  BoardManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "BoardManager.h"
#import "YinLi.h"

#import "GallopExpertModel.h"

@interface BoardManager()
{
    int pageNum;
    int pageSize;
}
@end
@implementation BoardManager
- (id)init{
    if (self = [super init]){
        pageNum = 0;
        pageSize = 20;
        _dataSource = [[NSMutableArray alloc] init];
    }
    return self;
}


-(void)refreshData
{
    pageNum = 0;
    [self loadData0];
}
-(void)loadData
{
    [self loadData0];
}
-(void)loadData0 {
    pageNum++;
    [ESNetworkService expertBoardWithPage:pageNum PageSize:pageSize Rank:self.rank Field:self.field.integerValue Response:^(id dict, ESError *error) {
         NSArray*array = nil;
         if (dict && [dict[@"code"] integerValue] == 0) {
             id da = dict[@"data"];
             id data = da[@"expertList"];
             if ([data isKindOfClass:[NSString class]]) {
                 array = [data objectFromJSONString];
             }
             
             if ([data isKindOfClass:[NSArray class]]) {
                 array = data;
             }
             if (array.count == 0 && self->pageNum != 1) {
                 [CMMUtility showToastWithText:@"没有更多数据"];
             }else {
                 if (self->pageNum == 1) {
                     [self.dataSource removeAllObjects];
                 }
                 [self.dataSource addObjectsFromArray:[GallopExpertModel mj_objectArrayWithKeyValuesArray:array]];
//                 if (self.rank.integerValue == 1) {
//                     /// 连红
//                     for (NSDictionary *dic in array) {
//                         RedRank*model = [RedRank mj_objectWithKeyValues:dic];
//                         [self.dataSource addObject:model];
//                     }
//                 } else if (self.rank.integerValue == 2){
//                     /// 命中
//					 for (NSDictionary *dic in array) {
//						 HitRank*model = [HitRank mj_objectWithKeyValues:dic];
//						 [self.dataSource addObject:model];
//					 }
//				 } else {
//                     /// 返奖
//					 for (NSDictionary *dic in array) {
//						 YinLi*model = [YinLi mj_objectWithKeyValues:dic];
//						 [self.dataSource addObject:model];
//					 }
//				 }
             }
         }
        if (self.delegate&&[self.delegate respondsToSelector:@selector(BoardManager:didEndLoadDataIsRefresh:shouldReload:)]) {
            [self.delegate BoardManager:self didEndLoadDataIsRefresh:(array.count == 0) shouldReload:(error)];
        }
    }];
   
}
@end
