//
//  PersonManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PersonManager.h"
#import "PlanModel.h"
@interface PersonManager()
{
    int pageNum;
    int pageSize;
}
@end
@implementation PersonManager
- (id)init{
    if (self = [super init]){
        pageNum = 0;
        pageSize = 20;
        _dataSource = [[NSMutableArray alloc] init];
    }
    return self;
}


-(void)refreshDataWithType:(NSString *)type andField:(NSString *)field
{
    pageNum = 0;
    [self loadDataWithPageNumWithType:type andField:field];
}
-(void)loadDataWithType:(NSString *)type andField:(NSString *)field
{
    [self loadDataWithPageNumWithType:type andField:field];
}
-(void)loadDataWithPageNumWithType:(NSString*)type andField:(NSString *)field{
    pageNum++;
    [ESNetworkService expertPlanListWithPage:pageNum PageSize:pageSize Field:field Type:type ExpertId:self.expertId.integerValue ForExpert:self.forExpert Response:^(id dict, ESError *error) {
        NSArray*array = nil;
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id da = dict[@"data"];
            id data = da[@"data"];
            if ([data isKindOfClass:[NSString class]]) {
                array = [data objectFromJSONString];
            }
            
            if ([data isKindOfClass:[NSArray class]]) {
                array = data;
            }
            if (array.count == 0&&self->pageNum != 1) {
                [CMMUtility showToastWithText:@"没有更多数据"];
            }else {
                if (self->pageNum == 1) {
                    [self.dataSource removeAllObjects];
                }
                
                for (NSDictionary *dic in array) {
                    PlanModel*model = [PlanModel mj_objectWithKeyValues:dic];
                    NSMutableArray*arrM = [NSMutableArray arrayWithCapacity:0];
                    NSArray*matchInfo = [dic[@"matchInfo"] objectFromJSONString];
                    for (NSDictionary*dic_info in matchInfo) {
                        MatchTag*tag = [MatchTag mj_objectWithKeyValues:dic_info];
                        [arrM addObject:tag];
                    }
                    model.matchInfoArr = [arrM copy];
                    [self.dataSource addObject:model];
                }
            }
        }
        if (self.delegate&&[self.delegate respondsToSelector:@selector(PersonManager:didEndLoadDataIsRefresh:shouldReload:)]) {
            [self.delegate PersonManager:self didEndLoadDataIsRefresh:(array.count == 0) shouldReload:(error)];
        }
    }];
}
@end
