//
//  SaleDetailManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN
@class SaleDetailManager;

@protocol SaleDetailManagerDelegate <NSObject>

- (void)SaleDetailManager:(SaleDetailManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload;


@end
@interface SaleDetailManager : NSObject
@property (nonatomic, weak) id<SaleDetailManagerDelegate> delegate;
@property (nonatomic, strong, readonly) NSMutableArray *dataSource;
@property (nonatomic, strong) NSString*planId;
- (void)refreshData;
- (void)loadData;
@end


NS_ASSUME_NONNULL_END
