//
//  SaleDetailManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/15.
//  Copyright © 2019 homosum. All rights reserved.
//
#import "SaleDetail.h"
#import "SaleDetailManager.h"
@interface SaleDetailManager()
{
    int pageNum;
    int pageSize;
}
@end
@implementation SaleDetailManager
- (id)init{
    if (self = [super init]){
        pageNum = 0;
        pageSize = 20;
        _dataSource = [[NSMutableArray alloc] init];
    }
    return self;
}


-(void)refreshData
{
    pageNum = 0;
    [self loadData0];
}
-(void)loadData
{
    [self loadData0];
}
-(void)loadData0{
    pageNum++;
    [ESNetworkService saleDetailWithPage:pageNum PageSize:pageSize PlanId:[self.planId longLongValue] Response:^(id dict, ESError *error) {
        NSArray*array = nil;
        if (dict&&[dict[@"code"] integerValue] == 0) {
            id da = dict[@"data"];
            id data = da[@"planOrderList"];
            if ([data isKindOfClass:[NSString class]]) {
                array = [data objectFromJSONString];
            }
            
            if ([data isKindOfClass:[NSArray class]]) {
                array = data;
            }
            if (array.count == 0&&self->pageNum != 1) {
                [CMMUtility showToastWithText:@"没有更多数据"];
            }else {
                if (self->pageNum == 1) {
                    [self.dataSource removeAllObjects];
                }
                
                    
                for (NSDictionary *dic in array) {
                    SaleDetail*model = [SaleDetail mj_objectWithKeyValues:dic];
                    [self.dataSource addObject:model];
                }
                
            }
        }
        if (self.delegate&&[self.delegate respondsToSelector:@selector(SaleDetailManager:didEndLoadDataIsRefresh:shouldReload:)]) {
            [self.delegate SaleDetailManager:self didEndLoadDataIsRefresh:(array.count == 0) shouldReload:(error)];
        }
    }];
    
}
@end
