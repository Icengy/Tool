//
//  BoardManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/2.
//  Copyright © 2019 homosum. All rights reserved.
//


#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class BoardManager;

@protocol BoardManagerDelegate <NSObject>

- (void)BoardManager:(BoardManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload;


@end
@interface BoardManager : NSObject
@property (nonatomic, weak) id<BoardManagerDelegate> delegate;
@property (nonatomic, strong, readonly) NSMutableArray *dataSource;

@property (nonatomic, copy) NSString*rank;
@property (nonatomic, copy) NSString*field;

- (void)refreshData;
- (void)loadData;
@end

NS_ASSUME_NONNULL_END
