//
//  PersonManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@class PersonManager;

@protocol PersonManagerDelegate <NSObject>

- (void)PersonManager:(PersonManager *)newsPostManager didEndLoadDataIsRefresh:(BOOL)isRefresh shouldReload:(BOOL)shouldReload;


@end
@interface PersonManager : NSObject
@property (nonatomic, weak) id<PersonManagerDelegate> delegate;
@property (nonatomic, strong, readonly) NSMutableArray *dataSource;
@property (nonatomic, strong) NSNumber *expertId;
@property (nonatomic, assign) int forExpert;
- (void)refreshDataWithType:(NSString*)type andField:(NSString*)field;
- (void)loadDataWithType:(NSString*)type andField:(NSString*)field;
@end

NS_ASSUME_NONNULL_END
