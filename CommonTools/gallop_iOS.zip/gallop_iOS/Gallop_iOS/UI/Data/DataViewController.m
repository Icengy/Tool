//
//  DataViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "DataViewController.h"
#import "WorldRankingViewController.h"
#import "LeagueViewController.h"
#import "MatchEvents.h"
#import "DataHomeCollectionViewCell.h"
#import "HotLeagueCollectionViewCell.h"
#import "LeagueChooseView.h"
#import "DataSearchViewController.h"
#import "UIBarButtonItem+CreateExt.h"

#define hotWidth (kScreen_Width*0.2)

@interface DataViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,UIScrollViewDelegate,UISearchBarDelegate>
//**热门赛事**//
//**排名**//
//**全部赛事**//
{
    UIButton*markButton;
}

@property(nonatomic,strong)UISearchBar*searchBar;

@property (nonatomic,strong)UICollectionView*allCollectionView;

@property (nonatomic,strong)UICollectionView*hotCollectionView;

@property (nonatomic,strong) NSMutableArray*hotDataSource;

@property (nonatomic, weak) NSTimer *timer;

@property (nonatomic,strong)UIView *headView;

@property (nonatomic,strong) UIView*buttonV;
/** 是否自动滚动,默认Yes */
@property(nonatomic,assign) BOOL autoScroll;

@property (nonatomic,assign) NSInteger totalItemsCount;


@end

@implementation DataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem createBackBarItemWithImage:@"nav_return_black" withHightImg:nil target:self action:@selector(navBackClick)];
    
    [self setupViews];
    [self loadData];
}

- (void)navBackClick {
	//match TabBarController back To Main Tabbar
	[self.navigationController popViewControllerAnimated:YES];
}

-(void)setupViews{
    self.navigationItem.title = @"足球数据";
	
	[self.view addSubview:self.searchBar];
	[self.searchBar mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.view);
		make.top.equalTo(self.view).offset(NavBarHeight);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 40));
	}];
    self.hotDataSource = [NSMutableArray arrayWithCapacity:0];
    self.totalItemsCount = 0;
	self.tableView.frame = CGRectMake(0,NavBarHeight + 50, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight - kBottomSafeArea - 50);
    self.tableView.tag = 3333;
    self.tableView.placeHolderView = nil;
    if (@available(iOS 11.0, *)){
        self.tableView.contentInsetAdjustmentBehavior = UIScrollViewContentInsetAdjustmentNever;
    }
    [self.view addSubview:self.tableView];
    self.headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, kScreen_Height-NavBarHeight-kBottomSafeArea)];
    self.tableView.tableHeaderView = self.headView;
    self.headView.backgroundColor = [UIColor colorWithHexString:@"#f4f4f4"];
    UIView*hotV = [[UIView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, 35)];
    hotV.backgroundColor = [UIColor whiteColor];
    [self.headView addSubview:hotV];
    
    UILabel*matchL = [[UILabel alloc] initWithFrame:CGRectMake(15, 8, kScreen_Width-30, 20)];
    matchL.text = @"热门赛事";
    matchL.font = GetBoldFont(14.0f);
    matchL.textColor = [UIColor colorWithHexString:@"#15151A"];
    matchL.textAlignment = NSTextAlignmentLeft;
    [self.headView addSubview:matchL];
    
    UIView*rankV = [[UIView alloc] initWithFrame:CGRectMake(0, 127, kScreen_Width,40)];
    rankV.backgroundColor = [UIColor whiteColor];
    [self.headView addSubview:rankV];
    
    UIImageView*cupV = [[UIImageView alloc] initWithFrame:CGRectMake(15, 8, 21, 21)];
    cupV.image = [UIImage imageNamed:@"data_trophy_icon"];
    [rankV addSubview:cupV];

    UILabel*cupL = [UILabel new];
    cupL.textColor = ColorSubTitle;
    cupL.font = GetFont(14);
    [rankV addSubview:cupL];
    cupL.text = @"足球世界排名和俱乐部排名";
    [cupL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.mas_equalTo(cupV);
        make.left.mas_equalTo(cupV.mas_right).offset(10);
    }];
    
    UIImageView*arowV = [UIImageView new];
    [rankV addSubview:arowV];
    [arowV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.mas_equalTo(rankV).offset(-10);
        make.centerY.mas_equalTo(rankV);
        make.size.mas_equalTo(CGSizeMake(14, 14));
    }];
    [arowV setImage:[UIImage imageNamed:@"go_arrow"]];
    
    rankV.userInteractionEnabled = YES;
    UITapGestureRecognizer*tap =  [[UITapGestureRecognizer
                                    alloc] initWithTarget:self action:@selector(showRank)];
    [rankV addGestureRecognizer:tap];
    
    UIView*allV = [[UIView alloc] initWithFrame:CGRectMake(0, 173
                                                           , kScreen_Width, 30)];
    allV.backgroundColor = [UIColor whiteColor];
    [self.headView addSubview:allV];
    UILabel*allL = [[UILabel alloc] initWithFrame:CGRectMake(15, 178, kScreen_Width-30, 20)];
    allL.text = @"全部赛事";
    allL.font = GetFont(14);
    allL.textColor = ColorSubTitle;
    matchL.textAlignment = NSTextAlignmentLeft;
    [self.headView addSubview:allL];
    
    
    UICollectionViewFlowLayout*layout=[[UICollectionViewFlowLayout alloc]init];
    
    self.allCollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(kScreen_Width*0.25, 204,kScreen_Width*0.75, kScreen_Height - NavBarHeight - 192-kBottomSafeArea-60) collectionViewLayout:layout];
    self.allCollectionView.backgroundColor=[UIColor whiteColor];
    self.allCollectionView.showsHorizontalScrollIndicator=NO;
    self.allCollectionView.tag = 1993;
    layout.scrollDirection=UICollectionViewScrollDirectionVertical;
    layout.minimumInteritemSpacing=8;
    layout.minimumLineSpacing = 10;
    layout.itemSize=CGSizeMake((kScreen_Width*0.75-80)/3 - 0.1,(kScreen_Width*0.75-80)/3+20);
    self.allCollectionView.delegate=self;
    self.allCollectionView.dataSource=self;
    [self.allCollectionView registerClass:[DataHomeCollectionViewCell class] forCellWithReuseIdentifier:@"DataHomeCollectionViewCell"];
    
    [self.headView addSubview:self.allCollectionView];
    
    UICollectionViewFlowLayout*layoutHot=[[UICollectionViewFlowLayout alloc]init];
    
    self.hotCollectionView=[[UICollectionView alloc]initWithFrame:CGRectMake(0,36,kScreen_Width,85) collectionViewLayout:layoutHot];
    self.hotCollectionView.backgroundColor=[UIColor whiteColor];
    self.hotCollectionView.showsHorizontalScrollIndicator=NO;
    self.hotCollectionView.tag = 1994;
    layoutHot.scrollDirection=UICollectionViewScrollDirectionHorizontal;
    layoutHot.minimumInteritemSpacing=0;
    layoutHot.minimumLineSpacing = 0;
    layoutHot.itemSize=CGSizeMake(hotWidth,hotWidth+10);
    self.hotCollectionView.delegate=self;
    self.hotCollectionView.dataSource=self;
    [self.hotCollectionView registerClass:[HotLeagueCollectionViewCell class] forCellWithReuseIdentifier:@"HotLeagueCollectionViewCell"];
    
    [self.headView addSubview:self.hotCollectionView];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
}

-(void)setupButtonV{
    [self.buttonV removeFromSuperview];
    self.buttonV = [[UIView alloc] initWithFrame:CGRectMake(0, 204, kScreen_Width*0.25-1, kScreen_Height - NavBarHeight - 192-kBottomSafeArea)];
    [self.headView addSubview:self.buttonV];
    self.buttonV.backgroundColor = [UIColor whiteColor];
    NSArray*arr = @[@"国际",@"欧洲",@"美洲",@"亚洲",@"大洋洲",@"非洲"];
   
	if (self.dataSource.count < 6) {
		return;
	}
    for (int i = 0; i<6; i++) {
        UIButton*button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 40*i, kScreen_Width*0.25-1, 40)];
        [self.buttonV addSubview:button];
        [button addTarget:self action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
        MatchEvents*model = self.dataSource[i];
        [button setTitle:arr[model.areaId.intValue] forState:UIControlStateNormal];
        button.titleLabel.font = GetFont(12.0f);
        button.tag = 2000+i;
        if (markButton) {
            NSInteger markNum = markButton.tag - 2000;
            if (markNum != 0 ) {
                if (i == markNum) {
                    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                    [button setBackgroundColor:ColorAppRed];
                    button.selected = YES;
                    markButton = button;
                }else{
                    [button setTitleColor:ColorSubTitle forState:UIControlStateNormal];
                    [button setBackgroundColor:[UIColor whiteColor]];
                    button.selected = NO;
                }
            }else{
                if (i != markNum) {
                    [button setTitleColor:ColorSubTitle forState:UIControlStateNormal];
                    [button setBackgroundColor:[UIColor whiteColor]];
                    button.selected = NO;
                }else{
                    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                    [button setBackgroundColor:ColorAppRed];
                    button.selected = YES;
                    markButton = button;
                }
            }
        }else{
            if (i == 0) {
                [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                [button setBackgroundColor:ColorAppRed];
                button.selected = YES;
                markButton = button;
            }else{
                [button setTitleColor:ColorSubTitle forState:UIControlStateNormal];
                [button setBackgroundColor:[UIColor whiteColor]];
                button.selected = NO;
            }
        }
        
        
//        }
       
        
    }
}

#pragma mark 滚动特效
-(void)setAutoScroll:(BOOL)autoScroll{
    _autoScroll = autoScroll;
    [_timer invalidate];
    _timer = nil;
    
    if (_autoScroll) {
        [self setupTimer];
    }
}
- (void)setupTimer
{
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(automaticScroll) userInfo:nil repeats:YES];
    _timer = timer;
    [[NSRunLoop mainRunLoop] addTimer:timer forMode:NSRunLoopCommonModes];
}
-(void)automaticScroll{
    
    if (hotWidth*self.hotDataSource.count < kScreen_Width) return;
     int currentIndex = (self.hotCollectionView.contentOffset.x + hotWidth -1 )/ hotWidth;
    int targetIndex = currentIndex + (kScreen_Width+hotWidth-1)/hotWidth;
    if (targetIndex >= self.totalItemsCount) {
        targetIndex = self.hotDataSource.count * 0.5;
        [self.hotCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
        return;
    }
    [self.hotCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:targetIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:YES];
}
    
- (void)willMoveToSuperview:(UIView *)newSuperview
{
    if (!newSuperview) {
        [_timer invalidate];
        _timer = nil;
    }
}
#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	if ([scrollView isEqual:self.hotCollectionView]) {
		return;
	}
    CGPoint offset = self.tableView.contentOffset;
    if (offset.y >= 0) {
        offset.y = 0;
    }
    self.tableView.contentOffset = offset;
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    
        [_timer invalidate];
        _timer = nil;
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    
        [self setupTimer];
    
}

- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView
{
    
}
#pragma mark collection代理
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section

{
    if (collectionView.tag == 1993) {
         return UIEdgeInsetsMake(10, 20,10, 20);//分别为上、左、下、右
    }else{
         return UIEdgeInsetsMake(0, 0,0,0);//分别为上、左、下、右
    }

}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
     if (collectionView.tag == 1993) {
        NSInteger i = markButton.tag - 2000;
        if (self.dataSource.count>=i+1) {
            MatchEvents*modle = self.dataSource[i];
            return modle.countries.count;
        }else{
            return 0;
        }
     }else{
         return self.totalItemsCount;
     }
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView.tag == 1993) {
        static NSString *cellID = @"DataHomeCollectionViewCell";
        DataHomeCollectionViewCell*cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
        if (!cell) {
            cell= [[DataHomeCollectionViewCell alloc] init];
        }
        dispatch_main_async_safe(^{
            NSInteger i = markButton.tag - 2000;
            if (self.dataSource.count>=i+1) {
                MatchEvents*modle = self.dataSource[i];
                cell.model = modle.countries[indexPath.row];
            }
        });
         return cell;
    }else{
        static NSString *cellID = @"HotLeagueCollectionViewCell";
        HotLeagueCollectionViewCell*cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
        if (!cell) {
            cell= [[HotLeagueCollectionViewCell alloc] init];
        }
        
        
            League*model = self.hotDataSource[(indexPath.row%self.hotDataSource.count)];
            cell.model = model;
        
        return cell;
    }
    
   
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (collectionView.tag == 1993) {
        DataHomeCollectionViewCell*cell = (DataHomeCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        [LeagueChooseView showWithModle:cell.model andBlock:^(League * _Nonnull league) {
            //弹出联赛详情
            dispatch_main_async_safe(^{
                LeagueViewController *leagueVc = [LeagueViewController new];
                leagueVc.leagueId = league.m_id.integerValue;
                [self.navigationController pushViewController:leagueVc animated:YES];
            });
        }];
        
    }else{
        League*league = self.hotDataSource[indexPath.row%self.hotDataSource.count];
        //弹出联赛详情
        dispatch_main_async_safe(^{
            LeagueViewController *leagueVc = [LeagueViewController new];
            leagueVc.leagueId = league.m_id.integerValue;
            [self.navigationController pushViewController:leagueVc animated:YES];
        });
    }
}

-(void)clickButton:(UIButton*)button{
    if (button.selected||markButton == button) {
        return;
    }
    
    dispatch_main_async_safe(^{
        [markButton setTitleColor:ColorSubTitle forState:UIControlStateNormal];
        [markButton setBackgroundColor:[UIColor whiteColor]];
        markButton.selected = NO;
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button setBackgroundColor:ColorAppRed];
        button.selected = YES;
        markButton = button;
        [self.allCollectionView reloadData];
    });
    
}
-(void)showRank{
    WorldRankingViewController*vc = [WorldRankingViewController new];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)loadData{
    
    [ESNetworkService allEventsResponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				[self.tableView.mj_header endRefreshing];
			});
            NSDictionary*data = dict[@"data"];
			if (!QM_IS_DICT_NIL(data)) {
                dispatch_main_async_safe(^{
					[self.dataSource removeAllObjects];
					NSArray*arr = data[@"footballAreas"];
					for (NSDictionary*model_dic in arr) {
						MatchEvents*model = [MatchEvents mj_objectWithKeyValues:model_dic];
						[self.dataSource addObject:model];
					}
                    [self.allCollectionView reloadData];
                    [self setupButtonV];
                });
            }
        }
    }];
    
    [ESNetworkService hotEventsResponse:^(id dict, ESError *error) {
        if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				[self.tableView.mj_header endRefreshing];
			});
            NSDictionary*data = dict[@"data"];
            if (!QM_IS_DICT_NIL(data)) {
                dispatch_main_async_safe(^{
					[self.hotDataSource removeAllObjects];
					NSArray*arr = data[@"hotLeagues"];
					for (NSDictionary*model_dic in arr) {
						League*model = [League mj_objectWithKeyValues:model_dic];
						[self.hotDataSource addObject:model];
						
					}
                    [self.hotCollectionView reloadData];
                    if (self.hotDataSource.count*hotWidth>kScreen_Width) {
                        self.autoScroll = YES;
                        self.totalItemsCount = self.hotDataSource.count*200;
                        [self.hotCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:self.totalItemsCount*0.5 inSection:0] atScrollPosition:UICollectionViewScrollPositionNone animated:NO];
                    }else{
                        self.autoScroll = NO;
                        self.totalItemsCount = self.hotDataSource.count;
                    }
                });
            }
        }
    }];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
	[ESNetworkService customPostionCode:@"004"];
}
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
}

#pragma mark - searchBar delegate
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar {
	DataSearchViewController*vc = [DataSearchViewController new];
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
	return NO;
}

#pragma mark - lazy init
-(UISearchBar*)searchBar
{
	if (!_searchBar) {
		_searchBar=[[UISearchBar alloc] initWithFrame:CGRectMake(10, NavBarHeight-40,kScreen_Width-70, 30)];
		
		_searchBar.placeholder=@"搜索赛事、球队或球员";
		//searchBar内部背景
		
		if(@available(iOS 13.0, *)) {
			_searchBar.searchTextField.backgroundColor = [UIColor colorWithHexString:@"#EBEBEB"];
		}else{
			UITextField *txfSearchField = [_searchBar valueForKey:@"_searchField"];
			txfSearchField.backgroundColor = [UIColor colorWithHexString:@"#EBEBEB"];
		}
		
		
		_searchBar.backgroundColor=[UIColor clearColor];
		_searchBar.backgroundImage=[[UIImage alloc]init];
		_searchBar.delegate = self;
	}
	return _searchBar;
}

@end
