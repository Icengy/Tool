//
//  PayViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface PayViewController : ESViewController

@end

NS_ASSUME_NONNULL_END
