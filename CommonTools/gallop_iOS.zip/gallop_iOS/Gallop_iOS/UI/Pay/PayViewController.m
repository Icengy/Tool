//
//  PayViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/6/13.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "PayViewController.h"
#import "CoinPrice.h"
#import "PayWay.h"
#import "AccountDetailViewController.h"
#import "IAPManager.h"
#import <CommonCrypto/CommonDigest.h>
#import "GTMBase64.h"

#import "UIBarButtonItem+CreateExt.h"

static int apple_pay = 1;
@interface PayViewController ()
{
    int money;
    NSMutableArray*coinArr;
    NSMutableArray*wayArr;
}
@property (nonatomic, strong) UIScrollView*customScrollerView;
@property (nonatomic,strong) UIView*accountV;
@property (nonatomic,strong) UIView*selectMoenyV;
@property (nonatomic,strong) UIView*selectPayV;
/**accountV**/
@property (nonatomic,strong) UILabel*accountL;
@property (nonatomic,strong) UILabel*unabelL;
/**selectMoneyV**/
@property (nonatomic,strong) UILabel*selectL;
-(void)creatMoneyLabels;
-(void)didSelectMoneyLabel:(UITapGestureRecognizer*)tap;
@property (nonatomic,assign) NSInteger selectedMoeny;
/**selectPayV**/
@property (nonatomic,strong) UILabel*fangshiL;
@property (nonatomic,strong) UIButton*wayB1;
@property (nonatomic,strong) UILabel*wayL1;
@property (nonatomic,strong) UIImageView*wayV1;
@property (nonatomic,strong) UIButton*wayB2;
@property (nonatomic,strong) UILabel*wayL2;
@property (nonatomic,strong) UIImageView*wayV2;
@property (nonatomic,strong) UIButton*payButton;
@property (nonatomic, assign) NSInteger selectedWay;


/**applepay**/
@property (nonatomic,strong) IAPManager *iapManager;


@property (nonatomic,strong) UIView*tishiV;
@property (nonatomic,strong) UILabel*tishiL;
@property (nonatomic,strong) UILabel*tishi1L;
@property (nonatomic,strong) UILabel*tishi2L;
@property (nonatomic,strong) UILabel*tishi3L;


-(void)didSelectWay:(UIButton*)button;
-(void)pay:(UIButton*)button;

@end

@implementation PayViewController


-(UIButton*)payButton
{
    if(!_payButton){
        _payButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_payButton setBackgroundColor:ColorAppRed];
        [_payButton setTitle:@"充值" forState:UIControlStateNormal];
        _payButton.layer.cornerRadius = 4.0f;
        _payButton.titleLabel.font = GetFont(14.0f);
        _payButton.clipsToBounds = YES;
        [_payButton addTarget:self action:@selector(pay:) forControlEvents:UIControlEventTouchUpInside];
        [self.selectPayV addSubview:_payButton];
    }
    return _payButton;
}
-(UIImageView*)wayV2
{
    if (!_wayV2) {
        _wayV2 = [UIImageView new];
        _wayV2.layer.cornerRadius = 15.0f;
        _wayV2.clipsToBounds = YES;
        [self.wayB2 addSubview:_wayV2];
    }
    return _wayV2;
}
-(UILabel*)wayL2
{
    if (!_wayL2) {
        _wayL2 = [UILabel new];
        _wayL2.textColor = ColorTitle;
        _wayL2.font = GetFont(12.0f);
        [self.wayB2 addSubview:_wayL2];
    }
    return _wayL2;
}
-(UIImageView*)wayV1
{
    if (!_wayV1) {
        _wayV1 = [UIImageView new];
        _wayV1.layer.cornerRadius = 15.0f;
        _wayV1.clipsToBounds = YES;
        [self.wayB1 addSubview:_wayV1];
    }
    return _wayV1;
}
-(UILabel*)wayL1
{
    if (!_wayL1) {
        _wayL1 = [UILabel new];
        _wayL1.textColor = ColorTitle;
        _wayL1.font = GetFont(12.0f);
        [self.wayB1 addSubview:_wayL1];
    }
    return _wayL1;
}
-(UIButton*)wayB2
{
    if(!_wayB2){
        _wayB2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_wayB2 addTarget:self action:@selector(didSelectWay:) forControlEvents:UIControlEventTouchUpInside];
        _wayB2.layer.borderColor = ColorGrayBack.CGColor;
        _wayB2.layer.cornerRadius = 4;
        _wayB2.layer.borderWidth = 1;
        _wayB2.clipsToBounds = YES;
        _wayB2.tag = 1001;
        [self.selectPayV addSubview:_wayB2];
    }
    return _wayB2;
}
-(UIButton*)wayB1
{
    if(!_wayB1){
        _wayB1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [_wayB1 addTarget:self action:@selector(didSelectWay:) forControlEvents:UIControlEventTouchUpInside];
        _wayB1.layer.borderColor = ColorGrayBack.CGColor;
        _wayB1.layer.borderWidth = 1;
        _wayB1.layer.cornerRadius = 4;
        _wayB1.clipsToBounds = YES;
        _wayB1.tag = 1000;
        [self.selectPayV addSubview:_wayB1];
    }
    return _wayB1;
}
-(UILabel*)fangshiL
{
    if (!_fangshiL) {
        _fangshiL = [UILabel new];
        _fangshiL.textColor = ColorTitle;
        _fangshiL.font = GetFont(14.0f);
        [self.selectPayV addSubview:_fangshiL];
    }
    return _fangshiL;
}
-(UILabel*)selectL
{
    if (!_selectL) {
        _selectL = [UILabel new];
        _selectL.textColor = ColorTitle;
        _selectL.font = GetFont(14.0f);
        [self.selectMoenyV addSubview:_selectL];
    }
    return _selectL;
}
-(UILabel*)unabelL
{
    if (!_unabelL) {
        _unabelL = [UILabel new];
        _unabelL.textColor = ColorSubTitle;
        _unabelL.font = GetFont(10.0f);
        [self.accountV addSubview:_unabelL];
    }
    return _unabelL;
}

-(UILabel*)accountL
{
    if (!_accountL) {
        _accountL = [UILabel new];
        _accountL.textColor = [UIColor colorWithHexString:@"#FFA847"];
        _accountL.font = GetFont(14.0f);
        [self.accountV addSubview:_accountL];
    }
    return _accountL;
}

-(UIView*)accountV
{
    if (!_accountV) {
        _accountV = [[UIView alloc] init];
        _accountV.backgroundColor = [UIColor whiteColor];
        [self.customScrollerView addSubview:_accountV];
    }
    return _accountV;
}
-(UIView*)selectMoenyV
{
    if (!_selectMoenyV) {
        _selectMoenyV = [[UIView alloc] init];
        _selectMoenyV.backgroundColor = [UIColor whiteColor];
        [self.customScrollerView addSubview:_selectMoenyV];
    }
    return _selectMoenyV;
}
-(UIView*)selectPayV
{
    if (!_selectPayV) {
        _selectPayV = [[UIView alloc] init];
        _selectPayV.backgroundColor = [UIColor whiteColor];
        [self.customScrollerView addSubview:_selectPayV];
    }
    return _selectPayV;
}
-(UIView*)tishiV
{
    if (!_tishiV) {
        _tishiV = [[UIView alloc] init];
        [self.customScrollerView addSubview:_tishiV];

    }
    return _tishiV;
}
-(UILabel*)tishi1L
{
    if (!_tishi1L) {
        _tishi1L = [UILabel new];
        _tishi1L.textColor = ColorSubTitle;
        _tishi1L.font = GetFont(12.0f);
        _tishi1L.numberOfLines = 0;
        _tishi1L.preferredMaxLayoutWidth = kScreen_Height;
        [_tishi1L setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
        _tishi1L.textAlignment = NSTextAlignmentLeft;
        [self.tishiV addSubview:_tishi1L];
    }
    return _tishi1L;
}
-(UILabel*)tishi2L
{
    if (!_tishi2L) {
        _tishi2L = [UILabel new];
        _tishi2L.textColor = ColorSubTitle;
        _tishi2L.font = GetFont(12.0f);
        _tishi2L.numberOfLines = 0;
        _tishi2L.preferredMaxLayoutWidth = kScreen_Height;
        [_tishi2L setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
        _tishi2L.textAlignment = NSTextAlignmentLeft;
        [self.tishiV addSubview:_tishi2L];
    }
    return _tishi2L;
}
-(UILabel*)tishi3L
{
    if (!_tishi3L) {
        _tishi3L = [UILabel new];
        _tishi3L.textColor = ColorSubTitle;
        _tishi3L.font = GetFont(12.0f);
        _tishi3L.numberOfLines = 0;
        _tishi3L.preferredMaxLayoutWidth = kScreen_Height;
        [_tishi3L setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisVertical];
        _tishi3L.textAlignment = NSTextAlignmentLeft;
        [self.tishiV addSubview:_tishi3L];
    }
    return _tishi3L;
}
-(UILabel*)tishiL
{
    if (!_tishiL) {
        _tishiL = [UILabel new];
        _tishiL.textColor = ColorSubTitle;
        _tishiL.font = GetFont(12.0f);
        _tishiL.textAlignment = NSTextAlignmentLeft;
        [self.tishiV addSubview:_tishiL];
    }
    return _tishiL;
}
-(UIScrollView*)customScrollerView
{
    if (!_customScrollerView) {
        _customScrollerView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, kScreen_Width, kScreen_Height)];
        _customScrollerView.backgroundColor = ColorGrayBack;
        [self.view addSubview:_customScrollerView];
    }
    return _customScrollerView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    coinArr = [NSMutableArray arrayWithCapacity:0];
    wayArr = [NSMutableArray arrayWithCapacity:0];
    self.selectedMoeny = -1;
    self.selectedWay = -1;
    [self setupViews];
    [self loadData];
    __weak __typeof(self)weakSelf = self;
   
    // Do any additional setup after loading the view.
    [weakSelf loadData];
}
-(void)detailShow:(UIButton*)button
{
//    [CMMUtility showToastWithText:@"显示明细"];
    AccountDetailViewController*vc = [AccountDetailViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void)setupViews{
    __weak PayViewController*weakSelf = self;
    self.navigationItem.title = @"充值";
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem createBarItemWithTitle:@"明细" titleColor:ColorMainAppRed target:self action:@selector(detailShow:)];
    
    [self.accountV setFrame:CGRectMake(0, 0, kScreen_Width, 60)];
    [self.accountL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.accountV).offset(15);
        make.top.mas_equalTo(weakSelf.accountV).offset(10);
       make.height.mas_equalTo(20);
    }];
    [self.unabelL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.accountV).offset(15);
        make.bottom.mas_equalTo(weakSelf.accountV).offset(-10);
    }];
    [self.selectMoenyV setFrame:CGRectMake(0, 65, kScreen_Width, 30)];
    [self.selectL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.selectMoenyV).offset(15);
        make.top.mas_equalTo(weakSelf.selectMoenyV).offset(10);
        make.height.mas_equalTo(20);
    }];

    
    [self.selectPayV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(weakSelf.view).offset(0);
        make.top.mas_equalTo(weakSelf.selectMoenyV.mas_bottom).offset(5);
        make.bottom.mas_equalTo(weakSelf.view).offset(0);
    }];
    [self.fangshiL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.selectPayV).offset(15);
        make.top.mas_equalTo(weakSelf.selectPayV).offset(10);
        make.height.mas_equalTo(20);
    }];
    [self.wayB1 setFrame:CGRectMake(15, 40, (kScreen_Width-55)*0.5, 45)];
    [self.wayB2 setFrame:CGRectMake(15+25+(kScreen_Width-55)*0.5, 40, (kScreen_Width-55)*0.5, 45)];
    [self.wayV1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.wayB1).offset(8);
        make.centerY.mas_equalTo(weakSelf.wayB1);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [self.wayL1 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.wayV1.mas_right).offset(20);
         make.centerY.mas_equalTo(weakSelf.wayB1);
    }];
    [self.wayV2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.wayB2).offset(8);
        make.centerY.mas_equalTo(weakSelf.wayB2);
        make.size.mas_equalTo(CGSizeMake(30, 30));
    }];
    [self.wayL2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.wayV2.mas_right).offset(20);
        make.centerY.mas_equalTo(weakSelf.wayB2);
    }];
    
    [self.payButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(weakSelf.selectPayV).offset(15);
        make.right.mas_equalTo(weakSelf.selectPayV).offset(-15);
        make.top.mas_equalTo(weakSelf.wayB1.mas_bottom).offset(30);
        make.height.mas_equalTo(40);
    }];
    self.wayB1.hidden = YES;
    self.wayB2.hidden = YES;
    self.payButton.hidden = YES;
    

    
    
    [self.tishiV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.mas_equalTo(weakSelf.view).offset(0);
        make.top.mas_equalTo(weakSelf.selectMoenyV.mas_bottom).offset(5);
        make.bottom.mas_equalTo(weakSelf.view).offset(0);
    }];
    
    [self.tishiL mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.tishiV).offset(20);
        make.top.mas_equalTo(self.tishiV).offset(10);
        make.right.mas_equalTo(self.tishiV).offset(-20);
    }];
    [self.tishi1L mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.tishiL.mas_bottom).offset(10);
        make.left.mas_equalTo(self.tishiV).offset(20);
        make.right.mas_equalTo(self.tishiV).offset(-20);
    }];
    [self.tishi2L mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.tishi1L.mas_bottom).offset(2);
        make.left.mas_equalTo(self.tishiV).offset(20);
        make.right.mas_equalTo(self.tishiV).offset(-20);
    }];
    [self.tishi3L mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.tishi2L.mas_bottom).offset(2);
        make.left.mas_equalTo(self.tishiV).offset(20);
        make.right.mas_equalTo(self.tishiV).offset(-20);
    }];
    self.tishiL.text = @"温馨提示：";
    self.tishi1L.text = @"1，飞驰币充值成功后不支持提现";
    self.tishi2L.text = @"2，若出现充值问题，请在\"我的\"页面点击\"联系客服\"";
    self.tishi3L.text = @"3，苹果充值需要缓冲时间，请耐心等待";

}
-(void)pay:(UIButton *)button
{

    
}
//encode
- (NSString*)encodeValue:(NSString*)value
{
    NSString* encodedValue = value;
    if (value.length > 0) {
        NSCharacterSet *charset = [[NSCharacterSet characterSetWithCharactersInString:@"!*'();:@&=+$,/?%#[]\"{} "]invertedSet];
        encodedValue = [value stringByAddingPercentEncodingWithAllowedCharacters:charset];
    }
    return encodedValue;
}
-(void)refreshPayViews{
    self.fangshiL.text = @"支付方式";
    NSArray*nameArr = @[@"",@""];
    NSArray*wayVarr = @[self.wayV1,self.wayV2];
    NSArray*titleArr = @[self.wayL1,self.wayL2];
    self.wayB1.hidden = YES;
    self.wayB2.hidden = YES;
    NSArray*buttonArr = @[self.wayB1,self.wayB2];
    for (int i = 0; i<wayArr.count; i++) {
        PayWay*model = wayArr[i];
        UILabel*label = titleArr[i];
        UIImageView*imageV = wayVarr[i];
        label.text = model.payName;
        imageV.image = [UIImage imageNamed:nameArr[model.payType.intValue -1]];
        UIButton*button  = buttonArr[i];
        button.hidden = NO;
    }
    self.payButton.hidden = NO;
    [self.payButton setTitle:@"充值" forState:UIControlStateNormal];
    
    if (apple_pay == 1) {
         self.payButton.hidden = YES;
        self.wayB1.hidden = YES;
        self.wayB2.hidden = YES;
        self.fangshiL.hidden = YES;
    }
    
}
-(void)didSelectWay:(UIButton *)button
{
   
    if (self.selectedWay == -1) {
        self.selectedWay = button.tag - 1000;
        button.layer.borderColor = ColorAppRed.CGColor;
    }else{
        for (UIView*view in self.selectPayV.subviews) {
            if (view.tag == 1000+self.selectedWay) {
                view.layer.borderColor = ColorGrayBack.CGColor;
            }
        }
        button.layer.borderColor = ColorAppRed.CGColor;
        self.selectedWay = button.tag - 1000;
    }
}
-(void)refreshViews{
    self.accountL.text = [NSString stringWithFormat:@"当前飞驰币：%d",money];
    self.unabelL.text = @"充值的飞驰币不可提现";
    self.selectL.text = @"充值选择";
    [self creatMoneyLabels];
}
-(void)creatMoneyLabels
{
    NSInteger line = (coinArr.count+2)/3;
    CGFloat height = 30+ 10 +15 + line*40+(line-1)*15;
    [self.selectMoenyV setFrame:CGRectMake(0, 65, kScreen_Width, height)];
    CGFloat width = (kScreen_Width-40-30)*0.333;
    for (int i = 0; i<coinArr.count; i++) {
        CoinPrice*model = coinArr[i];
        int a = i%3;
        int b = i/3;
        UILabel*label = [[UILabel alloc] initWithFrame:CGRectMake(15+a*width+a*20, 30+10+b*40+b*15, width, 40)];
        label.layer.borderWidth = 1;
        label.font = GetFont(11.0);
        label.layer.borderColor = ColorGrayBack.CGColor;
        label.numberOfLines =3;
        label.textColor = ColorTitle;
        label.layer.cornerRadius = 4;
        label.clipsToBounds = YES;
        label.textAlignment = NSTextAlignmentCenter;
        
        label.text = [NSString stringWithFormat:@"%d飞驰币\n%d元",model.gallopAmount.intValue,model.payMoney.intValue];
        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:label.text];
        NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
        paragraphStyle.alignment = NSTextAlignmentCenter;
//        paragraphStyle.maximumLineHeight = 60;  //最大的行高
        paragraphStyle.lineSpacing = 5;  //行自定义行高度
        [attributedString addAttribute:NSParagraphStyleAttributeName value:paragraphStyle range:NSMakeRange(0, label.text.length)];
        label.attributedText = attributedString;
        label.tag = i+3000;
        label.userInteractionEnabled = YES;
        UITapGestureRecognizer*tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didSelectMoneyLabel:)];
        [label addGestureRecognizer:tap];
        [self.selectMoenyV addSubview:label];
        
    }
    
}
-(void)didSelectMoneyLabel:(UITapGestureRecognizer *)tap {
    [CMMUtility showWaitingAlertView];
    UILabel*label = (UILabel *)tap.view;
    self.selectedMoeny = label.tag - 3000;
    CoinPrice*price = coinArr[self.selectedMoeny];
    
    NSString*productId = [NSString stringWithFormat:@"com.gallop.bifen_coin%ld",price.payMoney.integerValue];
    
    if (apple_pay == 1) {
        [ESNetworkService applePrechargeWithMoney:price.payMoney Response:^(id dict, ESError *error) {
            if (dict&&[dict[@"code"] integerValue] == 0) {
                NSDictionary*data = dict[@"data"];
                NSNumber*orderId = data[@"orderId"];
                if (!_iapManager) {
                    _iapManager = [[IAPManager alloc] init];
                }
                _iapManager.orderId = orderId;
                [_iapManager startPurchWithID:productId completeHandle:^(IAPPurchType type,NSData *receipt,NSString *transactionId) {
                    //将data给后台进行校验，等回台返回代码
                    if (type == kIAPPurchSuccess) {
                        NSString*str = [NSString stringWithFormat:@"orderId=%@&&transactionId=%@",orderId.stringValue,transactionId];
                        
                        NSString*encrypt = [DES3Util getDESEncrypt:str withKey:payKey];
                        
                        [ESNetworkService appleVerityWithReceipt:[receipt base64EncodedStringWithOptions:0] Type:!SandBox ReceiptToken:encrypt Response:^(id dict, ESError *error) {
                            
                            [CMMUtility hideWaitingAlertView];
                            [ES_LPUnitily removeHUDToCurrentView];
                            
                            if (dict&&[dict[@"code"] integerValue] == 0) {
                                NSArray*cArr = [[NSUserDefaults standardUserDefaults] objectForKey:kUnfinishedTradeArr];
                                if (!QM_IS_ARRAY_NIL(cArr)) {
                                    NSMutableArray*mArr = [NSMutableArray arrayWithArray:cArr];
                                    [mArr enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                                        NSDictionary*cDic = obj;
                                        NSString*encrypt = cDic[@"receiptToken"];
                                        NSString*str = [DES3Util getDESDecrypt:encrypt withKey:payKey];
                                        NSArray*pramArr = [str componentsSeparatedByString:@"&&"];
                                        NSString*orStr = pramArr[0];
                                        NSString*cOrderId = [orStr componentsSeparatedByString:@"="][1];
                                        
                                        if (orderId.longLongValue == cOrderId.longLongValue) {
                                            [mArr removeObject:cDic];
                                        }
                                    }];
                                    [[NSUserDefaults standardUserDefaults] setObject:[mArr copy] forKey:kUnfinishedTradeArr];
                                    [[NSUserDefaults standardUserDefaults] synchronize];
                                    
                                    [CMMUtility showToastWithText:@"购买成功"];
                                    [self loadData];
                                }
                            }
                        }];
                    }else {
                        [CMMUtility hideWaitingAlertView];
                        [ES_LPUnitily removeHUDToCurrentView];
                        switch (type) {
                            case kIAPPurchFailed:
                                [CMMUtility showToastWithText:@"购买失败"];
                                break;
                            case kIAPPurchCancle:
                                [CMMUtility showToastWithText:@"购买取消"];
                                break;
                            case KIAPPurchVerFailed:
                                [CMMUtility showToastWithText:@"订单校验失败"];
                                break;
                            case kIAPPurchNotArrow:
                                [CMMUtility showToastWithText:@"未开启应用内付费购买功能"];
                                break;
                                
                            default:
                                break;
                        }
                    }
                }];
            }
        }];
        
    }
}

-(void)loadData{
    @weakify(self);
    [ESNetworkService payInfoResponse:^(id dict, ESError *error) {
        @strongify(self);
        [self->coinArr removeAllObjects];
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSDictionary*data = dict[@"data"];
            self->money = [data[@"gallopAmount"] intValue];
            NSArray*list = data[@"rechageTypeList"];
            for (NSDictionary*coinDic in list) {
                CoinPrice*modle = [CoinPrice mj_objectWithKeyValues:coinDic];
                [self->coinArr addObject:modle];
            }
            dispatch_main_async_safe(^{
                [self refreshViews];
            });
        }
    }];
    [ESNetworkService payWayWithResponse:^(id dict, ESError *error) {
        @strongify(self);
        if (dict&&[dict[@"code"] integerValue] == 0) {
            NSDictionary*data = dict[@"data"];
            [self->wayArr removeAllObjects];
            for (NSDictionary*wayDic in data) {
                PayWay*modle = [PayWay mj_objectWithKeyValues:wayDic];
                if (modle.iosStatus.intValue != 0) {
                    [self->wayArr addObject:modle];
                }
            }
            dispatch_main_async_safe(^{
                [self refreshPayViews];
            });
        }
    }];
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self loadData];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
