//
//  CommunityTopicDetailViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/30.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityTopicDetailViewController.h"
#import "CommunityPostViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityHomePageViewController.h"
#import "PointExtenButton.h"
#import "NavButton.h"
#import "CommunityTopicDetailCell.h"
#import "SureCustomActionSheet.h"

#define kPageSize 20

@interface CommunityTopicDetailViewController ()<CommunityTopicDetailCellDelegate>
@property (nonatomic,strong) PointExtenButton 	*backBtn;
@property (nonatomic,strong) UIImageView 				*headView;
@property (nonatomic,strong) UILabel 			*topicTitleLabel;
@property (nonatomic,strong) PointExtenButton 	*focusBtn;
@property (nonatomic,strong) UILabel			*topicDetailLabel;
@property (nonatomic,strong) UIView				*selectedLine;
@property (nonatomic,strong) UIView				*seperatorLine;

@property (nonatomic,strong) NavButton	*postBtn;

@property (nonatomic,assign) CGFloat oldY;
@property (nonatomic,assign) NSUInteger currentPage;
@property (nonatomic,strong) NSMutableArray<PointExtenButton *>		*segmentBtnArr;
@property (nonatomic,assign) NSUInteger	currentSegment;//排序类型，1：最新回复，2：最新发帖，3：精选
@end

@implementation CommunityTopicDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	[self setupView];
	[self loadHeadInfo];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	if (self.headView.hidden == YES) {
		self.navigationController.navigationBarHidden = NO;
	}
}

- (void)setupView {
	self.fd_prefersNavigationBarHidden = YES;
	[self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.view);
		make.height.mas_equalTo(154 + kStatusBarHeight);
	}];
	[self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.view).offset(15);
		make.top.equalTo(self.headView).offset(18 + kStatusBarHeight);
		make.size.mas_equalTo(CGSizeMake(22, 22));
	}];
	[self.topicTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.backBtn.mas_bottom).offset(15);
		make.left.equalTo(self.headView).offset(15);
	}];
	[self.focusBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.headView).offset(-15);
		make.centerY.equalTo(self.topicTitleLabel);
		make.size.mas_equalTo(CGSizeMake(54, 24));
	}];
	[self.topicDetailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.topicTitleLabel.mas_bottom).offset(16);
		make.left.equalTo(self.headView).offset(15);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH - 30, 42.5));
	}];
	
	[self.segmentBtnArr[0] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headView.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(80, 44.5));
		make.centerX.equalTo(self.view).offset(-62);
	}];
	
	[self.segmentBtnArr[1] mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headView.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(80, 44.5));
		make.centerX.equalTo(self.view).offset(62);
	}];
	
	[self.selectedLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.segmentBtnArr[0]);
		make.size.mas_equalTo(CGSizeMake(60, 4));
		make.bottom.equalTo(self.segmentBtnArr[0]).offset(-4);
	}];
	
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.selectedLine.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 1));
	}];
	
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.bottom.equalTo(self.view);
		make.top.equalTo(self.seperatorLine.mas_bottom);
	}];

    self.tableView.contentInset = kTableViewDetailtContentInset;
	[self.tableView registerClass:[CommunityTopicDetailCell class] forCellReuseIdentifier:@"CommunityTopicDetailCell"];
	
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self.tableView.mj_header beginRefreshing];
	
	[self.postBtn setFrame:CGRectMake(kScreen_Width - 65, kScreen_Height-TabBarHeight-65, 45, 45)];
}

- (void)loadHeadInfo {
	@weakify(self)
	[ESNetworkService getCommunityTopicDetailInfoWithTopicId:self.topicId Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			CommunityTopicDetailInfo *model = [CommunityTopicDetailInfo mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				[self configHeadView:model];
			});
		}
	}];
}

- (void)configHeadView:(CommunityTopicDetailInfo *)model {
	self.topicTitleLabel.text = [@"#" stringByAppendingString:model.name];
	self.navigationItem.title = [@"#" stringByAppendingString:model.name];
	self.topicDetailLabel.text = model.desc;
	self.focusBtn.selected = model.isFollowed;
	[self.headView sd_setImageWithURL:[NSURL URLWithString:model.backgroundPic] placeholderImage:GetImage(@"topic_backgroud_icon")];
}

- (void)loadData {
	self.currentPage = 1;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityTopicDetailListWithTopicId:self.topicId page:self.currentPage type:self.currentSegment pageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
					self.tableView.mj_footer.hidden = YES;
				} else {
					self.tableView.mj_footer.hidden = NO;
					[self.tableView.mj_footer resetNoMoreData];
				}
				[self.dataSource removeAllObjects];
				[self.dataSource addObjectsFromArray:model.posts];
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	@weakify(self)
	[ESNetworkService getCommunityTopicDetailListWithTopicId:self.topicId page:self.currentPage type:self.currentSegment pageSize:kPageSize Response:^(id dict, ESError *error) {
			@strongify(self)
			dispatch_main_async_safe(^{
				[self.tableView.mj_footer endRefreshing];
			});
			if (dict&&[dict[@"code"] integerValue] == 0) {
				CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
				dispatch_main_async_safe(^{
					if (model.page >= model.pageCount) {
						[self.tableView.mj_footer endRefreshingWithNoMoreData];
					}
					[self.dataSource addObjectsFromArray:model.posts];
					[self.tableView reloadData];
				});
			}
	}];
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	return nil;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityTopicDetailCell"];
	cell.personalClick = ^(CommunityTopicDetailItem *model) {
		//点击头像
		CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
		vc.authorUid = @(model.authorUid).stringValue;
		
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	};
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.cellType = CellTypeDetail;
	cell.cellDelegate = self;
	[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row sortTpye:(self.currentSegment-1)];
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicDetailItem *item =  self.dataSource[indexPath.row];
    return item.myHeight;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	CommunityTopicDetailItem *item =  self.dataSource[indexPath.row];
	//跳转帖子详情
	CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
	vc.postId = item.postId;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
		[self.tableView.mj_header beginRefreshing];
	};
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - cellDelegate
- (void)likeBtnClick:(NSUInteger)row {
	CommunityTopicDetailItem *item =  self.dataSource[row];
	@weakify(self)
	[ESNetworkService communityPostLikeWithPostId:item.postId likeStatus:!item.isLiked Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			dispatch_main_async_safe(^{
				//点赞接口调用成功后
				NSDictionary *dic = dict[@"data"];
				item.isLiked = !item.isLiked;
				item.likeCount = [dic[@"likeCount"] integerValue];
				[UIView performWithoutAnimation:^{
					[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
				}];
			});
		}
	}];
}

- (void)commentBtnClick:(NSUInteger)row {
	
	CommunityTopicDetailItem *item =  self.dataSource[row];
	//跳转帖子详情
	CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
	vc.postId = item.postId;
	vc.needShowCommentWhenPush = YES;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
		[self loadData];
	};
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)shieldingBtnClick:(NSUInteger)row {
	//屏蔽
	NSArray *dataArr = @[@"内容质量不佳",@"仅仅不喜欢",@"我要举报"];
	@weakify(self)
	__block SureCustomActionSheet *optionsView = [[SureCustomActionSheet alloc] initWithFrame:self.view.bounds title:@"请选择屏蔽理由" optionsArr:dataArr cancelTitle:@"取消" selectedBlock:^(NSInteger index) {
		@strongify(self)
		CommunityTopicDetailItem *item = self.dataSource[row];
		if (index < 2) {
			//屏蔽
			[ESNetworkService blockCommunityPostWithPostId:item.postId type:index reason:@"" Response:^(id dict, ESError *error) {
				if (dict&&[dict[@"code"] integerValue] == 0) {
					dispatch_main_async_safe(^{
						[CMMUtility showToastWithText:@"屏蔽成功"];
						[self.dataSource removeObjectAtIndex:row];
						[self.tableView reloadData];
					});
				}
			}];
		} else if (index == 2) {
			[optionsView dismiss];
			//举报
			NSArray *secondDataArr = @[@"营销广告，虚假谣言",@"恶意谩骂，淫秽色情",@"涉及时政，违反法律"];
			SureCustomActionSheet *secondOptionsView = [[SureCustomActionSheet alloc] initWithFrame:self.view.bounds title:@"请选择举报理由" optionsArr:secondDataArr cancelTitle:@"取消" selectedBlock:^(NSInteger index) {
				NSString *reason = secondDataArr[index];
				//举报
				[ESNetworkService blockCommunityPostWithPostId:item.postId type:2 reason:reason Response:^(id dict, ESError *error) {
					if (dict&&[dict[@"code"] integerValue] == 0) {
						dispatch_main_async_safe(^{
							[CMMUtility showToastWithText:@"举报成功，已通知管理员"];
						});
					}
				}];
			} cancelBlock:^{
				//弹出一级菜单
				[self shieldingBtnClick:row];
			}];
			[self.view addSubview:secondOptionsView];
		}
	} cancelBlock:^{
		
	}];
	
	[self.view addSubview:optionsView];
}

#pragma mark - 头部视图收缩
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if(scrollView.contentOffset.y - self.oldY >20 && scrollView.contentOffset.y>0){
		self.oldY = scrollView.contentOffset.y;
		self.navigationController.navigationBarHidden = NO;
		[UIView animateWithDuration:0.2 animations:^{
			self.headView.hidden = YES;
			[self.segmentBtnArr[0] mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.view).offset(NavBarHeight);
				make.size.mas_equalTo(CGSizeMake(80, 44.5));
				make.centerX.equalTo(self.view).offset(-62);
			}];
			
			[self.segmentBtnArr[1] mas_makeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.view).offset(NavBarHeight);
				make.size.mas_equalTo(CGSizeMake(80, 44.5));
				make.centerX.equalTo(self.view).offset(62);
			}];
			[self.segmentBtnArr[0].superview layoutIfNeeded];
		}];
		return;
	}
	if(scrollView.contentOffset.y- self.oldY < -20&&scrollView.contentOffset.y < 0){
		self.oldY = scrollView.contentOffset.y;
		self.navigationController.navigationBarHidden = YES;
		[UIView animateWithDuration:0.2 animations:^{
			self.headView.hidden = NO;
			[self.segmentBtnArr[0] mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.headView.mas_bottom);
				make.size.mas_equalTo(CGSizeMake(80, 44.5));
				make.centerX.equalTo(self.view).offset(-62);
			}];
			
			[self.segmentBtnArr[1] mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.headView.mas_bottom);
				make.size.mas_equalTo(CGSizeMake(80, 44.5));
				make.centerX.equalTo(self.view).offset(62);
			}];
			[self.segmentBtnArr[0].superview layoutIfNeeded];
		}];
	}
}

#pragma mark - action
- (void)back {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)focusBtnClick {
	@weakify(self)
	[ESNetworkService followCommunityTopicWithTopicId:self.topicId followStatus:!self.focusBtn.selected Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				//关注接口调用成功后
				self.focusBtn.selected = !self.focusBtn.selected;
			});
		}
	}];
}

- (void)segmentClick:(PointExtenButton *)btn {
	if (btn.selected == YES) {
		return;
	}
	for (PointExtenButton *btn  in self.segmentBtnArr) {
		btn.selected = NO;
		btn.titleLabel.font = fcBoldFont(16);
	}
	[self.selectedLine mas_remakeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(btn);
		make.size.mas_equalTo(CGSizeMake(80, 4));
		make.bottom.equalTo(btn).offset(-4);
	}];
	btn.selected = YES;
	btn.titleLabel.font = fcBoldFont(18);
	self.currentSegment = btn.tag;
	[self.tableView.mj_header beginRefreshing];
}

//发布
- (void)goPost {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//发布
	CommunityPostViewController *vc = [[CommunityPostViewController alloc] init];
	vc.topicId = self.topicId;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - lazy init
- (PointExtenButton *)backBtn {
	if (!_backBtn) {
		_backBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_backBtn setImage:GetImage(@"nav_return_white") forState:UIControlStateNormal];
		_backBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_backBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
		[self.headView addSubview:_backBtn];
	}
	return _backBtn;
}

- (UIImageView *)headView {
	if (!_headView) {
		_headView = [UIImageView new];
		_headView.userInteractionEnabled = YES;
		_headView.backgroundColor = [UIColor blackColor];
		[self.view addSubview:_headView];
	}
	return _headView;
}

- (UILabel *)topicTitleLabel {
	if (!_topicTitleLabel) {
		_topicTitleLabel = [UILabel new];
		_topicTitleLabel.text = @"#话题";
		_topicTitleLabel.textColor = [UIColor whiteColor];
		_topicTitleLabel.font = fcBoldFont(20);
		[self.headView addSubview:_topicTitleLabel];
	}
	return _topicTitleLabel;
}

- (PointExtenButton *)focusBtn {
	if (!_focusBtn) {
		_focusBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_focusBtn setTitleColor:ColorAppBlack forState:UIControlStateNormal];
		[_focusBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateSelected];
		[_focusBtn setTitle:@"+关注" forState:UIControlStateNormal];
		[_focusBtn setTitle:@"已关注" forState:UIControlStateSelected];
		_focusBtn.layer.cornerRadius = 2;
		_focusBtn.clipsToBounds = YES;
		_focusBtn.backgroundColor = [UIColor whiteColor];
		_focusBtn.titleLabel.font = fcFont(12);
		[_focusBtn addTarget:self action:@selector(focusBtnClick) forControlEvents:UIControlEventTouchUpInside];
		[self.headView addSubview:_focusBtn];
	}
	return _focusBtn;
}

- (UILabel *)topicDetailLabel {
	if (!_topicDetailLabel) {
		_topicDetailLabel = [UILabel new];
		_topicDetailLabel.textColor = RGBCOLOR(231, 231, 231);
		_topicDetailLabel.font = fcFont(12);
		_topicDetailLabel.numberOfLines = 2;
		[self.headView addSubview:_topicDetailLabel];
	}
	return _topicDetailLabel;
}

- (NSMutableArray<PointExtenButton *> *)segmentBtnArr {
	if (!_segmentBtnArr) {
		_segmentBtnArr = [NSMutableArray array];
		NSArray *titleArr = @[@"最新回复",@"最新发帖"];
		for (NSUInteger i = 0; i < 2; i++) {
			PointExtenButton *btn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
			[btn setTitle:titleArr[i] forState:UIControlStateNormal];
			[btn setTitleColor:RGBCOLOR(102, 102, 102) forState:UIControlStateNormal];
			[btn setTitleColor:ColorAppBlack forState:UIControlStateSelected];
			btn.titleLabel.font = fcBoldFont(16);
			btn.titleLabel.textAlignment = NSTextAlignmentLeft;
			btn.tag = i + 1;
			[btn addTarget:self action:@selector(segmentClick:) forControlEvents:UIControlEventTouchUpInside];
			[_segmentBtnArr addObject:btn];
			[self.view addSubview:btn];
		}
		//默认最新回复
		_segmentBtnArr[0].selected = YES;
		self.currentSegment = 1;
	}
	return _segmentBtnArr;
}

- (UIView *)selectedLine {
	if (!_selectedLine) {
		_selectedLine = [UIView new];
		_selectedLine.backgroundColor = ColorAppRed;
		[self.view addSubview:_selectedLine];
	}
	return _selectedLine;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.view addSubview:_seperatorLine];
	}
	return _seperatorLine;
}

- (NavButton*)postBtn
{
	if(!_postBtn){
		_postBtn = [NavButton buttonWithType:UIButtonTypeCustom];
		[_postBtn setImage:[UIImage imageNamed:@"edit"] forState:UIControlStateNormal];
		[_postBtn addTarget:self action:@selector(goPost) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_postBtn];
	}
	return _postBtn;
}
@end
