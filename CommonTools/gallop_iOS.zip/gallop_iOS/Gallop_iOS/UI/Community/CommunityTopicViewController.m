//
//  CommunityTopicViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityTopicViewController.h"
#import "CommunityTopicCell.h"
#import "CommunityTopicSectionHeader.h"
#import "CommunityTopicDetailViewController.h"

#define kCommunityTopicCellIdentifier @"CommunityTopicCellIdentifier"
#define kCommunityTopicSectionHeader @"CommunityTopicSectionHeader"

@interface CommunityTopicViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,CommunityTopicCellDelegate>
@property(nonatomic, strong) UICollectionView      *collectionView;
@end

@implementation CommunityTopicViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

- (void)setupView {
	[self.view addSubview:self.collectionView];
    [self.collectionView addRefreshHeaderWithTarget:self action:@selector(loadData)];
	[self.collectionView.mj_header beginRefreshing];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.bottom.equalTo(self.view);
//        make.top.equalTo(self.view.mas_top).offset(NavBarHeight);
    }];
}

- (void)loadData {
	@weakify(self)
	[ESNetworkService getCommunityTopicWithResponse:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.collectionView.mj_header endRefreshing];
		});
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			CommunityTopicModel *model = [CommunityTopicModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_async(dispatch_get_main_queue(), ^{
				[self.dataSource removeAllObjects];
				[self.dataSource addObject:QM_IS_ARRAY_NIL(model.followedTopics) ? @[] : model.followedTopics];
				[self.dataSource addObject:QM_IS_ARRAY_NIL(model.topics) ? @[] : model.topics];
				[self.collectionView reloadData];
			});
		}
	}];
    [[NSNotificationCenter defaultCenter] postNotificationName:kRefreshComunityMessageCount object:nil];
}

#pragma mark - cellDelegate
- (void)focusBtnClick:(NSUInteger)row {
	CommunityTopicItem *item =  [self.dataSource lastObject][row];
	
	@weakify(self)
	[ESNetworkService followCommunityTopicWithTopicId:item.topicId followStatus:!item.isFollowed Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				//关注接口调用成功后
				item.isFollowed = !item.isFollowed;
				[UIView performWithoutAnimation:^{
					if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
						[self.collectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]]];
					} else {
						[self.collectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:1]]];
					}
				}];
			});
		}
	}];
}

#pragma mark UICollectionView代理
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
	if (QM_IS_ARRAY_NIL(self.dataSource)) {
		return 0;
	}
	
	if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
		NSArray *arr = self.dataSource[1];
		return arr.count;
	} else {
		NSArray *arr = self.dataSource[section];
		return arr.count;
	}
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
	if (QM_IS_ARRAY_NIL(self.dataSource)) {
		return 0;
	}
	if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
		return 1;
	}
	return 2;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCommunityTopicCellIdentifier forIndexPath:indexPath];
	cell.cellDelegate = self;
	NSIndexPath *newPath;
	if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
		newPath = [NSIndexPath indexPathForRow:indexPath.row inSection:1];
	} else {
		newPath = [NSIndexPath indexPathForRow:indexPath.row inSection:indexPath.section];
	}
	[cell configCellWithModel:self.dataSource[newPath.section][newPath.row] indexPath:newPath];
	return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
	CommunityTopicSectionHeader *view = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kCommunityTopicSectionHeader forIndexPath:indexPath];
	
	if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
		view.titleLabel.text = @"全部话题";
	} else {
		view.titleLabel.text = indexPath.section == 0 ? @"已关注的话题" : @"全部话题";
	}
	return view;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	CommunityTopicDetailViewController *vc = [CommunityTopicDetailViewController new];
	if (QM_IS_ARRAY_NIL(self.dataSource[0])) {
		CommunityTopicItem *item = self.dataSource[1][indexPath.row];
		vc.topicId = item.topicId;
	} else {
		CommunityTopicItem *item = self.dataSource[indexPath.section][indexPath.row];
		vc.topicId = item.topicId;
	}
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - lazy init
- (UICollectionView *)collectionView {
	if (!_collectionView) {
		UICollectionViewFlowLayout  *layout = [[UICollectionViewFlowLayout alloc] init];
		layout.minimumLineSpacing = 6.5;
		layout.minimumInteritemSpacing  = 6.5;
		layout.itemSize = CGSizeMake(kCellWidth + 24, kCellWidth + 82);
		layout.scrollDirection =  UICollectionViewScrollDirectionVertical;
		layout.sectionInset = UIEdgeInsetsZero;
		layout.headerReferenceSize = CGSizeMake(SCREEN_WIDTH - 20, 50);
		_collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
		_collectionView.backgroundColor = [UIColor clearColor];
		_collectionView.showsHorizontalScrollIndicator = NO;
		_collectionView.showsVerticalScrollIndicator = NO;
		_collectionView.delegate = self;
		_collectionView.dataSource = self;
		[_collectionView registerClass:[CommunityTopicCell class] forCellWithReuseIdentifier:kCommunityTopicCellIdentifier];
		[_collectionView registerClass:[CommunityTopicSectionHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kCommunityTopicSectionHeader];
	}
	return _collectionView;
}

@end
