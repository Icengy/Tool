//
//  CommunityFansViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/6/17.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityFansViewController.h"
#import "CommunityFansListCell.h"
#import "CommunityHomePageViewController.h"

#define kPageSize 20

@interface CommunityFansViewController ()
@property (nonatomic,assign) NSUInteger			currentPage;
@end

@implementation CommunityFansViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

- (void)setupView {
	self.navigationItem.title = @"Ta的粉丝";
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.view).offset(NavBarHeight);
		make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
	}];
//	self.tableView.backgroundColor = RGBCOLOR(248, 249, 251);
	[self.tableView registerClass:[CommunityFansListCell class] forCellReuseIdentifier:@"CommunityFansListCell"];
	
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self.tableView.mj_header beginRefreshing];
}

- (void)loadData {
	self.currentPage = 1;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityFansList:self.userId page:self.currentPage pageSize:kPageSize response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			CommunityFansModel *model = [CommunityFansModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (self.currentPage >= model.totalPages) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
					self.tableView.mj_footer.hidden = YES;
				} else {
					self.tableView.mj_footer.hidden = NO;
					[self.tableView.mj_footer resetNoMoreData];
				}
				[self.dataSource removeAllObjects];
				[self.dataSource addObjectsFromArray:model.content];
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityFansList:self.userId page:self.currentPage pageSize:kPageSize response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			CommunityFansModel *model = [CommunityFansModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (self.currentPage >= model.totalPages) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.dataSource addObjectsFromArray:model.content];
				[self.tableView reloadData];
			});
		}
	}];
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	return nil;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityFansListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityFansListCell"];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	[cell configCellWithModel:self.dataSource[indexPath.row]];
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 66;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	CommunityFansItem *model = self.dataSource[indexPath.row];
	//跳转用户详情
	CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
	vc.authorUid = @(model.userId).stringValue;
	
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

@end
