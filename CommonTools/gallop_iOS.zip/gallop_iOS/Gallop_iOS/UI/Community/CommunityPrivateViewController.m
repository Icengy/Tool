//
//  CommunityPrivateViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/31.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityPrivateViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityHomePageViewController.h"
#import "CommunityTopicDetailCell.h"

#define kPageSize 20

@interface CommunityPrivateViewController ()
@property (nonatomic,assign) NSUInteger			currentPage;
@end

@implementation CommunityPrivateViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

- (void)setupView {
	self.navigationItem.title = @"被屏蔽文章";
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.view).offset(NavBarHeight);
		make.bottom.equalTo(self.view).offset(-kBottomSafeArea);
	}];
//	self.tableView.backgroundColor = RGBCOLOR(248, 249, 251);
	[self.tableView registerClass:[CommunityTopicDetailCell class] forCellReuseIdentifier:@"CommunityTopicDetailCell"];
	
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
    
	[self.tableView.mj_header beginRefreshing];
}

- (void)loadData {
	self.currentPage = 1;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityHomePageListWithHomeUserId:self.authorUid page:self.currentPage type:2 pageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
					self.tableView.mj_footer.hidden = YES;
				} else {
					self.tableView.mj_footer.hidden = NO;
					[self.tableView.mj_footer resetNoMoreData];
				}
				[self.dataSource removeAllObjects];
				[self.dataSource addObjectsFromArray:model.posts];
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityHomePageListWithHomeUserId:self.authorUid page:self.currentPage type:2 pageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.dataSource addObjectsFromArray:model.posts];
				[self.tableView reloadData];
			});
		}
	}];
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	return nil;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityTopicDetailCell"];
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.cellType = CellTypePrivate;
	cell.personalClick = ^(CommunityTopicDetailItem *model) {
		//点击头像
		CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
		vc.authorUid = @(model.authorUid).stringValue;
		
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	};
	[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row sortTpye:0];
	return cell;
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicDetailItem *item =  self.dataSource[indexPath.row];
	return item.myHeight;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	//跳转帖子详情
	CommunityTopicDetailItem *item = self.dataSource[indexPath.row];
	CommunityPaperContentViewController *vc = [[CommunityPaperContentViewController alloc] init];
	vc.postId = item.postId;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
		[self loadData];
	};
	[self.navigationController pushViewController:vc animated:YES];
}

@end

