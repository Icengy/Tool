//
//  CommunityHomePageViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/30.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface CommunityHomePageViewController : ESViewController
@property (nonatomic,strong) NSString *authorUid;
@end

