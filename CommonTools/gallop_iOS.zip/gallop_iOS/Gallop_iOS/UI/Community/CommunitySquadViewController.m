//
//  CommunitySquadViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunitySquadViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityPostViewController.h"
#import "LMHWaterFallLayout.h"
#import "ComunitySquadCell.h"
#import "NavButton.h"

#define kPageSize 20
#define kComunitySquadCellIdentifier @"ComunitySquadCellIdentifier"

@interface CommunitySquadViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,ComunitySquadCellDelegate,LMHWaterFallLayoutDeleaget>
@property (nonatomic,assign) NSUInteger	currentPage;
@property(nonatomic, strong) UICollectionView      *collectionView;
@property (nonatomic,strong) NavButton	*postBtn;
@end

@implementation CommunitySquadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	[self setupView];
}

- (void)setupView {
	[self.view addSubview:self.collectionView];
    [self.collectionView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.collectionView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	[self.collectionView.mj_header beginRefreshing];
	
	[self.postBtn setFrame:CGRectMake(kScreen_Width - 65, kScreen_Height-TabBarHeight-65-NavBarHeight, 45, 45)];
}

- (void)loadData {
	self.currentPage = 1;
	@weakify(self)
	[ESNetworkService getCommunitySquadListPage:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.collectionView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			ComunitySquadModel *model = [ComunitySquadModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.collectionView.mj_footer endRefreshingWithNoMoreData];
					self.collectionView.mj_footer.hidden = YES;
				} else {
					self.collectionView.mj_footer.hidden = NO;
					[self.collectionView.mj_footer resetNoMoreData];
				}
				[self.dataSource removeAllObjects];
				[self adjustCollectionView:model.posts];
			});
		}
	}];
    [[NSNotificationCenter defaultCenter] postNotificationName:kRefreshComunityMessageCount object:nil];
}

- (void)loadMoreData {
	self.currentPage ++;
	@weakify(self)
	[ESNetworkService getCommunitySquadListPage:self.currentPage PageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
		dispatch_main_async_safe(^{
			[self.collectionView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			ComunitySquadModel *model = [ComunitySquadModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.collectionView.mj_footer endRefreshingWithNoMoreData];
				}
				[self adjustCollectionView:model.posts];
			});
		}
	}];
}

- (void)adjustCollectionView:(NSArray *)array {
	[array enumerateObjectsUsingBlock:^(ComunitySquadItem *item, NSUInteger idx, BOOL * _Nonnull stop) {
		if (!QM_IS_STR_NIL(item.headImg) && item.height <= 80) {
			NSString *scaleStr = [item.headImg substringWithRange:NSMakeRange(0, item.headImg.length - 4)];
			NSRange range = [scaleStr rangeOfString:@"_" options:NSBackwardsSearch];
			scaleStr = [scaleStr substringWithRange:NSMakeRange(range.location + 1, scaleStr.length - range.location - 1)];
			CGFloat scale = scaleStr.integerValue / 1000.0;
			scale = scale > 2 ? 2 : scale;
			item.height = 80 + scale  * kCellWidth;
		} else {
			item.height = 80;
		}
	}];
	
	[self.dataSource addObjectsFromArray:array];
	[self.collectionView reloadData];
}

#pragma mark - cellDelegate
- (void)likeBtnClick:(NSUInteger)row {
	ComunitySquadItem *item =  self.dataSource[row];
	@weakify(self)
	[ESNetworkService communityPostLikeWithPostId:item.postId likeStatus:!item.isLiked Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			dispatch_main_async_safe(^{
				//点赞接口调用成功后
				NSDictionary *dic = dict[@"data"];
				item.isLiked = !item.isLiked;
				item.likeCount = [dic[@"likeCount"] integerValue];
				[UIView performWithoutAnimation:^{
					[self.collectionView reloadItemsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]]];
				}];
			});
		}
	}];
}

#pragma mark - action
- (void)goPost {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//发布
	CommunityPostViewController *vc = [[CommunityPostViewController alloc] init];
	vc.topicId = [SystemManager eventTopicId].integerValue;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark UICollectionView代理
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
	return self.dataSource.count;
}
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
	return 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
	ComunitySquadCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kComunitySquadCellIdentifier forIndexPath:indexPath];
	cell.cellDelegate = self;
	if (indexPath.row < self.dataSource.count) {
		[cell configCellWithModel:self.dataSource[indexPath.row] row:indexPath.row];
	}
	return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
	ComunitySquadItem *item =  self.dataSource[indexPath.row];
	//跳转帖子详情
	CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
	vc.postId = item.postId;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
		[self loadData];
	};
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark  - <LMHWaterFallLayoutDeleaget>
/**
 * 每个item的高度
 */
- (CGFloat)waterFallLayout:(LMHWaterFallLayout *)waterFallLayout heightForItemAtIndexPath:(NSUInteger)indexPath itemWidth:(CGFloat)itemWidth {
	ComunitySquadItem *item = self.dataSource[indexPath];
	return item.height;
}

/**
 * 有多少列
 */
- (NSUInteger)columnCountInWaterFallLayout:(LMHWaterFallLayout *)waterFallLayout {
	return 2;
}

/**
 * 每列之间的间距
 */
- (CGFloat)columnMarginInWaterFallLayout:(LMHWaterFallLayout *)waterFallLayout {
	return 7;
}

/**
 * 每行之间的间距
 */
- (CGFloat)rowMarginInWaterFallLayout:(LMHWaterFallLayout *)waterFallLayout {
	return 7;
}

/**
 * 每个item的内边距
 */
- (UIEdgeInsets)edgeInsetdInWaterFallLayout:(LMHWaterFallLayout *)waterFallLayout {
	return UIEdgeInsetsZero;
}



#pragma mark - lazy init
- (UICollectionView *)collectionView {
	if (!_collectionView) {
		LMHWaterFallLayout * layout = [[LMHWaterFallLayout alloc]init];
		layout.delegate = self;
		
		_collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(10, 10, SCREEN_WIDTH - 20, SCREEN_HEIGHT - NavBarHeight - TabBarHeight - 10) collectionViewLayout:layout];
		_collectionView.backgroundColor = [UIColor clearColor];
		_collectionView.showsHorizontalScrollIndicator = NO;
		_collectionView.showsVerticalScrollIndicator = NO;
		_collectionView.delegate = self;
		_collectionView.dataSource = self;
		[_collectionView registerClass:[ComunitySquadCell class] forCellWithReuseIdentifier:kComunitySquadCellIdentifier];
	}
	return _collectionView;
}

- (NavButton*)postBtn
{
	if(!_postBtn){
		_postBtn = [NavButton buttonWithType:UIButtonTypeCustom];
		[_postBtn setImage:[UIImage imageNamed:@"edit"] forState:UIControlStateNormal];
		[_postBtn addTarget:self action:@selector(goPost) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_postBtn];
	}
	return _postBtn;
}

@end
