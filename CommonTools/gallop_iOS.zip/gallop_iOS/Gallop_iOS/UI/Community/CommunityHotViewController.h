//
//  CommunityHotViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface CommunityHotViewController : ESViewController
@property (nonatomic,assign) NSUInteger topicId;
@end
