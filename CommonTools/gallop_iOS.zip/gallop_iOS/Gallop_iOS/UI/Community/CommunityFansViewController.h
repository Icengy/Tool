//
//  CommunityFansViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/6/17.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface CommunityFansViewController : ESViewController
@property (nonatomic,assign) NSUInteger userId;
@end
