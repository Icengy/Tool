//
//  CommunityHotViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityHotViewController.h"
#import "ESNewMainScrollView.h"
#import "WTCContentViewController.h"
#import "CommunityPostViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityHomePageViewController.h"
#import "GoodsDetailViewController.h"
#import "CommunityTopicDetailViewController.h"
#import "SureCustomActionSheet.h"
#import "PointExtenButton.h"
#import "NavButton.h"
#import "CommunityTopicDetailCell.h"
#import "CommunityBannerModel.h"
#import "ESBanner.h"

#define kheadViewHight ([UIScreen mainScreen].bounds.size.width)*(2.0/5.0)

#define kPageSize 20

@interface CommunityHotViewController ()<ESNewMainScrollViewDelegate,CommunityTopicDetailCellDelegate>
@property (nonatomic, strong) ESNewMainScrollView *mainScrollView;
@property (nonatomic,strong) UIView *tableHeadView;
@property (nonatomic,strong) NavButton	*postBtn;
@property (nonatomic,assign) NSUInteger currentPage;
@property (nonatomic,strong) NSMutableArray <CommunityBannerModel *>*banners;

@property (nonatomic,strong) CommunityTopicDetailModel *model;
@end

@implementation CommunityHotViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	[self setupView];
}

- (void)setupView {
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.offset(0);
	}];
//	self.tableView.backgroundColor = RGBCOLOR(248, 249, 251);
//	self.tableView.estimatedRowHeight = 147;
	[self.tableView registerClass:[CommunityTopicDetailCell class] forCellReuseIdentifier:@"CommunityTopicDetailCell"];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData:)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadData:)];
	
	[self.postBtn setFrame:CGRectMake(kScreen_Width - 65, kScreen_Height-TabBarHeight-65-NavBarHeight, 45, 45)];
    
    [self.tableView.mj_header beginRefreshing];
}

- (void)loadData:(id)sender  {
    [ES_HttpService showLoading:!sender];
    
    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    dispatch_group_t gcd_group = dispatch_group_create();
    /// 获取banner
    dispatch_group_async(gcd_group, queue, ^{
        [self loadBanner:sender withGroup:gcd_group];
    });
    /// 获取banner
    dispatch_group_async(gcd_group, queue, ^{
        [self loadListData:sender withGroup:gcd_group];
    });
    dispatch_group_notify(gcd_group, dispatch_get_main_queue(), ^{
        
        [self endAllFreshing:self.tableView];
        
        /// banner刷新
        [self.mainScrollView reloadData];

        if (self.model.page >= self.model.pageCount) {
            [self.tableView.mj_footer endRefreshingWithNoMoreData];
        }
        [self.tableView reloadData];
    });
}

- (void)loadListData:(id)sender withGroup:(dispatch_group_t)group {
    
    if (!group) {
        [ES_HttpService showLoading:!sender];
    }else
        dispatch_group_enter(group);
    
    if (sender && [sender isKindOfClass:[MJRefreshAutoStateFooter class]]) {
        self.currentPage ++;
    }else {
        self.currentPage = 1;
    }
    
	@weakify(self)
	[ESNetworkService getCommunityTopicDetailListWithTopicId:self.topicId page:self.currentPage type:1 pageSize:kPageSize Response:^(id dict, ESError *error) {
		@strongify(self)
        [self endAllFreshing:self.tableView];
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
            if (!QM_IS_ARRAY_NIL(self.model.posts)) {
                [self.dataSource addObjectsFromArray:self.model.posts];
            }
		}
        if (group) dispatch_group_leave(group);
	}];
}

- (void)loadBanner:(id)sender withGroup:(dispatch_group_t)group {
    
    if (group) dispatch_group_enter(group);
	@weakify(self);
	[ESNetworkService getCommunityBanberWithResponse:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			NSArray* bannerList = dict[@"data"];
            if (!QM_IS_ARRAY_NIL(bannerList)) {
                [self.banners removeAllObjects];
                for (NSDictionary *dic in bannerList) {
                    CommunityBannerModel *banner = [CommunityBannerModel mj_objectWithKeyValues:dic];
                    [self.banners addObject:banner];
                }
            }
		}
        if (group) dispatch_group_leave(group);
	}];
}

#pragma mark 轮播图代理
- (NSArray<ESBannerModel *> *)imagesInMainScrollView:(ESNewMainScrollView *)mainScrollView {
    NSMutableArray <ESBannerModel *>*banners = @[].mutableCopy;
    [self.banners enumerateObjectsUsingBlock:^(CommunityBannerModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        ESBannerModel *model = [ESBannerModel new];
        model.img = obj.img;
        [banners addObject:model];
    }];
    return banners.copy;
}

- (void)mainScrollView:(ESNewMainScrollView *)mainScrollView atIndex:(NSInteger)index {
	CommunityBannerModel *banner = [self.banners objectAtIndex:index];
	//baner点击计数
	if (!QM_IS_STR_NIL(banner.bannerId)) {
		[ESNetworkService hitsBannerWithBannerId:banner.bannerId Response:^(id dict, ESError *error) {
			
		}];
	}
	if (banner.type == 1) {
		//商品
		GoodsDetailViewController*vc = [[GoodsDetailViewController alloc] init];
		vc.productId = banner.content;
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	} else if (banner.type == 2) {
		//帖子
		CommunityPaperContentViewController*vc = [[CommunityPaperContentViewController alloc] init];
		vc.postId = banner.content.integerValue;
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	} else if (banner.type == 3) {
		//h5
		WTCContentViewController*vc = [[WTCContentViewController alloc] init];
		vc.contentType = WTCContentTypeNav;
		vc.url = banner.content;
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	} else if (banner.type == 4) {
		//话题
		CommunityTopicDetailViewController*vc = [[CommunityTopicDetailViewController alloc] init];
		vc.topicId = banner.content.integerValue;
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	}
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return self.banners.count ? kheadViewHight:CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return self.banners.count ? self.tableHeadView:[UIView new];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return CGFLOAT_MIN;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	CommunityTopicDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityTopicDetailCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
	cell.cellDelegate = self;
	cell.personalClick = ^(CommunityTopicDetailItem *model) {
		//点击头像
		CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
		vc.authorUid = @(model.authorUid).stringValue;
		
		vc.hidesBottomBarWhenPushed = YES;
		[self.navigationController pushViewController:vc animated:YES];
	};
	cell.cellType = CellTypeHot;
	[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row sortTpye:0];
	return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CommunityTopicDetailItem *item =  self.dataSource[indexPath.row];
    return item.myHeight;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	CommunityTopicDetailItem *item =  self.dataSource[indexPath.row];
	//跳转帖子详情
	CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
	vc.postId = item.postId;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
        [self loadData:nil];
	};
	[self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - cellDelegate
- (void)likeBtnClick:(NSUInteger)row {
	CommunityTopicDetailItem *item =  self.dataSource[row];
	@weakify(self)
	[ESNetworkService communityPostLikeWithPostId:item.postId likeStatus:!item.isLiked Response:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			dispatch_main_async_safe(^{
				//点赞接口调用成功后
				NSDictionary *dic = dict[@"data"];
				item.isLiked = !item.isLiked;
				item.likeCount = [dic[@"likeCount"] integerValue];
				[UIView performWithoutAnimation:^{
					[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
				}];
			});
		}
	}];
}

- (void)commentBtnClick:(NSUInteger)row {
	
	CommunityTopicDetailItem *item =  self.dataSource[row];
	//跳转帖子详情
	CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
	vc.postId = item.postId;
	vc.needShowCommentWhenPush = YES;
	vc.hidesBottomBarWhenPushed = YES;
	vc.deleteBlock = ^{
        [self loadData:nil];
	};
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)shieldingBtnClick:(NSUInteger)row {
	//屏蔽
	NSArray *dataArr = @[@"内容质量不佳",@"仅仅不喜欢",@"我要举报"];
	CGRect frame = self.view.frame;
	frame.size.height += kBottomSafeArea;
	@weakify(self)
	__block SureCustomActionSheet *optionsView = [[SureCustomActionSheet alloc] initWithFrame:frame title:@"请选择屏蔽理由" optionsArr:dataArr cancelTitle:@"取消" selectedBlock:^(NSInteger index) {
		@strongify(self)
		CommunityTopicDetailItem *item = self.dataSource[row];
		if (index < 2) {
			//屏蔽
			[ESNetworkService blockCommunityPostWithPostId:item.postId type:index reason:@"" Response:^(id dict, ESError *error) {
				if (dict&&[dict[@"code"] integerValue] == 0) {
					dispatch_main_async_safe(^{
						[CMMUtility showToastWithText:@"屏蔽成功"];
						[self.dataSource removeObjectAtIndex:row];
						[self.tableView reloadData];
					});
				}
			}];
		} else if (index == 2) {
			[optionsView dismiss];
			//举报
			NSArray *secondDataArr = @[@"营销广告，虚假谣言",@"恶意谩骂，淫秽色情",@"涉及时政，违反法律"];
			
			SureCustomActionSheet *secondOptionsView = [[SureCustomActionSheet alloc] initWithFrame:frame title:@"请选择举报理由" optionsArr:secondDataArr cancelTitle:@"取消" selectedBlock:^(NSInteger index) {
				NSString *reason = secondDataArr[index];
				//举报
				[ESNetworkService blockCommunityPostWithPostId:item.postId type:2 reason:reason Response:^(id dict, ESError *error) {
					if (dict&&[dict[@"code"] integerValue] == 0) {
						dispatch_main_async_safe(^{
							[CMMUtility showToastWithText:@"举报成功，已通知管理员"];
						});
					}
				}];
			} cancelBlock:^{
				//弹出一级菜单
				[self shieldingBtnClick:row];
			}];
			[self.view addSubview:secondOptionsView];
		}
	} cancelBlock:^{
		
	}];
	[self.view addSubview:optionsView];
}

#pragma mark - action
//发布
- (void)goPost {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//发布
	CommunityPostViewController *vc = [[CommunityPostViewController alloc] init];
	vc.topicId = self.topicId;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - lazy init
- (NavButton*)postBtn
{
	if(!_postBtn){
		_postBtn = [NavButton buttonWithType:UIButtonTypeCustom];
		[_postBtn setImage:[UIImage imageNamed:@"edit"] forState:UIControlStateNormal];
		[_postBtn addTarget:self action:@selector(goPost) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_postBtn];
	}
	return _postBtn;
}

- (UIView *)tableHeadView {
	if (!_tableHeadView) {
		_tableHeadView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kheadViewHight)];
		_tableHeadView.backgroundColor = [UIColor whiteColor];
		//轮播图
		[_tableHeadView addSubview:self.mainScrollView];
//		_tableHeadView.clipsToBounds = YES;
	}
	return _tableHeadView;
}

- (ESNewMainScrollView *)mainScrollView {
    if (!_mainScrollView) {
        _mainScrollView = [[ESNewMainScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, kheadViewHight) withDelegate:self];
        _mainScrollView.showPageControl = YES;
    }return _mainScrollView;
}

- (NSMutableArray <CommunityBannerModel *>*)banners{
	if (!_banners) {
		_banners = [NSMutableArray array];
	}
	
	return _banners;
}
@end
