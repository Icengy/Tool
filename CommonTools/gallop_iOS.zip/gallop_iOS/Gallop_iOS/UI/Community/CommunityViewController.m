//
//  CommunityViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityViewController.h"
#import "CommunityHotViewController.h"
#import "CommunitySquadViewController.h"
#import "CommunityTopicViewController.h"
#import "CommunityPostViewController.h"
#import "CommunityMessageViewController.h"
#import "CommunitySearchViewController.h"
#import "TYTabButtonPagerController.h"

@interface CommunityViewController () <TYPagerControllerDataSource>{
    NSInteger _currentIndex;
}
//view
@property (nonatomic,strong) UIView *switchView;
@property (nonatomic,strong) TYTabButtonPagerController *titleBarController;

@property (nonatomic ,copy) NSArray *barTitleArray;
@property (nonatomic ,copy) NSArray *barControllerArray;
@property (nonatomic ,strong) NSMutableArray <CYButton *>*switchChildArray;

@property (nonatomic,strong) CYButton *hotBtn;
@property (nonatomic,strong) CommunityHotViewController *hotVC;
@property (nonatomic,strong) CYButton *messageB;
@property (nonatomic,strong) CYButton *searchB;
@property (nonatomic,strong) UILabel *redLabel;
@property (nonatomic,strong) UIScrollView *bgScrollView;
//data
@property (nonatomic,strong) CommunityMessageCountModel *messageCountModel;
@property (nonatomic,assign) NSUInteger currentType; //0-热门 1-广场 2-话题
@end

@implementation CommunityViewController

- (void)dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
	[super viewDidLoad];
	
    self.barTitleArray = @[@"热门", @"广场", @"话题"];
    self.barControllerArray = [self getTitleControllerArray];
    self.switchChildArray = [NSMutableArray new];
    self.fd_prefersNavigationBarHidden = NO;
    
	[self setupView];
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(loadData) name:kRefreshComunityMessageCount object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
    
    self.barStyle = UIStatusBarStyleLightContent;
    self.navigationBarStyle = CYNavigationBarStyleRedContent;
    
	[self loadData];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    self.navigationBarStyle = CYNavigationBarStyleDefault;
}

- (void)loadData {
	if (![App_Utility checkCurrentUser]) {
		self.redLabel.text = @"";
		self.redLabel.hidden = YES;
		return;
	}
	//获取社区消息未读消息数量
	[ESNetworkService getCommunityMessageCountWithResponse:^(id dict, ESError *error) {
		if (dict&&[dict[@"code"] integerValue] == 0) {
			self.messageCountModel = [CommunityMessageCountModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (self.messageCountModel.totalUnreadMessage > 0) {
					self.redLabel.text = @(self.messageCountModel.totalUnreadMessage).stringValue;
					self.redLabel.hidden = NO;
				} else {
					self.redLabel.text = @"";
					self.redLabel.hidden = YES;
				}
			});
		}
	}];
}

- (void)setupView {
    
    self.navigationItem.titleView = self.switchView;
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.messageB];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.searchB];
    
    [self addChildViewController:self.titleBarController];
    [self.view addSubview:self.titleBarController.view];
    [self.titleBarController.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(self.view);
        make.top.equalTo(self.view).offset(NavBarHeight);
    }];
    
//	self.hotVC = [[CommunityHotViewController alloc] init];
//	self.hotVC.topicId = [SystemManager eventTopicId].integerValue;
//	[self addChildViewController:self.hotVC];
//	CommunitySquadViewController *squadVC = [[CommunitySquadViewController alloc] init];
//	[self addChildViewController:squadVC];
//	CommunityTopicViewController *topicVC = [[CommunityTopicViewController alloc] init];
//
//	[self addChildViewController:topicVC];
//	[self.bgScrollView addSubview:self.hotVC.view];
//	[self.bgScrollView addSubview:topicVC.view];
//	[self.bgScrollView addSubview:squadVC.view];
    
}

#pragma mark - action
- (void)swithBtnClick:(UIButton *)btn {
//	if (btn.selected) {
//		return;
//	} else {
//		btn.selected = YES;
//		btn.titleLabel.font = fcBoldFont(18);
//	}
    NSInteger tag = btn.tag - 10000;
    if (tag == self.currentType) return;
	self.currentType = tag;
    
    if (self.currentType < 0 || self.currentType >= self.barTitleArray.count) return;
    
    [self.switchChildArray enumerateObjectsUsingBlock:^(CYButton * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj setSelected:(idx == self.currentType)?YES:NO];
    }];
    [self.titleBarController moveToControllerAtIndex:self.currentType animated:YES];
	
//	if (self.currentType == 0) {
//		//热门活动
//		UIButton *btn = [self.switchView viewWithTag:10001];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		btn = [self.switchView viewWithTag:10002];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		[self.bgScrollView setContentOffset:CGPointMake(0, 0) animated:NO];
//	} else if (self.currentType == 1) {
//		//广场
//		UIButton *btn = [self.switchView viewWithTag:10000];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		btn = [self.switchView viewWithTag:10002];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		[self.bgScrollView setContentOffset:CGPointMake(SCREEN_WIDTH, 0) animated:NO];
//	} else {
//		//话题
//		UIButton *btn = [self.switchView viewWithTag:10000];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		btn = [self.switchView viewWithTag:10001];
//		btn.selected = NO;
//		btn.titleLabel.font = fcBoldFont(16);
//		[self.bgScrollView setContentOffset:CGPointMake(SCREEN_WIDTH * 2, 0) animated:NO];
//	}
}

-(void)goSearch{
    CommunitySearchViewController*vc = [CommunitySearchViewController new];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)goMessageCenter {
	if (![App_Utility checkCurrentUser]) {
		[App_Utility showLoginViewController];
		return;
	}
	//埋点
	[ESNetworkService customPostionCode:@"005005"];
	
	CommunityMessageViewController *vc = [CommunityMessageViewController new];
	vc.countModel = self.messageCountModel;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

#pragma mark -
- (NSInteger)numberOfControllersInPagerController {
    return self.barTitleArray.count;
}

- (NSString *)pagerController:(TYPagerController *)pagerController titleForIndex:(NSInteger)index {
    return self.barTitleArray[index];
}

- (UIViewController *)pagerController:(TYPagerController *)pagerController controllerForIndex:(NSInteger)index {
    return self.barControllerArray[index];
}

#pragma mark -
- (NSArray *)getTitleControllerArray {
    NSMutableArray *controllers = [NSMutableArray arrayWithCapacity:self.barTitleArray.count];
    
    self.hotVC = [[CommunityHotViewController alloc] init];
    self.hotVC.topicId = [SystemManager eventTopicId].integerValue;
    self.hotVC.hideBarSetting = YES;
    [controllers addObject:self.hotVC];
    
    CommunitySquadViewController *squadVC = [[CommunitySquadViewController alloc] init];
    squadVC.hideBarSetting = YES;
    [controllers addObject:squadVC];
    CommunityTopicViewController *topicVC = [[CommunityTopicViewController alloc] init];
    topicVC.hideBarSetting = YES;
    [controllers addObject:topicVC];
    
    return controllers.copy;
}

#pragma mark - lazy init
- (UIView *)switchView {
	if (!_switchView) {
        CGFloat tagWidth = 70.0, margin = 10.0, tagHeight = 30.0;
        
        _switchView = [[UIView alloc] initWithFrame:CGRectMake(0.0, 0.0, (tagWidth *self.barTitleArray.count + margin *(self.barTitleArray.count - 1)), tagHeight)];
        
        if (self.switchChildArray.count) [self.switchChildArray removeAllObjects];
        
        for (int i = 0; i < self.barTitleArray.count; i ++) {
            CYButton *tagBtn = [CYButton buttonWithType:UIButtonTypeCustom];
            tagBtn.frame = CGRectMake(i * (tagWidth + margin), 0.0, tagWidth, tagHeight);
            [_switchView addSubview:tagBtn];
            [tagBtn setTitle:self.barTitleArray[i] forState:UIControlStateNormal];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
            [tagBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:[UIColor clearColor]] forState:UIControlStateNormal];
            [tagBtn setBackgroundImage:[UIImage imageWithColor:ColorMainAppDarkRed] forState:UIControlStateSelected];
            tagBtn.titleLabel.font = [UIFont addPingFangSCMedium:16];;
            tagBtn.tag = 10000 + i;
            tagBtn.layer.cornerRadius = tagBtn.height / 2;
            tagBtn.clipsToBounds = YES;
            
            tagBtn.selected = (i == self.currentType) ? YES:NO;
            
            [tagBtn addTarget:self action:@selector(swithBtnClick:) forControlEvents:UIControlEventTouchUpInside];
            if (i == 0) {
                self.hotBtn = tagBtn;
                [self.switchChildArray addObject:self.hotBtn];
            }else {
                [self.switchChildArray addObject:tagBtn];
            }
        }
	}
	return _switchView;
}

- (UIScrollView *)bgScrollView {
	if (!_bgScrollView) {
		_bgScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, NavBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight - TabBarHeight)];
		_bgScrollView.scrollEnabled = NO;
		_bgScrollView.showsHorizontalScrollIndicator = NO;
		_bgScrollView.contentSize = CGSizeMake(SCREEN_WIDTH*3,0);
		[self.view addSubview:_bgScrollView];
	}
	return _bgScrollView;
}

-(CYButton *)searchB
{
    if(!_searchB){
        _searchB = [CYButton buttonWithType:UIButtonTypeCustom];
        _searchB.frame = CGRectMake(0, 0, 44, 44);
        [_searchB setImage:[[UIImage imageNamed:@"搜索"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
        _searchB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        [_searchB addTarget:self action:@selector(goSearch) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchB;
}

-(CYButton *)messageB {
	if(!_messageB){
		_messageB = [CYButton buttonWithType:UIButtonTypeCustom];
        _messageB.frame = CGRectMake(0, 0, 44, 44);
        _messageB.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [_messageB setImage:[[UIImage imageNamed:@"community_message_icon"] scaleToSize:CGSizeMake(20, 20)] forState:UIControlStateNormal];
		[_messageB addTarget:self action:@selector(goMessageCenter) forControlEvents:UIControlEventTouchUpInside];
		[_messageB addSubview:self.redLabel];
		[self.redLabel mas_makeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(_messageB.imageView.mas_right);
			make.centerY.equalTo(_messageB.imageView.mas_top);
			make.size.mas_equalTo(CGSizeMake(18, 18));
		}];
	}
	return _messageB;
}

-(UILabel*)redLabel
{
	if (!_redLabel) {
		_redLabel = [[UILabel alloc] init];
		_redLabel.textColor = [UIColor whiteColor];
		_redLabel.font = fcFont(12);
		_redLabel.textAlignment = NSTextAlignmentCenter;
		_redLabel.backgroundColor = [UIColor redColor];
		_redLabel.layer.cornerRadius = 9;
		_redLabel.hidden = YES;
		_redLabel.adjustsFontSizeToFitWidth = YES;
		_redLabel.clipsToBounds = YES;
	}
	return _redLabel;
}

- (TYTabButtonPagerController *)titleBarController {
    if (!_titleBarController) {
        _titleBarController = [[TYTabButtonPagerController alloc] init];
        _titleBarController.contentScrollEnabled = NO;
        _titleBarController.contentTopEdging = 0.0f;
        _titleBarController.dataSource = self;
    }return _titleBarController;
}

@end
