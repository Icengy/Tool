//
//  CommunityHomePageViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/30.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityHomePageViewController.h"
#import "SelfDetailViewController.h"
#import "CommunityPrivateViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityFoucsViewController.h"
#import "CommunityFansViewController.h"
#import "PaperContentViewController.h"
#import "PointExtenButton.h"
#import "NavButton.h"
#import "CommunityHomePageCell.h"
#import "CommunityHomePageModel.h"
#import "CommunityHomePagePaperCell.h"
#import "CommunityTopicDetailCell.h"
#import "ESBanner.h"

#define kPageSize 20

@interface CommunityHomePageViewController ()<CommunityTopicDetailCellDelegate>
@property (nonatomic,strong) PointExtenButton	*navFocusBtn;
//
@property (nonatomic,strong) UIView 				*headView;
@property (nonatomic,strong) PointExtenButton 	*backBtn;
@property (nonatomic,strong) UIImageView 		*headImageView;
@property (nonatomic,strong) UIImageView*officalImageV;
@property (nonatomic,strong) UILabel 			*userNameLabel;
@property (nonatomic,strong) UILabel *levelLabel;
@property (nonatomic,strong) UIImageView 		*sexImageView;
@property (nonatomic,strong) PointExtenButton	*focusBtn;
@property (nonatomic,strong) UILabel			*fansCountLabel;
@property (nonatomic,strong) UILabel			*focusCountLabel;
@property (nonatomic,strong) PointExtenButton 	*editBtn;
@property (nonatomic,strong) PointExtenButton 	*perseonalBtn;
@property (nonatomic,strong) UILabel			*signLabel;
@property (nonatomic,strong) UIView 			*seperatorView;
@property (nonatomic,strong) PointExtenButton   *countTitleLabel;
@property (nonatomic,strong) PointExtenButton   *countTitleLabel2;
@property (nonatomic,strong) PointExtenButton   *countTitleLabel3;
@property (nonatomic,strong) UIView				*selectedLine;
@property (nonatomic,strong) UIView				*seperatorLine;

@property (nonatomic,strong) CommunityHomePageModel	*model;
@property (nonatomic,assign) NSUInteger			currentPage;
@property (nonatomic,assign) NSUInteger			type;//0 发帖 1 文章 3 喜欢
@property (nonatomic,assign) CGFloat oldY;
@end

@implementation CommunityHomePageViewController

- (void)viewDidLoad {
	[super viewDidLoad];
    
    self.view.backgroundColor= UIColor.whiteColor;
    
	[self setupView];
	[self loadPersonInfo];
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	if (self.headView.hidden == YES) {
		self.navigationController.navigationBarHidden = NO;
	}
}

- (void)setupView {
	self.fd_prefersNavigationBarHidden = YES;
	UIView *navRightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 62, 22)];
	[navRightView addSubview:self.navFocusBtn];
	self.navFocusBtn.frame = CGRectMake(12, 0, 50, 22);
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:navRightView];
	[self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.right.equalTo(self.view);
		make.top.equalTo(self.view).offset(kStatusBarHeight);
	}];
	[self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.headView).offset(17.5);
		make.top.equalTo(self.headView).offset(11);
		make.size.mas_equalTo(CGSizeMake(22, 22));
	}];
	[self.headImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.headView).offset(15);
		make.top.equalTo(self.backBtn.mas_bottom).offset(12);
		make.size.mas_equalTo(CGSizeMake(60, 60));
	}];
	[self.officalImageV mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.bottom.equalTo(self.headImageView);
		make.size.mas_equalTo(CGSizeMake(18, 18));
	}];
	[self.userNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headImageView).offset(6);
		make.left.equalTo(self.headImageView.mas_right).offset(12);
		make.right.lessThanOrEqualTo(self.focusBtn).offset(-125);
	}];

	[self.sexImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.userNameLabel.mas_right).offset(8);
		make.centerY.equalTo(self.userNameLabel);
		make.size.mas_equalTo(CGSizeMake(18, 18));
	}];
	
	[self.levelLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerY.equalTo(self.userNameLabel);
		make.width.mas_greaterThanOrEqualTo(34);
		make.height.mas_equalTo(18);
		make.left.equalTo(self.sexImageView.mas_right).offset(10);
	}];
	
	[self.focusBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.right.equalTo(self.headView).offset(-10);
		make.size.mas_equalTo(CGSizeMake(50, 22));
		make.centerY.equalTo(self.userNameLabel);
	}];
	[self.fansCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.userNameLabel);
		make.bottom.equalTo(self.headImageView);
	}];
	
	//分割线
	UIView *seperatorLine = [UIView new];
	seperatorLine.backgroundColor = RGBCOLOR(102, 102, 102);
	[self.headView addSubview:seperatorLine];
	[seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.fansCountLabel.mas_right).offset(14);
		make.size.mas_equalTo(CGSizeMake(1, 14));
		make.centerY.equalTo(self.fansCountLabel);
	}];
	
	[self.focusCountLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(seperatorLine.mas_right).offset(14);
		make.centerY.equalTo(self.fansCountLabel);
	}];
	
	[self.signLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.headImageView.mas_bottom).offset(12);
		make.left.equalTo(self.headView).offset(15);
		make.right.equalTo(self.headView).offset(-15);
	}];
	[self.perseonalBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.signLabel.mas_bottom).offset(15);
		make.right.equalTo(self.headView).offset(-88);
		make.height.mas_equalTo(17);
	}];
	[self.editBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.signLabel.mas_bottom).offset(15);
		make.left.equalTo(self.headView).offset(88);
		make.height.mas_equalTo(17);
	}];
	[self.seperatorView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.signLabel.mas_bottom).offset(47);
		make.left.equalTo(self.headView);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 8));
		make.bottom.equalTo(self.headView);
	}];
	
	[self.countTitleLabel3 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.seperatorView.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(60, 65));
		make.centerX.equalTo(self.view).offset(self.model.isOfficial == 0 ? 48 : 0);
	}];
	
	[self.countTitleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.countTitleLabel3);
		make.size.mas_equalTo(CGSizeMake(60, 65));
		make.right.equalTo(self.countTitleLabel3.mas_left).offset(-36);
	}];
	
	[self.countTitleLabel2 mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.countTitleLabel3);
		make.size.mas_equalTo(CGSizeMake(60, 65));
		make.left.equalTo(self.countTitleLabel3.mas_right).offset(36);
	}];
	
	[self.selectedLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(self.countTitleLabel);
		make.size.mas_equalTo(CGSizeMake(60, 4));
		make.bottom.equalTo(self.countTitleLabel).offset(-4);
	}];
	
	[self.seperatorLine mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.selectedLine.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 1));
		make.left.equalTo(self.view);
	}];
	
	[self.view addSubview:self.tableView];
	[self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.bottom.left.right.equalTo(self.view);
		make.top.equalTo(self.seperatorLine.mas_bottom);
	}];
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, -kBottomSafeArea, 0);
	self.tableView.estimatedRowHeight = 0;
	self.tableView.estimatedSectionFooterHeight = 0;
	self.tableView.estimatedSectionHeaderHeight = 0;
	[self.tableView registerClass:[CommunityHomePageCell class] forCellReuseIdentifier:@"CommunityHomePageCell"];
	[self.tableView registerClass:[CommunityHomePagePaperCell class] forCellReuseIdentifier:@"CommunityHomePagePaperCell"];
	[self.tableView registerClass:[CommunityTopicDetailCell class] forCellReuseIdentifier:@"CommunityTopicDetailCell"];
    
    [self.tableView addRefreshHeaderWithTarget:self action:@selector(loadData)];
    [self.tableView addRefreshFooterWithTarget:self action:@selector(loadMoreData)];
	
	[self.tableView.mj_header beginRefreshing];
}

- (void)loadPersonInfo {
	if (!QM_IS_STR_NIL(self.authorUid) && (self.authorUid.integerValue != App_Utility.currentUser.userId.integerValue)) {
		//他人主页
		self.perseonalBtn.hidden = YES;
		self.editBtn.hidden = YES;
		[self.seperatorView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.signLabel.mas_bottom).offset(12);
			make.left.equalTo(self.headView);
			make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 8));
			make.bottom.equalTo(self.headView);
		}];
	} else {
		//个人主页
		self.perseonalBtn.hidden = NO;
		self.editBtn.hidden = NO;
		[self.seperatorView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.signLabel.mas_bottom).offset(47);
			make.left.equalTo(self.headView);
			make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 8));
			make.bottom.equalTo(self.headView);
		}];
	}
	//获取个人信息
	@weakify(self)
	[ESNetworkService communityHomePageInfoWithHomeUserId:self.authorUid Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			CommunityHomePageModel *model = [CommunityHomePageModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				[self configHeadViewWithModel:model];
			});
		}
	}];
}

- (void)configHeadViewWithModel:(CommunityHomePageModel *)model {
	self.model = model;
	[self.headImageView sd_setImageWithURL:[NSURL URLWithString:model.userAvatar] placeholderImage:GetImage(@"avatar")];
	self.officalImageV.hidden = model.isOfficial == 0 ? YES : NO;
	self.userNameLabel.text = model.userName;
	self.levelLabel.text = [@"LV" stringByAppendingFormat:@"%@",model.level];
	NSArray *colorArr = @[RGBCOLOR(148, 176, 125),RGBCOLOR(0, 145, 255),RGBCOLOR(144, 19, 254),RGBCOLOR(255, 125, 0),RGBCOLOR(253, 2, 48)];
	self.levelLabel.backgroundColor = colorArr[((model.level.integerValue  - 1) / 4)];

	self.navigationItem.title = model.userName;
	self.sexImageView.image = (model.gender == 0) ? GetImage(@"community_sex_women") : GetImage(@"community_sex_man");
	self.signLabel.text = model.userSignature;
	self.focusCountLabel.text = [NSString stringWithFormat:@"关注 %@",@(model.followingCount)];
	self.fansCountLabel.text = [NSString stringWithFormat:@"粉丝 %@",@(model.fansCount)];
	[self.focusBtn setTitle:(self.model.followStatus == 2? @"互相关注" : @"已关注") forState:UIControlStateSelected];
	[self.navFocusBtn setTitle:(self.model.followStatus == 2? @"互相关注" : @"已关注") forState:UIControlStateSelected];
	[self.focusBtn mas_updateConstraints:^(MASConstraintMaker *make) {
		make.width.mas_equalTo(self.model.followStatus == 2 ? 62 : 50);
	}];
	self.navFocusBtn.frame = self.model.followStatus == 2 ? CGRectMake(0, 0, 62, 22) : CGRectMake(10, 0, 50, 22);
	self.focusBtn.selected = model.followStatus == 0 ? NO : YES;
	self.navFocusBtn.selected = model.followStatus == 0 ? NO : YES;
	if (model.userId == App_Utility.currentUser.userId.integerValue) {
		self.focusBtn.hidden = YES;
		self.navFocusBtn.hidden = YES;
	} else {
		self.focusBtn.hidden = NO;
		self.navFocusBtn.hidden = NO;
	}
	if ([model.role containsObject:@(8)]) {
		//官方号
		self.countTitleLabel2.hidden = NO;
	} else {
		self.countTitleLabel2.hidden = YES;
	}
	
	[self.countTitleLabel3 mas_remakeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.seperatorView.mas_bottom);
		make.size.mas_equalTo(CGSizeMake(60, 65));
		make.centerX.equalTo(self.view).offset(self.model.isOfficial == 0 ? 48 : 0);
	}];
	[self.countTitleLabel setTitle:[NSString stringWithFormat:@"发帖\n%@",@(model.postCount)]  forState:UIControlStateNormal];
	[self.countTitleLabel2 setTitle:[NSString stringWithFormat:@"文章\n%@",@(model.textCount)]  forState:UIControlStateNormal];
	[self.countTitleLabel3 setTitle:[NSString stringWithFormat:@"喜欢\n%@",@(model.favouriteCount)]  forState:UIControlStateNormal];
}

- (void)loadData {
	self.currentPage = 1;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityHomePageListWithHomeUserId:self.authorUid page:self.currentPage type:self.type pageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_header endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
					self.tableView.mj_footer.hidden = YES;
				} else {
					self.tableView.mj_footer.hidden = NO;
					[self.tableView.mj_footer resetNoMoreData];
				}
				[self.dataSource removeAllObjects];
				[self.dataSource addObjectsFromArray:model.posts];
				[self.tableView reloadData];
			});
		}
	}];
}

- (void)loadMoreData {
	self.currentPage ++;
	//获取数据
	@weakify(self)
	[ESNetworkService getCommunityHomePageListWithHomeUserId:self.authorUid page:self.currentPage type:self.type pageSize:kPageSize Response:^(id dict, ESError *error) {
		dispatch_main_async_safe(^{
			[self.tableView.mj_footer endRefreshing];
		});
		if (dict&&[dict[@"code"] integerValue] == 0) {
			@strongify(self)
			CommunityTopicDetailModel *model = [CommunityTopicDetailModel mj_objectWithKeyValues:dict[@"data"]];
			dispatch_main_async_safe(^{
				if (model.page >= model.pageCount) {
					[self.tableView.mj_footer endRefreshingWithNoMoreData];
				}
				[self.dataSource addObjectsFromArray:model.posts];
				[self.tableView reloadData];
			});
		}
	}];
}

#pragma mark - tableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 0.01;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
	return 0.01;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
	return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	return nil;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return self.dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (self.type == 1) {
		//文章
		CommunityHomePagePaperCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityHomePagePaperCell"];
		[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row];
			return cell;
	} else if (self.type == 0){
		CommunityHomePageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityHomePageCell"];
		cell.cellDelegate = self;
		[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row];
		return cell;
	} else {
		CommunityTopicDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CommunityTopicDetailCell"];
		cell.cellType = CellTypeFavorate;
		cell.personalClick = ^(CommunityTopicDetailItem *model) {
			//点击头像
			CommunityHomePageViewController *vc = [CommunityHomePageViewController new];
			vc.authorUid = @(model.authorUid).stringValue;
			
			vc.hidesBottomBarWhenPushed = YES;
			[self.navigationController pushViewController:vc animated:YES];
		};
		cell.cellDelegate = self;
		[cell configCellWithModel:self.dataSource[indexPath.row] indexPath:indexPath.row sortTpye:-1];
		return cell;
	}
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CommunityTopicDetailItem *item = self.dataSource[indexPath.row];
	if (self.type == 0) {
		//发帖
		return item.myHeight - 50;
	} else if (self.type == 3){
		//喜欢
		return item.myHeight;
	} else {
		//文章
		tableView.rowHeight = UITableViewAutomaticDimension;
		tableView.estimatedRowHeight = 147;
		return tableView.rowHeight;
	}
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:NO];
	CommunityTopicDetailItem *item = self.dataSource[indexPath.row];
	if (self.type == 0 || self.type == 3) {
		//跳转帖子详情
		CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
		vc.postId = item.postId;
		vc.hidesBottomBarWhenPushed = YES;
		vc.deleteBlock = ^{
			[self.tableView.mj_header beginRefreshing];
		};
		[self.navigationController pushViewController:vc animated:YES];
	} else {
		ESBanner *bannerModel = [ESBanner new];
		bannerModel.textId = @(item.textId).stringValue;
		bannerModel.textType = 0;
		bannerModel.textFormat = @"1";
		bannerModel.link = @"";
		//文章
		PaperContentViewController*vc = [PaperContentViewController new];
		vc.banerModel = bannerModel;
		[self.navigationController pushViewController:vc animated:YES];
	}
}

#pragma mark - cellDelegate
- (void)likeBtnClick:(NSUInteger)row {
	if (self.type == 0 || self.type == 3) {
		CommunityTopicDetailItem *item =  self.dataSource[row];
		@weakify(self)
		[ESNetworkService communityPostLikeWithPostId:item.postId likeStatus:!item.isLiked Response:^(id dict, ESError *error) {
			if (dict&&[dict[@"code"] integerValue] == 0) {
				@strongify(self)
				dispatch_main_async_safe(^{
					//点赞接口调用成功后
					NSDictionary *dic = dict[@"data"];
					item.isLiked = !item.isLiked;
					item.likeCount = [dic[@"likeCount"] integerValue];
					[UIView performWithoutAnimation:^{
						[self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
					}];
				});
			}
		}];
	}
}

- (void)commentBtnClick:(NSUInteger)row {
	CommunityTopicDetailItem *item = self.dataSource[row];
	if (self.type == 0 || self.type == 3) {
		//跳转帖子详情
		CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
		vc.postId = item.postId;
		vc.hidesBottomBarWhenPushed = YES;
		vc.needShowCommentWhenPush = YES;
		vc.deleteBlock = ^{
			[self.tableView.mj_header beginRefreshing];
		};
		[self.navigationController pushViewController:vc animated:YES];
	} else {
		ESBanner *bannerModel = [ESBanner new];
		bannerModel.textId = @(item.textId).stringValue;
		bannerModel.textType = 0;
		bannerModel.textFormat = @"1";
		bannerModel.link = @"";
		//文章
		PaperContentViewController*vc = [PaperContentViewController new];
		vc.needShowCommentWhenPush = YES;
		vc.banerModel = bannerModel;
		[self.navigationController pushViewController:vc animated:YES];
	}
}

#pragma mark - 头部视图收缩
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
	if(scrollView.contentOffset.y - self.oldY >20 && scrollView.contentOffset.y>0){
		self.oldY = scrollView.contentOffset.y;
		self.navigationController.navigationBarHidden = NO;
		[UIView animateWithDuration:0.2 animations:^{
			self.headView.hidden = YES;
			[self.countTitleLabel3 mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.view).offset(NavBarHeight);
				make.size.mas_equalTo(CGSizeMake(60, 65));
				make.centerX.equalTo(self.view).offset(self.model.isOfficial == 0 ? 48 : 0);
			}];
			
			[self.countTitleLabel3.superview layoutIfNeeded];
		}];
		return;
	}
	if(scrollView.contentOffset.y- self.oldY < -20&&scrollView.contentOffset.y < 0){
		self.oldY = scrollView.contentOffset.y;
		self.navigationController.navigationBarHidden = YES;
		[UIView animateWithDuration:0.2 animations:^{
			self.headView.hidden = NO;
			[self.countTitleLabel3 mas_remakeConstraints:^(MASConstraintMaker *make) {
				make.top.equalTo(self.seperatorView.mas_bottom);
				make.size.mas_equalTo(CGSizeMake(60, 65));
				make.centerX.equalTo(self.view).offset(self.model.isOfficial == 0 ? 48 : 0);
			}];
			[self.countTitleLabel3.superview layoutIfNeeded];
		}];
	}
}

#pragma mark - action
- (void)back {
	[self.navigationController popViewControllerAnimated:YES];
}

- (void)editBtnClick {
	//个人资料
	SelfDetailViewController*vc= [SelfDetailViewController new];
	[vc setHidesBottomBarWhenPushed:YES];
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)perseonalBtnClick {
	//私人空间
	CommunityPrivateViewController *vc = [CommunityPrivateViewController new];
	vc.authorUid = self.authorUid;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)segmentClick:(PointExtenButton *)btn {
	if (btn.selected == YES) {
		return;
	}
	btn.selected = !btn.selected;
	btn.titleLabel.font = fcBoldFont(18);
	if (btn.tag == 1000) {
		//发帖
		self.type = 0;
		self.countTitleLabel2.selected = NO;
		self.countTitleLabel3.selected = NO;
		self.countTitleLabel2.titleLabel.font = fcBoldFont(16);
		self.countTitleLabel3.titleLabel.font = fcBoldFont(16);
		[self.selectedLine mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(self.countTitleLabel);
			make.size.mas_equalTo(CGSizeMake(60, 4));
			make.bottom.equalTo(self.countTitleLabel3).offset(-4);
		}];
	} else if (btn.tag == 1001) {
		//文章
		self.type = 1;
		self.countTitleLabel.selected = NO;
		self.countTitleLabel3.selected = NO;
		self.countTitleLabel.titleLabel.font = fcBoldFont(16);
		self.countTitleLabel3.titleLabel.font = fcBoldFont(16);
		[self.selectedLine mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(self.countTitleLabel2);
			make.size.mas_equalTo(CGSizeMake(60, 4));
			make.bottom.equalTo(self.countTitleLabel3).offset(-4);
		}];
	} else {
		//喜欢
		self.type = 3;
		self.countTitleLabel.selected = NO;
		self.countTitleLabel2.selected = NO;
		self.countTitleLabel.titleLabel.font = fcBoldFont(16);
		self.countTitleLabel2.titleLabel.font = fcBoldFont(16);
		[self.selectedLine mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.centerX.equalTo(self.countTitleLabel3);
			make.size.mas_equalTo(CGSizeMake(60, 4));
			make.bottom.equalTo(self.countTitleLabel3).offset(-4);
		}];
	}
	[self.tableView.mj_header beginRefreshing];
}

- (void)focusBtnClick:(PointExtenButton *)btn {
	NSUInteger followStatus = btn.isSelected == YES ? 0 : 1;
	//关注
	@weakify(self)
	[ESNetworkService followCommunityUserWithUserId:self.model.userId followStatus:followStatus Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				btn.selected = !btn.selected;
				NSDictionary *result = dict[@"data"];
				self.model.followStatus = [result[@"followStatus"] integerValue];
				[self.focusBtn setTitle:(self.model.followStatus == 2? @"互相关注" : @"已关注") forState:UIControlStateSelected];
				[self.navFocusBtn setTitle:(self.model.followStatus == 2? @"互相关注" : @"已关注") forState:UIControlStateSelected];
				self.focusBtn.selected = self.model.followStatus == 0 ? NO : YES;
				self.navFocusBtn.selected = self.model.followStatus == 0 ? NO : YES;
				[self.focusBtn mas_updateConstraints:^(MASConstraintMaker *make) {
					make.width.mas_equalTo(self.model.followStatus == 2 ? 62 : 50);
				}];
				self.navFocusBtn.frame = self.model.followStatus == 2 ? CGRectMake(0, 0, 62, 22) : CGRectMake(10, 0, 50, 22);
			});
		}
	}];
}

- (void)fansCountLabelClick {
	//粉丝数量点击
	CommunityFansViewController *vc = [CommunityFansViewController new];
	vc.userId = self.model.userId;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}

- (void)focusCountLabelClick {
	//关注数点击
	CommunityFoucsViewController *vc = [CommunityFoucsViewController new];
	vc.userId = self.model.userId;
	vc.hidesBottomBarWhenPushed = YES;
	[self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - lazy init
- (PointExtenButton *)navFocusBtn {
	if (!_navFocusBtn) {
		_navFocusBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_navFocusBtn setTitle:@"+关注" forState:UIControlStateNormal];
		[_navFocusBtn setTitle:@"已关注" forState:UIControlStateSelected];
		[_navFocusBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_navFocusBtn.titleLabel.font = fcFont(11);
		[_navFocusBtn setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(204, 204, 204)] forState:UIControlStateSelected];
		[_navFocusBtn setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(253, 2, 48)] forState:UIControlStateNormal];
		[_navFocusBtn addTarget:self action:@selector(focusBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_navFocusBtn.layer.cornerRadius = 11;
		_navFocusBtn.clipsToBounds = YES;
	}
	return _navFocusBtn;
}

- (UIView *)headView {
	if (!_headView) {
		_headView = [UIView new];
		_headView.backgroundColor = [UIColor whiteColor];
		[self.view addSubview:_headView];
	}
	return _headView;
}

- (PointExtenButton *)backBtn {
	if (!_backBtn) {
		_backBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_backBtn setImage:GetImage(@"nav_return_black") forState:UIControlStateNormal];
		_backBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_backBtn addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
		[self.headView addSubview:_backBtn];
	}
	return _backBtn;
}

- (UIImageView *)headImageView {
	if (!_headImageView) {
		_headImageView = [UIImageView new];
		_headImageView.layer.cornerRadius = 30;
		_headImageView.clipsToBounds = YES;
		[self.headView addSubview:_headImageView];
	}
	return _headImageView;
}

-(UIImageView*)officalImageV
{
	if (!_officalImageV) {
		_officalImageV = [UIImageView new];
		_officalImageV.image = GetImage(@"topic_official_icon");
		[self.headView addSubview:_officalImageV];
	}
	return _officalImageV;
}

- (UILabel *)userNameLabel {
	if (!_userNameLabel) {
		_userNameLabel = [UILabel new];
		_userNameLabel.text = @"用户名";
		_userNameLabel.textColor = ColorAppBlack;
		_userNameLabel.font = fcBoldFont(18);
		[self.headView addSubview:_userNameLabel];
	}
	return _userNameLabel;
}

- (UILabel *)levelLabel {
	if (!_levelLabel) {
		_levelLabel = [UILabel new];
		_levelLabel.font = fcBoldFont(12);
		_levelLabel.textColor = [UIColor whiteColor];
		_levelLabel.textAlignment = NSTextAlignmentCenter;
		_levelLabel.layer.cornerRadius = 4;
		_levelLabel.clipsToBounds = YES;
        _levelLabel.hidden = YES;
		[self.headView addSubview:_levelLabel];
	}
	return _levelLabel;
}

- (UIImageView *)sexImageView {
	if (!_sexImageView) {
		_sexImageView = [UIImageView new];
		_sexImageView.image = GetImage(@"community_sex_man");
		[self.headView addSubview:_sexImageView];
	}
	return _sexImageView;
}

- (PointExtenButton *)focusBtn {
	if (!_focusBtn) {
		_focusBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_focusBtn setTitle:@"+关注" forState:UIControlStateNormal];
		[_focusBtn setTitle:@"已关注" forState:UIControlStateSelected];
		[_focusBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_focusBtn.titleLabel.font = fcFont(11);
		[_focusBtn setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(204, 204, 204)] forState:UIControlStateSelected];
		[_focusBtn setBackgroundImage:[UIImage imageWithColor:RGBCOLOR(253, 2, 48)] forState:UIControlStateNormal];
		[_focusBtn addTarget:self action:@selector(focusBtnClick:) forControlEvents:UIControlEventTouchUpInside];
		_focusBtn.layer.cornerRadius = 11;
		_focusBtn.clipsToBounds = YES;
		[self.headView addSubview:_focusBtn];
	}
	return _focusBtn;
}

- (UILabel *)fansCountLabel {
	if (!_fansCountLabel) {
		_fansCountLabel = [UILabel new];
		_fansCountLabel.textColor = ColorAppBlack;
		_fansCountLabel.font = fcFont(12);
		_fansCountLabel.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fansCountLabelClick)];
		[_fansCountLabel addGestureRecognizer:tap];
		[self.headView addSubview:_fansCountLabel];
	}
	return _fansCountLabel;
}

- (UILabel *)focusCountLabel {
	if (!_focusCountLabel) {
		_focusCountLabel = [UILabel new];
		_focusCountLabel.textColor = ColorAppBlack;
		_focusCountLabel.font = fcFont(12);
		_focusCountLabel.userInteractionEnabled = YES;
		UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(focusCountLabelClick)];
		[_focusCountLabel addGestureRecognizer:tap];
		[self.headView addSubview:_focusCountLabel];
	}
	return _focusCountLabel;
}

- (PointExtenButton *)editBtn {
	if (!_editBtn) {
		_editBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_editBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_editBtn setTitle:@"编辑资料" forState:UIControlStateNormal];
		[_editBtn setImage:GetImage(@"community_edit_icon") forState:UIControlStateNormal];
		_editBtn.titleLabel.font = fcFont(12);
		_editBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_editBtn addTarget:self action:@selector(editBtnClick) forControlEvents:UIControlEventTouchUpInside];
		[self.headView addSubview:_editBtn];
	}
	return _editBtn;
}

- (PointExtenButton *)perseonalBtn {
	if (!_perseonalBtn) {
		_perseonalBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_perseonalBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_perseonalBtn setTitle:@"私人空间" forState:UIControlStateNormal];
		[_perseonalBtn setImage:GetImage(@"community_private_icon") forState:UIControlStateNormal];
		_perseonalBtn.titleLabel.font = fcFont(12);
		_perseonalBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_perseonalBtn addTarget:self action:@selector(perseonalBtnClick) forControlEvents:UIControlEventTouchUpInside];
		[self.headView addSubview:_perseonalBtn];
	}
	return _perseonalBtn;
}

- (UILabel *)signLabel {
	if (!_signLabel) {
		_signLabel = [UILabel new];
		_signLabel.textColor = RGBCOLOR(58, 58, 58);
		_signLabel.font = fcFont(14);
		_signLabel.numberOfLines = 0;
		[self.headView addSubview:_signLabel];
	}
	return _signLabel;
}

- (UIView *)seperatorView {
	if (!_seperatorView) {
		_seperatorView = [UIView new];
		_seperatorView.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.headView addSubview:_seperatorView];
	}
	return _seperatorView;
}

- (PointExtenButton *)countTitleLabel {
	if (!_countTitleLabel) {
		_countTitleLabel = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_countTitleLabel setTitle:@"发帖\n0" forState:UIControlStateNormal];
		[_countTitleLabel setTitleColor:RGBCOLOR(102, 102, 102) forState:UIControlStateNormal];
		[_countTitleLabel setTitleColor:ColorAppBlack forState:UIControlStateSelected];
		_countTitleLabel.titleLabel.font = fcBoldFont(16);
		_countTitleLabel.titleLabel.numberOfLines = 2;
		_countTitleLabel.titleLabel.textAlignment = NSTextAlignmentCenter;
		_countTitleLabel.tag = 1000;
		_countTitleLabel.selected = YES;
		[_countTitleLabel addTarget:self action:@selector(segmentClick:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_countTitleLabel];
	}
	return _countTitleLabel;
}

- (PointExtenButton *)countTitleLabel2 {
	if (!_countTitleLabel2) {
		_countTitleLabel2 = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_countTitleLabel2 setTitle:@"文章\n0" forState:UIControlStateNormal];
		[_countTitleLabel2 setTitleColor:RGBCOLOR(102, 102, 102) forState:UIControlStateNormal];
		[_countTitleLabel2 setTitleColor:ColorAppBlack forState:UIControlStateSelected];
		_countTitleLabel2.titleLabel.font = fcBoldFont(16);
		_countTitleLabel2.titleLabel.numberOfLines = 2;
		_countTitleLabel2.titleLabel.textAlignment = NSTextAlignmentCenter;
		_countTitleLabel2.tag = 1001;
		_countTitleLabel2.hidden = YES;
		[_countTitleLabel2 addTarget:self action:@selector(segmentClick:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_countTitleLabel2];
	}
	return _countTitleLabel2;
}

- (PointExtenButton *)countTitleLabel3 {
	if (!_countTitleLabel3) {
		_countTitleLabel3 = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_countTitleLabel3 setTitle:@"喜欢\n0" forState:UIControlStateNormal];
		[_countTitleLabel3 setTitleColor:RGBCOLOR(102, 102, 102) forState:UIControlStateNormal];
		[_countTitleLabel3 setTitleColor:ColorAppBlack forState:UIControlStateSelected];
		_countTitleLabel3.titleLabel.font = fcBoldFont(16);
		_countTitleLabel3.titleLabel.numberOfLines = 2;
		_countTitleLabel3.titleLabel.textAlignment = NSTextAlignmentCenter;
		_countTitleLabel3.tag = 1002;
		[_countTitleLabel3 addTarget:self action:@selector(segmentClick:) forControlEvents:UIControlEventTouchUpInside];
		[self.view addSubview:_countTitleLabel3];
	}
	return _countTitleLabel3;
}

- (UIView *)selectedLine {
	if (!_selectedLine) {
		_selectedLine = [UIView new];
		_selectedLine.backgroundColor = ColorAppRed;
		_selectedLine.layer.cornerRadius = 2;
		_selectedLine.clipsToBounds = YES;
		[self.view addSubview:_selectedLine];
	}
	return _selectedLine;
}

- (UIView *)seperatorLine {
	if (!_seperatorLine) {
		_seperatorLine = [UIView new];
		_seperatorLine.backgroundColor = RGBCOLOR(244, 244, 244);
		[self.view addSubview:_seperatorLine];
	}
	return _seperatorLine;
}
@end
