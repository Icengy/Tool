//
//  CommunityViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/3/28.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CommunityViewController : ESViewController

@end

NS_ASSUME_NONNULL_END
