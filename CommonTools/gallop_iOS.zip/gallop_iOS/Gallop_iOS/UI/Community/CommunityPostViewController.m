//
//  CommunityPostViewController.m
//  Gallop_iOS
//
//  Created by lixuanye on 2020/4/1.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "CommunityPostViewController.h"
#import "CommunityPaperContentViewController.h"
#import "CommunityPostContentScrollView.h"
#import "ComunityTopicSelectView.h"
#import "ImageDeliverManager.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <IQKeyboardManager.h>
#define uCloudPrefix @"http://gallop-avatar.cn-bj.ufileos.com/"

@interface CommunityPostViewController ()<AppUtilityDelegate,CommunityPostContentScrollViewDelegate>
//ui
@property (nonatomic,strong) UIButton *postBtn;

@property (nonatomic,strong) CommunityPostContentScrollView *contentView;
//topicSelect
@property (nonatomic,strong) ComunityTopicSelectView *topicSelectView;
//video
@property (nonatomic,strong) UIView *videoView;
@property (nonatomic,strong) UIImageView *videoFirstFrameImageView;
@property (nonatomic,strong) PointExtenButton *deleteVideoBtn;
@property (nonatomic,strong) UIView *coverView;
@property (nonatomic,strong) MBProgressHUD *hud;

//bottom
@property (nonatomic,strong) UIView *bottomView;
@property (nonatomic,strong) UIButton *picBtn;
@property (nonatomic,strong) UIButton *videoBtn;
//data
@property (nonatomic,strong) NSString *videoPath;
@property (nonatomic,strong) NSString *videoFirstFrameUrl;
@property (nonatomic,strong) NSMutableArray *imgArray;//最终确定照片URl数组

@property (nonatomic,assign) int seletedImageCount;//最多9张
@property (nonatomic,assign) NSInteger currentTextIndex;//当前光标位置
@property (nonatomic,assign) BOOL isVideoUpLoading;//是否后台上传视频中
@end

@implementation CommunityPostViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	[self clearCache];
	[self setupView];
	[self getTopicList];
	self.navigationItem.title = @"发布内容";
	self.seletedImageCount = 0;
}

- (void)viewWillAppear:(BOOL)animated {
	[super viewWillAppear:animated];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
	[IQKeyboardManager sharedManager].enable = NO;
    
    [(ESNavigationViewController *)self.navigationController updateDefaultSetting];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	[IQKeyboardManager sharedManager].enableAutoToolbar = YES;
	[IQKeyboardManager sharedManager].enable = YES;
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark--键盘弹出
-(void)keyboardWillShow:(NSNotification *)notification
{
	CGRect frame = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
	CGFloat keyboardDuration = [[notification userInfo][UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	[UIView animateWithDuration:keyboardDuration animations:^{
		[self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.view);
			make.left.equalTo(self.view);
			make.width.mas_equalTo(SCREEN_WIDTH);
			make.bottom.equalTo(self.view).offset(-50-frame.size.height);
		}];
		[self.contentView.superview layoutIfNeeded];
	}];
}

-(void)keyboardWillHide:(NSNotification *)notification
{
	CGFloat keyboardDuration = [[notification userInfo][UIKeyboardAnimationDurationUserInfoKey] doubleValue];
	[UIView animateWithDuration:keyboardDuration animations:^{
		[self.contentView mas_remakeConstraints:^(MASConstraintMaker *make) {
			make.top.equalTo(self.view);
			make.left.equalTo(self.view);
			make.width.mas_equalTo(SCREEN_WIDTH);
			make.bottom.equalTo(self.view).offset(-50-kBottomSafeArea);
		}];
		[self.contentView.superview layoutIfNeeded];
	}];
}

- (void)clearCache {
	if (!QM_IS_ARRAY_NIL([SystemManager uploadedPhotoCache])) {
		for (NSString *keyName in [SystemManager uploadedPhotoCache]) {
			[[ImageDeliverManager sharedInstance] deletePublicImage:keyName];
		}
		[SystemManager setUploadedPhotoCache:[NSMutableArray array]];
	}
	if (!QM_IS_ARRAY_NIL([SystemManager uploadedVideoCache])) {
		for (NSString *keyName in [SystemManager uploadedVideoCache]) {
			[[ImageDeliverManager sharedInstance] deletePublicImage:keyName];
		}
		[SystemManager setUploadedVideoCache:[NSMutableArray array]];
	}
}

- (void)setupView {
	UIView *barButtonView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 42, 22)];
	[barButtonView addSubview:self.postBtn];
	self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:barButtonView];
	
	
	[self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.view);
		make.left.equalTo(self.view);
		make.width.mas_equalTo(SCREEN_WIDTH);
		make.bottom.equalTo(self.view).offset(-50-kBottomSafeArea);
	}];
							  
	[self.bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView.mas_bottom);
		make.left.right.equalTo(self.view);
		make.height.mas_offset(50);
	}];
	
	[self.videoView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.equalTo(self.contentView.mas_bottom).offset(-120);
		make.left.equalTo(self.view).offset(15);
		make.size.mas_equalTo(CGSizeMake(115, 115));
	}];
	
	[self.videoFirstFrameImageView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.bottom.equalTo(self.videoView);
		make.right.equalTo(self.videoView).offset(-15);
		make.top.equalTo(self.videoView).offset(15);
	}];
	
	[self.coverView mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.bottom.equalTo(self.videoView);
		make.right.equalTo(self.videoView).offset(-15);
		make.top.equalTo(self.videoView).offset(15);
	}];
	[self.deleteVideoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.top.right.equalTo(self.videoView);
		make.size.mas_equalTo(CGSizeMake(30, 30));
	}];
	
	[self.picBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.bottomView).offset(15);
		make.centerY.equalTo(self.bottomView);
		make.height.mas_equalTo(18);
	}];
	[self.videoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
		make.left.equalTo(self.picBtn.mas_right).offset(20);
		make.centerY.equalTo(self.bottomView);
		make.height.mas_equalTo(18);
	}];
	
	UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selectTopic)];
	[self.contentView.topicLabel addGestureRecognizer:tap];
}

- (void)getTopicList {
	//获取话题列表
	@weakify(self)
	[ESNetworkService getCommunityPostTopicWithResponse:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				CommunityPostTopicList *model = [CommunityPostTopicList mj_objectWithKeyValues:dict];
				[model.data enumerateObjectsUsingBlock:^(CommunityPostTopicItem * item, NSUInteger idx, BOOL * _Nonnull stop) {
					if (item.topicId == self.topicId) {
						self.contentView.topicLabel.text = [@"#" stringByAppendingString:item.name];
					}
				}];
				if (QM_IS_STR_NIL(self.contentView.topicLabel.text)) {
					self.contentView.topicLabel.text = [@"#" stringByAppendingString:model.data[0].name];
				}
				[self.topicSelectView configSelectView:model];
			});
		}
	}];
}

#pragma mark - action
- (void)selectTopic {
	//选择话题
	[UIView animateWithDuration:.3f animations:^{
		self.topicSelectView.frame = CGRectMake(0, NavBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight);
	}];
}

- (void)addPicture {
	if (self.seletedImageCount >= 9) {
		[CMMUtility showToastWithText:@"最多选择9张图片"];
		return;
	}
	self.currentTextIndex = -1;
	[self.contentView.contentTextViewArr enumerateObjectsUsingBlock:^(ESAdjustTextView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
		if (obj.textView.isFirstResponder) {
			self.currentTextIndex = idx;
			[obj.textView resignFirstResponder];
		}
	}];
	App_Utility.delegate = self;
	App_Utility.completeImage = 3;
	App_Utility.seletedImageCount = self.seletedImageCount;
	[App_Utility usePhotoForGetImage];
}

- (void)addVideo {
	if (_hud) {
		[CMMUtility showToastWithText:@"视频上传中"];
		return;
	}
	App_Utility.delegate = self;
	[App_Utility usePhotoForGetVideo];
}

- (void)post {
	if (self.imgArray.count < self.seletedImageCount) {
		[CMMUtility showToastWithText:@"正在上传图片"];
		return;
	}
	if (self.isVideoUpLoading) {
		[CMMUtility showToastWithText:@"正在上传视频"];
		return;
	}
	
	if (QM_IS_STR_NIL(self.contentView.titleTextField.text)) {
		[CMMUtility showToastWithText:@"请填写标题"];
		return;
	}
	if (self.contentView.titleTextField.text.length < 4 || self.contentView.titleTextField.text.length > 50) {
		[CMMUtility showToastWithText:@"标题要求4-50字"];
		return;
	}
	
	NSUInteger count = 0;
	for (ESAdjustTextView *view in self.contentView.contentTextViewArr) {
		count += view.textView.text.length;
	}
	if (count <= 0 && self.seletedImageCount <= 0 && QM_IS_STR_NIL(self.videoPath)) {
		[CMMUtility showToastWithText:@"请输入内容"];
		return;
	}
	
	
	NSMutableArray *resultArr = [NSMutableArray array];
	__block NSUInteger imageIndex = 0;
	[self.contentView.contentTextViewArr enumerateObjectsUsingBlock:^(ESAdjustTextView *view, NSUInteger idx, BOOL * _Nonnull stop) {
		if (!QM_IS_STR_NIL(view.textView.text)) {
			[resultArr addObject:@{@"type":@"words",@"content":view.textView.text}];
		}
		if (imageIndex < self.imgArray.count) {
			[resultArr addObject:@{@"type":@"image",@"content":self.imgArray[imageIndex]}];
			imageIndex ++;
		}
	}];
	
	NSString *headImg = QM_IS_ARRAY_NIL(self.imgArray) ? @"" : self.imgArray[0];
	@weakify(self)
	[ESNetworkService communityPostCreate:self.topicId
                                    title:self.contentView.titleTextField.text
                                  headImg:headImg
                                videoPath:self.videoPath
                                 pictures:[self.imgArray componentsJoinedByString:@","]
                          videoFirstFrame:self.videoFirstFrameUrl
                                  content:[resultArr JSONString]
                                wordCount:count
                                 Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				NSDictionary *mdoel = dict[@"data"];
				[SystemManager setUploadedPhotoCache:[NSMutableArray array]];
				[SystemManager setUploadedVideoCache:[NSMutableArray array]];
				[self.navigationController popViewControllerAnimated:NO];
				//跳转帖子详情
				CommunityPaperContentViewController *vc = [CommunityPaperContentViewController new];
				vc.postId = [[mdoel objectForKey:@"postId"] integerValue];
				vc.hidesBottomBarWhenPushed = YES;
				UITabBarController *tab = ((UITabBarController *) APP_DELEGATE.window.rootViewController);
				UINavigationController*nav = tab.selectedViewController;
				[nav pushViewController:vc animated:YES];
			});
		}
	}];
}

- (void)deletePicture:(NSUInteger)index {
	if (!QM_IS_ARRAY_NIL(self.imgArray)) {
		NSString *link = [self.imgArray objectAtIndex:index];
		[self.imgArray removeObjectAtIndex:index];
		NSString *keyName = [link substringFromIndex:[uCloudPrefix length]];
		[[ImageDeliverManager sharedInstance] deletePublicImage:keyName];
		NSMutableArray *arr = [NSMutableArray arrayWithArray:[SystemManager uploadedPhotoCache]];
		[arr removeObject:keyName];
		[SystemManager setUploadedPhotoCache:arr];
		self.seletedImageCount -= 1;
		[self.imgArray removeObject:link];
	}
}

- (NSString *)deleteVideo:(PointExtenButton *)btn {
	if (!QM_IS_STR_NIL(self.videoPath)) {
		NSString *keyName = [self.videoPath substringFromIndex:[uCloudPrefix length]];
		[[ImageDeliverManager sharedInstance] deletePublicImage:keyName];
		NSMutableArray *arr = [NSMutableArray arrayWithArray:[SystemManager uploadedVideoCache]];
		[arr removeObject:keyName];
		[SystemManager setUploadedVideoCache:arr];
		self.videoPath = @"";
		self.videoFirstFrameUrl = @"";
		self.videoView.hidden = YES;
	}
	return @"iOS";
}

#pragma mark - AppUtilityDelegate
- (void)getPhotoImageSuccessWithImageArr:(NSArray *)imageArr
{
	NSMutableArray *tmpArr = [NSMutableArray array];
	[imageArr enumerateObjectsUsingBlock:^(NSData *imageData, NSUInteger idx, BOOL * _Nonnull stop) {
		//判断图片是否大于10m
		if (imageData.length > 1024 * 1024 * 10) {
			[CMMUtility showToastWithText:@"上传图片过大，自动压缩后可能影响质量" duration:3];
		}
		
		UIImage *image = [UIImage imageWithData:imageData];
		CGFloat scaleFloat = image.size.height / image.size.width;
		//尺寸压缩
		if (image.size.width > SCREEN_WIDTH * 4) {
			image = [image imageByScalingToSize:CGSizeMake(SCREEN_WIDTH * 4, scaleFloat * SCREEN_WIDTH * 4)];
		}
		
		//填充图片
		[tmpArr addObject:image];
		
		self.seletedImageCount += 1;
	}];
	
	if (!QM_IS_ARRAY_NIL(tmpArr)) {
		[self.contentView addPicture:tmpArr currentIndex:self.currentTextIndex];
	}
	
	//异步压缩上传
	dispatch_async(dispatch_get_global_queue(0, 0), ^{
		[tmpArr enumerateObjectsUsingBlock:^(UIImage *image, NSUInteger idx, BOOL * _Nonnull stop) {
			//质量压缩
			NSData *data = [UIImage compressImageSize:image toByte:230400];
			NSUInteger scale = image.size.height / image.size.width * 1000;
			NSString *keyName = [NSString stringWithFormat:@"community/post/img/%@_%@_%@.jpg",App_Utility.currentUser.userId,@([LPUnitily getTimeSp]+rand()/100000),@(scale)];
	
			[[ImageDeliverManager sharedInstance] deliverImageWithKeyName:keyName fileData:data  mimeType:@"" imgType:5 result:^(NSString * _Nonnull url, ESError * _Nonnull error) {
				[self.imgArray addObject:url];
				NSMutableArray *arr = [NSMutableArray arrayWithArray:[SystemManager uploadedPhotoCache]];
				[arr addObject:keyName];
				[SystemManager setUploadedPhotoCache:arr];
				dispatch_main_async_safe(^{
					[self.contentView updatePicState:image];
				});
			}];
		}];
	});
}

- (void)completePhotoImageFaild {
	
}

- (void)getPhotoImageSuccessWithImage:(UIImage *)image {
	NSArray *arr = @[UIImageJPEGRepresentation(image, 1)];
	[self getPhotoImageSuccessWithImageArr:arr];
}

- (void)showVideoView:(UIImage *)shotImage {
	self.videoView.hidden = NO;
	self.coverView.hidden = NO;
	self.videoFirstFrameImageView.image = shotImage;
	self.deleteVideoBtn.hidden = YES;
	
	[UIViewController showHUD:self.hud];
}

- (void)uploadVideoSuccess {
	self.deleteVideoBtn.hidden = NO;
	self.coverView.hidden = YES;
	[UIViewController hideHUD:self.hud];
	self.hud = nil;
}

- (void)getVideoSuccessWithData:(NSData *)data url:(NSString *)url shotImage:(UIImage *)shotImage{
	if (data.length/1048576 >= 50) {
		[CMMUtility showToastWithText:@"用户最多上传50M视频"];
		return;
	}
	self.videoPath = url;
	//上传缩略图
	if (!shotImage) {
		shotImage = [self getScreenShotImageFromVideoPath:url];
	}
	NSData *shotImageData = UIImageJPEGRepresentation(shotImage, 0.5);
	NSUInteger scale = shotImage.size.height / shotImage.size.width * 1000;
	NSString *keyName = [NSString stringWithFormat:@"community/post/img/%@_%@_%@.jpg",App_Utility.currentUser.userId,@([LPUnitily getTimeSp]),@(scale)];
	self.isVideoUpLoading = YES;
	[[ImageDeliverManager sharedInstance] deliverImageWithKeyName:keyName fileData:shotImageData  mimeType:@"" imgType:5 result:^(NSString * _Nonnull url, ESError * _Nonnull error) {
		dispatch_main_async_safe((^{
			[ES_LPUnitily removeHUDToSystemWindow];
			NSMutableArray *arr = [NSMutableArray arrayWithArray:[SystemManager uploadedPhotoCache]];
			[arr addObject:keyName];
			[SystemManager setUploadedPhotoCache:arr];
			self.videoFirstFrameUrl = url;
			[self showVideoView:shotImage];
			//上传视频
			NSString *vidokeyName = [NSString stringWithFormat:@"community/post/video/%@_%@.mp4",App_Utility.currentUser.userId,@([LPUnitily getTimeSp])];
			[[ImageDeliverManager sharedInstance] deliverImageWithKeyName:vidokeyName fileData:data  mimeType:@"" imgType:5 result:^(NSString * _Nonnull url, ESError * _Nonnull error) {
				dispatch_main_async_safe(^{
					//上传成功
					NSMutableArray *arr = [NSMutableArray arrayWithArray:[SystemManager uploadedVideoCache]];
					[arr addObject:keyName];
					[SystemManager setUploadedVideoCache:arr];
					self.isVideoUpLoading = NO;
					self.videoPath = url;
					[self uploadVideoSuccess];
				});
			}];
		}));
	}];
}

- (UIImage *)getScreenShotImageFromVideoPath:(NSString *)filePath{
	UIImage *shotImage;
	//视频路径URL
	NSURL *fileURL = [NSURL fileURLWithPath:filePath];
	
	AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:fileURL options:nil];
	
	AVAssetImageGenerator *gen = [[AVAssetImageGenerator alloc] initWithAsset:asset];
	
	gen.appliesPreferredTrackTransform = YES;
	
	CMTime time = CMTimeMakeWithSeconds(0.0, 600);
	
	NSError *error = nil;
	
	CMTime actualTime;
	
	CGImageRef image = [gen copyCGImageAtTime:time actualTime:&actualTime error:&error];
	
	shotImage = [[UIImage alloc] initWithCGImage:image];
	
	CGImageRelease(image);
	
	return shotImage;
}

- (void)completeVideoImageFaild {
	
}

#pragma mark - 懒加载
-(NSMutableArray *)imgArray
{
	if (!_imgArray) {
		_imgArray = [NSMutableArray array];
	}
	return _imgArray;
}

//UI
- (UIButton *)postBtn {
	if (!_postBtn) {
		_postBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		_postBtn.frame = CGRectMake(0, 0, 42, 22);
		[_postBtn setTitle:@"发布" forState:UIControlStateNormal];
		_postBtn.backgroundColor = ColorAppBlack;
		[_postBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
		_postBtn.titleLabel.font = fcFont(12);
		_postBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
		_postBtn.layer.cornerRadius = 2;
		_postBtn.clipsToBounds = YES;
		[_postBtn addTarget:self action:@selector(post) forControlEvents:UIControlEventTouchUpInside];
	}
	return _postBtn;
}

- (CommunityPostContentScrollView *)contentView {
	if (!_contentView) {
		_contentView = [[CommunityPostContentScrollView alloc] init];
		_contentView.backgroundColor = [UIColor whiteColor];
		_contentView.viewDelegate = self;
		[self.view addSubview:_contentView];
	}
	return _contentView;
}

- (ComunityTopicSelectView *)topicSelectView {
	if (!_topicSelectView) {
		_topicSelectView = [[ComunityTopicSelectView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH, NavBarHeight, SCREEN_WIDTH, SCREEN_HEIGHT - NavBarHeight)];;
		[self.view addSubview:_topicSelectView];
		@weakify(self)
		_topicSelectView.selectedBlock = ^(CommunityPostTopicItem *item) {
			@strongify(self)
			self.topicId = item.topicId;
			self.contentView.topicLabel.text = [@"#" stringByAppendingString:item.name];
		};
	}
	return _topicSelectView;
}

- (UIView *)videoView {
	if (!_videoView) {
		_videoView = [[UIView alloc] init];
		_videoView.backgroundColor = [UIColor clearColor];
		_videoView.hidden = YES;
		[self.view addSubview:_videoView];
	}
	return _videoView;
}

- (UIImageView *)videoFirstFrameImageView {
	if (!_videoFirstFrameImageView) {
		_videoFirstFrameImageView = [UIImageView new];
		_videoFirstFrameImageView.contentMode = UIViewContentModeScaleAspectFill;
		_videoFirstFrameImageView.clipsToBounds = YES;
		[self.videoView addSubview:_videoFirstFrameImageView];
	}
	return _videoFirstFrameImageView;
}

- (PointExtenButton *)deleteVideoBtn {
	if (!_deleteVideoBtn) {
		_deleteVideoBtn = [PointExtenButton buttonWithType:UIButtonTypeCustom];
		[_deleteVideoBtn setImage:GetImage(@"community_delete_icon") forState:UIControlStateNormal];
		[_deleteVideoBtn addTarget:self action:@selector(deleteVideo:) forControlEvents:UIControlEventTouchUpInside];
		[self.videoView addSubview:_deleteVideoBtn];
	}
	return _deleteVideoBtn;
}

- (UIView *)coverView {
	if (!_coverView) {
		_coverView = [UIView new];
		_coverView.backgroundColor = RGBA_COLOR(0, 0, 0, 0.5);
		[self.videoView addSubview:_coverView];
	}
	return _coverView;
}

- (MBProgressHUD *)hud {
	if (!_hud) {
		_hud = [UIViewController hudWithText:nil detail:@"" toView:self.coverView yOffset:0.0f];
		_hud.mode = MBProgressHUDModeIndeterminate;
		_hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
		_hud.bezelView.color = [[UIColor blackColor] colorWithAlphaComponent:0.0];
		_hud.contentColor = [UIColor whiteColor];
		_hud.detailsLabel.font = fcFont(11);
	}
	return _hud;
}

- (UIView *)bottomView {
	if (!_bottomView) {
		_bottomView = [UIView new];
		_bottomView.backgroundColor = [UIColor whiteColor];
		[self.view addSubview:_bottomView];
	}
	return _bottomView;
}

- (UIButton *)picBtn {
	if (!_picBtn) {
		_picBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_picBtn setTitle:@"图片" forState:UIControlStateNormal];
		_picBtn.titleLabel.font = GetFont(12);
		[_picBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_picBtn setImage:GetImage(@"community_post_picture_icon") forState:UIControlStateNormal];
		_picBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_picBtn addTarget:self action:@selector(addPicture) forControlEvents:UIControlEventTouchUpInside];
		[self.bottomView addSubview:_picBtn];
	}
	return _picBtn;
}

- (UIButton *)videoBtn {
	if (!_videoBtn) {
		_videoBtn = [UIButton buttonWithType:UIButtonTypeCustom];
		[_videoBtn setTitle:@"视频" forState:UIControlStateNormal];
		_videoBtn.titleLabel.font = GetFont(12);
		[_videoBtn setTitleColor:RGBCOLOR(136, 136, 136) forState:UIControlStateNormal];
		[_videoBtn setImage:GetImage(@"community_post_video_icon") forState:UIControlStateNormal];
		_videoBtn.imageView.contentMode = UIViewContentModeScaleAspectFit;
		[_videoBtn addTarget:self action:@selector(addVideo) forControlEvents:UIControlEventTouchUpInside];
		[self.bottomView addSubview:_videoBtn];
	}
	return _videoBtn;
}
@end
