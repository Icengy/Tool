//
//  LoginViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CYButton;
@class AgreementTextView;

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *headLabel;
@property (weak, nonatomic) IBOutlet UITableView *inputTableView;

@property (weak, nonatomic) IBOutlet CYButton *registButton;
//@property (weak, nonatomic) IBOutlet CYButton *forgetButton;
@property (weak, nonatomic) IBOutlet CYButton *loginButton;
@property (weak, nonatomic) IBOutlet CYButton *closeButton;
@property (weak, nonatomic) IBOutlet CYButton *changeWayB;

@property (weak, nonatomic) IBOutlet CYButton *loginForWeixinBtn;


@property (weak, nonatomic) IBOutlet UIView *thirdLoginCarrier;

@property (weak, nonatomic) IBOutlet AgreementTextView *agreementTV;


@end

NS_ASSUME_NONNULL_END
