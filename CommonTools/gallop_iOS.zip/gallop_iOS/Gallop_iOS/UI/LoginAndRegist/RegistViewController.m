//
//  RegistViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/12.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "RegistViewController.h"
#import "GallopInputTableViewCell.h"
#import "FinishRegistViewController.h"
#import "WTCContentViewController.h"

#import "AgreementTextView.h"

@interface RegistViewController ()<GallopInputTableViewCellDelegate>
{
    GallopInputTableViewCell *_markInputCell;
    NSString *_phoneNum;
    NSString *_SMSVerificationCode;
    BOOL getCode;
}
@property (nonatomic, strong)NSArray *imageNameArray;
/** 计数器*/
@property (nonatomic, strong) NSTimer *resendTimer;
/** 计数*/
@property (nonatomic) int counter;

@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) CYButton *backBtn;

@end

@implementation RegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.counter = 60;
    self.dataSource = @[@"请输入手机号", @"请输入验证码"].mutableCopy;
    
    [self initWithSubViews];
    
    // Do any additional setup after loading the view.
}
- (void)initWithSubViews{
//    self.title = @"注册";
//    self.navigationItem.title = @"注册";
    
    self.view.backgroundColor = UIColor.whiteColor;
    self.tableView.backgroundColor = UIColor.whiteColor;
    
//    [self.view addSubview:self.backBtn];
    [self.view addSubview:self.titleLabel];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.tableView registerNibCell:[GallopInputTableViewCell class]];
    [self.view addSubview:self.tableView];
    
    [self setFooterView];
    [self addAgreementView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if (self.resendTimer) {
        [self.resendTimer invalidate];
        self.resendTimer = nil;
    }
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left).offset(25);
        make.top.equalTo(self.view).offset(NavBarHeight);
        make.height.offset(44.0);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(25);
        make.right.offset(-25);
        make.bottom.equalTo(self.view);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(16);
    }];
}

- (void)setFooterView
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
    [view setBackgroundColor:self.tableView.backgroundColor];
    
    UIButton *regist = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [regist setTitle:@"下一步" forState:UIControlStateNormal];
    
    [regist setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [regist setBackgroundColor:ColorMainAppRed];
    regist.titleLabel.font = [UIFont addPingFangSCRegular:16];
    [regist addTarget:self action:@selector(registDone) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:regist];
    [LPUnitily addCornerToView:regist withRadius:22];
    
    self.tableView.tableFooterView = view;
    
    [regist mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@30);
        make.left.right.equalTo(@0);
        make.height.equalTo(@44);
    }];

}

- (void)addAgreementView {
    AgreementTextView *agreementTV = [[AgreementTextView alloc] init];
    
    NSArray <NSString *>*agreements = @[@"《飞驰体育用户注册协议》",@"《隐私协议》"];
    __block NSString *str = @"点击下一步，即表示已阅读并同意";
    ;
    [agreements enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        str = [str stringByAppendingFormat:@"%@",obj];
    }];
    
    NSArray *linkKeys = @[@"RegisterKey", @"PrivacyKey"];
    UIColor *linkColor = RGBCOLORV(0x232323);
    @weakify(self);
    [agreementTV setMarksWithAllText:str allFont:[UIFont addPingFangSCRegular:9] allTextColor:RGBCOLORV(0x8F8F8F) linkData:@[@{@"linkText":agreements.firstObject,@"linkKey":linkKeys.firstObject,@"linkTextColor":linkColor},
                                                                                                                                  @{@"linkText":agreements.lastObject,@"linkKey":linkKeys.lastObject,@"linkTextColor":linkColor}] block:^(NSString * _Nullable linkKey) {
        @strongify(self);
        if ([linkKey isEqualToString:linkKeys.firstObject]) {
            /// 注册协议
            [self xyAction];
        }
        if ([linkKey isEqualToString:linkKeys.lastObject]) {
            /// 隐私协议
            [self xyAction2];
        }
    }];
    [self.view addSubview:agreementTV];
    [agreementTV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.offset(20);
        make.bottom.equalTo(self.view.mas_bottom).offset(-kBottomSafeArea);
        make.left.right.equalTo(self.tableView);
//        make.left.offset(25);
//        make.right.offset(-25);
    }];
}

-(void)xyAction{
    WTCContentViewController*vc = [WTCContentViewController new];
    vc.url = @"http://common.feichitiyu.com/pages/agreements/userService.html";
    vc.hidesBottomBarWhenPushed = YES;
    vc.contentType = WTCContentTypeNav;
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)xyAction2{
    WTCContentViewController*vc = [WTCContentViewController new];
    vc.url = @"http://common.feichitiyu.com/pages/agreements/privacy.html";
    vc.hidesBottomBarWhenPushed = YES;
    vc.contentType = WTCContentTypeNav;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)registDone {
//    FinishRegistViewController *vc = [[FinishRegistViewController alloc] init];
//    vc.phone = self->_phoneNum;
//    NSArray *array = [NSArray arrayWithObjects:self.navigationController.viewControllers.firstObject,vc,nil];
//    dispatch_main_async_safe(^{
//        [self.navigationController setViewControllers:array animated:YES];
//    });
//
//    return;
    if (_SMSVerificationCode.length==0) {
        [CMMUtility showToastWithText:@"请输入短信验证码"];
        return;
    }
    if ([self verificationLogic]) {//客户端判断
        if (!getCode) {
            [CMMUtility showToastWithText:@"请先获取验证码"];
            return;
        }
        if (QM_IS_STR_NIL(_SMSVerificationCode)) {
            _SMSVerificationCode = @"";
        }
        [self.view endEditing:YES];
        @weakify(self)
        [ESNetworkService checkCodeWithPhone:_phoneNum captchaType:1 captcha:_SMSVerificationCode Response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict&&[dict[@"code"] integerValue] == 0) {
                FinishRegistViewController *vc = [[FinishRegistViewController alloc] init];
                vc.phone = self->_phoneNum;
                NSArray *array = [NSArray arrayWithObjects:self.navigationController.viewControllers.firstObject,vc,nil];
                dispatch_main_async_safe(^{
                    [self.navigationController setViewControllers:array animated:YES];
                });
               
            }
        }];
       
    }
    
}

- (BOOL)verificationLogic{
    if (_phoneNum.length==0) {
        [CMMUtility showToastWithText:@"请输入手机号"];
        return NO;
    }
    if (_phoneNum.length!=11) {
        [CMMUtility showToastWithText:@"请输入正确的手机号格式"];
        return NO;
    }
    return YES;
}

#pragma mark - GallopInputTableViewCellDelegate
//监听输入框
- (void)inputTableViewCell:(GallopInputTableViewCell *)inputTableViewCell textFieldValueDidChange:(UITextField *)textField
{
   
    switch (textField.tag) {
        case 100:{
            _phoneNum = textField.text;
        }
            break;
        case 101:{
            _SMSVerificationCode = textField.text;
        }
            break;
        default:
            break;
    }
}
- (void)requestVerificationCodeResponseWithButton:(UIButton *)button
{
    if ([self verificationLogic]) {//客户端判断
        [self SMSVerificationWithButton:button];//服务器判断
    }
}
-(void)resend:(NSTimer *)timer{
    if (self.counter != 0) {
        _markInputCell.freeGetButton.userInteractionEnabled = NO;
        [_markInputCell.freeGetButton setTitle:[NSString stringWithFormat:@"%d",self.counter] forState:UIControlStateNormal];
        self.counter--;
    }
    else{
        self.counter = 60;
        [_markInputCell.freeGetButton setTitle:@"免费获取" forState:UIControlStateNormal];
        _markInputCell.freeGetButton.userInteractionEnabled = YES;
        [timer invalidate];
    }
}
#pragma mark - 网络请求
/** 短信验证码接口*/
- (void)SMSVerificationWithButton:(UIButton *)button
{
    @weakify(button)
    @weakify(self)
    [ESNetworkService getCodeWithPhone:_phoneNum captchaType:1 Response:^(id dict, ESError *error) {
        
            @strongify(button)
            @strongify(self)
            if (dict && [dict[@"code"] integerValue] == 0) {
                //获取短信验证码成功
                dispatch_main_async_safe(^{
                    if (button.userInteractionEnabled) {
                        button.userInteractionEnabled = NO;
                        if (self.resendTimer) {
                            [self.resendTimer invalidate];
                        }
                        self.resendTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(resend:) userInfo:nil repeats:YES];
                        [self.resendTimer fire];
                    }
                    self->getCode = 1;
                });
                
                
            }else{
                [CMMUtility showToastWithText:dict[@"message"]];
            }
    }];
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GallopInputTableViewCell *cell = [tableView dequeueReusableCell:[GallopInputTableViewCell class]];
    cell.type = InputCellTypeRegist;
    cell.delegate = self;
    if (indexPath.section == 1) {
        _markInputCell = cell;
    }
    
    [cell setValueWithPlaceholderTextArray:self.dataSource indexPath:indexPath];
    
    return cell;
}
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GallopInputTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return section?CGFLOAT_MIN:10;
}

#pragma mark -
- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.font = [UIFont addPingFangSCMedium:21];
        _titleLabel.textColor = RGBCOLORV(0x232323);
        _titleLabel.text = @"注册";
    }return _titleLabel;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
