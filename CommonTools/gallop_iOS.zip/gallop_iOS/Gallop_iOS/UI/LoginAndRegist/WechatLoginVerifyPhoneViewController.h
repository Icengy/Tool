//
//  WechatLoginVerifyPhoneViewController.h
//  Gallop_iOS
//
//  Created by lixuanye on 2020/6/18.
//  Copyright © 2020 homosum. All rights reserved.
//

#import "ESViewController.h"

@interface WechatLoginVerifyPhoneViewController : ESViewController
@property (nonatomic,strong) NSString *token;
@end
