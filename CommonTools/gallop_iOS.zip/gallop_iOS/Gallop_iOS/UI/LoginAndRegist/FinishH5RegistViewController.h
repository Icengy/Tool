//
//  FinishH5RegistViewController.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ESViewController.h"



@interface FinishH5RegistViewController : ESViewController
@property (nonatomic, strong) NSString*phone;
@end


