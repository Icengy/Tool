//
//  ForgetPasswordViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ForgetPasswordViewController.h"
#import "GallopInputTableViewCell.h"
#import "SetNewPasswordViewController.h"
@interface ForgetPasswordViewController ()<GallopInputTableViewCellDelegate>
{
    GallopInputTableViewCell *_markInputCell;
    NSString *_phoneNum;
    NSString *_SMSVerificationCode;
    BOOL getCode;
}
@property (nonatomic, strong)NSArray *imageNameArray;
/** 计数器*/
@property (nonatomic, strong) NSTimer *resendTimer;
/** 计数*/
@property (nonatomic) int counter;
@property (nonatomic, strong) UILabel *titleLabel;
@end

@implementation ForgetPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.counter = 60;
    [self.dataSource addObject:@"请输入手机号"];
    [self.dataSource addObject:@"请输入验证码"];
    
    [self initWithSubViews];

    // Do any additional setup after loading the view.
}
- (void)initWithSubViews{
//    self.navigationItem.title = @"找回密码";
    
    self.view.backgroundColor = UIColor.whiteColor;
    self.tableView.backgroundColor = UIColor.whiteColor;
    
//    [self.view addSubview:self.backBtn];
    [self.view addSubview:self.titleLabel];
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    self.tableView.rowHeight = 44.0;
    [self.tableView registerNibCell:[GallopInputTableViewCell class]];
    [self.view addSubview:self.tableView];
    [self setFooterView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
//    [self.navigationController setNavigationBarHidden:NO animated:YES];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
}


- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left).offset(25);
        make.top.equalTo(self.view).offset(NavBarHeight);
        make.height.offset(44.0);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(25);
        make.right.offset(-25);
        make.bottom.equalTo(self.view);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(16);
    }];
}


-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if (self.resendTimer) {
        [self.resendTimer invalidate];
        self.resendTimer = nil;
    }
}

- (void)setFooterView
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
    [view setBackgroundColor:self.tableView.backgroundColor];
    UIButton *regist = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [regist setTitle:@"下一步" forState:UIControlStateNormal];
    [regist setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [regist setBackgroundColor:ColorMainAppRed];
    regist.titleLabel.font = [UIFont addPingFangSCRegular:16];
    [regist addTarget:self action:@selector(registDone) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:regist];
    [LPUnitily addCornerToView:regist withRadius:22];
    self.tableView.tableFooterView = view;
    [regist mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@30);
        make.left.right.equalTo(@0);
        make.height.equalTo(@44);
    }];
 
}
-(void)registDone{
    if (_SMSVerificationCode.length==0) {
        [CMMUtility showToastWithText:@"请输入短信验证码"];
        return;
    }
    if ([self verificationLogic]) {//客户端判断
        if (!getCode) {
            [CMMUtility showToastWithText:@"请先获取验证码"];
            return;
        }
        if (QM_IS_STR_NIL(_SMSVerificationCode)) {
            _SMSVerificationCode = @"";
        }
        [self.view endEditing:YES];
        @weakify(self)
        [ESNetworkService checkCodeWithPhone:_phoneNum captchaType:2 captcha:_SMSVerificationCode Response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict&&[dict[@"code"] integerValue] == 0) {
                SetNewPasswordViewController *vc = [[SetNewPasswordViewController alloc] init];
                vc.phone = self->_phoneNum;
                NSArray *array = [NSArray arrayWithObjects:self.navigationController.viewControllers.firstObject,vc,nil];
                dispatch_main_async_safe(^{
                    [self.navigationController setViewControllers:array animated:YES];
                });
                
            }
        }];
        
    }
    
}
- (BOOL)verificationLogic{
    if (_phoneNum.length==0) {
        [CMMUtility showToastWithText:@"请输入手机号"];
        return NO;
    }
    if (_phoneNum.length!=11) {
        [CMMUtility showToastWithText:@"请输入正确的手机号格式"];
        return NO;
    }
    return YES;
}
#pragma mark - GallopInputTableViewCellDelegate
//监听输入框

- (void)inputTableViewCell:(GallopInputTableViewCell *)inputTableViewCell textFieldValueDidChange:(UITextField *)textField
{
    
    switch (textField.tag) {
        case 100:{
            _phoneNum = textField.text;
        }
            break;
        case 101:{
            _SMSVerificationCode = textField.text;
        }
            break;
        default:
            break;
    }
}
- (void)requestVerificationCodeResponseWithButton:(UIButton *)button
{
    if ([self verificationLogic]) {//客户端判断
        [self SMSVerificationWithButton:button];//服务器判断
    }
}
-(void)resend:(NSTimer *)timer{
    if (self.counter != 0) {
        _markInputCell.freeGetButton.userInteractionEnabled = NO;
        [_markInputCell.freeGetButton setTitle:[NSString stringWithFormat:@"%d",self.counter] forState:UIControlStateNormal];
        self.counter--;
    }
    else{
        self.counter = 60;
        [_markInputCell.freeGetButton setTitle:@"免费获取" forState:UIControlStateNormal];
        _markInputCell.freeGetButton.userInteractionEnabled = YES;
        [timer invalidate];
    }
}
#pragma mark - 网络请求
/** 短信验证码接口*/
- (void)SMSVerificationWithButton:(UIButton *)button
{
    @weakify(button)
    @weakify(self)
    [ESNetworkService getCodeWithPhone:_phoneNum captchaType:2 Response:^(id dict, ESError *error) {
        
        @strongify(button)
        @strongify(self)
        if (dict && [dict[@"code"] integerValue] == 0) {
            //获取短信验证码成功
            dispatch_main_async_safe(^{
                if (button.userInteractionEnabled) {
                    button.userInteractionEnabled = NO;
                    if (self.resendTimer) {
                        [self.resendTimer invalidate];
                    }
                    self.resendTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(resend:) userInfo:nil repeats:YES];
                    [self.resendTimer fire];
                }
                self->getCode = 1;
            });
            
            
        }else{
            [CMMUtility showToastWithText:dict[@"message"]];
        }
    }];
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GallopInputTableViewCell *cell = [tableView dequeueReusableCell:[GallopInputTableViewCell class]];

    cell.type = InputCellTypeForget;
    cell.delegate = self;
    if (indexPath.section == 1) {
        _markInputCell = cell;
    }
    [cell setValueWithPlaceholderTextArray:self.dataSource indexPath:indexPath];
    return cell;
}
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GallopInputTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return section?CGFLOAT_MIN:10;
}

- (UILabel *)titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.font = [UIFont addPingFangSCMedium:21];
        _titleLabel.textColor = RGBCOLORV(0x232323);
        _titleLabel.text = @"找回密码";
    }return _titleLabel;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
