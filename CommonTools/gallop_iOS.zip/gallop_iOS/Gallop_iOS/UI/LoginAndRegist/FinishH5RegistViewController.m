//
//  FinishH5RegistViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/12/11.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "FinishH5RegistViewController.h"
#import "GallopInputTableViewCell.h"
#import "WTCTabBarViewController.h"
@interface FinishH5RegistViewController ()<GallopInputTableViewCellDelegate>
{
    NSString *_name;
    NSString *_password1;
    NSString *_password2;
    NSString *_invitorCode;
}
@end

@implementation FinishH5RegistViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initWithSubViews];
    [self.dataSource addObject:@"用户名2-10位中文汉字"];
    [self.dataSource addObject:@"密码6-16位数字或字母"];
    [self.dataSource addObject:@"确认密码"];
    // Do any additional setup after loading the view.
}
-(void)initWithSubViews{
    self.navigationItem.title = @"完善信息";
    //创建一个UIButton
    UIButton *backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 22, 22)];
    //设置UIButton的图像
    [backButton setImage:[UIImage imageNamed:@"nav_return_black"] forState:UIControlStateNormal];
    //给UIButton绑定一个方法，在这个方法中进行popViewControllerAnimated
    [backButton addTarget:self action:@selector(backItemClick) forControlEvents:UIControlEventTouchUpInside];
    //然后通过系统给的自定义BarButtonItem的方法创建BarButtonItem
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc]initWithCustomView:backButton];
    //覆盖返回按键
    self.navigationItem.leftBarButtonItem = backItem;
    
    self.fd_interactivePopDisabled = YES;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = 44.0;
    self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    [self.tableView registerNibCell:[GallopInputTableViewCell class]];
    [self.view addSubview:self.tableView];
    
    [self setFooterView];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(25);
        make.right.offset(-25);
        make.bottom.equalTo(self.view);
        make.top.equalTo(self.view).offset(30 + NavBarHeight);
    }];
}

-(void)backItemClick{
    WTCTabBarViewController *tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
    tabBarVC.selectedIndex = 0;
    [APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
    }];
}
-(void)setFooterView{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
    [view setBackgroundColor:self.tableView.backgroundColor];
    
    UIButton *regist = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [regist setTitle:@"完成" forState:UIControlStateNormal];
    [regist setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [regist setBackgroundColor:ColorMainAppRed];
    regist.titleLabel.font = [UIFont addPingFangSCRegular:16];
    [regist addTarget:self action:@selector(registDone) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:regist];
    [LPUnitily addCornerToView:regist withRadius:22];
    self.tableView.tableFooterView = view;
    [regist mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@30);
        make.left.right.equalTo(@0);
        make.height.equalTo(@44);
    }];
}

-(void)registDone{
    if ([self verificationLogic]) {
        [self.view endEditing:YES];
        
        
        [ESNetworkService supplyInfoWithUserName:_name passWord:_password1 response:^(id dict, ESError *error) {

            if (dict&&[dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    WTCTabBarViewController *tabBarVC = (WTCTabBarViewController *)APP_DELEGATE.window.rootViewController;
                    tabBarVC.selectedIndex = 0;
                    [APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
                    }];
                });
            }
        }];
        
    }
}
- (BOOL)verificationLogic{
    
    if (_name.length==0) {
        [CMMUtility showToastWithText:@"请输入昵称"];
        return NO;
    }
    if (_password1.length==0) {
        [CMMUtility showToastWithText:@"请输入密码"];
        return NO;
    }
    if (_invitorCode.length>10) {
        [CMMUtility showToastWithText:@"邀请码仅支持1-10位数字"];
        return NO;
    }
    if (_password1.length<6||_password1.length>16) {
        [CMMUtility showToastWithText:@"密码是6-16位数字或英文字母"];
        return NO;
    }
    if (_name.length<2||_name.length>10) {
        [CMMUtility showToastWithText:@"用户名请控制在2-10位"];
        return NO;
    }
    if ([_name containsString:@" "]) {
        [CMMUtility showToastWithText:@"用户名不能含有空格"];
        return NO;
    }
    NSString*regex = @"[\u4e00-\u9fa5]+";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    if(![pred evaluateWithObject:_name]){
        [CMMUtility showToastWithText:@"用户名只能由中文组成"];
        return NO;
        
    }
    if (![_password1 isEqualToString:_password2]) {
        [CMMUtility showToastWithText:@"确认密码与密码不一致"];
        return NO;
    }
    
    
    return YES;
    
}
#pragma mark - GallopInputTableViewCellDelegate
//监听输入框

- (void)inputTableViewCell:(GallopInputTableViewCell *)inputTableViewCell textFieldValueDidChange:(UITextField *)textField
{
    
    switch (textField.tag) {
        case 100:{
            _name = textField.text;
        }
            break;
        case 101:{
            _password1 = textField.text;
        }
            break;
        case 102:{
            _password2 = textField.text;
        }
            break;
        case 103:{
            _invitorCode = textField.text;
        }
            break;
        default:
            break;
    }
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GallopInputTableViewCell *cell = [tableView dequeueReusableCell:[GallopInputTableViewCell class]];
    cell.type = InputCellTypeFinishRegist;
    cell.delegate = self;
    [cell setValueWithPlaceholderTextArray:self.dataSource indexPath:indexPath];
    return cell;
}
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GallopInputTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return (section == (self.dataSource.count - 1))?CGFLOAT_MIN:10;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
