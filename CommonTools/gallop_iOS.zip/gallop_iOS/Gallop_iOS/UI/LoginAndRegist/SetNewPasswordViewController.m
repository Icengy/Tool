//
//  SetNewPasswordViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/17.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "SetNewPasswordViewController.h"
#import "GallopInputTableViewCell.h"
@interface SetNewPasswordViewController ()<GallopInputTableViewCellDelegate>
{
    NSString *_password1;
    NSString *_password2;
}
@end

@implementation SetNewPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initWithSubViews];
    [self.dataSource addObject:@"新密码6-16位数字或字母"];
    [self.dataSource addObject:@"确认密码"];
    // Do any additional setup after loading the view.
}
-(void)initWithSubViews{
    self.navigationItem.title = @"设置新密码";
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = 44.0;
    self.tableView.sectionHeaderHeight = CGFLOAT_MIN;
    [self.tableView registerNibCell:[GallopInputTableViewCell class]];
    
    [self.view addSubview:self.tableView];
    
    [self setFooterView];
}

- (void)viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.offset(25);
        make.right.offset(-25);
        make.bottom.equalTo(self.view);
        make.top.equalTo(self.view).offset(30+NavBarHeight);
    }];
}

-(void)setFooterView{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 200)];
    [view setBackgroundColor:self.tableView.backgroundColor];
    
    UIButton *regist = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [regist setTitle:@"完成" forState:UIControlStateNormal];
    [regist setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [regist setBackgroundColor:ColorMainAppRed];
    regist.titleLabel.font = [UIFont addPingFangSCRegular:16];
    [regist addTarget:self action:@selector(registDone) forControlEvents:UIControlEventTouchUpInside];
	[LPUnitily addCornerToView:regist withRadius:22];
    [view addSubview:regist];
    self.tableView.tableFooterView = view;
    [regist mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.right.equalTo(@30);
        make.left.equalTo(@0);
        make.height.equalTo(@44);
    }];
}
-(void)registDone{
    if ([self verificationLogic]) {
        [self.view endEditing:YES];
        @weakify(self)
        [ESNetworkService findPhone:_phone Password:_password1 Response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict && [dict[@"code"] integerValue] == 0) {
                dispatch_main_async_safe(^{
                    [self.navigationController popToRootViewControllerAnimated:YES];
                });
                
            }
        }];
    }
}
- (BOOL)verificationLogic{
    
    
    if (_password1.length==0) {
        [CMMUtility showToastWithText:@"请输入密码"];
        return NO;
    }
    
    if (_password1.length<6||_password1.length>16) {
        [CMMUtility showToastWithText:@"密码是6-16位数字或英文字母"];
        return NO;
    }
    
   
    
    if (![_password1 isEqualToString:_password2]) {
        [CMMUtility showToastWithText:@"两次输入的密码不一样"];
        return NO;
    }
    
    
    return YES;
    
}
#pragma mark - GallopInputTableViewCellDelegate
//监听输入框

- (void)inputTableViewCell:(GallopInputTableViewCell *)inputTableViewCell textFieldValueDidChange:(UITextField *)textField
{
    
    switch (textField.tag) {
        case 100:{
            _password1 = textField.text;
        }
            break;
        case 101:{
            _password2 = textField.text;
        }
            break;
        default:
            break;
    }
}
#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GallopInputTableViewCell *cell = [tableView dequeueReusableCell:[GallopInputTableViewCell class]];
    
    cell.type = InputCellTypeDefault;
    cell.delegate = self;
    [cell setValueWithPlaceholderTextArray:self.dataSource indexPath:indexPath];
    
    return cell;
}
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GallopInputTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    
    return section?CGFLOAT_MIN:10;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
