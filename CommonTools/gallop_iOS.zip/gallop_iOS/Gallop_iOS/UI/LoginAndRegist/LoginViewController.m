//
//  LoginViewController.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/4/18.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "LoginViewController.h"
#import "GallopInputTableViewCell.h"
#import "ForgetPasswordViewController.h"
#import "RegistViewController.h"
#import "WTCContentViewController.h"
#import "FinishH5RegistViewController.h"
#import "FinishRegistViewController.h"
#import "WechatLoginVerifyPhoneViewController.h"
#import "WXApi.h"

#import "CYButton.h"
#import "AgreementTextView.h"

@interface LoginViewController ()<GallopInputTableViewCellDelegate,UITableViewDelegate,UITableViewDataSource>
{
    GallopInputTableViewCell *_markInputCell;
    NSString *_userName;
    NSString *_password;
    NSString *_code;
}
@property (weak, nonatomic) IBOutlet CYButton *backBtn;

@property (nonatomic, strong) NSMutableArray *dataSource;
@property (nonatomic, strong) NSMutableArray *imageNameArray;
@property (nonatomic, assign) BOOL isVerifyLogin;
@property (nonatomic, assign) BOOL didGetCode;
/** 计数器*/
@property (nonatomic, strong) NSTimer *resendTimer;
/** 计数*/
@property (nonatomic) int counter;
@end

@implementation LoginViewController

-(void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.counter = 60;
    [App_Utility clearCurrentUser];
    
    [self setupViews];
    
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(weChatLoginSuccess:) name:kWechatLoginSuccess object:NULL];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    NSLog(@"ViewController = %@ self.navigationController = %@", NSStringFromClass([self class]), self.navigationController);
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    self.thirdLoginCarrier.hidden = ![CommonUtils canShowWXAbout];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if (self.resendTimer) {
        [self.resendTimer invalidate];
        self.resendTimer = nil;
    }
}

-(void)weChatLoginSuccess:(NSNotification *)notify {
	NSString *token = notify.object;
	//判断三方登录是否手机认证接口(这里就按照需求走了)
	[App_Utility clearCurrentUser];
	@weakify(self)
	[ESNetworkService weChatLoginWithCode:token phone:@"" captcha:@"" Response:^(id dict, ESError *error) {
		@strongify(self)
		if (dict&&[dict[@"code"] integerValue] == 0) {
			dispatch_main_async_safe(^{
				NSDictionary *data = dict[@"data"];
				App_Utility.currentUser.userId = data[@"userId"];
				App_Utility.currentUser.role = data[@"role"];
				App_Utility.currentUser.token = data[@"token"];
				[App_Utility saveCurrentUser];
				[[NSNotificationCenter defaultCenter] postNotificationName:kESDidLoginNotification object:nil userInfo:@{@"toDo":@"login"}];
				NSString*deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:kDeviceTokenUmeng];
				if (!QM_IS_STR_NIL(deviceToken)) {
					[ESNetworkService setDeviceToken:deviceToken Response:^(id dict, ESError *error) {
						
					}];
				};
				dispatch_main_async_safe(^{
					[ES_LPUnitily removeHUDToSystemWindow];
					[self.view endEditing:YES];
					[APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
					}];
				});
			});
		} else if ([dict[@"code"] integerValue] == 10023000) {
			dispatch_main_async_safe(^{
				//跳转绑定手机页面
				WechatLoginVerifyPhoneViewController *vc = [WechatLoginVerifyPhoneViewController new];
				vc.token = token;
				[self.navigationController pushViewController:vc animated:YES];
			});
		}
	}];
}

-(void)setupViews {
    
    if ([CommonUtils canShowWXAbout]) {
        self.isVerifyLogin = 1;
        self.dataSource = @[@"请输入手机号", @"请输入验证码"].mutableCopy;
    }else {
        self.isVerifyLogin = 0;
        self.dataSource = @[@"请输入手机号", @"请输入密码"].mutableCopy;
    }
    
    self.inputTableView.dataSource = self;
    self.inputTableView.delegate = self;
    self.inputTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	self.inputTableView.bounces = NO;
    [self.inputTableView registerNibCell:[GallopInputTableViewCell class]];
    
    self.changeWayB.tag = self.isVerifyLogin;
    if (self.isVerifyLogin) {
        [self.changeWayB setTitle:@"密码登录" forState:UIControlStateNormal];
    } else {
        [self.changeWayB setTitle:@"验证码登录" forState:UIControlStateNormal];
    }
    
    NSArray <NSString *>*agreements = @[@"《飞驰体育用户注册协议》",@"《隐私协议》"];
    __block NSString *str = @"登录即表示已阅读并同意";
    ;
    [agreements enumerateObjectsUsingBlock:^(NSString * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        str = [str stringByAppendingFormat:@"%@",obj];
    }];
    
    NSArray *linkKeys = @[@"RegisterKey", @"PrivacyKey"];
    UIColor *linkColor = RGBCOLORV(0x232323);
    @weakify(self);
    [self.agreementTV setMarksWithAllText:str allFont:[UIFont addPingFangSCRegular:9] allTextColor:RGBCOLORV(0x8F8F8F) linkData:@[@{@"linkText":agreements.firstObject,@"linkKey":linkKeys.firstObject,@"linkTextColor":linkColor},
                                                                                                                                  @{@"linkText":agreements.lastObject,@"linkKey":linkKeys.lastObject,@"linkTextColor":linkColor}] block:^(NSString * _Nullable linkKey) {
        @strongify(self);
        if ([linkKey isEqualToString:linkKeys.firstObject]) {
            /// 注册协议
            [self xyAction];
        }
        if ([linkKey isEqualToString:linkKeys.lastObject]) {
            /// 隐私协议
            [self xyAction2];
        }
    }];
}

//- (void)viewWillLayoutSubviews {
//    [super viewWillLayoutSubviews];
//
//    [self.inputTableView mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.height.offset(44.0 * self.dataSource.count + 10.0 *(self.dataSource.count - 1));
//    }];
//}

#pragma mark - GallopInputTableViewCellDelegate
//监听输入框
- (void)inputTableViewCell:(GallopInputTableViewCell *)inputTableViewCell textFieldValueDidChange:(UITextField *)textField {
    switch (textField.tag) {
        case 100:{
            _userName = textField.text;
        }
            break;
        case 101:{
            _password = textField.text;
        }
            break;
        default:
            break;
    }
}

- (void)requestVerificationCodeResponseWithButton:(UIButton *)button {
    if ([self verificationLogic:NO]) {//客户端判断
        [self SMSVerificationWithButton:button];//服务器判断
    }
}

- (void)requestForgetPasswordResponseWithButton:(UIButton *)button {
    ForgetPasswordViewController *vc = [ForgetPasswordViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}


- (BOOL)verificationLogic:(BOOL)isLogin{
    if (_userName.length==0) {
        [CMMUtility showToastWithText:@"请输入手机号"];
        return NO;
    }
    
    if (_userName.length!=11) {
        [CMMUtility showToastWithText:@"请输入正确的手机号格式"];
        return NO;
    }
    
    if (!self.didGetCode && self.isVerifyLogin && isLogin) {
        [CMMUtility showToastWithText:@"请先获取验证码"];
        return NO;
    }
    
    if (isLogin && _password.length == 0) {
        if (self.isVerifyLogin) {
            [CMMUtility showToastWithText:@"请输入验证码"];
        } else {
            [CMMUtility showToastWithText:@"请输入密码"];
        }
        return NO;
    }
    return YES;
}

#pragma mark tableview代理
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.dataSource.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //不复用
    GallopInputTableViewCell *cell =  [tableView dequeueReusableCell:[GallopInputTableViewCell class]];
    cell.delegate = self;
   
    if (indexPath.section == 1) {
        _markInputCell = cell;
    }
    
    cell.type = self.isVerifyLogin?InputCellTypeCodeLogin:InputCellTypePasswordLogin;
    
    [self.dataSource replaceObjectAtIndex:self.dataSource.count - 1 withObject:self.isVerifyLogin?@"请输入验证码":@"请输入密码"];
    [cell setValueWithPlaceholderTextArray:self.dataSource indexPath:indexPath];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    GallopInputTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return CGFLOAT_MIN;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return section? CGFLOAT_MIN:10.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return [UIView new];
}

#pragma mark - 网络请求
/** 短信验证码接口*/
- (void)SMSVerificationWithButton:(UIButton *)button
{
    @weakify(button)
    @weakify(self)
    [ESNetworkService getLoginCodeWithPhone:_userName Response:^(id dict, ESError *error) {

        @strongify(button)
        @strongify(self)
        if (dict && [dict[@"code"] integerValue] == 0) {
            //获取登录短信验证码成功
            dispatch_main_async_safe(^{
                if (button.userInteractionEnabled) {
                    button.userInteractionEnabled = NO;
                    if (self.resendTimer) {
                        [self.resendTimer invalidate];
                    }
                    self.resendTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(resend:) userInfo:nil repeats:YES];
                    [self.resendTimer fire];
                }
                self.didGetCode = 1;
            });


        }else{
            [CMMUtility showToastWithText:dict[@"message"]];
        }
    }];
}

-(void)resend:(NSTimer *)timer{
    if (self.counter != 0) {
        _markInputCell.freeGetButton.userInteractionEnabled = NO;
        [_markInputCell.freeGetButton setTitle:[NSString stringWithFormat:@"%d",self.counter] forState:UIControlStateNormal];
        self.counter--;
    }
    else{
        self.counter = 60;
        [_markInputCell.freeGetButton setTitle:@"重新获取" forState:UIControlStateNormal];
        _markInputCell.freeGetButton.userInteractionEnabled = YES;
        [timer invalidate];
    }
}

#pragma mark 控件方法
- (IBAction)close:(id)sender {
    [APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
    }];
}
- (IBAction)switchLoginMethod:(UIButton *)btn {

    btn.tag = !btn.tag;
    //清空密码
//    _markInputCell.textField.text = @"";
    
    if (btn.tag) {
        [btn setTitle:@"密码登录" forState:UIControlStateNormal];
    } else {
        [btn setTitle:@"验证码登录" forState:UIControlStateNormal];
    }
    //切换验证码登录
    self.isVerifyLogin = btn.tag;
    [self.inputTableView reloadRowsAtIndexPaths:@[[self.inputTableView indexPathForCell:_markInputCell]] withRowAnimation:(UITableViewRowAnimationNone)];
}

- (IBAction)regist:(id)sender {
    RegistViewController *vc = [[RegistViewController alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)login:(id)sender {
    if ([self verificationLogic:YES]) {
        [self.view endEditing:YES];
        @weakify(self);
        [App_Utility clearCurrentUser];
        [ESNetworkService loginWithPhone:_userName password:_password loginType:self.isVerifyLogin + 1 Response:^(id dict, ESError *error) {
            @strongify(self)
            if (dict && [dict[@"code"] integerValue] == 0) {
                NSDictionary *data = dict[@"data"];
                App_Utility.currentUser.userId = data[@"userId"];
                App_Utility.currentUser.role = data[@"role"];
                App_Utility.currentUser.token = data[@"token"];
                [App_Utility saveCurrentUser];
                [[NSNotificationCenter defaultCenter] postNotificationName:kESDidLoginNotification object:nil userInfo:@{@"toDo":@"login"}];
                NSString*deviceToken = [[NSUserDefaults standardUserDefaults] objectForKey:kDeviceTokenUmeng];
                if (!QM_IS_STR_NIL(deviceToken)) {
                    [ESNetworkService setDeviceToken:deviceToken Response:^(id dict, ESError *error) {
                        
                    }];
                };
                NSNumber*needSupplyInfo = data[@"needSupplyInfo"];
                if (!needSupplyInfo.boolValue) {
                    dispatch_main_async_safe(^{
                                       [ES_LPUnitily removeHUDToSystemWindow];
                                       [self.view endEditing:YES];
                                       [APP_DELEGATE.window.rootViewController dismissViewControllerAnimated:YES completion:^{
                                       }];
                                   });
                }else{
                    dispatch_main_async_safe(^{
                        FinishH5RegistViewController*vc = [FinishH5RegistViewController new];
                        [self.navigationController pushViewController:vc animated:YES];
                    });
                }
               
                
            }
            if (dict&&[dict[@"code"] integerValue] == 100300001&&self.isVerifyLogin == 1) {
                dispatch_main_async_safe(^{
                    FinishRegistViewController*vc = [FinishRegistViewController new];
                    vc.phone = _userName;
                    [self.navigationController pushViewController:vc animated:YES];
                });
                   
            }
        }];
    }
}

- (void)setFooterView
{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor:[UIColor whiteColor]];
    view.userInteractionEnabled = YES;
    [self.view addSubview:view];
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(self.loginButton.mas_bottom).offset(0);
        make.centerX.mas_equalTo(self.view);
        make.size.mas_equalTo(CGSizeMake(SCREEN_WIDTH, 220));
    }];
    
    UILabel *detailLabel  = [UILabel new];
    detailLabel.text = @"点击登录，即表示已阅读并同意";
    detailLabel.font = GetFont(12.0f);
    detailLabel.textColor = [UIColor colorWithHexString:@"#A8A8A8"];
    [view addSubview:detailLabel];
    
    UIButton *xyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [xyButton.titleLabel setFont:GetFont(12.0f)];
    [xyButton setTitleColor:ColorSubTitle forState:UIControlStateNormal];
    [xyButton setTitle:[NSString stringWithFormat:@"《飞驰体育用户注册协议》"] forState:UIControlStateNormal];
    [xyButton addTarget:self action:@selector(xyAction) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:xyButton];
    
    UIButton *xyButton2 = [UIButton buttonWithType:UIButtonTypeCustom];
    [xyButton2.titleLabel setFont:GetFont(12.0f)];
    [xyButton2 setTitleColor:ColorSubTitle forState:UIControlStateNormal];
    [xyButton2 setTitle:[NSString stringWithFormat:@",《隐私协议》"] forState:UIControlStateNormal];
    [xyButton2 addTarget:self action:@selector(xyAction2) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:xyButton2];
    
    
	UIButton *wechatButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[wechatButton setImage:GetImage(@"微信") forState:UIControlStateNormal];
	[wechatButton setTitle:@"微信账户快速登录" forState:UIControlStateNormal];
	wechatButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
	wechatButton.imageEdgeInsets = UIEdgeInsetsMake(7, -15, 7, 15);
	wechatButton.titleEdgeInsets = UIEdgeInsetsMake(0, -20, 0, 20);
	[wechatButton setTitleColor:RGBCOLOR(58, 58, 58) forState:UIControlStateNormal];
	wechatButton.titleLabel.font = fcFont(14);
	wechatButton.layer.cornerRadius = 22;
	wechatButton.clipsToBounds = YES;
	wechatButton.backgroundColor = RGBCOLOR(244, 244, 244);
    [wechatButton addTarget:self action:@selector(wechatLogin:) forControlEvents:UIControlEventTouchUpInside];
	[view addSubview:wechatButton];
	
	if([WXApi isWXAppInstalled]) {
		wechatButton.hidden = NO;
	} else {
		wechatButton.hidden = YES;
	}
	
    [detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(view);
        make.top.mas_equalTo(view).offset(20);
    }];
    
    [xyButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(detailLabel.mas_bottom).offset(5);
        make.centerX.mas_equalTo(view).offset(-45);
        make.width.mas_equalTo(180);
        make.height.equalTo(@20);
    }];
    xyButton.userInteractionEnabled = YES;
    
    [xyButton2 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(xyButton);
        make.left.equalTo(xyButton.mas_right);
        make.height.equalTo(@20);
    }];
	
	[wechatButton mas_makeConstraints:^(MASConstraintMaker *make) {
		make.centerX.equalTo(view);
		make.bottom.equalTo(view);
		make.size.mas_equalTo(CGSizeMake(220, 44));
	}];
}

#pragma mark - action
-(void)xyAction{
    WTCContentViewController*vc = [WTCContentViewController new];
    vc.url = @"http://common.feichitiyu.com/pages/agreements/userService.html";
    vc.hidesBottomBarWhenPushed = YES;
    vc.contentType = WTCContentTypeNav;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)contactToUs:(id)sender {
    [self openFeedBackPage];
}

-(void)xyAction2{
    WTCContentViewController*vc = [WTCContentViewController new];
    vc.url = @"http://common.feichitiyu.com/pages/agreements/privacy.html";
    vc.hidesBottomBarWhenPushed = YES;
    vc.contentType = WTCContentTypeNav;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)openFeedBackPage {
    NSString *userId = App_Utility.currentUser.userId.stringValue;
    ES_LPUnitily.feedbackKit.extInfo = @{@"loginTime":[[NSDate date] description],
                                         @"visitPath":@"登陆->关于->反馈",
                                         @"userid":QM_STR_NOT_NIL(userId)};
    __weak typeof(self) weakSelf = self;
    [ES_LPUnitily.feedbackKit makeFeedbackViewControllerWithCompletionBlock:^(YWFeedbackViewController *viewController, NSError *error) {
        if (viewController != nil) {
            viewController.hidesBottomBarWhenPushed = YES;
            [weakSelf.navigationController pushViewController:viewController animated:YES];
            [viewController setCloseBlock:^(UIViewController *aParentController){
                [aParentController.navigationController popViewControllerAnimated:YES];
            }];
        }
    }];
}

//微信联合登录
- (IBAction)wechatLogin:(id)sender {
	//构造SendAuthReq结构体
	SendAuthReq* req = [[SendAuthReq alloc] init];
	req.scope = @"snsapi_userinfo";
	req.state = @"123";
	req.openID = kWxKey;
	//第三方向微信终端发送一个SendAuthReq消息结构
	[WXApi sendReq:req completion:nil];
}
@end
