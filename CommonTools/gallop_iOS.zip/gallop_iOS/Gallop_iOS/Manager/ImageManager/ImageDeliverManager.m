//
//  ImageDeliverManager.m
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "ImageDeliverManager.h"
#define kTimeoutIntervalForRequest 60
#import <SDWebImage/SDImageCache.h>

@implementation ImageDeliverManager
+(instancetype)sharedInstance
{
    static ImageDeliverManager *sharedInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}
- (UFFileClient *)fileClient
{
    if (!_fileClient) {
        NSString *bucketPublicKey = @"iN4nOtUEF3qRm4xZ4Ggjg+AHnWKLg6YT10PtgBLu1JtXxULZZARzIQ==";
//        NSString *bucketPrivateKey = @"";
        NSString *bucketName = @"gallop";
        NSString *proxySuffix = @"cn-bj.ufileos.com";
        NSString *fileOperateEncryptServer = [NSString stringWithFormat:@"%@/ios/ucloud/sign/",HostUrl];
        NSString *fileAddressEncryptServer = [NSString stringWithFormat:@"%@/ios/ucloud/read/sign/",HostUrl];
        
        if (!bucketPublicKey || !bucketName  || !proxySuffix) {
            NSLog(@"bucket config does not complete , please check..");
            return nil;
        }
        UFConfig *ufConfig = [UFConfig instanceConfigWithPrivateToken:nil publicToken:bucketPublicKey bucket:bucketName fileOperateEncryptServer:fileOperateEncryptServer fileAddressEncryptServer:fileAddressEncryptServer proxySuffix:proxySuffix];
        _fileClient = [UFFileClient instanceFileClientWithConfig:ufConfig];
//		_fileClient.timeoutIntervalForRequest = kTimeoutIntervalForRequest;
    }
    return _fileClient;
}
- (UFFileClient *)filePublicClient
{
    if (!_filePublicClient) {
        NSString *bucketPublicKey = @"iN4nOtUEF3qRm4xZ4Ggjg+AHnWKLg6YT10PtgBLu1JtXxULZZARzIQ==";
        //        NSString *bucketPrivateKey = @"";
        NSString *bucketName = @"gallop-avatar";
        NSString *proxySuffix = @"cn-bj.ufileos.com";
        NSString *fileOperateEncryptServer = [NSString stringWithFormat:@"%@/ios/ucloud/sign/",HostUrl];
        NSString *fileAddressEncryptServer = [NSString stringWithFormat:@"%@/ios/ucloud/read/sign/",HostUrl];
        
        if (!bucketPublicKey || !bucketName  || !proxySuffix) {
            NSLog(@"bucket config does not complete , please check..");
            return nil;
        }
        UFConfig *ufConfig = [UFConfig instanceConfigWithPrivateToken:nil publicToken:bucketPublicKey bucket:bucketName fileOperateEncryptServer:fileOperateEncryptServer fileAddressEncryptServer:fileAddressEncryptServer proxySuffix:proxySuffix];
        _filePublicClient = [UFFileClient instanceFileClientWithConfig:ufConfig];
//		_filePublicClient.timeoutIntervalForRequest = kTimeoutIntervalForRequest;
    }
    return _filePublicClient;
}
-(NSString*)privateImageUrlWithImageName:(NSString *)imageName
{
   NSString* url = [self.fileClient filePrivateUrlWithKeyName:imageName expiresTime:0];
    return url;
}
-(void)deletePublicImage:(NSString*)imageName
{
    [self.filePublicClient deleteWithKeyName:imageName deleteHandler:^(UFError * _Nullable ufError, NSObject * _Nullable obj) {
        [[SDImageCache sharedImageCache] removeImageForKey:imageName withCompletion:^{
            
        }];
    }];
}
-(void)deletePrivateImage:(NSString *)imageName
{
    [self.fileClient deleteWithKeyName:imageName deleteHandler:^(UFError * _Nullable ufError, NSObject * _Nullable obj) {
        [[SDImageCache sharedImageCache] removeImageForKey:imageName withCompletion:^{
            
        }];
    }];
}
-(void)deliverImageWithKeyName:(NSString *)keyName fileData:(NSData *)fileData mimeType:(NSString *)mimeType imgType:(int)imgType result:(ImageResult)result
{
    if (fileData.length/1048576 >= 5 && imgType != 5) {
        [CMMUtility showToastWithText:@"单张图片不可超过5m"];
        return;
    }
    if (imgType == 1 || imgType ==2 || imgType == 5) {
        [self.filePublicClient uploadWithKeyName:keyName fileData:fileData mimeType:mimeType progress:^(NSProgress * _Nonnull progress) {
        } uploadHandler:^(UFError * _Nullable ufError, UFUploadResponse * _Nullable ufUploadResponse) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ufError) {
                    WTCLog(@"%@", [NSString stringWithFormat:@"上传成功，服务器返回信息--> %@",ufUploadResponse.description]);
                    
                    if (imgType == 1) {
                        NSString *url = [NSString stringWithFormat:@"http://gallop-avatar.cn-bj.ufileos.com/%@",keyName];
                        [ESNetworkService changeVwithUrl:url Response:^(id dict, ESError *error) {
                            if (dict&&[dict[@"code"] integerValue] == 0) {
                                
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    [CMMUtility showToastWithText:@"修改成功"];
									result(url,error);
                                });
                            }
                        }];
                    } else if (imgType == 2 || imgType == 5){
                        NSString *url = [NSString stringWithFormat:@"http://gallop-avatar.cn-bj.ufileos.com/%@",keyName];
                         dispatch_async(dispatch_get_main_queue(), ^{
                             result(url,ufError);
                        });
                        
					}
                } else if (ufError.type == UFErrorType_Sys) {
                    WTCLog(@"%@", [NSString stringWithFormat:@"上传失败，系统错误信息--> %@",ufError.error.description]);
				} else if (ufError.type == UFErrorType_Server) {
					WTCLog(@"%@", [NSString stringWithFormat:@"上传失败，服务器错误信息--> %@",ufError.error.description]);
					result(@"",ufError);
				}
            });
        }];
    }else{
    [self.fileClient uploadWithKeyName:keyName fileData:fileData mimeType:mimeType progress:^(NSProgress * _Nonnull progress) {
        
    } uploadHandler:^(UFError * _Nullable ufError, UFUploadResponse * _Nullable ufUploadResponse) {
        
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!ufError) {
                    WTCLog(@"%@", [NSString stringWithFormat:@"上传成功，服务器返回信息--> %@",ufUploadResponse.description]);
                        NSString *url = [self.fileClient filePrivateUrlWithKeyName:keyName expiresTime:0];
                      dispatch_async(dispatch_get_main_queue(), ^{
                        result(url,ufError);
                           });
				} else if (ufError.type == UFErrorType_Sys) {
					WTCLog(@"%@", [NSString stringWithFormat:@"上传失败，系统错误信息--> %@",ufError.error.description]);
				}
            });
    }];
    }
}
@end
