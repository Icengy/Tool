//
//  ImageDeliverManager.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/5/15.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UFileSDK.h>
NS_ASSUME_NONNULL_BEGIN
typedef void (^ImageResult)(NSString *url, ESError* error);
@interface ImageDeliverManager : NSObject
@property (nonatomic,strong) UFFileClient *fileClient;
@property (nonatomic,strong) UFFileClient *filePublicClient;
+ (instancetype)sharedInstance;
//imgtype 1:头像 2:专家头像 3:专家手持身份证 4:申请理由 5:社区相关
- (void)deliverImageWithKeyName:(NSString*)keyName fileData:(NSData *)fileData mimeType:(NSString *)mimeType imgType:(int)imgType result:(ImageResult)result;
-(NSString*)privateImageUrlWithImageName:(NSString*)imageName;
-(void)deletePublicImage:(NSString*)imageName;
-(void)deletePrivateImage:(NSString*)imageName;
@end

NS_ASSUME_NONNULL_END
