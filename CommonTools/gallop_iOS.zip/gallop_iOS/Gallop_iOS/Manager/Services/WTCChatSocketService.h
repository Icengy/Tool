//
//  WTCChatSocketService.h
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SocketRocket.h>
#import "ChatTCPMessageModel.h"

@interface WTCChatSocketService : NSObject
/** 获取连接状态 */
@property (nonatomic,assign,readonly) SRReadyState socketReadyState;

/** 开始连接 */
- (void)SRWebSocketOpenWithURLString:(NSString *)urlString;

/** 关闭连接 */
- (void)SRWebSocketClose;

/** 发送数据 */
- (void)sendData:(id)data;

+ (WTCChatSocketService *)instance;
@end

