//
//  ESNetworkService.h
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/25.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface ESNetworkService : NSObject
/**
 * 专家号申请
 **/
+(void)applyForExpertWithExpertName:(NSString*)expertName ExpertAvatar:(NSString*)expertAvatar Introduction:(NSString*)introduction ApplyCondition:(NSString*)applyCondition ConditionImage:(NSString*)conditionImage IdentityImage:(NSString*)identityImage field:(NSString *)field Response:(ESResponse)response;
/**
 * 获取专家号信息
 **/
+(void)getExpertInfoResponse:(ESResponse)response;
/**
 * 设为已读
 **/
+(void)readMessageId:(NSString*)messageId  andType:(NSString*)type Response:(ESResponse)response;
/**
 * 设为互动消息已读
 **/
+(void)readInteractMessageWithResponse:(ESResponse)response;
/**
 * 消息列表
 **/
+(void)getMessageListWithType:(NSInteger)type Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 获取个人消息
 **/
+(void)getPersonalInfoResponse:(ESResponse)response;
/**
 * 修改专家头像
 **/
+(void)changeExpertVwithUrl:(NSString*)url Response:(ESResponse)response;
/**
 * 修改Token
 **/
+(void)setDeviceToken:(NSString*)deviceToken Response:(ESResponse)response;
/**
 * 修改手机号
 * @param phone 手机号
 * @param captcha 验证码
 **/
+(void)changePhoneWithPhone:(NSString*)phone captcha:(NSString*)captcha Response:(ESResponse)response;
/**
 * 修改用户名
 **/
+(void)setUserName:(NSString*)userName Response:(ESResponse)response;
/**
 * 修改性别
 **/
+(void)setSex:(NSUInteger)gender Response:(ESResponse)response;
/**
 * 修改签名
 **/
+(void)setSign:(NSString *)signature Response:(ESResponse)response;
/**
 * 修改邮箱
 **/
+(void)setEmail:(NSString*)email Response:(ESResponse)response;
/**
 * 等级中心签到
 **/
+(void)gradeCenterSignInWithResponse:(ESResponse)response;
/**
 * 完成每日分享任务
 **/
+(void)completeShareTaskWithResponse:(ESResponse)response;
/**
 * 完成每日观看动画直播任务
 **/
+(void)completeLiveTastWithResponse:(ESResponse)response;
/**
 * 等级中心详情
 **/
+ (void)getGradeCenterInfo:(NSString *)userId Response:(ESResponse)response;
/**
 * 经验明细
 **/
+ (void)getGradeCenterDetail:(NSString *)userId page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;

/**
 * 登出
 **/
+(void)logoutResponse:(ESResponse)response;
/**
 * 修改密码
 *
 **/
+(void)changePasswordWithOldpassword:(NSString*)oldpassword Password:(NSString*)password Response:(ESResponse)response;
/**
 * 找回密码
 * @param phone 手机号
 * @param password 密码
 **/
+(void)findPhone:(NSString*)phone Password:(NSString*)password Response:(ESResponse)response;
/**
 * 登录接口
 * phone 手机号
 * password 密码
 * loginType 登录方式
 **/
+(void)loginWithPhone:(NSString*)phone password:(NSString*)password loginType:(NSUInteger)loginType Response:(ESResponse)response;
/**
 * 微信联合登录接口
 * code 微信token
 * phone 手机号
 * captch 验证码
 **/
+ (void)weChatLoginWithCode:(NSString*)code phone:(NSString*)phone captcha:(NSString*)captcha Response:(ESResponse)response;
/**
 * 微信绑定接口
 * code 微信token
 **/
+ (void)bindWeChatWithCode:(NSString*)code Response:(ESResponse)response;
/**
 * 微信解除绑定
 **/
+ (void)unbindWeChat:(ESResponse)response;
/**
 * 修改头像
 * @param url 头像地址
 **/
+(void)changeVwithUrl:(NSString*)url Response:(ESResponse)response;
/**
 * 获取我的信息
 **/
+(void)getSelfMessageResponse:(ESResponse)response;
/**
 * 获取消息中心标题列表
 **/
+ (void)getMessageCenterListResponse:(ESResponse)response;
/**
 * 获取社区消息未读消息数量统计
 **/
+ (void)getCommunityMessageCountWithResponse:(ESResponse)response;
/**
 * 社区消息已读接口
 **/
+ (void)readCommunityMessageWithMessageType:(NSString *)messageType Response:(ESResponse)response;
/**
 * 获取官方推荐/活动中心/NBA伤停 列表
 **/
+ (void)getOffcialBannersWithType:(NSUInteger)type page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/**
 * 校验验证码
 * @param phone 手机号
 * @param captchaType 类型
 **/
+(void)checkCodeWithPhone:(NSString*)phone captchaType:(int)captchaType captcha:(NSString*)captcha Response:(ESResponse)response;
/**
 * 获取验证码
 * @param phone 手机号
 * @param captchaType 类型
 **/
+(void)getCodeWithPhone:(NSString*)phone captchaType:(int)captchaType Response:(ESResponse)response;
/**
* 获取登录验证码
* phone 手机号
**/
+(void)getLoginCodeWithPhone:(NSString*)phone Response:(ESResponse)response;
/**
 * 测试
 *
 *  @param response 返回结果
 */
+ (void)getTest:(NSString*)test Response:(ESResponse)response;

/**
 * 注册接口
 * @param userName 用户名
 * @param password 密码
 * @param phone 手机号
 * @param invitationCode 邀请码
 **/
+(void)registWithUserName:(NSString*)userName password:(NSString*)password phone:(NSString*)phone invitationCode:(NSString*)invitationCode Response:(ESResponse)response;
/**
 * 发方案基本配置
 *
 *  @param response 返回结果
 */
+ (void)sendPreNewResponse:(ESResponse)response;
/**
 * 赛事接口
 *
 *  @param response 返回结果
 */
+ (void)getPlanInitWithField:(NSInteger)field Response:(ESResponse)response;
/**
 * 创建方案接口
 * @param price 价格
 * @param content 内容
 * @param title 标题
 * @param type 方案类型
 * @param commentAreaType 方案评论权限
 * @param declarationPic 方案宣言图片
 * @param response 返回结果
 */
+ (void)createPlanWithMatchInfo:(NSArray*)matchInfo price:(int)price content:(NSString*)content title:(NSString*)title type:(NSString*)type pic:(NSString*)pic field:(NSInteger)field declaration:(NSString*)declaration declarationPic:(NSString *)declarationPic commentAreaType:(NSUInteger)commentAreaType Response:(ESResponse)response;
/**
 * 方案详情页面
 * @param planId 订单id
 *  @param response 返回结果
 */
+(void)planDetailWithPlanId:(NSInteger)planId Response:(ESResponse)response;
/**
 * 方案详情页面评论列表
 */
+ (void)planDetailCommentList:(NSInteger)planId Page:(NSInteger)Page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 方案详情评论接口
 */
+(void)planDetailComment:(NSUInteger)planId content:(NSString *)content Response:(ESResponse)response;
/**
 * 购买方案
 * @param planId 订单id
 * @param userCouponId 优惠券id
 * @param response 返回结果
 */
+(void)payOrderWithPlanId:(NSInteger)planId userCouponId:(NSUInteger)userCouponId Response:(ESResponse)response;
/**
 * 我的购买记录
 * @param page 页码
 *  @param pageSize 页面大小
 */
+(void)myPayListWithPage:(int)page PageSize:(int)pageSize Response:(ESResponse)response;

/**
 * 充值明细
 * @param page 页码
 *  @param pageSize 页面大小
 */
+(void)myAccountListWithPage:(int)page PageSize:(int)pageSize Response:(ESResponse)response;

/**
 * 方案频道
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 足球篮球
 *  @param type 比赛类型
 */
+(void)planListWithPage:(int)page PageSize:(int)pageSize Field:(NSString*)field Type:(NSString*)type SelectedLeague:(NSString *)selectedLeague SortType:(int)sortType MatchSelectType:(int)matchSelectType Response:(ESResponse)response;

/**
 * 新方案频道
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 1足球/2篮球
 *  @param type 3免费/所有
 *  @param selectedLeague 联赛名
 *  @param matchSelectType 1：单关/2：2串1
 */
+ (void)planListWithoutHUDWithPage:(NSInteger)page
                         pageSize:(NSInteger)pageSize
                            field:(NSString *)field
                             type:(NSString *)type
                   selectedLeague:(NSString *)selectedLeague
                  matchSelectType:(NSInteger)matchSelectType
                          response:(ESResponse)response;
/**
 * 专家详情页面
 * @param expertId 专家id
 *  @param response 返回结果
 */
+(void)expertViewWithExpertId:(NSInteger)expertId Response:(ESResponse)response;
+(void)expertViewWithoutHUDWithExpertId:(NSInteger)expertId Response:(ESResponse)response;
/**
 * 专家联赛统计
 * @param expertId 专家id
 * @param field 足球/篮球
 * @param response 返回结果
 */
+(void)expertLeagueCountWithExpertId:(NSInteger)expertId field:(NSUInteger)field page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
+(void)expertLeagueCountWithHUD:(BOOL)allowHUD withExpertId:(NSInteger)expertId field:(NSUInteger)field page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/**
 * 订阅设置
 **/
+(void)getPushExpertListWithPage:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;


+(void)ocWithExpertId:(NSInteger)expertId  andOpenClose:(int)openClose Response:(ESResponse)response;

+(void)changeIntroduceWithIntroduction:(NSString*)introduction Response:(ESResponse)response;
/**
 * 指定专家方案列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 足球篮球
 *  @param type 比赛类型
  * @param expertId 专家id
 */
+(void)expertPlanListWithPage:(int)page PageSize:(int)pageSize Field:(NSString*)field Type:(NSString*)type ExpertId:(NSInteger)expertId ForExpert:(int)forExpert Response:(ESResponse)response;
+ (void)expertPlanListWithHUD:(BOOL)allowHUD withPage:(int)page PageSize:(int)pageSize Field:(NSString*)field Type:(NSString*)type ExpertId:(NSInteger)expertId ForExpert:(int)forExpert Response:(ESResponse)response;
/**
 * 历史足迹方案列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 足球篮球
 *  @param type 比赛类型
 */
+(void)trackPlanListWithPage:(int)page PageSize:(int)pageSize Field:(NSString*)field Type:(NSString*)type Response:(ESResponse)response;
/**
 * 飞驰榜
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param rank 类型
 *  @param field 比赛类型
 */
+(void)feichiBoardWithPage:(NSInteger)page
                  PageSize:(NSInteger)pageSize
                      Rank:(NSString*)rank
                     Field:(NSInteger)field
                  Response:(ESResponse)response;

/**
 * 专家榜
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param rank 类型
 *  @param field 比赛类型
 */
+(void)expertBoardWithPage:(NSInteger)page
                  PageSize:(NSInteger)pageSize
                      Rank:(NSString *)rank
                     Field:(NSInteger)field
                  Response:(ESResponse)response;
/**
 * 用户购买列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param planId 方案id
 */
+(void)saleDetailWithPage:(int)page PageSize:(int)pageSize PlanId:(long)planId Response:(ESResponse)response;
/**
 * 搜索
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param searchKey 专家名称
 */
+(void)searchExpertWithPage:(int)page PageSize:(int)pageSize SearchKey:(NSString*)searchKey Response:(ESResponse)response;
/**
 * 我的订阅
 * @param page 页码
 *  @param pageSize 页面大小
 */
+(void)myExpertWithPage:(int)page PageSize:(int)pageSize Response:(ESResponse)response;
/*
 * 轮播图
 */
+(void)getBannersWithField:(NSUInteger)field Response:(ESResponse)response;
/*
 * 更新轮播图访问信息
 */
+(void)updateBannersVisit:(NSUInteger)bannerId InfoType:(NSUInteger)infoType Response:(ESResponse)response;
/*
 * 热门大神
 */
+(void)getDaShenWithField:(NSInteger)field Response:(ESResponse)response;
/*
 * 专家页联赛列表(筛选选项)
 */
+(void)getHomeLeagueListWithField:(NSInteger)field Response:(ESResponse)response;
/*
 * 订阅专家
 */
+(void)followExpert:(NSInteger)expertId Response:(ESResponse)response;
/*
 * 取消订阅专家
 */
+(void)unfollowExpert:(NSInteger)expertId Response:(ESResponse)response;
/*
 * 支付方式
 */
+(void)payWayWithResponse:(ESResponse)response;
/*
 * 支付相关信息
 */
+(void)payInfoResponse:(ESResponse)response;

/*
 * 版本更新
 */
+(void)checkVersonResponse:(ESResponse)response;
/*
 * 获取进球通知设置
 */
+ (void)getGoalNotfiySetting:(ESResponse)response;
/*
 * 设置进球通知
 *  @param sound 是否有声音
 *  @param shake 是否有震动
 *  @param showAll 0:所有比赛，1：仅关注的比赛
 */
+ (void)setGoalNotify:(BOOL)sound shake:(BOOL)shake showAll:(BOOL)showAll response:(ESResponse)response;

/*
 *获取分享链接
 */
+ (void)getShareUrl:(ESResponse)response;

/*
*获取app初始化信息
*/
+ (void)getAppInitInfo:(ESResponse)response;
/*
 *消息中心消息已读接口
 */
+ (void)readMessageWithReadType:(NSUInteger)readType;
/*
 *自定义埋点接口
 */
+ (void)customPostionCode:(NSString *)positionCode;

#pragma mark - 优惠券
/*
 *  获取优惠券列表信息
 *  @param type 1:可使用；2：已使用；3：已过期
 *  @param page 页数
 *  @param pageSize 页大小
*/
+ (void)getMyCouponsList:(NSUInteger)type page:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESResponse)response;

/*
 *  使用优惠券列表
 *  @param scope 1:购买方案；2：购买会员；
 *  @param amount 订单金额
 *  @param page 页数
 *  @param pageSize 页大小
*/
+ (void)applyCoupons:(NSUInteger)scope amount:(NSUInteger)amount page:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESResponse)response;
#pragma mark - 比赛
/**
 * 获取比赛id
 */
+(void)getMatchId:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取筛选列表
 */
+(void)getScreenList:(NSInteger)matchType pageType:(NSInteger)pageType date:(NSString *)date response:(ESResponse)response;
/**
 * 筛选确认
 */
+(void)matchScreen:(NSInteger)matchType pageType:(NSInteger)pageType league:(NSString *)league isAll:(NSInteger)isAll date:(NSString *)date response:(ESResponse)response;
/**
 * 获取即时比赛列表
 * field 0:足球 1:篮球
 */
+ (void)getInstantListWithField:(NSInteger)field withPage:(NSInteger)page pageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 获取即时比赛列表-足球
 */
+(void)getInstantListWithPage:(NSInteger)page pageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 关注/取消关注 比赛
 */
+(void)focusMatch:(BOOL)status matchId:(NSInteger)matchId response:(ESResponse)response;
/**
 * 关注/取消关注 篮球比赛
 */
+(void)focusBasketMatch:(NSUInteger)type matchId:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取关注比赛列表
 */
+(void)getFollowListResponse:(ESResponse)response;
/**
 * 获取赛程/赛果列表
 */
+ (void)getSchedulesList:(NSInteger)pageType date:(NSString *)date sclassId:(NSInteger)sclassId response:(ESResponse)response;
/**
 * 获取比赛直播头部列表
 */
+ (void)getLiveTopList:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛重要事件列表
 */
+ (void)getImportantEventList:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛表格
 */
+ (void)getMatchTable:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取直播指数表格
 */
+ (void)getInstantOddsList:(NSInteger)matchId response:(ESResponse)response;
/**
 * 比赛方案列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param matchId 方案id
 */
+(void)matchPlanWithPage:(int)page PageSize:(int)pageSize matchId:(long)matchId Response:(ESResponse)response;
/**
 * 获取比赛阵容
 */
+ (void)getLineUp:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛情报
 */
+ (void)getIntelligence:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛情报页数据
 */
+ (void)getIntelligencePage:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛情报页欧亚对比数据
*/
+ (void)getIntelligenceEurasianInfo:(NSInteger)matchId response:(ESResponse)response;
/**
 * 比赛情报页欧亚转换器
 */
+ (void)getOddsConversionInfo:(CGFloat)hostOdds drawOdds:(CGFloat)drawOdds awayOdds:(CGFloat)awayOdds response:(ESResponse)response;
/**
 * 获取比赛指数
 */
+ (void)getMatchExpnentialList:(NSInteger)matchId response:(ESResponse)response;
/**
 * 获取比赛直播页即时指数(亚指/大小球)
 */
+ (void)getMatchLiveExpnentialList:(NSInteger)matchId companyId:(NSUInteger)companyId oddsType:(NSUInteger)oddsType response:(ESResponse)response;
/**
 * 获取比赛指数图标
*/
+ (void)getMatchExpnentialChart:(NSUInteger)matchId companyId:(NSUInteger)companyId oddsType:(NSUInteger)oddsType response:(ESResponse)response;
/**
 * 获取比赛指数变化
 */
+ (void)getMatchExpnentialChange:(NSInteger)matchId companyId:(NSUInteger)companyId oddsType:(NSUInteger)oddsType response:(ESResponse)response;
/**
 * 获取比赛数据
 */
+ (void)getMatchData:(NSInteger)matchId dataType:(NSUInteger)dataType response:(ESResponse)response;
/**
 * 获取聊天禁言状态
 */
+ (void)getChatForbiddenResponse:(ESResponse)response;
/**
 * 获取比赛分享地址
*/
+ (void)getMatchShareUrl:(NSUInteger)matchId response:(ESResponse)response;
#pragma mark - 数据
/**
 * 世界排名
 */
+ (void)getWorldRankListWithType:(NSUInteger)type date:(NSString *)date response:(ESResponse)response;
/**
 * 球队标题
 */
+ (void)getTeamTitleWithTeamId:(NSUInteger)teamId Response:(ESResponse)response;
/**
 * 球队比赛
 */
+ (void)getTeamMatchWithPage:(NSUInteger)page PageSize:(NSUInteger)pageSize TeamId:(NSUInteger)teamId  Response:(ESResponse)response;
/**
 * 获取更多球队比赛
 */
+ (void)getMoreTeamMatch:(NSUInteger)teamId  Response:(ESResponse)response;
/**
 * 球队资料
 */
+ (void)getTeamDetailWithTeamId:(NSUInteger)teamId Response:(ESResponse)response;
/**
 * 球队积分
 */
+ (void)getTeamPointWithTeamId:(NSUInteger)teamId leagueId:(NSUInteger)leagueId Response:(ESResponse)response;
/**
 * 联赛详情
 */
+ (void)getleagueTitleWithleagueId:(NSUInteger)leagueId Response:(ESResponse)response;
/**
 * 篮球联赛详情
 */
+ (void)getBasketLeagueTitleWithleagueId:(NSUInteger)leagueId Response:(ESResponse)response;
/**
 * 联赛tab
*/
+ (void)getleagueTabWithleagueId:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;
/**
 * 联赛积分
 */
+ (void)getLeaguePointWithLeagueId:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;
/**
 * 联赛积分附加赛列表
*/
+ (void)loadSchedulesList:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;
/**
 * 联赛积分淘汰赛列表
*/
+ (void)loadKnockoutList:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;
/**
 *
 * 联赛赛程
 */
+ (void)getLeagueScheduleWithLeagueId:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;
/**
 * 子联赛赛程
 */
+ (void)getLeagueSubScheduleWithLeagueId:(NSUInteger)leagueId subIndex:(NSString *)subIndex Season:(NSString *)season Response:(ESResponse)response;
/**
 * 球队阵容
 */
+ (void)getTeamMembersWithTeamId:(NSUInteger)teamId Response:(ESResponse)response;
/**
 * 比赛推送设置
 */
+ (void)setMatchAlertSettingWithStart:(NSInteger)start Before:(NSInteger)before Finished:(NSInteger)finished Goal:(NSInteger)goal Red:(NSInteger)red Yellow:(NSInteger)yellow Corner:(NSInteger)corner Response:(ESResponse)response;
/**
 * 比赛推送
 */
+ (void)matchAlertSettingResponse:(ESResponse)response;

/**
 * 球员基本信息
 */
+(void)playInfoWithPlayerId:(int)playerId TeamId:(int)teamId Response:(ESResponse)response;
/**
 * 球员数据
 */
+(void)playerTechYearWithPlayerId:(NSInteger)playerId Response:(ESResponse)response;
/**
 * 球员年度数据
 */
+(void)playerTechWithPlayerId:(NSInteger)playerId Season:(NSString*)season LeagueId:(NSInteger)leagueId Response:(ESResponse)response;
/**
 * 球员标题
 */
+(void)playerTitleWithPlayerId:(int)playerId TeamId:(int)teamId Response:(ESResponse)response;

/**
 * 历史交锋
 */
+(void)historyPlaysWithMatchId:(NSString *)matchId
                   withDataType:(int)dataType
                        withNum:(int)num
                      Response:(ESResponse)response;

/**
 * 最近战绩
 */
+ (void)lastPlaysWithMatchId:(NSString *)matchId
                withDataType:(int)dataType
                     withNum:(int)num
                     Response:(ESResponse)response;

/**
 * 伤停情况
 */
+(void)injuryWithMatchId:(NSString*)matchId Response:(ESResponse)response;

/**
 * 联赛积分
 */
+(void)integralWithMatchId:(NSString*)matchId Response:(ESResponse)response;

/**
 * 数据对比
 */
+(void)dataCompareWithMatchId:(NSString*)matchId DataType:(int)dataType Num:(int)num Response:(ESResponse)response;
/**
 * 未来三场
 **/
+(void)futureMatchWithMatchId:(NSString*)matchId Response:(ESResponse)response;

/**
 * 所有联赛
 **/
+(void)allEventsResponse:(ESResponse)response;
/**
 * 热门赛事
 **/
+(void)hotEventsResponse:(ESResponse)response;
/**
 * 赛前指数
 **/
+(void)beforeMatchWithMatchId:(NSString*)matchId Response:(ESResponse)response;
/**
 * 历史同盘
 **/
+(void)sameDiskWithMatchId:(NSString*)matchId Response:(ESResponse)response;
/**
 * 射手榜
 */
+ (void)mvpWithLeagueId:(NSUInteger)leagueId Season:(NSString *)season Response:(ESResponse)response;


/**
* 苹果预下单
**/
+(void)applePrechargeWithMoney:(NSNumber *)money Response:(ESResponse)response;
/**
* 苹果校验
**/
+(void)appleVerityWithReceipt:(NSString*)receipt Type:(int)type ReceiptToken:(NSString*)receiptToken Response:(ESResponse)response;


/**
* 单双
**/
+(void)oddOrEvenWithMatchId:(NSString*)matchId Response:(ESResponse)response;
/**
* 进球分布
**/
+(void)scoreTimeWithMatchId:(NSString*)matchId Response:(ESResponse)response;
/**
* 大小球
**/
+(void)bigOrSmallWithMatchId:(NSString*)matchId Response:(ESResponse)response;
/**
* 赛季数据
**/
+(void)seasonDataWithMatchId:(NSString*)matchId Response:(ESResponse)response;
+(void)newGetMatchDateNum:(NSInteger)matchDateNum response:(ESResponse)response;

/**
* 搜索数据
**/
+(void)searchDataWithType:(NSString*)type andKeyWord:(NSString*)keyword page:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESResponse)response;

/**
* 推荐赛事
**/
+(void)recomandMatchWithresponse:(ESResponse)response;
/**
* 首页推荐赛事
**/
+ (void)homeRecomandMatchWithresponse:(ESResponse)response;
/**
 最新战报
 */
+(void)recentMatchResultWithresponse:(ESResponse)response;

/*
 * 足彩分析
 */
+(void)getlotteryDataWithMatchId:(NSString*)matchId Response:(ESResponse)response;
#pragma mark - 发现
/*
 * 轮播图
 */
+(void)getBannersDiscoverWithResponse:(ESResponse)response;
/*
 * 飞驰头条
 */
+(void)getHeadlinesDiscoverWithResponse:(ESResponse)response;
/**
 * 资讯页
 */
+(void)newsListPage:(NSInteger)page PageSize:(NSInteger)pageSize Withresponse:(ESResponse)response;
/**
 * 统计文章浏览量
 **/
+ (void)viewPaperWithTextId:(NSInteger)textId Response:(ESResponse)response;
/*
 * 资讯文章详情
 */
+(void)getNewsDetailWithTextId:(NSString *)textId Response:(ESResponse)response;
/*
 * 资讯文章评论列表
 */
+(void)getCommentListWithTextId:(NSString *)textId sortType:(NSUInteger)sortType page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/*
 * 资讯文章评论的点赞
 */
+ (void)commentLikeStatusChangeWithCommentId:(NSUInteger)commentId likeStatus:(BOOL)likeStatus Response:(ESResponse)response;
/*
 * 资讯文章点赞
 */
+ (void)paperLikeStatusChangeWithTextId:(NSUInteger)textId likeStatus:(BOOL)likeStatus Response:(ESResponse)response;
/*
 * 资讯文章评论
 */
+ (void)paperCommentWithTextId:(NSUInteger)textId content:(NSString *)content Response:(ESResponse)response;
/*
 * 资讯评论回复列表
 */
+ (void)paperCommentReplyListWithHostCommentId:(NSUInteger)hostCommentId sortType:(NSUInteger)sortType page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/*
 * 回复评论
 */
+ (void)paperCommentWithHostCommentId:(NSUInteger)hostCommentId otherCommentId:(NSUInteger)otherCommentId content:(NSString *)content Response:(ESResponse)response;
/*
 * 社区回复消息列表
 */
+ (void)communityRepyMessageListWithPage:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/*
 * 社区评论消息列表
 */
+ (void)communityCommentMessageListWithPage:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/*
 * 社区官方消息列表
 */
+ (void)communityOffcialMessageListWithPage:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/*
* 获取评论回复消息
*/
+ (void)getCommunityReplyMessageWithCommentId:(NSUInteger)commentId messageType:(NSUInteger)messageType Response:(ESResponse)response;
/*
 * 获取文章分享信息
 */
+ (void)getPaperFowardInfoWithTextId:(NSUInteger)textId Response:(ESResponse)response;
#pragma mark - 篮球
/**
 * 获取篮球即时列表
 */
+(void)getBaskectballList:(ESResponse)response;
/**
 * 获取篮球赛果列表
 */
+(void)getEndBaskectballList:(NSString *)date response:(ESResponse)response;
/**
 * 获取篮球赛程列表
 */
+(void)getUnstartBaskectballList:(NSString *)date response:(ESResponse)response;
/**
 * 获取篮球关注列表
 */
+(void)getBasketFollowList:(ESResponse)response;
/**
 * 获取篮球关注数
 */
+(void)getBasketFollowCount:(ESResponse)response;
/**
 * 获取篮球筛选列表
 */
+(void)getBasketScreenList:(NSInteger)pageType date:(NSString *)date response:(ESResponse)response;
/**
 * 获取篮球比赛直播头部列表
 */
+ (void)getBasketLiveTopList:(NSInteger)matchId response:(ESResponse)response;
/*
* 篮球直播
*/
+ (void)getBasketLive:(NSInteger)matchId response:(ESResponse)response;
/*
 * 篮球统计
 */
+ (void)getBasketStatistics:(NSInteger)matchId response:(ESResponse)response;
/*
 * 篮球数据
 */
+ (void)getBasketData:(NSInteger)matchId response:(ESResponse)response;
/*
 * 篮球指数
 */
+ (void)getBasketExpnentialList:(NSInteger)matchId response:(ESResponse)response;
/*
 * 篮球指数折线图
 */
+ (void)getBasketExpnentialChange:(NSInteger)matchId companyId:(NSUInteger)companyId type:(NSUInteger)type response:(ESResponse)response;

/**
 * 新增完善资料
 */
+(void)supplyInfoWithUserName:(NSString*)userName passWord:(NSString*)passWord response:(ESResponse)response;
/**
* 自定义情报
**/
+(void)customizeIntelligenceWithMatchId:(NSString*)matchId Response:(ESResponse)response;

/**
 * 篮球情报
 **/
+(void)getBaskectballIntelligence:(NSUInteger)matchId response:(ESResponse)response;

/**
 * 篮球积分
 */
+(void)getBaskectballLeaguePoint:(NSUInteger)eventId response:(ESResponse)response;
/**
* 我的发布记录
**/
+(void)mySaleListWithPage:(int)page PageSize:(int)pageSize Response:(ESResponse)response;
/**
* 校验方案
**/
+(void)checkPlanWithMatchDateNums:(NSString*)matchId Response:(ESResponse)response;
/**
* 篮球推送设置
**/
+(void)setBasketAlertSettingWithStart:(NSInteger)start Before:(NSInteger)before harf:(NSInteger)half Finished:(NSInteger)finished Response:(ESResponse)response;
/**
* 篮球推送初始
**/
+ (void)basketAlertSettingResponse:(ESResponse)response;

#pragma mark - 商城
/**
 * 商城商品品类列表
 **/
+(void)getShopProductCategoryList:(ESResponse)response;
/**
 * 商城品类下标签列表
 **/
+(void)getShopTagLIstWithCategoryId:(NSString *)categoryId Response:(ESResponse)response;
/**
 * 商城商品列表
 **/
+(void)getShopProductListWithCategoryId:(NSString *)categoryId Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 商城标签页商品列表
 **/
+(void)getShopProductListWithCategoryId:(NSString *)categoryId tagId:(NSString *)tagId Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 商城我的订单列表
 **/
+ (void)getShopOrderListWithState:(NSInteger)state Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;

/**
 * 商城我的订单列表详情
 **/
+ (void)getShopOrderDetailWithOrderId:(NSInteger)orderId Response:(ESResponse)response;
/**
 * 商城取消订单
 **/
+ (void)cancelShopOrderWithOrderId:(NSInteger)orderId Response:(ESResponse)response;
/**
 * 商城删除订单
 **/
+ (void)deleteShopOrderWithOrderId:(NSInteger)orderId Response:(ESResponse)response;
/**
 * 商城订单确认收货
 **/
+ (void)comfirmShopOrderWithOrderId:(NSInteger)orderId Response:(ESResponse)response;
/**
 * 获取商品分享链接
 **/
+ (void)getProductShareUrl:(NSUInteger)productId Response:(ESResponse)response;
/**
 * 微信小程序分享商品
 **/
+ (void)productShareWechat:(NSUInteger)productId Response:(ESResponse)response;
/**
 * 获取订单物流信息
 **/
+ (void)getOrderExpress:(NSString *)orderId response:(ESResponse)response;

#pragma mark - 购物车相关
/**
 * 获取购物车详情
 **/
+(void)getShopCartDetailWithResponse:(ESResponse)response;
/**
 * 获取购物车中商品数量
 **/
+(void)getShopCartCountWithResponse:(ESResponse)response;
/**
 * 加入商品到购物车
 **/
+(void)addGoodsToShopCart:(NSUInteger)productId productSpecificationId:(NSUInteger)productSpecificationId num:(NSUInteger)num reponse:(ESResponse)response;
/**
 * 修改购物车商品数量
 **/
+(void)modifyGoodsNumInShopCart:(NSUInteger)productId productSpecificationId:(NSUInteger)productSpecificationId num:(NSUInteger)num reponse:(ESResponse)response;
/**
 * 从购物车中删除商品
 **/
+(void)deleteGoodsFromShopCart:(NSString *)productSpecificationIdList reponse:(ESResponse)response;
/**
 * 选择购物车商品
 **/
+(void)selectGoodsInShopCart:(NSString *)productSpecificationIdList isChosen:(NSUInteger)isChosen reponse:(ESResponse)response;
/**
 * 购物车预下单
 **/
+(void)shopCartPreOrderCreateWithResponse:(ESResponse)response;

#pragma mark - 地址管理
/**
 * 收货地址列表
 **/
+ (void)getAddreesListWithPage:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;

/**
 * 收货地址添加
 **/
+ (void)addAddreesWithModel:(NSDictionary *)mallAddress Response:(ESResponse)response;
/**
 * 收货地址修改
 **/
+ (void)modifyAddreesWithModel:(NSDictionary *)mallAddress Response:(ESResponse)response;
/**
 * 收货地址删除
 **/
+ (void)deleteAddreesWithAddressId:(NSString *)addressId Response:(ESResponse)response;
#pragma mark - 社区
/**
*获取uCloud图片信息
 **/
+ (void)getUCloudImageInfo:(NSString *)imageUrl Response:(ESResponse)response;
/**
 * 统计帖子浏览量
 **/
+ (void)viewCommunityPostWithPostId:(NSInteger)postId Response:(ESResponse)response;
/**
 * 社区发帖
 **/
+ (void)communityPostCreate:(NSInteger)topicId title:(NSString *)title headImg:(NSString *)headImg videoPath:(NSString *)videoPath pictures:(NSString *)pictures videoFirstFrame:(NSString *)videoFirstFrame content:(NSString *)content wordCount:(NSUInteger)wordCount Response:(ESResponse)response;
/**
 * 社区banner
 **/
+(void)getCommunityBanberWithResponse:(ESResponse)response;
/**
 * 获取广场列表
 **/
+ (void)getCommunitySquadListPage:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**
 * 获取话题列表
 **/
+ (void)getCommunityTopicWithResponse:(ESResponse)response;
/**
 * 获取话题列表(发帖用)
 **/
+ (void)getCommunityPostTopicWithResponse:(ESResponse)response;
/**
 * 获取话题详情列表
 **/
+ (void)getCommunityTopicDetailListWithTopicId:(NSUInteger)topicId
										  page:(NSUInteger)page
										  type:(NSUInteger)type
									  pageSize:(NSUInteger)pageSize
									  Response:(ESResponse)response;
/**
 * 获取话题详情信息
 **/
+ (void)getCommunityTopicDetailInfoWithTopicId:(NSUInteger)topicId
									  Response:(ESResponse)response;
/**
 * 关注话题
 **/
+ (void)followCommunityTopicWithTopicId:(NSUInteger)topicId followStatus:(NSUInteger)followStatus Response:(ESResponse)response;
/**
 * 关注用户
 **/
+ (void)followCommunityUserWithUserId:(NSUInteger)focusUserId followStatus:(NSUInteger)followStatus Response:(ESResponse)response;
/**
 * 个人主页信息
 **/
+ (void)communityHomePageInfoWithHomeUserId:(NSString *)userId Response:(ESResponse)response;
/**
 * 个人主页列表
 **/
+ (void)getCommunityHomePageListWithHomeUserId:(NSString *)homeUserId
										  page:(NSUInteger)page
										  type:(NSUInteger)type
									  pageSize:(NSUInteger)pageSize
									  Response:(ESResponse)response;
/**
 * 获取社区关注列表
 **/
+ (void)getCommunityFocusList:(NSUInteger)homeUserId page:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESResponse)response;
/**
 * 获取社区粉丝列表
 **/
+ (void)getCommunityFansList:(NSUInteger)homeUserId page:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESResponse)response;
/**
 * 删除帖子
 **/
+ (void)deleteCommunityPostWithPostId:(NSUInteger)postId Response:(ESResponse)response;

/// 屏蔽/举报帖子
/// @param postId 帖子id
/// @param type 0-内容质量不佳 1-仅仅不喜欢 2-举报
/// @param reason 举报原因nullable
+(void)blockCommunityPostWithPostId:(NSUInteger)postId type:(NSUInteger)type reason:(NSString *)reason Response:(ESResponse)response;
/**
 * 帖子详情
 **/
+(void)getCommunityPostDetailWithPostId:(NSString *)postId Response:(ESResponse)response;
/**
 * 帖子点赞
 **/
+ (void)communityPostLikeWithPostId:(NSUInteger)postId likeStatus:(NSUInteger)likeStatus Response:(ESResponse)response;
/**
 * 帖子喜欢
 **/
+ (void)communityPostCollectionWithPostId:(NSUInteger)postId Response:(ESResponse)response;
/**
 * 帖子取消喜欢
 **/
+ (void)communityPostUncollectionWithPostId:(NSUInteger)postId Response:(ESResponse)response;
/**
 * 转发帖子
 **/
+ (void)getCommunityPostForwardWithPostId:(NSUInteger)postId Response:(ESResponse)response;
/**
 * 帖子评论列表
 **/
+(void)getCommunityPostCommentListWithPostId:(NSString *)postId sortType:(NSUInteger)sortType page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/**
 * 对帖子评论进行点赞
 **/
+ (void)communityPostCommentLikeWithCommentId:(NSUInteger)commentId likeStatus:(BOOL)likeStatus Response:(ESResponse)response;
/**
 * 对帖子进行评论
 **/
+ (void)communityPostCommentWithPostId:(NSUInteger)postId content:(NSString *)content Response:(ESResponse)response;
/**
 * 帖子评论的回复列表
 **/
+ (void)communityPostCommentReplyListWithHostCommentId:(NSUInteger)hostCommentId sortType:(NSUInteger)sortType page:(NSUInteger)page pageSize:(NSUInteger)pageSize Response:(ESResponse)response;
/**
 * 对帖子评论进行回复
 **/
+ (void)communityPostReplyCommentWithHostCommentId:(NSUInteger)hostCommentId otherCommentId:(NSUInteger)otherCommentId content:(NSString *)content Response:(ESResponse)response;
/**
 * 商品详情
 */
+(void)productDetailWithProductId:(NSString*)productId Response:(ESResponse)response;
/**
* 商品初始化
*/
+(void)productOrderInitWith:(NSInteger)productSpecificationId num:(NSInteger)num Response:(ESResponse)response;
/**
 * 商品规格列表
 */
+(void)getProductSpecListWithProductId:(NSUInteger)productId response:(ESResponse)response;
/**
* 商品订单创建(立即购买使用)
*/
+(void)productOrderCreatWithOrderId:(NSString*)orderId productId:(NSString*)productId productSpecificationId:(NSString*)productSpecificationId num:(NSString*)num addressId:(NSString*)addressId price:(NSString*)price Response:(ESResponse)response;
/**
 * 商品订单创建(购物车使用)
 */
+(void)productOrderCreatWithOrderId:(NSString*)orderId addressId:(NSString*)addressId Response:(ESResponse)response;
/**
 * 点击banner增加点击数
 */
+(void)hitsBannerWithBannerId:(NSString*)bannerId Response:(ESResponse)response;
/**
* 获取邮费
*/
+(void)getpostfeedWithResponse:(ESResponse)response;
/**
* 点击启动图增加点击数
*/
+(void)hitsStartImageWithImageId:(NSString*)imageId Response:(ESResponse)response;
//帖子搜索
+(void)getSearchPostListWithKeyword:(NSString *)keyword Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
//用户搜索
+(void)getSearchUserListWithKeyword:(NSString *)keyword Page:(NSInteger)page PageSize:(NSInteger)pageSize Response:(ESResponse)response;
/**分享专家*/
+(void)expertIdShareWithExpertId:(NSString*)expertId Field:(NSString*)fieId Response:(ESResponse)response;
/**分享方案*/
+(void)planShareWithPlanId:(NSString*)planId Response:(ESResponse)response;

/**关注的专家列表*/
+ (void)expertSubscribedListWithPage:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESCodeResponse)response;

/**推荐专家列表*/
+ (void)expertRecommendListWithResponse:(ESCodeResponse)response;

/**关注的专家方案列表*/
+ (void)plansSubscribedListWithPage:(NSUInteger)page pageSize:(NSUInteger)pageSize response:(ESCodeResponse)response;

/**发布方案-赛事初始化数据 */
+ (void)getPlanInitWithResponse:(ESResponse)response;
@end

