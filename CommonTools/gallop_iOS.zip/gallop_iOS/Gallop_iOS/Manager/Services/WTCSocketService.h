//
//  WTCSocketService.h
//  Gallop_iOS
//
//  Created by Homosum on 2019/7/9.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <SocketRocket.h>
NS_ASSUME_NONNULL_BEGIN

@interface WTCSocketService : NSObject

/** 获取连接状态 */
@property (nonatomic,assign,readonly) SRReadyState socketReadyState;

/** 开始连接 */
- (void)SRWebSocketOpenWithURLString:(NSString *)urlString;

/** 关闭连接 */
- (void)SRWebSocketClose;

/** 发送数据 */
- (void)sendData:(id)data;

+ (WTCSocketService *)instance;
@end

NS_ASSUME_NONNULL_END
