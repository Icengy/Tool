//
//  WTCChatSocketService.m
//  Gallop_iOS
//
//  Created by lixuanye on 2019/8/21.
//  Copyright © 2019 homosum. All rights reserved.
//

#import "WTCChatSocketService.h"

@interface WTCChatSocketService()<SRWebSocketDelegate>

{
    int _index;
    NSTimer * _heartBeat;
    NSTimeInterval _reConnectTime;
}
@property (nonatomic,strong) SRWebSocket *socket;
@property (nonatomic,strong) dispatch_queue_t receiveQueue;
@property (nonatomic,strong) dispatch_queue_t sendQueue;
@property (nonatomic,copy)   NSString *urlString;
@property(nonatomic, strong) NSString *heartJsonStr;

@end
@implementation WTCChatSocketService
+ (WTCChatSocketService *)instance {
    static WTCChatSocketService *Instance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        Instance = [[WTCChatSocketService alloc] init];
        Instance.receiveQueue = dispatch_queue_create("receiveQueue", NULL);
        Instance.sendQueue = dispatch_queue_create("sendQueue", NULL);
    });
    return Instance;
}

#pragma mark - **************** public methods
-(void)SRWebSocketOpenWithURLString:(NSString *)urlString {
    
    //如果是同一个url return
    if (self.socket) {
        return;
    }
    
    if (!urlString) {
        return;
    }
    
    self.urlString = urlString;
    
    self.socket = [[SRWebSocket alloc] initWithURLRequest:
                   [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]]];
    
    NSLog(@"请求的websocket地址：%@",self.socket.url.absoluteString);
    
    //SRWebSocketDelegate 协议
    self.socket.delegate = self;
    
    //开始连接
    [self.socket open];
}

- (void)SRWebSocketClose {
    if (self.socket){
        [self.socket close];
        self.socket = nil;
        //断开连接时销毁心跳
        [self destoryHeartBeat];
    }
}

#define WeakSelf(ws) __weak __typeof(&*self)weakSelf = self
- (void)sendData:(id)data {
    if (![data isEqualToString:self.heartJsonStr]) {
        NSLog(@"socketSendData --------------- %@",data);
    }
    
    WeakSelf(ws);
    dispatch_async(self.sendQueue, ^{
        if (weakSelf.socket != nil) {
            if (weakSelf.socket.readyState == SR_OPEN) {
                [weakSelf.socket send:data];    // 发送数据
                
            } else if (weakSelf.socket.readyState == SR_CONNECTING) {
                NSLog(@"正在连接中，重连后其他方法会去自动同步数据");
                [self reConnect];
                
            } else if (weakSelf.socket.readyState == SR_CLOSING || weakSelf.socket.readyState == SR_CLOSED) {
                
                NSLog(@"重连");
                
                [self reConnect];
            }
        } else {
            NSLog(@"没网络，发送失败，一旦断网 socket 会被我设置 nil 的");
            NSLog(@"其实最好是发送前判断一下网络状态比较好，我写的有点晦涩，socket==nil来表示断网");
        }
    });
}

#pragma mark - **************** private mothodes
//重连机制
- (void)reConnect {
    [self SRWebSocketClose];
    
    if (_reConnectTime > 64) {
        
        return;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(_reConnectTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.socket = nil;
        [self SRWebSocketOpenWithURLString:self.urlString];
        NSLog(@"重连");
    });
    
    //重连时间2的指数级增长
    if (_reConnectTime == 0) {
        _reConnectTime = 2;
    } else {
        _reConnectTime *= 2;
    }
}


//取消心跳
- (void)destoryHeartBeat {
    dispatch_main_async_safe(^{
        if (self->_heartBeat) {
            if ([self->_heartBeat respondsToSelector:@selector(isValid)]){
                if ([self->_heartBeat isValid]){
                    [self->_heartBeat invalidate];
                    self->_heartBeat = nil;
                }
            }
        }
    })
}

//初始化心跳
- (void)initHeartBeat {
    dispatch_main_async_safe(^{
        [self destoryHeartBeat];
        //心跳设置为3分钟，NAT超时一般为5分钟
        self->_heartBeat = [NSTimer timerWithTimeInterval:3 target:self selector:@selector(sentheart) userInfo:nil repeats:YES];
        //和服务端约定好发送什么作为心跳标识，尽可能的减小心跳包大小
        [[NSRunLoop currentRunLoop] addTimer:self->_heartBeat forMode:NSRunLoopCommonModes];
    })
}

- (void)sentheart {
//    self.heartJsonStr = [@{@"type":@(0)} JSONString];
//    [self sendData:self.heartJsonStr];
}

//pingPong
- (void)ping {
    if (self.socket.readyState == SR_OPEN) {
        [self.socket sendPing:nil];
    }
}

#pragma mark - **************** SRWebSocketDelegate
- (void)webSocketDidOpen:(SRWebSocket *)webSocket {
    //每次正常连接的时候清零重连时间
    _reConnectTime = 0;
    //开启心跳
    [self initHeartBeat];
    if (webSocket == self.socket) {
        NSLog(@"************************** socket 连接成功************************** ");
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error {
    if (webSocket == self.socket) {
        NSLog(@"************************** socket 连接失败************************** ");
        _socket = nil;
        //连接失败就重连
        [self reConnect];
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean {
    if (webSocket == self.socket) {
        NSLog(@"************************** socket连接断开************************** ");
        NSLog(@"被关闭连接，code:%ld,reason:%@,wasClean:%d",(long)code,reason,wasClean);
        [self SRWebSocketClose];
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didReceivePong:(NSData *)pongPayload {
    NSString *reply = [[NSString alloc] initWithData:pongPayload encoding:NSUTF8StringEncoding];
    NSLog(@"reply===%@",reply);
}

- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message  {
    dispatch_async(self.receiveQueue, ^{
        if (webSocket == self.socket) {
            NSLog(@"************************** socket收到数据了************************** ");
            NSLog(@"message:%@",message);
            NSData *jsonData = [message dataUsingEncoding:NSUTF8StringEncoding];
            NSError *error;
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                options:NSJSONReadingMutableContainers
                                                                  error:&error];
            if(error)
            {
                NSLog(@"json解析失败：%@",error);
                return;
            }
            [self handleReceivedMessage:dic];
        }
    });
}

#pragma mark - 消息解析(后续创建解析类)
- (void)handleReceivedMessage:(NSDictionary *)message {
    //处理收到的消息(根据消息类型转换)
    switch ([message[@"type"] integerValue]) {
        case 1: {
//            建立连接成功，初始化消息
            ChatTCPInitModel *model = [ChatTCPInitModel mj_objectWithKeyValues:message];
            [[NSNotificationCenter defaultCenter] postNotificationName:kChatTCPInitModel object:model];
        }
            break;
        case 2: {
            //发送消息后的返回结果
            ChatTCPResponseModel *model = [ChatTCPResponseModel mj_objectWithKeyValues:message];
            [[NSNotificationCenter defaultCenter] postNotificationName:kChatTCPResponseModel object:model];
        }
            break;
        case 3: {
            //新消息
            ChatTCPMessageModel *model = [ChatTCPMessageModel mj_objectWithKeyValues:message];
            [[NSNotificationCenter defaultCenter] postNotificationName:kChatTCPMessageModel object:model];
        }
        default:
            break;
    }
}

#pragma mark - **************** setter getter
- (SRReadyState)socketReadyState {
    return self.socket.readyState;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


@end
