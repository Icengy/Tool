//
//  ESNetworkService.m
//  ESTicket
//
//  Created by 鹏 刘 on 15/11/25.
//  Copyright © 2015年 鹏 刘. All rights reserved.
//

#import "ESNetworkService.h"
#import "ESUrl.h"
#import "GTMBase64.h"
#import <CommonCrypto/CommonDigest.h>
#import <AFNetworking/AFNetworking.h>
#define BMEncode(str) [str dataUsingEncoding:NSUTF8StringEncoding]


@implementation ESNetworkService

#pragma mark - base api

+ (NSDictionary *)dictWithSigned:(NSMutableDictionary *)dic
                         andUrl:(NSString *)url {
    
    NSString *sign = [self sign:[NSDictionary dictionaryWithDictionary:dic] andUrl:url];
    dic[@"sign"] = [sign urlEncodedString];
    return dic.copy;
}

+ (NSString *)dealPassword:(NSString *)password
              andDic:(NSString *)time {
    if (![CommonUtils isEqualToNonNull:password]) return @"";
    
    if (![CommonUtils isEqualToNonNull:time]) {
        NSDate *now = [NSDate date];
        NSTimeInterval a = [now timeIntervalSince1970]*1000;
        NSString *timeString = [NSString stringWithFormat:@"%0.f", a];
        time = timeString;
    }
    
    NSString *base64_str  = [GTMBase64 stringByEncodingData:[password dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSString *md5_str = [self md5:base64_str];
    NSString *key = [NSString stringWithFormat:@"%@%@%@",[time substringFromIndex:time.length-7],@"PASSWORD",time];
    NSString *key_base64 = [GTMBase64 stringByEncodingData:[key dataUsingEncoding:NSUTF8StringEncoding]];
    NSString *newPW = [DES3Util getDESEncrypt:md5_str withKey:key_base64];
    
//    dic[@"password"] = newPW;
    return newPW;
}

+ (NSMutableDictionary *)dictForApi {
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    dic[@"from"] = AppFrom;
    NSArray *verArray = [APP_CONFIG.version componentsSeparatedByString:@"."];
    if (verArray.count == 5) {
        NSInteger version = [verArray[0] integerValue]*10000+[verArray[1] integerValue]*1000+[verArray[2] integerValue]*100+[verArray[3] integerValue]*10+[verArray[4] integerValue]*1;
        dic[@"version"] = [NSString stringWithFormat:@"%@",@(version)];
    }
    
    if (verArray.count == 4) {
        NSInteger version = [verArray[0] integerValue]*10000+[verArray[1] integerValue]*1000+[verArray[2] integerValue]*100+[verArray[3] integerValue]*10;
        dic[@"version"] = [NSString stringWithFormat:@"%@",@(version)];
    }
    if (verArray.count == 3) {
        NSInteger version = [verArray[0] integerValue]*10000+[verArray[1] integerValue]*1000+[verArray[2] integerValue]*100;
        dic[@"version"] = [NSString stringWithFormat:@"%@",@(version)];
    }
    
    if ([CommonUtils stringIsUsefull:App_Utility.currentUser.token]) {
        dic[@"token"] = App_Utility.currentUser.token;
    }else {
        dic[@"token"] = @"";
    }
    
    if ([App_Utility.currentUser.userId longLongValue] > 0) {
        dic[@"userId"] = App_Utility.currentUser.userId;
    }else {
        dic[@"userId"] = @"0";
    }
	if (!QM_IS_STR_NIL([[NSUserDefaults standardUserDefaults] objectForKey:kDeviceTokenUmeng])) {
        dic[@"deviceId"] = [[NSUserDefaults standardUserDefaults] objectForKey:kDeviceTokenUmeng];
	}
    NSDate *now = [NSDate date];
    NSTimeInterval a = [now timeIntervalSince1970]*1000;
    NSString *timeString = [NSString stringWithFormat:@"%0.f", a];
    dic[@"time"] = timeString;
    
    return dic;
}

+ (NSString *)sign:(NSDictionary *)dic andUrl:(NSString *)url {
    
    /* 普通参数*/
    
    NSArray *allKeyArray = [dic allKeys];
    NSMutableArray *afterSortKeyArray = [NSMutableArray arrayWithArray:[allKeyArray sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSComparisonResult resuest = [obj2 compare:obj1];
        return resuest;
    }]];
    [afterSortKeyArray removeObject:@"time"];
    
    
    //通过排列的key值获取value
    NSMutableArray *valueArray = [NSMutableArray array];
    for (NSString *sortsing in afterSortKeyArray) {
        NSString *valueString = [dic objectForKey:sortsing];
        [valueArray addObject:valueString];
    }
    
    NSMutableArray *signArray = [NSMutableArray array];
    for (int i = 0 ; i < afterSortKeyArray.count; i++) {
        NSCharacterSet  *set = [NSCharacterSet whitespaceAndNewlineCharacterSet];
        if ([valueArray[i] isKindOfClass:[NSString class]]) {
            valueArray[i] = [valueArray[i] stringByTrimmingCharactersInSet:set];
        }
        NSString *keyValue = [NSString stringWithFormat:@"%@=%@",afterSortKeyArray[i],valueArray[i]];
        [signArray addObject:keyValue];
    }
    
    //signString用于签名的原始参数集合
    NSString *tmpStr = [signArray componentsJoinedByString:@"&&"];
    
    NSString *time = [dic objectForKey:@"time"];
    NSString *secondStr = [NSString stringWithFormat:@"%@%@##%@##%@",[time substringFromIndex:time.length - 7],[self subTheUrl:url],tmpStr,time];
    
    NSString *str  = [GTMBase64 stringByEncodingData:[secondStr dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSString*D = [self md5:str];
    NSString*E = [NSString stringWithFormat:@"%@%@",[D substringFromIndex:9],[D substringToIndex:9]];
    NSString*F = [NSString stringWithFormat:@"%@%@",[E substringFromIndex:15],[E substringToIndex:15]];
    return F;
}

+ (NSString *)subTheUrl:(NSString *)url {
    NSRange range = [url rangeOfString:HostUrl];
    return [url substringFromIndex:range.length];
}

+ (NSString *)md5:(NSString *)str {
    // 判断传入的字符串是否为空
    if (! str) return nil;
    // 转成utf-8字符串
    const char *cStr = str.UTF8String;
    // 设置一个接收数组
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    // 对密码进行加密
    CC_MD5(cStr, (CC_LONG) strlen(cStr), result);
    NSMutableString *md5Str = [NSMutableString string];
    // 转成32字节的16进制
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i ++) {
        [md5Str appendFormat:@"%02X", result[i]];
    }
    return md5Str;
}
#pragma mark 接口
/**
 * 专家号申请
 **/
+ (void)applyForExpertWithExpertName:(NSString*)expertName
                        ExpertAvatar:(NSString*)expertAvatar
                        Introduction:(NSString*)introduction
                      ApplyCondition:(NSString*)applyCondition
                      ConditionImage:(NSString*)conditionImage
                       IdentityImage:(NSString*)identityImage
                               field:(NSString *)field
                            Response:(ESResponse)response
{
    NSMutableDictionary *params = [self dictForApi];
    params[@"expertName"] = expertName;
    params[@"expertAvatar"] = expertAvatar;
    params[@"introduction"] = introduction;
    params[@"applyCondition"] = applyCondition;
    params[@"conditionImage"] = conditionImage;
    params[@"identityImage"] = identityImage;
    params[@"field"] = field;
    
    NSString *hostLink = ES_Url.becomeExpert;
    NSDictionary *finalDic = [self dictWithSigned:params andUrl:hostLink];
    [ES_HttpService sendGetWithURL:ES_Url.becomeExpert parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 消息列表
 **/
+ (void)getMessageListWithType:(NSInteger)type
                          Page:(NSInteger)page
                      PageSize:(NSInteger)pageSize
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = @(type);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    NSString *hostLink = ES_Url.messageList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 订阅设置
 **/
+ (void)getPushExpertListWithPage:(NSInteger)page
                         PageSize:(NSInteger)pageSize
                         Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);

    NSString *hostLink = ES_Url.pushSetting;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 设为已读
 **/
+ (void)readMessageId:(NSString *)messageId
              andType:(NSString *)type
             Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"messageId"] = messageId;
    dic[@"type"] = type;
    
    NSString *hostLink = ES_Url.readMessage;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 设为互动消息已读
 **/
+ (void)readInteractMessageWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.readInteractMessage;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 获取专家号信息
 **/
+ (void)getExpertInfoResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.expertInfo;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 获取个人消息
 **/
+ (void)getPersonalInfoResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.personalInfo;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 修改手机号
 * phone 手机号
 * captcha 验证码
 **/
+ (void)changePhoneWithPhone:(NSString *)phone
                     captcha:(NSString *)captcha
                    Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    dic[@"captcha"] = captcha;
    
    NSString *hostLink = ES_Url.setPhone;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 修改用户名
 **/

+ (void)setUserName:(NSString *)userName
           Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"userName"] = userName;
    NSString *hostLink = ES_Url.setUserName;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)setSex:(NSUInteger)gender
      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"gender"] = @(gender);
    
	NSString *hostLink = ES_Url.setSex;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)setSign:(NSString *)signature
      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"signature"] = signature;
    
	NSString *hostLink = ES_Url.setSign;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 修改邮箱
 **/
+ (void)setEmail:(NSString *)email
       Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"email"] = email;
    NSString *hostLink = ES_Url.setEmail;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)gradeCenterSignInWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.gradeCenterSignIn;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)completeShareTaskWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.gradeCenterShareTask;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)completeLiveTastWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.gradeCenterLiveTask;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}


+ (void)getGradeCenterInfo:(NSString *)userId
                  Response:(ESResponse)response {
	NSMutableString *hostLink = [NSMutableString stringWithString:ES_Url.gradeCenterInfo];
	
	[hostLink appendString:QM_STR_NOT_NIL(userId)];
	
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getGradeCenterDetail:(NSString *)userId
                        page:(NSUInteger)page
                    pageSize:(NSUInteger)pageSize
                    Response:(ESResponse)response {
	NSMutableString *hostLink = [NSMutableString stringWithString:ES_Url.gradeCenterDetail];
	
	[hostLink appendString:QM_STR_NOT_NIL(userId)];
	
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 修改Token
 **/
+ (void)setDeviceToken:(NSString *)deviceToken
              Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"deviceToken"] = deviceToken;
    
    NSString *hostLink = ES_Url.setToken;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 登出
 **/
+ (void)logoutResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.logout;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 修改密码
 *
 **/
+ (void)changePasswordWithOldpassword:(NSString*)oldpassword
                             Password:(NSString*)password
                             Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    oldpassword = [self dealPassword:oldpassword andDic:[dic objectForKey:@"time"]];
    dic[@"oldPassword"] = [oldpassword urlEncodedString];
    password = [self dealPassword:password andDic:[dic objectForKey:@"time"]];
    dic[@"newPassword"] = [password urlEncodedString];

    NSString *hostLink = ES_Url.changePassword;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    finalDic[@"newPassword"] = [dic[@"newPassword"] urlEncodedString];
//    finalDic[@"oldPassword"] = [dic[@"oldPassword"] urlEncodedString];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 找回密码
 * phone 手机号
 * password 密码
 **/
+ (void)findPhone:(NSString*)phone
         Password:(NSString*)password
         Response:(ESResponse)response {
    
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    password = [self dealPassword:password andDic:[dic objectForKey:@"time"]];
    dic[@"password"] = [password urlEncodedString];
    
    NSString *hostLink = ES_Url.findPassword;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 登录接口
 * phone 手机号
 * password 密码
 * loginType 登录方式
 **/
+ (void)loginWithPhone:(NSString*)phone
              password:(NSString*)password
             loginType:(NSUInteger)loginType
              Response:(ESResponse)response {
    
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    dic[@"loginType"] = @(loginType);
    
    if (loginType == 2) {
        dic[@"captcha"] = password;
    } else {
        password = [self dealPassword:password andDic:[dic objectForKey:@"time"]];
        dic[@"password"] = [password urlEncodedString];
    }
    NSString *hostLink = ES_Url.login;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)weChatLoginWithCode:(NSString*)code
                      phone:(NSString*)phone
                    captcha:(NSString*)captcha
                   Response:(ESResponse)response {
    
	NSString *hostLink = ES_Url.wechatLogin;
	NSDictionary *finalDic = [self dictWithSigned:[self dictForApi] andUrl:hostLink];
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:0];
    dic[@"code"] = code;
	if (!QM_IS_STR_NIL(phone)) {
        dic[@"phone"] = phone;
	}
	if (!QM_IS_STR_NIL(captcha)) {
        dic[@"captcha"] = captcha;
	}
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];
	
	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostForJSONRequestWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)bindWeChatWithCode:(NSString*)code
                  Response:(ESResponse)response {
	NSMutableDictionary *dic_old = [self dictForApi];
	NSString *hostLink = ES_Url.bindWeChat;
	NSDictionary *finalDic = [self dictWithSigned:dic_old andUrl:hostLink];
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:0];
    dic[@"code"] = code;
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];
	
	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostForJSONRequestWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)unbindWeChat:(ESResponse)response {
	NSMutableDictionary *dic_old = [self dictForApi];
	NSString *hostLink = ES_Url.unbindWechat;
	NSDictionary *finalDic = [self dictWithSigned:dic_old andUrl:hostLink];
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:0];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];
	
	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostForJSONRequestWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 修改头像
 * 头像地址
 **/
+ (void)changeVwithUrl:(NSString *)url
              Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"avatar"] = url;
    NSString *hostLink = ES_Url.changeV;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)changeExpertVwithUrl:(NSString *)url
                   Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"avatar"] = url;
    NSString *hostLink = ES_Url.changeExpertAvatar;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 获取我的信息
 **/
+ (void)getSelfMessageResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.personalDetail;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 获取消息中心标题列表
 **/
+ (void)getMessageCenterListResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.messageCenterList;
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityMessageCountWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.communityMessageCount;
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)readCommunityMessageWithMessageType:(NSString *)messageType
                                   Response:(ESResponse)response{
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = [NSString stringWithFormat:@"%@/community/%@/message/read/",HostUrl,messageType];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getOffcialBannersWithType:(NSUInteger)type
                             page:(NSUInteger)page
                         pageSize:(NSUInteger)pageSize
                         Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSString *hostLink;
    if (type == 0) {
        hostLink = ES_Url.officialBannerList;
    }else if (type == 1) {
        hostLink = ES_Url.activityBannerList;
    }else {
        hostLink = ES_Url.injuryBannerList;
    }
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 校验验证码
 * phone 手机号
 * captchaType 类型
 **/
+ (void)checkCodeWithPhone:(NSString *)phone
              captchaType:(int)captchaType
                  captcha:(NSString *)captcha
                 Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    dic[@"captchaType"] = @(captchaType);
    dic[@"captcha"] = captcha;
    
    NSString *hostLink = ES_Url.checkCaptcha;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 获取验证码
 * phone 手机号
 * captchaType 类型
 **/
+ (void)getCodeWithPhone:(NSString *)phone
             captchaType:(int)captchaType
                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    dic[@"captchaType"] = @(captchaType);
    NSString *hostLink = ES_Url.getCaptcha;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 获取登录验证码
 * phone 手机号
 **/
+ (void)getLoginCodeWithPhone:(NSString *)phone
                     Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"phone"] = phone;
    
    NSString *hostLink = ES_Url.getLoginCaptcha;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 *  首页轮播图
 *
 *  @param response 返回结果
 */
/*测试接口**/
+ (void)getTest:(NSString*)test Response:(ESResponse)response{
//    NSMutableDictionary *dic = [self dictForApi];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] initWithDictionary:@{@"version":@(10000),@"userId":@(0),@"token":@"",@"time":@"1554977909739",@"test":@"caesar",@"from":@"ios"}];
//    [dic setValue:test forKey:@"test"];
    NSDictionary*finalDic = [self dictWithSigned:dic andUrl:ES_Url.ceshi];
    [ES_HttpService sendPostWithURL:ES_Url.ceshi parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 *注册接口
 * userName 用户名
 * password 密码
 * phoen 手机号
 * invitationCode 邀请码
 **/
+ (void)registWithUserName:(NSString *)userName
                  password:(NSString *)password
                     phone:(NSString *)phone
            invitationCode:(NSString *)invitationCode
                  Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    
    dic[@"userName"] = userName;
    dic[@"phone"] = phone;
    dic[@"invitationCode"] = [CommonUtils isEqualToNonNull:invitationCode replace:@""];
    password = [self dealPassword:password andDic:[dic objectForKey:@"time"]];
    dic[@"password"] = [password urlEncodedString];
    
    NSString *hostLink = ES_Url.regist;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 发方案基本配置
 *
 *  @param response 返回结果
 */
+ (void)sendPreNewResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
     NSString *hostLink = ES_Url.planPre;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 、赛事接口
 *
 *  @param response 返回结果
 */
+ (void)getPlanInitWithField:(NSInteger)field
                    Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"field"] = @(field);
    
    NSString *hostLink = ES_Url.planInit;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 创建方案接口
 * @param price 价格
 * @param content 内容
 * @param title 标题
 * @param type 方案类型
 * @param commentAreaType 方案评论权限
 * @param declarationPic 方案宣言图片
 * @param response 返回结果
 */
+ (void)createPlanWithMatchInfo:(NSArray*)matchInfo
                          price:(int)price
                        content:(NSString*)content
                          title:(NSString*)title
                           type:(NSString*)type
                            pic:(NSString*)pic
                          field:(NSInteger)field
                    declaration:(NSString*)declaration
                 declarationPic:(NSString *)declarationPic
                commentAreaType:(NSUInteger)commentAreaType
                       Response:(ESResponse)response {
    NSMutableDictionary *dic_old = [self dictForApi];
    NSString *hostLink = ES_Url.planCreat;
    NSDictionary *finalDic = [self dictWithSigned:dic_old andUrl:hostLink];
    
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:0];
    dic[@"matchInfo"] = matchInfo;
    dic[@"price"] = @(price);
    dic[@"content"] = content;
    dic[@"title"] = title;
    dic[@"type"] = type;
    dic[@"pic"] = pic;
    dic[@"field"] = @(field);
    dic[@"declaration"] = declaration;
    dic[@"declarationPic"] = declarationPic;
    dic[@"commentAreaType"] = @(commentAreaType);
    
    NSArray*vA = [finalDic allValues];
    NSArray*kA = [finalDic allKeys];
    
    NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
    for (int i = 0;i<kA.count;i++) {
        url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
    }
    url = [url substringToIndex:url.length-1];
    
    [ES_HttpService sendPostForJSONRequestWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 方案详情页面
 * @param planId 订单id
 * @param response 返回结果
 */
+ (void)planDetailWithPlanId:(NSInteger)planId
                   Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"planId"] = @(planId);
    
    NSString *hostLink = ES_Url.planView;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)planDetailCommentList:(NSInteger)planId
                         Page:(NSInteger)page
                     PageSize:(NSInteger)pageSize
                     Response:(ESResponse)response {
	
    
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"planId"] = @(planId);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
    NSString *hostLink = ES_Url.planCommentList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
		response(dict, error);
	}];
}

+ (void)planDetailComment:(NSUInteger)planId
                  content:(NSString *)content
                 Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	
    dic[@"planId"] = @(planId);
    dic[@"content"] = content;
    
    NSString *hostLink = ES_Url.planComment;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
    
    [ES_HttpService sendPostForJSONRequestWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
		response(dict, error);
	}];
}

/**
 * 购买方案
 * @param planId 订单id
 *  @param response 返回结果
 */
+ (void)payOrderWithPlanId:(NSInteger)planId
              userCouponId:(NSUInteger)userCouponId
                  Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"planId"] = @(planId);
    
    NSString *hostLink = ES_Url.orderPay;
    if (userCouponId != -1) {
        dic[@"userCouponId"] = @(userCouponId);
    }
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 我的购买记录
 * @param page 页码
 *  @param pageSize 页面大小
 */
+ (void)myPayListWithPage:(int)page
                 PageSize:(int)pageSize
                 Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.buyRecord;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 我的发布记录
 * @param page 页码
 *  @param pageSize 页面大小
 */
+ (void)mySaleListWithPage:(int)page
                  PageSize:(int)pageSize
                  Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.saleRecord;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 方案频道
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 足球篮球
 *  @param type 比赛类型
 */
+ (void)planListWithPage:(int)page
                PageSize:(int)pageSize
                   Field:(NSString *)field
                    Type:(NSString *)type
          SelectedLeague:(NSString *)selectedLeague
                SortType:(int)sortType
         MatchSelectType:(int)matchSelectType
                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"sortType"] = @(sortType);
	if (!QM_IS_STR_NIL(type)) {
        dic[@"type"] = type;
	}
	if (!QM_IS_STR_NIL(selectedLeague)) {
        dic[@"selectedLeague"] = selectedLeague;
	}
	if (matchSelectType != 0) {
        dic[@"matchSelectType"] = @(matchSelectType);
	}
    dic[@"field"] = field;
    
    NSString *hostLink = ES_Url.planList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 新方案频道
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 1足球/2篮球
 *  @param type 3免费/所有
 *  @param selectedLeague 联赛名
 *  @param matchSelectType 1：单关/2：2串1
 */
+ (void)planListWithoutHUDWithPage:(NSInteger)page
                         pageSize:(NSInteger)pageSize
                            field:(NSString *)field
                             type:(NSString *)type
                   selectedLeague:(NSString *)selectedLeague
                  matchSelectType:(NSInteger)matchSelectType
                         response:(ESResponse)response {
    
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.planListV2;
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"field"] = field;
    dic[@"type"] = type;
    dic[@"selectedLeague"] = selectedLeague;
    if (matchSelectType == 0) {
        dic[@"matchSelectType"] = @"";
    }else {
        dic[@"matchSelectType"] = @(matchSelectType);
    }
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}



/**
 * 专家详情页面
 * @param expertId 专家id
 *  @param response 返回结果
 */
+ (void)expertViewWithExpertId:(NSInteger)expertId
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.expertView;
    dic[@"expertId"] = @(expertId);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)expertViewWithoutHUDWithExpertId:(NSInteger)expertId
                                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.expertView;
    dic[@"expertId"] = @(expertId);
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+(void)expertLeagueCountWithExpertId:(NSInteger)expertId
                               field:(NSUInteger)field
                                page:(NSUInteger)page
                            pageSize:(NSUInteger)pageSize
                            Response:(ESResponse)response {
    [self expertLeagueCountWithHUD:YES withExpertId:expertId field:field page:page pageSize:pageSize Response:response];
}

+ (void)expertLeagueCountWithHUD:(BOOL)allowHUD
                    withExpertId:(NSInteger)expertId
                           field:(NSUInteger)field
                            page:(NSUInteger)page
                        pageSize:(NSUInteger)pageSize
                        Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.expertLeagueCount;
    dic[@"expertId"] = @(expertId);
    dic[@"field"] = @(field);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink showHUD:allowHUD needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)ocWithExpertId:(NSInteger)expertId
          andOpenClose:(int)openClose
              Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.ocPush;
    dic[@"expertId"] = @(expertId);
    dic[@"openClose"] = @(openClose);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)changeIntroduceWithIntroduction:(NSString *)introduction
                               Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.changeIntroduce;
    dic[@"introduction"] = introduction;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 历史足迹方案列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param field 足球篮球
 *  @param type 比赛类型
 */
+ (void)trackPlanListWithPage:(int)page
                     PageSize:(int)pageSize
                        Field:(NSString *)field
                         Type:(NSString *)type
                     Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.track;
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"field"] = field;
    dic[@"type"] = type;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)expertPlanListWithPage:(int)page
                      PageSize:(int)pageSize
                         Field:(NSString *)field
                          Type:(NSString *)type
                      ExpertId:(NSInteger)expertId
                     ForExpert:(int)forExpert
                      Response:(ESResponse)response {
    [self expertPlanListWithHUD:NO withPage:page PageSize:pageSize Field:field Type:type ExpertId:expertId ForExpert:forExpert Response:response];
}

+ (void)expertPlanListWithHUD:(BOOL)allowHUD
                     withPage:(int)page
                     PageSize:(int)pageSize
                        Field:(NSString*)field
                         Type:(NSString*)type
                     ExpertId:(NSInteger)expertId
                    ForExpert:(int)forExpert
                     Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"field"] = field;
    dic[@"type"] = type;
    dic[@"expertId"] = @(expertId);
    dic[@"forExpert"] = @(forExpert);

    NSString *hostLink = ES_Url.expertPlanList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink showHUD:allowHUD needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 飞驰榜
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param rank 类型
 *  @param field 比赛类型
 */
+ (void)feichiBoardWithPage:(NSInteger)page
                   PageSize:(NSInteger)pageSize
                       Rank:(NSString*)rank
                      Field:(NSInteger)field
                   Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"field"] = @(field);
    dic[@"rank"] = rank;
    
    NSString *hostLink = ES_Url.feiChiBoard;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 专家榜
 *  @param page 页码
 *  @param pageSize 页面大小
 *  @param rank 类型
 *  @param field 比赛类型
 */
+ (void)expertBoardWithPage:(NSInteger)page
                   PageSize:(NSInteger)pageSize
                       Rank:(NSString *)rank
                      Field:(NSInteger)field
                   Response:(ESResponse)response {
    
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"field"] = @(field);
    dic[@"rank"] = rank;
    
    NSString *hostLink = ES_Url.expertBoard;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    [ES_HttpService sendGetWithoutLoginWithURL:hostLink showHUD:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 用户购买列表
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param planId 方案id
 */
+ (void)saleDetailWithPage:(int)page
                  PageSize:(int)pageSize
                    PlanId:(long)planId
                  Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"planId"] = @(planId);
    
    NSString *hostLink = ES_Url.saleDetail;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 搜索
 * @param page 页码
 *  @param pageSize 页面大小
 *  @param searchKey 专家名称
 */
+ (void)searchExpertWithPage:(int)page
                    PageSize:(int)pageSize
                   SearchKey:(NSString*)searchKey
                    Response:(ESResponse)response {
    
    /*
     http://gallop.5000yuant.com/search/experts/?
     sign=9A70D46701F6C075A457A17F74EC3740&
     pageSize=30&
     from=android&
     time=1620875053985&
     searchKey=%E4%B8%80&
     page=1&
     userId=593513708794286080&
     deviceId=2ac79990017ff3b17b6c6d79ac1ec1637&
     version=10034&
     token=21fb7a49149689b26caa35dcb18d0453
     */
    
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"searchKey"] = searchKey;
    
    NSString *hostLink = ES_Url.searchExpert;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 我的订阅
 * @param page 页码
 *  @param pageSize 页面大小
 */
+ (void)myExpertWithPage:(int)page
                PageSize:(int)pageSize
                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.myExpert;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 充值明细
 * @param page 页码
 *  @param pageSize 页面大小
 */
+ (void)myAccountListWithPage:(int)page
                     PageSize:(int)pageSize
                     Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.myAccountList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBannersWithField:(NSUInteger)field
                   Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
//	[dic setObject:@(field) forKey:@"field"];
    NSString *hostLink = ES_Url.banner;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)updateBannersVisit:(NSUInteger)bannerId
                  InfoType:(NSUInteger)infoType
                  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"bannerId"] = @(bannerId);
    dic[@"infoType"] = @(infoType);
	
	NSString *hostLink = ES_Url.bannerVisit;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getDaShenWithField:(NSInteger)field
                  Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(1);
    dic[@"pageSize"] = @(8);
    dic[@"field"] = @(field);

    NSString *hostLink = ES_Url.dashen;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getHomeLeagueListWithField:(NSInteger)field
                          Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"field"] = @(field);
	
    NSString *hostLink = ES_Url.homeLeagueList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)followExpert:(NSInteger)expertId
            Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"expertId"] = @(expertId);
    
    NSString *hostLink = ES_Url.follow;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)unfollowExpert:(NSInteger)expertId
              Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"expertId"] = @(expertId);
    
    NSString *hostLink = ES_Url.unfollow;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)payWayWithResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.payWay;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)payInfoResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.payInfo;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)checkVersonResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.checkVersion;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoginWithURL:hostLink showHUD:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getGoalNotfiySetting:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.goalAcquireSetting;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)setGoalNotify:(BOOL)sound
                shake:(BOOL)shake
              showAll:(BOOL)showAll
             response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"sound"] = @(sound);
    dic[@"shake"] = @(shake);
    dic[@"showRange"] = @(showAll);
    
    NSString *hostLink = ES_Url.goalSetSetting;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShareUrl:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.shareUrl;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getAppInitInfo:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.appInitUrl;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)readMessageWithReadType:(NSUInteger)readType {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"readType"] = @(readType);
    
	NSString *hostLink = ES_Url.ensureUnRead;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:nil];
}

+ (void)customPostionCode:(NSString *)positionCode {

	NSMutableDictionary *dic = [self dictForApi];
    dic[@"positionCode"] = positionCode;
    
	NSString *hostLink = ES_Url.positionCode;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink showHUD:NO needLogin:NO parameters:finalDic headers:nil response:nil];
}

#pragma mark - 优惠券
+ (void)getMyCouponsList:(NSUInteger)type
                    page:(NSUInteger)page
                pageSize:(NSUInteger)pageSize
                response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = @(type);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.myCouponsList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)applyCoupons:(NSUInteger)scope
              amount:(NSUInteger)amount
                page:(NSUInteger)page
            pageSize:(NSUInteger)pageSize
            response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"scope"] = @(scope);
    dic[@"amount"] = @(amount);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.applyCoupons;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 比赛
+ (void)getMatchId:(NSInteger)matchId
          response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.getMatchId;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)newGetMatchDateNum:(NSInteger)matchDateNum
                  response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchDateNum"] = @(matchDateNum);
    
    NSString *hostLink = ES_Url.nowPlanMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getScreenList:(NSInteger)matchType
             pageType:(NSInteger)pageType
                 date:(NSString *)date
             response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchType"] = @(matchType);
    dic[@"pageType"] = @(pageType);
    dic[@"date"] = date;
    
    NSString *hostLink = ES_Url.screenList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)matchScreen:(NSInteger)matchType
           pageType:(NSInteger)pageType
             league:(NSString *)league
              isAll:(NSInteger)isAll
               date:(NSString *)date
           response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchType"] = @(matchType);
    dic[@"isAll"] = @(isAll);
    dic[@"league"] = league;
    dic[@"pageType"] = @(pageType);
    dic[@"date"] = date;
    
    NSString *hostLink = ES_Url.matchScreen;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getInstantListWithField:(NSInteger)field withPage:(NSInteger)page pageSize:(NSInteger)pageSize Response:(ESResponse)response {
    if (field == 1) {
        [self getInstantListWithPage:page pageSize:pageSize Response:response];
    }else {
        [self getBaskectballList:response];
    }
}

+ (void)getInstantListWithPage:(NSInteger)page
                      pageSize:(NSInteger)pageSize
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	if ([SystemManager footBallScreenCache][0].screenMatchType.integerValue == -1) {
        dic[@"clientSelect"] = @(0);
	} else {
        dic[@"clientSelect"] = @(1);
        dic[@"matchType"] = [SystemManager footBallScreenCache][0].screenMatchType;
        dic[@"league"] = [SystemManager footBallScreenCache][0].screenLeague;
        dic[@"isAll"] = [SystemManager footBallScreenCache][0].screenIsAll;
	}
	
    NSString *hostLink = ES_Url.instantList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 比赛方案列表
 *  @param page 页码
 *  @param pageSize 页面大小
 *  @param matchId 方案id
 */
+ (void)matchPlanWithPage:(int)page
                 PageSize:(int)pageSize
                  matchId:(long)matchId
                 Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchPlan;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)focusMatch:(BOOL)status
           matchId:(NSInteger)matchId
          response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"status"] = @(status);
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.fouceMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)focusBasketMatch:(NSUInteger)type
                 matchId:(NSInteger)matchId
                response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = @(type);
    dic[@"matchId"] = @(matchId);
	
	NSString *hostLink = ES_Url.fouceBasketMatch;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getFollowListResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.followList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getSchedulesList:(NSInteger)pageType
                    date:(NSString *)date
                sclassId:(NSInteger)sclassId
                response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"pageType"] = @(pageType);
    dic[@"sclassid"] = @(sclassId);
    if ([CommonUtils isEqualToNonNull:date]) {
        dic[@"date"] = date;
    }
    
	if ([SystemManager footBallScreenCache][pageType].screenMatchType.integerValue == -1) {
        dic[@"clientSelect"] = @(0);
	} else {
		[dic setObject:@(1) forKey:@"clientSelect"];
        dic[@"clientSelect"] = @(1);
        dic[@"matchType"] = [SystemManager footBallScreenCache][pageType].screenMatchType;
        dic[@"league"] = QM_STR_NOT_NIL([SystemManager footBallScreenCache][pageType].screenLeague);
        dic[@"isAll"] = QM_STR_NOT_NIL([SystemManager footBallScreenCache][pageType].screenIsAll);
	}
	
    NSString *hostLink = ES_Url.schedulesList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getLiveTopList:(NSInteger)matchId
              response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.liveTopList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getImportantEventList:(NSInteger)matchId
                     response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.importantEventList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchTable:(NSInteger)matchId
             response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchTable;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getInstantOddsList:(NSInteger)matchId
                  response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
	NSString *hostLink = ES_Url.instantOddsList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getLineUp:(NSInteger)matchId
         response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.lineUp;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getIntelligence:(NSInteger)matchId
               response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchIntelligence;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getIntelligencePage:(NSInteger)matchId
                   response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchIntelligencePage;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getIntelligenceEurasianInfo:(NSInteger)matchId
                           response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchIntelligenceEurasianInfo;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getOddsConversionInfo:(CGFloat)hostOdds
                     drawOdds:(CGFloat)drawOdds
                     awayOdds:(CGFloat)awayOdds
                     response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"hostOdds"] = @(hostOdds);
    dic[@"drawOdds"] = @(drawOdds);
    dic[@"awayOdds"] = @(awayOdds);
	
	NSString *hostLink = ES_Url.oddsConversion;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
		response(dict, error);
	}];
}

+ (void)getMatchExpnentialList:(NSInteger)matchId
                      response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchExponential;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchLiveExpnentialList:(NSInteger)matchId
                         companyId:(NSUInteger)companyId
                          oddsType:(NSUInteger)oddsType
                          response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    dic[@"companyId"] = @(companyId);
    dic[@"oddsType"] = @(oddsType);
	
	NSString *hostLink = ES_Url.matchLiveExponential;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchExpnentialChart:(NSUInteger)matchId
                      companyId:(NSUInteger)companyId
                       oddsType:(NSUInteger)oddsType
                       response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    dic[@"companyId"] = @(companyId);
    dic[@"oddsType"] = @(oddsType);
    
    NSString *hostLink = ES_Url.matchExponentialChart;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchExpnentialChange:(NSInteger)matchId
                       companyId:(NSUInteger)companyId
                        oddsType:(NSUInteger)oddsType
                        response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    dic[@"companyId"] = @(companyId);
    dic[@"oddsType"] = @(oddsType);
    
    NSString *hostLink = ES_Url.matchExponentialChange;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchData:(NSInteger)matchId dataType:(NSUInteger)dataType response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    dic[@"dataType"] = @(dataType);
    
    NSString *hostLink = ES_Url.matchData;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getChatForbiddenResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.chatForbidden;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMatchShareUrl:(NSUInteger)matchId
                response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
    
    NSString *hostLink = ES_Url.matchShareUrl;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 数据
+ (void)getWorldRankListWithType:(NSUInteger)type
                            date:(NSString *)date
                        response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = @(type);
    dic[@"date"] = [CommonUtils isEqualToNonNull:date replace:@""];
    
    NSString *hostLink = ES_Url.worldRankList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getTeamTitleWithTeamId:(NSUInteger)teamId
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.teamTitle;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getTeamMatchWithPage:(NSUInteger)page
                    PageSize:(NSUInteger)pageSize
                      TeamId:(NSUInteger)teamId
                    Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.teamMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getMoreTeamMatch:(NSUInteger)teamId
                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.teamMatchMore;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getTeamDetailWithTeamId:(NSUInteger)teamId
                       Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.teamDetail;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getTeamPointWithTeamId:(NSUInteger)teamId
                      leagueId:(NSUInteger)leagueId
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    dic[@"leagueId"] = @(leagueId);
    
    NSString *hostLink = ES_Url.teamPoint;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getleagueTitleWithleagueId:(NSUInteger)leagueId
                          Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    
    NSString *hostLink = ES_Url.leagueTitle;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketLeagueTitleWithleagueId:(NSUInteger)leagueId
                                Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"eventId"] = @(leagueId);
    
	NSString *hostLink = ES_Url.basketLeagueTitle;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getleagueTabWithleagueId:(NSUInteger)leagueId
                          Season:(NSString *)season
                        Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.leagueTab;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getLeaguePointWithLeagueId:(NSUInteger)leagueId
                            Season:(NSString *)season
                          Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"id"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.leaguePoint;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)loadSchedulesList:(NSUInteger)leagueId
                   Season:(NSString *)season
                 Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.additionList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)loadKnockoutList:(NSUInteger)leagueId
                  Season:(NSString *)season
                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.knockoutList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getLeagueScheduleWithLeagueId:(NSUInteger)leagueId
                               Season:(NSString *)season
                             Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.leagueSchedule;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getLeagueSubScheduleWithLeagueId:(NSUInteger)leagueId
                                subIndex:(NSString *)subIndex
                                  Season:(NSString *)season
                                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"subIndex"] = subIndex;
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.leagueSubSchedule;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getTeamMembersWithTeamId:(NSUInteger)teamId
                        Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.teamMembers;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)setMatchAlertSettingWithStart:(NSInteger)start
                               Before:(NSInteger)before
                             Finished:(NSInteger)finished
                                 Goal:(NSInteger)goal
                                  Red:(NSInteger)red
                               Yellow:(NSInteger)yellow
                               Corner:(NSInteger)corner
                             Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"start"] = @(start);
    dic[@"before"] = @(before);
    dic[@"finished"] = @(finished);
    dic[@"goal"] = @(goal);
    dic[@"red"] = @(red);
    dic[@"yellow"] = @(yellow);
    dic[@"corner"] = @(corner);
    
    NSString *hostLink = ES_Url.matchAlertSetting;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)setBasketAlertSettingWithStart:(NSInteger)start
                                Before:(NSInteger)before
                                  harf:(NSInteger)half
                              Finished:(NSInteger)finished
                              Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"start"] = @(start);
    dic[@"before"] = @(before);
    dic[@"finished"] = @(finished);
    dic[@"half"] = @(half);
    
    NSString *hostLink = ES_Url.basketAlertSetting;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 比赛推送
 */
+ (void)matchAlertSettingResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.matchAlert;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 篮球推送
*/
+ (void)basketAlertSettingResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.basketAlert;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 球员基本信息
 */
+ (void)playInfoWithPlayerId:(int)playerId
                     TeamId:(int)teamId
                   Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"playerId"] = @(playerId);
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.player;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 球员数据
 */
+ (void)playerTechYearWithPlayerId:(NSInteger)playerId
                         Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"playerId"] = @(playerId);
    
    NSString *hostLink = ES_Url.playerTechYear;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 球员年度数据
 */
+ (void)playerTechWithPlayerId:(NSInteger)playerId
                        Season:(NSString *)season
                      LeagueId:(NSInteger)leagueId
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"playerId"] = @(playerId);
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.playerTech;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 球员标题
 */
+ (void)playerTitleWithPlayerId:(int)playerId
                         TeamId:(int)teamId
                       Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"playerId"] = @(playerId);
    dic[@"teamId"] = @(teamId);
    
    NSString *hostLink = ES_Url.playerTitle;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 历史交锋
 */
+(void)historyPlaysWithMatchId:(NSString *)matchId
                   withDataType:(int)dataType
                        withNum:(int)num
                       Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    dic[@"dataType"] = @(dataType);
    dic[@"num"] = @(num);
    
    NSString *hostLink = ES_Url.confrontation;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 最近战绩
 */
+ (void)lastPlaysWithMatchId:(NSString *)matchId
                withDataType:(int)dataType
                     withNum:(int)num
                     Response:(ESResponse)response {
    
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    dic[@"dataType"] = @(dataType);
    dic[@"num"] = @(num);
    
    NSString *hostLink = ES_Url.record;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 伤停情况
 */
+ (void)injuryWithMatchId:(NSString*)matchId
                 Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.injuriesAndStoppages;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 联赛积分
 */
+ (void)integralWithMatchId:(NSString*)matchId
                   Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.integral;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
 * 数据对比
 */
+ (void)dataCompareWithMatchId:(NSString*)matchId
                      DataType:(int)dataType
                           Num:(int)num
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    dic[@"dataType"] = @(dataType);
    dic[@"num"] = @(num);
    
    NSString *hostLink = ES_Url.dataCompare;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 未来三场
 **/
+ (void)futureMatchWithMatchId:(NSString*)matchId
                      Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.futureMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 所有联赛
 **/
+ (void)allEventsResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.allEvents;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 热门赛事
 **/
+ (void)hotEventsResponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.hotEvents;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 赛前指数
 **/
+ (void)beforeMatchWithMatchId:(NSString*)matchId
                      Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.beforeMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 历史同盘
 **/
+ (void)sameDiskWithMatchId:(NSString*)matchId
                   Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.sameDisk;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 大小球
 **/
+ (void)bigOrSmallWithMatchId:(NSString*)matchId
                     Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.bigOrSmall;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 进球分布
**/
+ (void)scoreTimeWithMatchId:(NSString*)matchId
                    Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.scoreTime;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 单双
**/
+ (void)oddOrEvenWithMatchId:(NSString*)matchId
                    Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.oddOrEven;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 赛季数据
**/
+ (void)seasonDataWithMatchId:(NSString*)matchId
                     Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.seasonData;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)mvpWithLeagueId:(NSUInteger)leagueId
                 Season:(NSString *)season
               Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"leagueId"] = @(leagueId);
    dic[@"season"] = season;
    
    NSString *hostLink = ES_Url.mvp;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**
* 苹果预下单
**/
+ (void)applePrechargeWithMoney:(NSNumber *)money
                       Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"money"] = money;
    
    NSString *hostLink = ES_Url.apple_precharge;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 苹果校验
**/
+ (void)appleVerityWithReceipt:(NSString *)receipt
                          Type:(int)type
                  ReceiptToken:(NSString *)receiptToken
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"receipt"] = receipt;
    dic[@"type"] = @(type);
    dic[@"receiptToken"] = receiptToken;
    
    NSString *hostLink = ES_Url.apple_notify;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}


+ (void)searchDataWithType:(NSString *)type
                andKeyWord:(NSString *)keyword
                      page:(NSUInteger)page
                  pageSize:(NSUInteger)pageSize
                  response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = type;
    dic[@"keyword"] = keyword;
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.dataSearch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getlotteryDataWithMatchId:(NSString*)matchId
                         Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
	NSString *hostLink = ES_Url.lotteryData;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 发现
+ (void)getBannersDiscoverWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.bannerDiscover;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getHeadlinesDiscoverWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.headLinesDiscover;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)recomandMatchWithresponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.recommandMatch;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)homeRecomandMatchWithresponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.recommandMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)recentMatchResultWithresponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.recentMatch;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)newsListPage:(NSInteger)page
            PageSize:(NSInteger)pageSize
        Withresponse:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSString *hostLink = ES_Url.newsList;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)viewPaperWithTextId:(NSInteger)textId Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = @(textId);
    
	NSString *hostLink = ES_Url.viewPaper;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getNewsDetailWithTextId:(NSString *)textId
                       Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = textId;
    
	NSString *hostLink = ES_Url.newsDetail;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommentListWithTextId:(NSString *)textId
                        sortType:(NSUInteger)sortType
                            page:(NSUInteger)page
                        pageSize:(NSUInteger)pageSize
                        Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = textId;
    dic[@"sortType"] = @(sortType);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.commentList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)commentLikeStatusChangeWithCommentId:(NSUInteger)commentId
                                  likeStatus:(BOOL)likeStatus
                                    Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"commentId"] = @(commentId);
    dic[@"likeStatus"] = @(likeStatus);
    
	NSString *hostLink = ES_Url.commentLike;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)paperLikeStatusChangeWithTextId:(NSUInteger)textId
                             likeStatus:(BOOL)likeStatus
                               Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = @(textId);
    dic[@"likeStatus"] = @(likeStatus);
    
	NSString *hostLink = ES_Url.paperLike;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)paperCommentWithTextId:(NSUInteger)textId
                       content:(NSString *)content
                      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = @(textId);
    dic[@"content"] = content;
    
	NSString *hostLink = ES_Url.paperComment;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)paperCommentWithHostCommentId:(NSUInteger)hostCommentId
                       otherCommentId:(NSUInteger)otherCommentId
                              content:(NSString *)content
                             Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"hostCommentId"] = @(hostCommentId);
    dic[@"content"] = content;
    dic[@"otherCommentId"] = @(otherCommentId);
    
	NSString *hostLink = ES_Url.paperCommentReply;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)paperCommentReplyListWithHostCommentId:(NSUInteger)hostCommentId
                                      sortType:(NSUInteger)sortType
                                          page:(NSUInteger)page
                                      pageSize:(NSUInteger)pageSize
                                      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"hostCommentId"] = @(hostCommentId);
    dic[@"sortType"] = @(sortType);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.commentReplyList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityRepyMessageListWithPage:(NSUInteger)page
                                pageSize:(NSUInteger)pageSize
                                Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.communityRepyMessageList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityCommentMessageListWithPage:(NSUInteger)page
                                   pageSize:(NSUInteger)pageSize
                                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.communityCommentMessageList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityOffcialMessageListWithPage:(NSUInteger)page
                                   pageSize:(NSUInteger)pageSize
                                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.communityOffcialMessageList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityReplyMessageWithCommentId:(NSUInteger)commentId
                                  messageType:(NSUInteger)messageType
                                     Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"commentId"] = @(commentId);
    dic[@"messageType"] = @(messageType);
    
	NSString *hostLink = ES_Url.getCommunityReplyMessage;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getPaperFowardInfoWithTextId:(NSUInteger)textId
                            Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"textId"] = @(textId);
    
	NSString *hostLink = ES_Url.getPaperForwardInfo;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 篮球
+ (void)getBaskectballList:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = [SystemManager basketScreenCache][0].screenMatchType;
	if ([SystemManager basketScreenCache][0].screenIsAll.integerValue == 1) {
		
	} else {
        dic[@"eventIds"] = [SystemManager basketScreenCache][0].screenLeague;
	}
	NSString *hostLink = ES_Url.basketballList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getEndBaskectballList:(NSString *)date
                     response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"date"] = date;
    dic[@"type"] = [SystemManager basketScreenCache][2].screenMatchType;
	if ([SystemManager basketScreenCache][2].screenIsAll.integerValue == 1) {
		
	} else {
        dic[@"eventIds"] = [SystemManager basketScreenCache][2].screenLeague;
	}
	NSString *hostLink = ES_Url.endBasketballList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getUnstartBaskectballList:(NSString *)date
                         response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"date"] = date;
    dic[@"type"] = [SystemManager basketScreenCache][1].screenMatchType;
	if ([SystemManager basketScreenCache][1].screenIsAll.integerValue != 1) {
        dic[@"eventIds"] = [SystemManager basketScreenCache][1].screenLeague;
	}
    
	NSString *hostLink = ES_Url.unstartBasketballList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketFollowList:(ESResponse)response {
    NSString *hostLink = ES_Url.basketFollowList;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
		response(dict, error);
	}];
}

+ (void)getBasketFollowCount:(ESResponse)response {
    NSString *hostLink = ES_Url.basketFollowCount;
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithoutLoginWithURL:hostLink showHUD:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}


+ (void)getBasketScreenList:(NSInteger)pageType
                       date:(NSString *)date
                   response:(ESResponse)response {
    NSString *hostLink = ES_Url.basketScreenList;
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"type"] = @(pageType);
    dic[@"date"] = date;
    
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketLiveTopList:(NSInteger)matchId response:(ESResponse)response {
	NSMutableString *hostLink = [NSMutableString stringWithString:ES_Url.basketLiveTopList];
	[hostLink appendFormat:@"%@", @(matchId)];
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketLive:(NSInteger)matchId
             response:(ESResponse)response {
    NSString *hostLink = ES_Url.basketLive;
//    [hostLink appendFormat:@"%@", @(matchId)];
    hostLink = [hostLink stringByAppendingFormat:@"%@",@(matchId)];
    NSMutableDictionary *dic = [self dictForApi];
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketStatistics:(NSInteger)matchId
                   response:(ESResponse)response {
    NSString *hostLink = ES_Url.basketStatistics;
//	[hostLink appendFormat:@"%@", @(matchId)];
    hostLink = [hostLink stringByAppendingFormat:@"%@",@(matchId)];
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketData:(NSInteger)matchId
             response:(ESResponse)response {
	NSString *hostLink = ES_Url.basketRecord;
//	[hostLink appendFormat:@"%@", @(matchId)];
    hostLink = [hostLink stringByAppendingFormat:@"%@",@(matchId)];
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketExpnentialList:(NSInteger)matchId
                       response:(ESResponse)response {
    NSString *hostLink = ES_Url.basketExpnential;
//	[hostLink appendFormat:@"%@", @(matchId)];
    hostLink = [hostLink stringByAppendingFormat:@"%@",@(matchId)];
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBasketExpnentialChange:(NSInteger)matchId
                        companyId:(NSUInteger)companyId
                             type:(NSUInteger)type
                         response:(ESResponse)response {
    NSString *hostLink = ES_Url.basketExpnentialChange;
//	[hostLink appendFormat:@"%@", @(matchId)];
    hostLink = [hostLink stringByAppendingFormat:@"%@",@(matchId)];
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"companyId"] = @(companyId);
    dic[@"type"] = @(type);
    
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)supplyInfoWithUserName:(NSString *)userName
                      passWord:(NSString *)passWord
                      response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"userName"] = userName;
    passWord = [self dealPassword:passWord andDic:[dic objectForKey:@"time"]];
    dic[@"password"] = passWord;
    
    NSString *hostLink = ES_Url.supplyInfo;
    NSMutableDictionary*finalDic = [NSMutableDictionary dictionaryWithDictionary:[self dictWithSigned:dic andUrl:hostLink]] ;
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 自定义情报
**/
+ (void)customizeIntelligenceWithMatchId:(NSString*)matchId
                                Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = matchId;
    
    NSString *hostLink = ES_Url.customizeIntelligence;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
* 校验方案
**/
+ (void)checkPlanWithMatchDateNums:(NSString*)matchDateNums
                          Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchDateNums"] = matchDateNums;
    
    NSString *hostLink = ES_Url.checkPlan;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getBaskectballIntelligence:(NSUInteger)matchId
                          response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"matchId"] = @(matchId);
	
	NSString *hostLink = ES_Url.basketIntelligence;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}


+ (void)getBaskectballLeaguePoint:(NSUInteger)eventId
                         response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"eventId"] = @(eventId);
	
	NSString *hostLink = ES_Url.basketLeaguePoint;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 商城
+ (void)getShopProductCategoryList:(ESResponse)response {
    NSString *hostLink = ES_Url.shopProductCategoryList;
	NSMutableDictionary *dic = [self dictForApi];
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShopProductListWithCategoryId:(NSString *)categoryId
                                    Page:(NSInteger)page
                                PageSize:(NSInteger)pageSize
                                Response:(ESResponse)response {
	//url中包含参数服务端定义问题
	NSString *hostLink = [NSString stringWithFormat:@"%@/categories/%@/products",HostUrl,categoryId];
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShopProductListWithCategoryId:(NSString *)categoryId
                                   tagId:(NSString *)tagId
                                    Page:(NSInteger)page
                                PageSize:(NSInteger)pageSize
                                Response:(ESResponse)response {
	//url中包含参数服务端定义问题
    NSString *hostLink = [NSString stringWithFormat:@"%@/categories/%@/tags/%@/products",HostUrl,categoryId,tagId];
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShopTagLIstWithCategoryId:(NSString *)categoryId
                            Response:(ESResponse)response {
	//url中包含参数服务端定义问题
    NSString *hostLink = [NSString stringWithFormat:@"%@/categories/%@/tags",HostUrl,categoryId];
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 购物车相关
+ (void)getShopCartDetailWithResponse:(ESResponse)response {
	//url中包含参数服务端定义问题
    NSString *hostLink = ES_Url.shopCartDetail;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShopCartCountWithResponse:(ESResponse)response {
	//url中包含参数服务端定义问题
    NSString *hostLink = ES_Url.shopCartCount;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)addGoodsToShopCart:(NSUInteger)productId
    productSpecificationId:(NSUInteger)productSpecificationId
                       num:(NSUInteger)num
                   reponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productId"] = @(productId);
    dic[@"productSpecificationId"] = @(productSpecificationId);
    dic[@"num"] = @(num);
    
    NSString *hostLink = ES_Url.addGoodsToShopCart;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPutWithURL:url showHUD:YES needLogin:YES parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
	}];
}

+ (void)modifyGoodsNumInShopCart:(NSUInteger)productId
          productSpecificationId:(NSUInteger)productSpecificationId
                             num:(NSUInteger)num
                         reponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productSpecificationId"] = @(productSpecificationId);
    dic[@"num"] = @(num);
    dic[@"productId"] = @(productId);
    
    NSString *hostLink = ES_Url.modifyGoodsNum;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPutWithURL:url showHUD:YES needLogin:YES parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)deleteGoodsFromShopCart:(NSString *)productSpecificationIdList
                        reponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productSpecificationIdList"] = productSpecificationIdList;
    
    NSString *hostLink = ES_Url.deleteGoods;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString *url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
    
    [ES_HttpService sendPutWithURL:url showHUD:YES needLogin:YES parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)selectGoodsInShopCart:(NSString *)productSpecificationIdList
                     isChosen:(NSUInteger)isChosen
                      reponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productSpecificationIdList"] = productSpecificationIdList;
    dic[@"isChosen"] = @(isChosen);
    
    NSString *hostLink = ES_Url.selectGoods;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPutWithURL:url showHUD:YES needLogin:YES parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)shopCartPreOrderCreateWithResponse:(ESResponse)response {
	//url中包含参数服务端定义问题
    NSString *hostLink = ES_Url.shopCartPreOrderCreate;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 地址
+ (void)getAddreesListWithPage:(NSInteger)page
                      PageSize:(NSInteger)pageSize
                      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
	NSString *hostLink = ES_Url.addressMangerList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)addAddreesWithModel:(NSDictionary *)mallAddress
                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	for (NSString *key in mallAddress.allKeys) {
        if ([CommonUtils isEqualToNonNull:key]) {
            dic[key] = [mallAddress objectForKey:key];
//            [dic setObject:[mallAddress objectForKey:key] forKey:key];
        }
		
	}
	NSString *hostLink = ES_Url.addAddress;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)modifyAddreesWithModel:(NSDictionary *)mallAddress
                      Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	for (NSString *key in mallAddress.allKeys) {
        if ([CommonUtils isEqualToNonNull:key]) {
            dic[key] = [mallAddress objectForKey:key];
        }
	}
	NSString *hostLink = ES_Url.modifyAddress;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)deleteAddreesWithAddressId:(NSString *)addressId
                          Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"id"] = addressId;
	
	NSString *hostLink = ES_Url.deleteAddress;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

#pragma mark - 商城订单
+ (void)getShopOrderListWithState:(NSInteger)state
                             Page:(NSInteger)page
                         PageSize:(NSInteger)pageSize
                         Response:(ESResponse)response {
    NSString *hostLink = ES_Url.shopOrderList;
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"state"] = @(state);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getShopOrderDetailWithOrderId:(NSInteger)orderId
                             Response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@%@/", ES_Url.shopOrderDetail, @(orderId)];
	
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)cancelShopOrderWithOrderId:(NSInteger)orderId
                          Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"id"] = @(orderId);
	
	NSString *hostLink = ES_Url.cancelShopOrder;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)deleteShopOrderWithOrderId:(NSInteger)orderId Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"id"] = @(orderId);
	
	NSString *hostLink = ES_Url.deleteShopOrder;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)comfirmShopOrderWithOrderId:(NSInteger)orderId
                           Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"id"] = @(orderId);
	
	NSString *hostLink = ES_Url.comfirmShopOrder;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getProductShareUrl:(NSUInteger)productId
                  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productId"] = @(productId);
	
	NSString *hostLink = ES_Url.productShareUrl;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)productShareWechat:(NSUInteger)productId
                  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"productId"] = @(productId);
	
	NSString *hostLink = ES_Url.productWechatShare;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getOrderExpress:(NSString *)orderId
               response:(ESResponse)response {
    NSString *hostLink = ES_Url.shopOrderExpress;
	
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"orderId"] = orderId;
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
#pragma mark - 社区
+ (void)getUCloudImageInfo:(NSString *)imageUrl
                  Response:(ESResponse)response {
	NSString *hostLink = [imageUrl stringByAppendingString:@"?iopcmd=imageinfo"];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostCreate:(NSInteger)topicId
                      title:(NSString *)title
                    headImg:(NSString *)headImg
                  videoPath:(NSString *)videoPath
                   pictures:(NSString *)pictures
            videoFirstFrame:(NSString *)videoFirstFrame
                    content:(NSString *)content
                  wordCount:(NSUInteger)wordCount
                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"topicId"] = @(topicId);
    dic[@"title"] = [CommonUtils isEqualToNonNull:title replace:@""];
    dic[@"headImg"] = [CommonUtils isEqualToNonNull:headImg replace:@""];
    dic[@"videoPath"] = [CommonUtils isEqualToNonNull:videoPath replace:@""];
    dic[@"pictures"] = [CommonUtils isEqualToNonNull:pictures replace:@""];
    dic[@"videoFirstFrame"] = [CommonUtils isEqualToNonNull:videoFirstFrame replace:@""];
    dic[@"content"] = [CommonUtils isEqualToNonNull:content replace:@""];
    dic[@"wordCount"] = @(wordCount);

	NSString *hostLink = ES_Url.communityPostCreate;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)viewCommunityPostWithPostId:(NSInteger)postId
                           Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = @(postId);
	
	NSString *hostLink = ES_Url.viewCommunityPost;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityBanberWithResponse:(ESResponse)response {
    NSString *hostLink = ES_Url.coumunityBanner;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunitySquadListPage:(NSInteger)page
                         PageSize:(NSInteger)pageSize
                         Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSString *hostLink = ES_Url.communitySquadList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityTopicWithResponse:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.communityTopicList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityPostTopicWithResponse:(ESResponse)response {
    NSString *hostLink = ES_Url.communityPostTopicList;
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityTopicDetailListWithTopicId:(NSUInteger)topicId
									  page:(NSUInteger)page
									  type:(NSUInteger)type
								  pageSize:(NSUInteger)pageSize
								  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"topicId"] = @(topicId);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    dic[@"type"] = @(type);
	
	NSString *hostLink = ES_Url.communityTopicDetailList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityTopicDetailInfoWithTopicId:(NSUInteger)topicId
									  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"topicId"] = @(topicId);
	
	NSString *hostLink = ES_Url.communityTopicDetailInfo;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)followCommunityTopicWithTopicId:(NSUInteger)topicId
                           followStatus:(NSUInteger)followStatus
                               Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"topicId"] = @(topicId);
    dic[@"followStatus"] = @(followStatus);
	
	NSString *hostLink = ES_Url.communityTopicFllow;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)followCommunityUserWithUserId:(NSUInteger)focusUserId
                         followStatus:(NSUInteger)followStatus
                             Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink;
	if (followStatus == 1) {
		hostLink = [NSString stringWithFormat:@"%@/community/user/follow/%@/",HostUrl,@(focusUserId)];
	} else {
		hostLink = [NSString stringWithFormat:@"%@/community/user/unfollow/%@/",HostUrl,@(focusUserId)];
	}
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];

	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostWithURL:url parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityHomePageInfoWithHomeUserId:(NSString *)userId
                                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	if (userId == 0) {
        dic[@"homeUserId"] = App_Utility.currentUser.userId;
	} else {
        dic[@"homeUserId"] = userId;
	}
	NSString *hostLink = ES_Url.communityHomePageInfo;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityHomePageListWithHomeUserId:(NSString *)homeUserId
										  page:(NSUInteger)page
										  type:(NSUInteger)type
									  pageSize:(NSUInteger)pageSize
									  Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	if (homeUserId == 0) {
        dic[@"homeUserId"] = App_Utility.currentUser.userId;
	} else {
        dic[@"homeUserId"] = homeUserId;
	}
    dic[@"page"] = @(page);
    dic[@"type"] = @(type);
    dic[@"pageSize"] = @(pageSize);
	
	NSString *hostLink = ES_Url.communityHomePageList;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityFocusList:(NSUInteger)homeUserId
                         page:(NSUInteger)page
                     pageSize:(NSUInteger)pageSize
                     response:(ESResponse)response {
    
    NSString *hostLink = ES_Url.communityFocusList;
	NSMutableDictionary *dic = [self dictForApi];
	
    dic[@"homeUserId"] = @(homeUserId);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityFansList:(NSUInteger)homeUserId
                        page:(NSUInteger)page
                    pageSize:(NSUInteger)pageSize
                    response:(ESResponse)response {
    NSString *hostLink = ES_Url.communityFansList;
	NSMutableDictionary *dic = [self dictForApi];
	
    dic[@"homeUserId"] = @(homeUserId);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
	
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}


+ (void)deleteCommunityPostWithPostId:(NSUInteger)postId
                             Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = @(postId);
    
	NSString *hostLink = ES_Url.deleteCommunityPost;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)blockCommunityPostWithPostId:(NSUInteger)postId
                                type:(NSUInteger)type
                              reason:(NSString *)reason
                            Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.blockComunityPost;
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    dic[@"postId"] = @(postId);
    dic[@"type"] = @(type);
    dic[@"reason"] = reason;
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];
	
	NSString*url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityPostDetailWithPostId:(NSString *)postId
                                Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = postId;
    
	NSString *hostLink = ES_Url.communityPostDetail;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostLikeWithPostId:(NSUInteger)postId
                         likeStatus:(NSUInteger)likeStatus
                           Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = @(postId);
    dic[@"likeStatus"] = @(likeStatus);
	
	NSString *hostLink = ES_Url.communityPostLike;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostCollectionWithPostId:(NSUInteger)postId
                                 Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSMutableString *hostLink = [NSMutableString stringWithFormat:@"%@/community/posts/%@/favourite/",HostUrl,@(postId)];

	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	[hostLink appendFormat:@"?"];
	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
		if (idx == 0) {
			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
		} else {
			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
		}
	}];
	
    [ES_HttpService sendPostWithURL:hostLink.copy parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostUncollectionWithPostId:(NSUInteger)postId
                                   Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSMutableString *hostLink = [NSMutableString stringWithFormat:@"%@/community/posts/%@/favourite/",HostUrl,@(postId)];
	
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
	[hostLink appendFormat:@"?"];
	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
		if (idx == 0) {
			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
		} else {
			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
		}
	}];
	
    [ES_HttpService sendDeleteWithURL:hostLink showHUD:YES needLogin:YES parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
		response(dict, error);
	}];
}

+ (void)hitsBannerWithBannerId:(NSString*)bannerId
                      Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSMutableString *hostLink = [NSMutableString stringWithFormat:@"%@/community/banners/%@/hits/",HostUrl,bannerId];
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [hostLink appendFormat:@"?"];
    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
		if (idx == 0) {
			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
		} else {
			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
		}
	}];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityPostForwardWithPostId:(NSUInteger)postId
                                 Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = @(postId);
	
	NSString *hostLink = ES_Url.communityPostForward;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getCommunityPostCommentListWithPostId:(NSString *)postId
                                     sortType:(NSUInteger)sortType
                                         page:(NSUInteger)page
                                     pageSize:(NSUInteger)pageSize
                                     Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.communityPostCommentList;
    dic[@"postId"] = postId;
    dic[@"sortType"] = @(sortType);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostCommentLikeWithCommentId:(NSUInteger)commentId
                                   likeStatus:(BOOL)likeStatus
                                     Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"commentId"] = @(commentId);
    dic[@"likeStatus"] = @(likeStatus);
    
	NSString *hostLink = ES_Url.communityPostCommentLike;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostCommentWithPostId:(NSUInteger)postId
                               content:(NSString *)content
                              Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"postId"] = @(postId);
    dic[@"content"] = content;
    
	NSString *hostLink = ES_Url.communityPostComment;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostCommentReplyListWithHostCommentId:(NSUInteger)hostCommentId
                                              sortType:(NSUInteger)sortType
                                                  page:(NSUInteger)page
                                              pageSize:(NSUInteger)pageSize
                                              Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
	NSString *hostLink = ES_Url.communityPostCommentReplyList;
    dic[@"hostCommentId"] = @(hostCommentId);
    dic[@"sortType"] = @(sortType);
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)communityPostReplyCommentWithHostCommentId:(NSUInteger)hostCommentId
                                    otherCommentId:(NSUInteger)otherCommentId
                                           content:(NSString *)content
                                          Response:(ESResponse)response {
	NSMutableDictionary *dic = [self dictForApi];
    dic[@"hostCommentId"] = @(hostCommentId);
    dic[@"otherCommentId"] = @(otherCommentId);
    dic[@"content"] = content;
    
	NSString *hostLink = ES_Url.communityPostReplyComment;
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
/**
 * 商品详情
 */
+ (void)productDetailWithProductId:(NSString*)productId
                          Response:(ESResponse)response{
    NSString *hostLink = [NSString stringWithFormat:@"%@/products/%@",HostUrl,productId];
    NSMutableDictionary *dic = [self dictForApi];
    
    if ([App_Utility.currentUser.userId longLongValue] > 0) {
        dic[@"userId"] = App_Utility.currentUser.userId;
    }else{
        dic[@"userId"] = @(0);
    }
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)productOrderInitWith:(NSInteger)productSpecificationId
                         num:(NSInteger)num
                    Response:(ESResponse)response {
	NSString *hostLink = ES_Url.productOrderInit;
	
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"productSpecificationId"] = @(productSpecificationId);
    dic[@"num"] = @(num);
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getProductSpecListWithProductId:(NSUInteger)productId
                               response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/products/%@/specifications",HostUrl,@(productId)];
	NSMutableDictionary *dic = [self dictForApi];
	
	NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//	[hostLink appendFormat:@"?"];
//	[finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)productOrderCreatWithOrderId:(NSString *)orderId
                           productId:(NSString *)productId
              productSpecificationId:(NSString *)productSpecificationId
                                 num:(NSString *)num
                           addressId:(NSString *)addressId
                               price:(NSString *)price
                            Response:(ESResponse)response {
    NSMutableDictionary *dic = [self dictForApi];
    NSString *hostLink = ES_Url.productOrderCreate;
    dic[@"orderId"] = orderId;
    dic[@"productId"] = productId;
    dic[@"productSpecificationId"] = productSpecificationId;
    dic[@"num"] = num;
    dic[@"addressId"] = addressId;
    dic[@"price"] = price;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [ES_HttpService sendPostWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)productOrderCreatWithOrderId:(NSString*)orderId
                           addressId:(NSString*)addressId
                            Response:(ESResponse)response {
	NSMutableDictionary *dic_old = [self dictForApi];
    NSString *hostLink = ES_Url.shopCartOrderCreate;
	NSDictionary *finalDic = [self dictWithSigned:dic_old andUrl:hostLink];
	
	NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:0];
	[dic setObject:orderId forKey:@"orderId"];
	[dic setObject:addressId forKey:@"addressId"];
	
	NSArray*vA = [finalDic allValues];
	NSArray*kA = [finalDic allKeys];
	
	NSString *url = [NSString stringWithFormat:@"%@?",hostLink];
	for (int i = 0;i<kA.count;i++) {
		url = [NSString stringWithFormat:@"%@%@=%@&",url,kA[i],[vA[i] isKindOfClass:[NSString class]]?[(NSString*)vA[i] urlEncodedString]:[vA[i] stringValue]];
	}
	url = [url substringToIndex:url.length-1];
	
    [ES_HttpService sendPostWithURL:url parameters:dic.copy headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)getpostfeedWithResponse:(ESResponse)response {
    NSString *hostLink = ES_Url.postFeed;
    NSMutableDictionary *dic = [self dictForApi];
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//		if (idx == 0) {
//			[hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//		} else {
//			[hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//		}
//	}];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

+ (void)hitsStartImageWithImageId:(NSString*)imageId
                         Response:(ESResponse)response{
    NSMutableDictionary *dic = [self dictForApi];
    
    NSMutableString *hostLink = [NSMutableString stringWithFormat:@"%@/start/images/%@/hits/",HostUrl,[CommonUtils isEqualToNonNull:imageId replace:@""]];
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
    [hostLink appendFormat:@"?"];
    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
        if (idx == 0) {
            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
        } else {
            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
        }
    }];
    
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:YES parameters:nil headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
//帖子搜索
+ (void)getSearchPostListWithKeyword:(NSString *)keyword
                                Page:(NSInteger)page
                            PageSize:(NSInteger)pageSize
                            Response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/community/search/post/",HostUrl];
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"keyword"] = [keyword urlEncodedString];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}
//用户搜索
+ (void)getSearchUserListWithKeyword:(NSString *)keyword
                                Page:(NSInteger)page
                            PageSize:(NSInteger)pageSize
                            Response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/community/search/user/",HostUrl];
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"keyword"] = [keyword urlEncodedString];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**分享专家*/
+ (void)expertIdShareWithExpertId:(NSString*)expertId
                            Field:(NSString*)fieId
                         Response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/plan/expert/share/",HostUrl];
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"expertId"] = expertId;
    dic[@"field"] = fieId;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
    
}
/**分享方案*/
+ (void)planShareWithPlanId:(NSString*)planId
                   Response:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/plan/view/share/",HostUrl];
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"planId"] = planId;
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [hostLink appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [hostLink appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [hostLink appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    
    [ES_HttpService sendGetWithURL:hostLink parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

/**关注的专家列表*/
+ (void)expertSubscribedListWithPage:(NSUInteger)page
                            pageSize:(NSUInteger)pageSize
                            response:(ESCodeResponse)response {
    NSMutableString *hostLink = [NSMutableString stringWithFormat:@"%@/follow/experts/", HostUrl];
    NSMutableDictionary *dic = [self dictForApi];
    dic[@"page"] = @(page);
    dic[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:dic andUrl:hostLink];
//    [link appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [link appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [link appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, code, error);
    }];
}

/**推荐的专家列表*/
+ (void)expertRecommendListWithResponse:(ESCodeResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/recommend/experts/", HostUrl];
    NSDictionary *finalDic = [self dictWithSigned:[self dictForApi] andUrl:hostLink];
//    [link appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [link appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [link appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, code, error);
    }];
}

/**关注的专家方案列表*/
+ (void)plansSubscribedListWithPage:(NSUInteger)page
                           pageSize:(NSUInteger)pageSize
                           response:(ESCodeResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/plan/follow_expert/list/v2/", HostUrl];
    NSMutableDictionary *params = [self dictForApi];
    params[@"page"] = @(page);
    params[@"pageSize"] = @(pageSize);
    
    NSDictionary *finalDic = [self dictWithSigned:params andUrl:hostLink];
    [ES_HttpService sendPostWithoutLoadingWithURL:hostLink needLogin:NO parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, code, error);
    }];
//    [ES_HttpService sendPostWithoutLoginWithURL:link params:params response:^(id dict, NSInteger code, ESError *error) {
//        response(dict, code, error);
//    }];
}

/**发布方案-赛事初始化数据 */
+ (void)getPlanInitWithResponse:(ESResponse)response {
    NSString *hostLink = [NSString stringWithFormat:@"%@/plan/lottery/matches/", HostUrl];
    NSDictionary *finalDic = [self dictWithSigned:[self dictForApi] andUrl:hostLink];
//    [link appendFormat:@"?"];
//    [finalDic.allKeys enumerateObjectsUsingBlock:^(NSString *str, NSUInteger idx, BOOL * _Nonnull stop) {
//        if (idx == 0) {
//            [link appendFormat:@"%@=%@",str,[finalDic objectForKey:str]];
//        } else {
//            [link appendFormat:@"&%@=%@",str,[finalDic objectForKey:str]];
//        }
//    }];
    
    [ES_HttpService sendGetWithoutLoadingWithURL:hostLink needLogin:YES parameters:finalDic headers:nil response:^(id dict, NSInteger code, ESError *error) {
        response(dict, error);
    }];
}

@end

