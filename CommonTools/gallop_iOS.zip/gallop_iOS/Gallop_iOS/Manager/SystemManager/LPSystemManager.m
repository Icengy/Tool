//
//  LPSystemManager.m
//  ArchInstance
//
//  Created by 刘 鹏 on 15/9/7.
//  Copyright (c) 2015年 LP. All rights reserved.
//

#import "LPSystemManager.h"
@implementation ScreenCacheModel

@end

@implementation LPSystemManager

+ (id)sharedInstance{
    static LPSystemManager *sharedInstance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        sharedInstance.bgGoalCache = [NSMutableArray array];
    });
    return sharedInstance;
}

//离线文件路径
- (NSString *)offlineFilePath
{
    if (!_offlineFilePath) {
        _offlineFilePath = [AppDocumentPath stringByAppendingPathComponent:@"ESTicket"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:_offlineFilePath]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:_offlineFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        [self addSkipBackupAttributeToItemAtURL:[NSURL fileURLWithPath:_offlineFilePath isDirectory:YES]];
    }
    
    return _offlineFilePath;
}
//jcmatch
-(NSString *)jcmatchFilePath
{
    if (!_jcmatchFilePath) {
        _jcmatchFilePath = [AppDocumentPath stringByAppendingPathComponent:@"JcMatch"];
        if (![[NSFileManager defaultManager] fileExistsAtPath:_jcmatchFilePath]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:_jcmatchFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        [self addSkipBackupAttributeToItemAtURL:[NSURL fileURLWithPath:_jcmatchFilePath isDirectory:YES]];
    }
    return _jcmatchFilePath;
}

//用户信息存储地址
- (NSString *)userInfoFilePath{
    if (!_userInfoFilePath) {
        _userInfoFilePath = [AppDocumentPath stringByAppendingPathComponent:@"UserInfo"];
        
        if (![[NSFileManager defaultManager] fileExistsAtPath:_userInfoFilePath]) {
            [[NSFileManager defaultManager] createDirectoryAtPath:_userInfoFilePath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
    
    return _userInfoFilePath;
}

//documents目录下文件最大3m同步到云服务  此方法可以对相应文件做标记不同步到云服务
- (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    NSError *error = nil;
    BOOL success = [URL setResourceValue: [NSNumber numberWithBool: YES]
                                  forKey: NSURLIsExcludedFromBackupKey error: &error];
    if(!success){
        NSLog(@"Error excluding %@ from backup %@", [URL lastPathComponent], error);
    }
    return success;
}

- (NSMutableArray *)socketGoalCache {
    return [[NSUserDefaults standardUserDefaults] objectForKey:kSocketGoalCache];
}

- (void)setSocketGoalCache:(NSMutableArray *)socketGoalCache {
    [[NSUserDefaults standardUserDefaults] setObject:socketGoalCache forKey:kSocketGoalCache];
}

//足球筛选相关,本地存储
- (NSMutableArray<ScreenCacheModel *> *)footBallScreenCache {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kFootBallScreenCache]) {
		NSMutableArray *arr = [NSMutableArray array];
		for (NSUInteger i = 0; i < 3 ; i ++) {
			ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
			model.screenMatchType = @"-1";
			model.screenLeague = @"-1";
			model.screenIsAll = @"1";
			[arr addObject:model];
		}
		return arr;
	}
	NSMutableArray *arr = [NSMutableArray array];
	for (NSDictionary *dict in [[NSUserDefaults standardUserDefaults] objectForKey:kFootBallScreenCache]) {
		ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
		model.screenMatchType = [dict objectForKey:@"type"];
		model.screenLeague = [dict objectForKey:@"league"];
		model.screenIsAll = [dict objectForKey:@"isAll"];
		[arr addObject:model];
	}
	return arr;
}

- (void)setFootBallScreenCache:(NSMutableArray<ScreenCacheModel *> *)footBallScreenCache {
	NSMutableArray *arr = [NSMutableArray array];
	for (ScreenCacheModel *model in footBallScreenCache) {
		NSMutableDictionary *dict = [NSMutableDictionary dictionary];
		[dict setObject:model.screenMatchType forKey:@"type"];
		[dict setObject:model.screenLeague forKey:@"league"];
		[dict setObject:model.screenIsAll forKey:@"isAll"];
		[arr addObject:dict];
	}
	[[NSUserDefaults standardUserDefaults] setObject:arr forKey:kFootBallScreenCache];
}

//篮球筛选相关,本地储存
- (NSMutableArray<ScreenCacheModel *> *)basketScreenCache {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kBasketScreenCache]) {
		NSMutableArray *arr = [NSMutableArray array];
		for (NSUInteger i = 0; i < 3 ; i ++) {
			ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
			model.screenMatchType = @"-1";
			model.screenLeague = @"-1";
			model.screenIsAll = @"1";
			[arr addObject:model];
		}
		return arr;
	}
	
	NSMutableArray *arr = [NSMutableArray array];
	for (NSDictionary *dict in [[NSUserDefaults standardUserDefaults] objectForKey:kBasketScreenCache]) {
		ScreenCacheModel *model = [[ScreenCacheModel alloc] init];
		model.screenMatchType = [dict objectForKey:@"type"];
		model.screenLeague = [dict objectForKey:@"league"];
		model.screenIsAll = [dict objectForKey:@"isAll"];
		[arr addObject:model];
	}
	return arr;
}

- (void)setBasketScreenCache:(NSMutableArray<ScreenCacheModel *> *)basketScreenCache {
	NSMutableArray *arr = [NSMutableArray array];
	for (ScreenCacheModel *model in basketScreenCache) {
		NSMutableDictionary *dict = [NSMutableDictionary dictionary];
		[dict setObject:model.screenMatchType forKey:@"type"];
		[dict setObject:model.screenLeague forKey:@"league"];
		[dict setObject:model.screenIsAll forKey:@"isAll"];
		[arr addObject:dict];
	}
	[[NSUserDefaults standardUserDefaults] setObject:arr forKey:kBasketScreenCache];
}

//记录上次退出是否在篮球页面
- (BOOL)lastHomePageIsBasket {
	return [[NSUserDefaults standardUserDefaults] boolForKey:kLastHomePageIsBasket];
}

- (void)setLastHomePageIsBasket:(BOOL)lastHomePageIsBasket {
	[[NSUserDefaults standardUserDefaults] setBool:lastHomePageIsBasket forKey:kLastHomePageIsBasket];
}

- (NSMutableArray<NSString *> *)uploadedPhotoCache {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kUploadedPhotoCache]) {
		NSMutableArray *arr = [NSMutableArray array];
		return arr;
	}
	return [[NSUserDefaults standardUserDefaults] objectForKey:kUploadedPhotoCache];
}

- (void)setUploadedPhotoCache:(NSMutableArray<NSString *> *)uploadedPhotoCache {
	[[NSUserDefaults standardUserDefaults] setObject:uploadedPhotoCache forKey:kUploadedPhotoCache];
}

- (NSMutableArray<NSString *> *)uploadedVideoCache {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kUploadedVideoCache]) {
		NSMutableArray *arr = [NSMutableArray array];
		return arr;
	}
	
	return [[NSUserDefaults standardUserDefaults] objectForKey:kUploadedVideoCache];
}

- (void)setUploadedVideoCache:(NSMutableArray<NSString *> *)uploadedVideoCache {
	[[NSUserDefaults standardUserDefaults] setObject:uploadedVideoCache forKey:kUploadedVideoCache];
}

- (NSString *)eventTopicName {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kEventTopicName]) {
		return @"热门";
	}
	return [[NSUserDefaults standardUserDefaults] objectForKey:kEventTopicName];
}

- (void)setEventTopicName:(NSString *)eventTopicName {
	[[NSUserDefaults standardUserDefaults] setObject:eventTopicName forKey:kEventTopicName];
}

- (NSString *)eventTopicId {
	if (![[NSUserDefaults standardUserDefaults] objectForKey:kEventTopicId]) {
		return @"6";
	}
	return [[NSUserDefaults standardUserDefaults] objectForKey:kEventTopicId];
}

- (void)setEventTopicId:(NSString *)eventTopicId {
	[[NSUserDefaults standardUserDefaults] setObject:eventTopicId forKey:kEventTopicId];
}

@end
