//
//  LPSystemManager.h
//  ArchInstance
//
//  Created by 刘 鹏 on 15/9/7.
//  Copyright (c) 2015年 LP. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SystemManager [LPSystemManager sharedInstance]

@interface ScreenCacheModel : NSObject
@property (nonatomic,assign) NSString *screenMatchType;
@property (nonatomic,strong) NSString *screenLeague;
@property (nonatomic,assign) NSString *screenIsAll;
@end

@interface LPSystemManager : NSObject

//离线文件地址
@property (nonatomic, strong) NSString *offlineFilePath;

//用户信息存储地址
@property (nonatomic, strong) NSString *userInfoFilePath;
//jcmatch
@property (nonatomic, strong) NSString *jcmatchFilePath;
//sockect 进球消息缓存
@property (nonatomic, strong) NSMutableArray *socketGoalCache;
//sockect 后台进球缓存
@property (nonatomic, strong) NSMutableArray *bgGoalCache;

//足球筛选相关,本地存储
@property (nonatomic,strong) NSMutableArray<ScreenCacheModel *> *footBallScreenCache;
//篮球筛选相关,本地储存
@property (nonatomic,strong) NSMutableArray<ScreenCacheModel *> *basketScreenCache;
//记录上次退出是否在篮球页面
@property (nonatomic,assign) BOOL lastHomePageIsBasket;


//社区发帖相关,上传图片缓存
@property (nonatomic,strong) NSMutableArray<NSString *> *uploadedPhotoCache;
//社区发帖相关,上传视频缓存
@property (nonatomic,strong) NSMutableArray<NSString *> *uploadedVideoCache;

//社区模块活动名称
@property (nonatomic, strong) NSString *eventTopicName;
//社区模块活动话题id
@property (nonatomic, strong) NSString *eventTopicId;
/**
 * 单利方法
 */
+ (id)sharedInstance;

@end
