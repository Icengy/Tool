//
//  Gallop_iOSTests.m
//  Gallop_iOSTests
//
//  Created by Homosum on 2019/4/9.
//  Copyright © 2019 homosum. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface Gallop_iOSTests : XCTestCase

@end

@implementation Gallop_iOSTests

+ (void)setUp {
    [super setUp];
}

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [super setUp];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
    
    //1、 Given 假定方法入参值（假定测试条件） OCMock OCMockito
    //2、 When 调用
    //3、 Then 断言 是否符合预期
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

+ (void)tearDown {
    [super tearDown];
}

@end
