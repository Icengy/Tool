//
//  ESNetworkServiceTest.m
//  Gallop_iOSTests
//
//  Created by lcy on 2021/10/8.
//  Copyright © 2021 homosum. All rights reserved.
//

#import <XCTest/XCTest.h>

#import "ESNetworkService.h"
#import "ServicesDefine.h"

@interface ESNetworkServiceTest : XCTestCase

@end

@implementation ESNetworkServiceTest

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testExpertRecommendList {
    
    XCTestExpectation *expectation = [self expectationWithDescription:@"获取推荐专家列表"];
    [ESNetworkService expertRecommendListWithResponse:^(id dict, NSInteger code, ESError *error) {
        XCTAssertNotNil(dict);
        [expectation fulfill];
    }];
    [self waitForExpectationsWithTimeout:20.0 handler:nil];
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
