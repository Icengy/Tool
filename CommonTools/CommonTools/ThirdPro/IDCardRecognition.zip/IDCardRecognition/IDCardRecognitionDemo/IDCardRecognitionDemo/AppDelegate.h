//
//  AppDelegate.h
//  IDCardRecognitionDemo
//
//  Created by 韩俊强 on 2017/4/19.
//  Copyright © 2017年 HaRi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

