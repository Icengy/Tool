//
//  IDAuthViewController.h
//  IDCardRecognition
//
//  Created by HanJunqiang on 2017/2/28.
//  Copyright © 2017年 HaRi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IDAuthViewController : UIViewController

@end
