//
//  ViewController.h
//  IDCardRecognitionDemo
//
//  Created by 韩俊强 on 2017/4/19.
//  Copyright © 2017年 HaRi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

